import Rule30Bridge

/-!
Cooperative bridge sharpening, 23 October 2026.
Uses the existing Rule 30 bridge and double-edged standard as the proof base.
No assertion of the remaining boundary-drive conjecture is introduced as an axiom.
-/

namespace BlackValueBridge

open Rule30Bridge Rule30Application

/-- At a black center cell the left neighbor's value is fixed by the next
center value, independent of the right neighbor. This is an all-time consequence
of the actual Rule 30 recurrence and the proved left-half identification. -/
theorem actual_black_value (t : Nat) (black : center30 t = true) :
    lh center30 t 1 = !(center30 (t + 1)) := by
  rw [lh_center30]
  change left30 t = !(center30 (t + 1))
  rw [left30_sideways, black]
  cases center30 (t + 1) <;> cases right30 t <;> rfl

/-- A sufficient remaining condition weaker than LeftHalfBreaksAtBlack:
an admissible eventually periodic drive cannot maintain the exact black-cell
value constraint at every black time in its periodic tail. The condition is
defined, not asserted. It need not force a period failure at a black cell. -/
def BlackValueObstruction : Prop :=
  ∀ (b : Nat → Bool) (N p : Nat), 0 < p → b 0 = true → PeriodicFrom b N p →
    (¬ ∃ M, ∀ t, M ≤ t → b t = false) →
    ¬ (∀ t, N ≤ t → b t = true → lh b t 1 = !(b (t + 1)))

/-- The broader conjecture from Claude's packet implies this weaker target.
Indeed, a correct black-cell value at every late black cell would make the
left response repeat there, because the drive's next values repeat. -/
theorem masked_breaks_imply_black_value_obstruction (h : LeftHalfBreaksAtBlack) :
    BlackValueObstruction := by
  intro b N p hp h0 periodic nonwhite values
  apply h b N p hp h0 periodic nonwhite
  intro t ht black
  have shiftedBlack : b (t + p) = true := by rw [periodic t ht, black]
  rw [values (t + p) (by omega) shiftedBlack, values t ht black]
  rw [show t + p + 1 = t + 1 + p by omega, periodic (t + 1) (by omega)]

/-- The weaker value-obstruction target already excludes eventual periodicity
of the actual center. This is constructive as a proof of not-EP, with the
positive witness formulation retained separately in the inherited R2 source. -/
theorem problem1_of_black_value_obstruction (h : BlackValueObstruction) :
    ¬ EventuallyPeriodic center30 := by
  rintro ⟨N,p,hp,periodic⟩
  apply h center30 N p hp rfl periodic center30_not_eventually_white
  intro t _ black
  exact actual_black_value t black

end BlackValueBridge
