import SeamClosureConditions

/-!
Certificate-or-residue bridge, R5, 23 October 2026.
A seed need not enter a free-edge shield for its actual output to settle.
The new sufficient condition admits a separately proved settling residue.
No unproved entry, independence or physics identification is assumed.
-/

namespace CertificateResidueBridge

open SeamClosure Rule30Bridge Rule30Application RightHalf UniformWindow ShieldEntry ClosureCheck

def FiniteStart (s : Nat → Bool) : Prop := ∃ K, ∀ i, K < i → s i = false

def EntersShield (w : List Bool) (s : Nat → Bool) : Prop :=
  ∃ J P t0, ∃ C : Certificate w J P, 0 < J ∧ 0 < P ∧ w.length ∣ P ∧
    C.R (t0 % P) (bandOf (rhc (pdrive w) s) J t0)

def NeverEnters (w : List Bool) (s : Nat → Bool) : Prop := ¬ EntersShield w s

def EveryFiniteStartSettles (w : List Bool) : Prop :=
  ∀ s, FiniteStart s → EventuallyPeriodic (fun t => rhc (pdrive w) s t 1)

theorem original_entry_iff (w : List Bool) :
    EveryFiniteStartEnters w ↔ ∀ s, FiniteStart s → EntersShield w s := Iff.rfl

theorem entry_implies_settling (w : List Bool) (s : Nat → Bool)
    (entry : EntersShield w s) : EventuallyPeriodic (fun t => rhc (pdrive w) s t 1) := by
  obtain ⟨J, P, t0, C, hJ, hP, hwP, hC⟩ := entry
  exact shield_periodic w J P hJ hP hwP C s t0 hC

theorem settles_of_certificate_or_residue (w : List Bool) (residue : (Nat → Bool) → Prop)
    (cover : ∀ s, FiniteStart s → EntersShield w s ∨ residue s)
    (receipt : ∀ s, FiniteStart s → residue s →
      EventuallyPeriodic (fun t => rhc (pdrive w) s t 1)) :
    EveryFiniteStartSettles w := by
  intro s finite
  obtain entry | residual := cover s finite
  · exact entry_implies_settling w s entry
  · exact receipt s finite residual

/-- This replaces the stronger all-shield-entry premise in the old bridge. -/
theorem right_settles_of_finite_settling (w : List Bool) (settles : EveryFiniteStartSettles w) :
    ∀ b : Nat → Bool, EventuallyRepeats b w → EventuallyPeriodic (fun t => rh b t 1) := by
  intro b hb
  obtain ⟨N, hN⟩ := hb
  have hdrive : (fun u => b (N + u)) = pdrive w := by
    funext u
    rw [hN (N + u) (Nat.le_add_right N u), Nat.add_sub_cancel_left]
    rfl
  have col : ∀ t, rh b (N + t) 1 = rhc (pdrive w) (fun m => rh b N m) t 1 := by
    intro t
    rw [rh_eq_rhc b (N + t) 1, rhc_restart b (fun _ => false) N t 1, hdrive]
    have hX : (fun m => rhc b (fun _ => false) N m) = (fun m => rh b N m) := by
      funext m
      exact (rh_eq_rhc b N m).symm
    rw [hX]
  obtain ⟨M, p, hp, hper⟩ :=
    settles (fun m => rh b N m) ⟨N, fun i hi => rh_outside b N i hi⟩
  refine ⟨N + M, p, hp, fun t ht => ?_⟩
  show rh b (t + p) 1 = rh b t 1
  have e1 : t + p = N + (t - N + p) := by omega
  have e2 : t = N + (t - N) := by omega
  have h3 : rhc (pdrive w) (fun m => rh b N m) (t - N + p) 1 =
      rhc (pdrive w) (fun m => rh b N m) (t - N) 1 := hper (t - N) (by omega)
  rw [e1, col (t - N + p), h3, ← col (t - N), ← e2]

theorem center_avoids_of_finite_settling (w : List Bool) (hw : 0 < w.length)
    (settles : EveryFiniteStartSettles w) : ¬ EventuallyRepeats center30 w :=
  center_avoids_pattern_of_right_settles w hw
    (fun b _ hb => right_settles_of_finite_settling w settles b hb)

theorem center_avoids_of_certificate_or_residue (w : List Bool) (hw : 0 < w.length)
    (residue : (Nat → Bool) → Prop)
    (cover : ∀ s, FiniteStart s → EntersShield w s ∨ residue s)
    (receipt : ∀ s, FiniteStart s → residue s →
      EventuallyPeriodic (fun t => rhc (pdrive w) s t 1)) :
    ¬ EventuallyRepeats center30 w :=
  center_avoids_of_finite_settling w hw
    (settles_of_certificate_or_residue w residue cover receipt)

/-- Non-entry remains a quantified statement about admitted, reachable states. -/
theorem never_enters_iff_all_checks_fail (w : List Bool) (s : Nat → Bool) :
    NeverEnters w s ↔
      ∀ J P t0, 0 < J → 0 < P → w.length ∣ P →
        ¬ ReachDet w J P (t0 % P) (bandOf (rhc (pdrive w) s) J t0) := by
  constructor
  · intro never J P t0 hJ hP hwP det
    obtain ⟨C, hC⟩ := (cert_iff_reachDet hJ hP (Nat.mod_lt _ hP)).2 det
    exact never ⟨J, P, t0, C, hJ, hP, hwP, hC⟩
  · intro checks entry
    obtain ⟨J, P, t0, C, hJ, hP, hwP, hC⟩ := entry
    exact checks J P t0 hJ hP hwP (reachDet_of_cert C hC)

/-- An abstract, explicitly conditional Pi1/nonrefutability interface.
Instantiating this with arithmetic requires an actual checker and an actual
finite-refutation completeness theorem for the chosen theory. -/
def UniformCheck (check : Nat → Bool) : Prop := ∀ n, check n = true

theorem nonrefutability_implies_uniform_check
    (check : Nat → Bool) (Provable : Prop → Prop)
    (finiteRefutation : ∀ n, check n = false → Provable (¬ UniformCheck check))
    (nonrefutable : ¬ Provable (¬ UniformCheck check)) : UniformCheck check := by
  intro n
  cases h : check n with
  | false => exact False.elim (nonrefutable (finiteRefutation n h))
  | true => rfl

end CertificateResidueBridge
