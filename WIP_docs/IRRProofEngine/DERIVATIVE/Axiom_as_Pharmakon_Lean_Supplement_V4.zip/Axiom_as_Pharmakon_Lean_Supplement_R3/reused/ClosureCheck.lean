import EntryBridge

/-!
Closure check, 23 October 2026. Claude, with Lu Semita.

`Certificate.R` is an arbitrary predicate, so "the band lies in some certificate" quantifies over an infinite
kind of object. This file replaces that quantifier by a finite check. A band state (f0, S0) lies in some
certificate of width J and period P exactly when the states reachable from it, with the bulk choosing every edge
bit freely, agree in column 1 whenever they have the same phase (`cert_iff_reachDet`). The reachable states lie
among the P * 2^J pairs (phase < P, band), so `ReachDet` is decided by computing a finite reachable set: the
closure computation used in the supplement.

`EntryBoundW w f g p` bounds every witness: entry by time f K, in a certificate of width at most g K and period
at most p K. For fixed computable f, g, p each instance is a finite computation, so a single start that fails the
check refutes it, and a false instance can always be found by search. `EntryBound w f` alone (width and period
unbounded) does not have that property: "in no certificate of any width" is not a finite check.

A certificate widens by one free column (`certWiden`), so entry at some width J ≤ g K is the same as entry at
width exactly g K (`boundW_iff_exact`): each start needs one closure check per period and time.
-/

namespace ClosureCheck

open Rule30Bridge Rule30Application RightHalf UniformWindow ShieldEntry EntryBridge

variable {w : List Bool} {J P f0 : Nat} {S0 : Fin J → Bool}

/-- States reachable from (f0, S0) by band steps, with each edge bit chosen freely. -/
inductive Reach (w : List Bool) (J P f0 : Nat) (S0 : Fin J → Bool) : Nat → (Fin J → Bool) → Prop
  | base : Reach w J P f0 S0 f0 S0
  | step {f : Nat} {S : Fin J → Bool} (e : Bool) :
      Reach w J P f0 S0 f S →
      Reach w J P f0 S0 ((f + 1) % P) (bandStep J S (w.getD (f % w.length) false) e)

/-- The finite check: any two reachable states with the same phase agree in column 1. -/
def ReachDet (w : List Bool) (J P f0 : Nat) (S0 : Fin J → Bool) : Prop :=
  ∀ (hJ : 0 < J) (f : Nat) (S S' : Fin J → Bool),
    Reach w J P f0 S0 f S → Reach w J P f0 S0 f S' → S ⟨0, hJ⟩ = S' ⟨0, hJ⟩

/-- Everything reachable from a certificate state stays in the certificate. -/
theorem reach_sub (C : Certificate w J P) (h0 : C.R f0 S0) :
    ∀ f S, Reach w J P f0 S0 f S → C.R f S := by
  intro f S h
  induction h with
  | base => exact h0
  | step e _ ih => exact C.closed _ _ ih e

theorem reachDet_of_cert (C : Certificate w J P) (h0 : C.R f0 S0) : ReachDet w J P f0 S0 := by
  intro hJ f S S' h1 h2
  rw [C.det f S hJ (reach_sub C h0 f S h1), C.det f S' hJ (reach_sub C h0 f S' h2)]

/-- Reachable phases stay below P. -/
theorem reach_phase_lt (hP : 0 < P) (hf0 : f0 < P) :
    ∀ f S, Reach w J P f0 S0 f S → f < P := by
  intro f S h
  induction h with
  | base => exact hf0
  | step _ _ _ => exact Nat.mod_lt _ hP

/-- The path on which the bulk always sends 0. -/
def canon (w : List Bool) (J P f0 : Nat) (S0 : Fin J → Bool) : Nat → (Fin J → Bool)
  | 0 => S0
  | k + 1 => bandStep J (canon w J P f0 S0 k) (w.getD (((f0 + k) % P) % w.length) false) false

theorem reach_canon (hf0 : f0 < P) :
    ∀ k, Reach w J P f0 S0 ((f0 + k) % P) (canon w J P f0 S0 k) := by
  intro k
  induction k with
  | zero =>
    rw [Nat.add_zero, Nat.mod_eq_of_lt hf0]
    exact Reach.base
  | succ k ih =>
    have h := Reach.step (e := false) ih
    rw [Nat.mod_add_mod] at h
    exact h

/-- The canonical path visits every phase below P. -/
theorem canon_phase (hf0 : f0 < P) (f : Nat) (hf : f < P) : (f0 + (f + P - f0) % P) % P = f := by
  rw [Nat.add_mod_mod, show f0 + (f + P - f0) = f + P by omega, Nat.add_mod_right, Nat.mod_eq_of_lt hf]

/-- A state that passes the check lies in a certificate: the reachable set itself, with column 1 read off the
canonical path. -/
def certOfReach (hJ : 0 < J) (hP : 0 < P) (hf0 : f0 < P) (hdet : ReachDet w J P f0 S0) :
    Certificate w J P where
  R := Reach w J P f0 S0
  closed := fun _ _ h e => Reach.step e h
  value := fun f => canon w J P f0 S0 ((f + P - f0) % P) ⟨0, hJ⟩
  det := by
    intro f S hJ' h
    have hf : f < P := reach_phase_lt hP hf0 f S h
    have hc := reach_canon (w := w) (S0 := S0) (J := J) hf0 ((f + P - f0) % P)
    rw [canon_phase hf0 f hf] at hc
    exact hdet hJ' f S _ h hc

/-- Membership in some certificate is the finite check. -/
theorem cert_iff_reachDet (hJ : 0 < J) (hP : 0 < P) (hf0 : f0 < P) :
    (∃ C : Certificate w J P, C.R f0 S0) ↔ ReachDet w J P f0 S0 :=
  ⟨fun ⟨C, h0⟩ => reachDet_of_cert C h0, fun h => ⟨certOfReach hJ hP hf0 h, Reach.base⟩⟩

/-- The first J columns of a band one column wider. -/
def restrictBand {J : Nat} (S : Fin (J + 1) → Bool) : Fin J → Bool := fun i => S ⟨i.val, by omega⟩

/-- Forgetting the last column commutes with the band step; the forgotten column becomes the edge bit. -/
theorem bandStep_restrict (J : Nat) (S : Fin (J + 1) → Bool) (d e : Bool) :
    restrictBand (bandStep (J + 1) S d e) = bandStep J (restrictBand S) d (S ⟨J, by omega⟩) := by
  funext i
  obtain ⟨k, hk⟩ := i
  simp only [restrictBand, bandStep]
  have h1 : k + 1 < J + 1 := by omega
  rw [dif_pos h1]
  by_cases h2 : k + 1 < J
  · rw [dif_pos h2]
  · rw [dif_neg h2]
    have h3 : k + 1 = J := by omega
    subst h3
    rfl

theorem restrictBand_bandOf (x : Nat → Nat → Bool) (J t : Nat) :
    restrictBand (bandOf x (J + 1) t) = bandOf x J t := by
  funext i
  rfl

/-- A certificate widens by one column: the new column is left free. -/
def certWiden (hJ : 0 < J) (C : Certificate w J P) : Certificate w (J + 1) P where
  R := fun f S => C.R f (restrictBand S)
  closed := by
    intro f S h e
    show C.R ((f + 1) % P) (restrictBand (bandStep (J + 1) S (w.getD (f % w.length) false) e))
    rw [bandStep_restrict]
    exact C.closed f _ h _
  value := C.value
  det := by
    intro f S _ h
    exact C.det f (restrictBand S) hJ h

/-- Entry at width J gives entry at every larger width, at the same time and phase. -/
theorem entry_widen (x : Nat → Nat → Bool) (f t : Nat) (hJ : 0 < J) :
    ∀ n, (∃ C : Certificate w J P, C.R f (bandOf x J t)) →
      ∃ C : Certificate w (J + n) P, C.R f (bandOf x (J + n) t) := by
  intro n
  induction n with
  | zero => exact id
  | succ n ih =>
    intro h
    obtain ⟨C, hC⟩ := ih h
    refine ⟨certWiden (Nat.lt_of_lt_of_le hJ (Nat.le_add_right J n)) C, ?_⟩
    show C.R f (restrictBand (bandOf x (J + n + 1) t))
    rw [restrictBand_bandOf]
    exact hC

/-- The bridge with every witness bounded. -/
def EntryBoundW (w : List Bool) (f g p : Nat → Nat) : Prop :=
  ∀ K (x0 : Nat → Bool), (∀ i, K < i → x0 i = false) →
    ∃ J P t0, 0 < J ∧ J ≤ g K ∧ 0 < P ∧ P ≤ p K ∧ w.length ∣ P ∧ t0 ≤ f K ∧
      ReachDet w J P (t0 % P) (bandOf (rhc (pdrive w) x0) J t0)

/-- The bounded form says the same as `EntryBound` with the certificate's width and period bounded. -/
theorem boundW_iff_cert (w : List Bool) (f g p : Nat → Nat) :
    EntryBoundW w f g p ↔
      ∀ K (x0 : Nat → Bool), (∀ i, K < i → x0 i = false) →
        ∃ J P t0, ∃ C : Certificate w J P, 0 < J ∧ J ≤ g K ∧ 0 < P ∧ P ≤ p K ∧ w.length ∣ P ∧
          t0 ≤ f K ∧ C.R (t0 % P) (bandOf (rhc (pdrive w) x0) J t0) := by
  constructor
  · intro h K x0 hK
    obtain ⟨J, P, t0, hJ, hg, hP, hp, hwP, ht, hR⟩ := h K x0 hK
    exact ⟨J, P, t0, certOfReach hJ hP (Nat.mod_lt _ hP) hR, hJ, hg, hP, hp, hwP, ht, Reach.base⟩
  · intro h K x0 hK
    obtain ⟨J, P, t0, C, hJ, hg, hP, hp, hwP, ht, hR⟩ := h K x0 hK
    exact ⟨J, P, t0, hJ, hg, hP, hp, hwP, ht, reachDet_of_cert C hR⟩

theorem bound_of_boundW (w : List Bool) (f g p : Nat → Nat) (h : EntryBoundW w f g p) :
    EntryBound w f := by
  intro K x0 hK
  obtain ⟨J, P, t0, C, hJ, _, hP, _, hwP, ht, hR⟩ := (boundW_iff_cert w f g p).1 h K x0 hK
  exact ⟨J, P, t0, C, hJ, hP, hwP, ht, hR⟩

/-- The width can be taken to be exactly g K: one closure check per period and time. -/
theorem boundW_iff_exact (w : List Bool) (f g p : Nat → Nat) :
    EntryBoundW w f g p ↔
      ∀ K (x0 : Nat → Bool), (∀ i, K < i → x0 i = false) →
        ∃ P t0, 0 < g K ∧ 0 < P ∧ P ≤ p K ∧ w.length ∣ P ∧ t0 ≤ f K ∧
          ReachDet w (g K) P (t0 % P) (bandOf (rhc (pdrive w) x0) (g K) t0) := by
  constructor
  · intro h K x0 hK
    obtain ⟨J, P, t0, hJ, hg, hP, hp, hwP, ht, hR⟩ := h K x0 hK
    have hC : ∃ C : Certificate w J P, C.R (t0 % P) (bandOf (rhc (pdrive w) x0) J t0) :=
      ⟨certOfReach hJ hP (Nat.mod_lt _ hP) hR, Reach.base⟩
    obtain ⟨C', hC'⟩ := entry_widen (rhc (pdrive w) x0) (t0 % P) t0 hJ (g K - J) hC
    have hR' := reachDet_of_cert C' hC'
    rw [show J + (g K - J) = g K by omega] at hR'
    exact ⟨P, t0, by omega, hP, hp, hwP, ht, hR'⟩
  · intro h K x0 hK
    obtain ⟨P, t0, hg, hP, hp, hwP, ht, hR⟩ := h K x0 hK
    exact ⟨g K, P, t0, hg, Nat.le_refl _, hP, hp, hwP, ht, hR⟩

/-- The bounded bridge, end to end. -/
theorem center_avoids_of_boundW (w : List Bool) (hw : 0 < w.length) (f g p : Nat → Nat)
    (h : EntryBoundW w f g p) : ¬ EventuallyRepeats center30 w :=
  center_avoids_of_bound w hw f (bound_of_boundW w f g p h)

end ClosureCheck
