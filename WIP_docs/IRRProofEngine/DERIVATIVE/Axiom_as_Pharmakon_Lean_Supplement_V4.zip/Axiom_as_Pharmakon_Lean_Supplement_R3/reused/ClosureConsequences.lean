import UniversalRecoveryClosure

/-!
Consequences of universal recovery closure, R8, 24 October 2026.
The null case is proved from a seam and global soundness, rather than inferred
from elapsed search. Every declaration below has an explicit axiom audit.
-/

namespace ClosureConsequences

open UniversalRecoveryClosure

universe u v w r s
variable {X : Type u} {Y : Type v} {Z : Type w}

def Recovers (observe : X → Y) (target : X → Z) : Prop :=
  ∃ decode : Y → Z, ∀ x, decode (observe x) = target x

theorem two_cases_exclude_every_decoder
    (observe : X → Y) (target : X → Z) (a b : X)
    (same : observe a = observe b) (different : target a ≠ target b)
    (decode : Y → Z) :
    ¬ (decode (observe a) = target a ∧ decode (observe b) = target b) := by
  intro both
  apply different
  exact both.1.symm.trans ((congrArg decode same).trans both.2)

theorem universal_class_is_closed
    (observe : X → Y) (target : X → Z) (a b : X)
    (same : observe a = observe b) (different : target a ≠ target b) :
    ¬ Recovers observe target :=
  no_decoder_recovers_erased_distinction observe target a b same different

def adaptiveTrace {State : Type r} (initial : Y → State) (advance : Y → State → State)
    (reading : Y) : Nat → State
  | 0 => initial reading
  | n + 1 => advance reading (adaptiveTrace initial advance reading n)

theorem no_adaptive_transcript_decoder
    (observe : X → Y) (target : X → Z) (a b : X)
    (same : observe a = observe b) (different : target a ≠ target b)
    {State : Type r} (initial : Y → State) (advance : Y → State → State)
    (decode : (Nat → State) → Z) :
    ¬ (∀ x, decode (adaptiveTrace initial advance (observe x)) = target x) :=
  no_processing_recovers_erased_distinction observe target a b same different
    (adaptiveTrace initial advance) decode

def SoundAttempt (observe : X → Y) (target : X → Z)
    (attempt : Y → Nat → Option Z) : Prop :=
  ∀ x n value, attempt (observe x) n = some value → value = target x

def CertifiedAbstention (attempt : Y → Nat → Option Z) (reading : Y) : Prop :=
  ∀ n, attempt reading n = none

theorem forced_abstention_at_seam
    (observe : X → Y) (target : X → Z) (a b : X)
    (same : observe a = observe b) (different : target a ≠ target b)
    (attempt : Y → Nat → Option Z) (sound : SoundAttempt observe target attempt) :
    CertifiedAbstention attempt (observe a) := by
  intro n
  cases output : attempt (observe a) n with
  | none => rfl
  | some value =>
    have atA : value = target a := sound a n value output
    have otherOutput : attempt (observe b) n = some value := by rw [← same]; exact output
    have atB : value = target b := sound b n value otherOutput
    exact False.elim (different (atA.symm.trans atB))

theorem both_witnesses_have_certified_abstention
    (observe : X → Y) (target : X → Z) (a b : X)
    (same : observe a = observe b) (different : target a ≠ target b)
    (attempt : Y → Nat → Option Z) (sound : SoundAttempt observe target attempt) :
    CertifiedAbstention attempt (observe a) ∧ CertifiedAbstention attempt (observe b) :=
  ⟨forced_abstention_at_seam observe target a b same different attempt sound,
   forced_abstention_at_seam observe target b a same.symm different.symm attempt sound⟩

theorem no_sound_attempt_is_total
    (observe : X → Y) (target : X → Z) (a b : X)
    (same : observe a = observe b) (different : target a ≠ target b)
    (attempt : Y → Nat → Option Z) (sound : SoundAttempt observe target attempt) :
    ¬ (∀ x, ∃ n value, attempt (observe x) n = some value) := by
  intro total
  obtain ⟨n, value, output⟩ := total a
  have abstains := forced_abstention_at_seam observe target a b same different attempt sound n
  rw [abstains] at output
  cases output

theorem adequate_coordinate_must_distinguish
    (observe : X → Y) (target : X → Z) (a b : X)
    (same : observe a = observe b) (different : target a ≠ target b)
    {Coordinate : Type r} (coordinate : X → Coordinate)
    (adequate : Recovers (fun x => (observe x, coordinate x)) target) :
    coordinate a ≠ coordinate b := by
  intro sameCoordinate
  obtain ⟨decode, correct⟩ := adequate
  exact two_cases_exclude_every_decoder (fun x => (observe x, coordinate x)) target a b
    (Prod.ext same sameCoordinate) different decode ⟨correct a, correct b⟩

theorem essential_coordinate_is_not_recoverable
    (observe : X → Y) (target : X → Z) (a b : X)
    (same : observe a = observe b) (different : target a ≠ target b)
    {Coordinate : Type r} (coordinate : X → Coordinate)
    (adequate : Recovers (fun x => (observe x, coordinate x)) target) :
    ¬ Recovers observe coordinate :=
  universal_class_is_closed observe coordinate a b same
    (adequate_coordinate_must_distinguish observe target a b same different coordinate adequate)

theorem recovery_requires_target_constancy
    (observe : X → Y) (target : X → Z) (adequate : Recovers observe target) :
    ∀ a b, observe a = observe b → target a = target b := by
  obtain ⟨decode, correct⟩ := adequate
  intro a b same
  exact (correct a).symm.trans ((congrArg decode same).trans (correct b))

theorem constant_target_is_recovered (observe : X → Y) (value : Z) :
    Recovers observe (fun _ => value) := ⟨fun _ => value, fun _ => rfl⟩

theorem identity_readout_recovers (target : X → Z) :
    Recovers (fun x : X => x) target := ⟨target, fun _ => rfl⟩

theorem target_retention_recovers (observe : X → Y) (target : X → Z) :
    Recovers (fun x => (observe x, target x)) target := ⟨Prod.snd, fun _ => rfl⟩

def bitReadout (_ : Bool) : Unit := ()
def bitTarget (x : Bool) : Bool := x
def nullAttempt (_ : Unit) (_ : Nat) : Option Bool := none

theorem bit_seam_excludes_every_decoder : ¬ Recovers bitReadout bitTarget :=
  universal_class_is_closed bitReadout bitTarget false true rfl (by decide)

theorem null_attempt_is_sound : SoundAttempt bitReadout bitTarget nullAttempt := by
  intro _ _ _ impossible
  cases impossible

theorem bit_null_has_a_certificate : CertifiedAbstention nullAttempt () :=
  forced_abstention_at_seam bitReadout bitTarget false true rfl (by decide)
    nullAttempt null_attempt_is_sound

theorem bit_distinction_restores_recovery :
    Recovers (fun x => (bitReadout x, x)) bitTarget := ⟨Prod.snd, fun _ => rfl⟩

end ClosureConsequences
