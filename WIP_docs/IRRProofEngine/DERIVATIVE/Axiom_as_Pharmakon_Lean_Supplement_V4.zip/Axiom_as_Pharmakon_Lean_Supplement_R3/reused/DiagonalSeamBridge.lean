import Rule30WhiteBoundary

/-!
Diagonal / recovery bridge, R6, 23 October 2026.

The diagonal core is the set/function form of Lawvere's fixed-point argument.
The coding interface constructs a semantic Godel sentence from explicit
quotation, substitution and representation receipts. Local soundness and
consistency then turn that sentence and falsum into the SAME SeamCertificate
type already used for the actual Rule 30 half-line.

This is a checked bridge schema, not an arithmetization of a named theory or
an independence proof for the open Rule 30 entry predicate.
-/

namespace DiagonalSeamBridge

open SeamClosure SeamIntegration

universe u v w r
variable {A : Type u} {B : Type v} {Y : Type w}

def FixedPointFree (flip : B → B) : Prop := ∀ b, flip b ≠ b

def diagonal (evaluate : A → A → B) (flip : B → B) (a : A) : B :=
  flip (evaluate a a)

theorem diagonal_differs_at_own_code (evaluate : A → A → B) (flip : B → B)
    (free : FixedPointFree flip) (code : A) :
    diagonal evaluate flip code ≠ evaluate code code := free _

theorem diagonal_is_not_a_represented_row (evaluate : A → A → B) (flip : B → B)
    (free : FixedPointFree flip) :
    ¬ (∃ code, ∀ a, evaluate code a = diagonal evaluate flip a) := by
  intro represented
  obtain ⟨code, correct⟩ := represented
  exact free (evaluate code code) (correct code).symm

/-- A decoder class is represented by rows; executable enumeration is not assumed. -/
def RepresentsAfter (observe : A → Y) (evaluate : A → A → B) : Prop :=
  ∀ decode : Y → B, ∃ code, ∀ a, evaluate code a = decode (observe a)

theorem represented_decoders_cannot_recover_diagonal
    (observe : A → Y) (evaluate : A → A → B) (flip : B → B)
    (represented : RepresentsAfter observe evaluate) (free : FixedPointFree flip) :
    ¬ Recovers observe (diagonal evaluate flip) := by
  intro recovery
  obtain ⟨decode, correct⟩ := recovery
  obtain ⟨code, row⟩ := represented decode
  exact free (evaluate code code) ((correct code).symm.trans (row code).symm)

theorem point_surjection_forces_fixed_point (evaluate : A → A → B)
    (covers : ∀ target : A → B, ∃ code, ∀ a, evaluate code a = target a)
    (flip : B → B) : ∃ b, flip b = b := by
  obtain ⟨code, correct⟩ := covers (diagonal evaluate flip)
  exact ⟨evaluate code code, (correct code).symm⟩

theorem bool_negation_is_fixed_point_free : FixedPointFree Bool.not := by
  intro b
  cases b <;> decide

theorem no_universal_boolean_evaluator (evaluate : A → A → Bool) :
    ¬ (∀ target : A → Bool, ∃ code, ∀ a, evaluate code a = target a) := by
  intro covers
  obtain ⟨b, fixed⟩ := point_surjection_forces_fixed_point evaluate covers Bool.not
  exact bool_negation_is_fixed_point_free b fixed

theorem no_universal_truth_evaluator (evaluate : A → A → Prop) :
    ¬ (∀ target : A → Prop, ∃ code, ∀ a, evaluate code a ↔ target a) := by
  intro covers
  obtain ⟨code, correct⟩ := covers (fun a => ¬ evaluate a a)
  have negative : ¬ evaluate code code := fun positive => (correct code).1 positive positive
  exact negative ((correct code).2 negative)

/-- An explicit nonvacuous finite instance: all decoders of a constant readout. -/
theorem constant_boolean_rows_represent_unit_decoders :
    RepresentsAfter (fun _ : Bool => ()) (fun code _ : Bool => code) := by
  intro decode
  exact ⟨decode (), fun _ => rfl⟩

theorem finite_diagonal_instance :
    ¬ Recovers (fun _ : Bool => ()) (fun b : Bool => !b) :=
  represented_decoders_cannot_recover_diagonal _ _ _
    constant_boolean_rows_represent_unit_decoders bool_negation_is_fixed_point_free

/-! A quotation/substitution interface, with every semantic receipt explicit. -/

structure DiagonalInterpretation (Sentence : Type u) (Code : Type v) (Unary : Type w) where
  holds : Sentence → Prop
  provable : Sentence → Prop
  quoteSentence : Sentence → Code
  quoteUnary : Unary → Code
  instantiate : Unary → Code → Sentence
  meaning : Unary → Code → Prop
  diagonalCode : Code → Code
  codeProvable : Code → Prop
  instantiationCorrect : ∀ formula code,
    holds (instantiate formula code) ↔ meaning formula code
  diagonalCodeCorrect : ∀ formula,
    diagonalCode (quoteUnary formula) =
      quoteSentence (instantiate formula (quoteUnary formula))
  quotationCorrect : ∀ sentence,
    codeProvable (quoteSentence sentence) ↔ provable sentence
  antiProofFormula : Unary
  antiProofCorrect : ∀ code,
    meaning antiProofFormula code ↔ ¬ codeProvable (diagonalCode code)

def constructedGodelSentence {Sentence : Type u} {Code : Type v} {Unary : Type w}
    (frame : DiagonalInterpretation Sentence Code Unary) : Sentence :=
  frame.instantiate frame.antiProofFormula (frame.quoteUnary frame.antiProofFormula)

/-- The self-referential semantic equivalence is constructed, not a conclusion assumed. -/
theorem constructed_sentence_has_diagonal_meaning
    {Sentence : Type u} {Code : Type v} {Unary : Type w}
    (frame : DiagonalInterpretation Sentence Code Unary) :
    frame.holds (constructedGodelSentence frame) ↔
      ¬ frame.provable (constructedGodelSentence frame) := by
  unfold constructedGodelSentence
  rw [frame.instantiationCorrect, frame.antiProofCorrect,
      frame.diagonalCodeCorrect, frame.quotationCorrect]

variable {Sentence : Type u}

theorem semantic_diagonal_is_unprovable (provable holds : Sentence → Prop)
    (sentence : Sentence) (diagonalMeaning : holds sentence ↔ ¬ provable sentence)
    (soundAtSentence : provable sentence → holds sentence) : ¬ provable sentence :=
  fun proof => (diagonalMeaning.1 (soundAtSentence proof)) proof

theorem semantic_diagonal_is_true (provable holds : Sentence → Prop)
    (sentence : Sentence) (diagonalMeaning : holds sentence ↔ ¬ provable sentence)
    (soundAtSentence : provable sentence → holds sentence) : holds sentence :=
  diagonalMeaning.2
    (semantic_diagonal_is_unprovable provable holds sentence diagonalMeaning soundAtSentence)

theorem soundness_excludes_proof_of_falsum (provable holds : Sentence → Prop)
    (falsum : Sentence) (falseFalsum : ¬ holds falsum)
    (soundAtFalsum : provable falsum → holds falsum) : ¬ provable falsum :=
  fun proof => falseFalsum (soundAtFalsum proof)

/-- Same provability status, different semantic status: the existing seam object. -/
def godelProvabilitySeam (provable holds : Sentence → Prop)
    (sentence falsum : Sentence)
    (diagonalMeaning : holds sentence ↔ ¬ provable sentence)
    (soundAtSentence : provable sentence → holds sentence)
    (consistent : ¬ provable falsum) (falseFalsum : ¬ holds falsum) :
    SeamCertificate provable holds where
  left := sentence
  right := falsum
  sameReading := propext ⟨fun proof => False.elim
    (semantic_diagonal_is_unprovable provable holds sentence diagonalMeaning soundAtSentence proof),
    fun proof => False.elim (consistent proof)⟩
  distinctTargets := by
    intro same
    exact falseFalsum (same.mp
      (semantic_diagonal_is_true provable holds sentence diagonalMeaning soundAtSentence))

theorem godel_truth_cannot_be_recovered_from_provability
    (provable holds : Sentence → Prop) (sentence falsum : Sentence)
    (diagonalMeaning : holds sentence ↔ ¬ provable sentence)
    (soundAtSentence : provable sentence → holds sentence)
    (consistent : ¬ provable falsum) (falseFalsum : ¬ holds falsum) :
    ¬ Recovers provable holds :=
  seam_certificate_closes_decoder_class _ _
    (godelProvabilitySeam provable holds sentence falsum diagonalMeaning
      soundAtSentence consistent falseFalsum)

theorem status_relabelling_cannot_recover_truth
    (provable holds : Sentence → Prop) (sentence falsum : Sentence)
    (diagonalMeaning : holds sentence ↔ ¬ provable sentence)
    (soundAtSentence : provable sentence → holds sentence)
    (consistent : ¬ provable falsum) (falseFalsum : ¬ holds falsum)
    {Reading : Type v} (post : Prop → Reading) :
    ¬ Recovers (fun s => post (provable s)) holds :=
  seam_certificate_survives_any_relabelling _ _ post
    (godelProvabilitySeam provable holds sentence falsum diagonalMeaning
      soundAtSentence consistent falseFalsum)

theorem adequate_godel_refinement_must_split
    (provable holds : Sentence → Prop) (sentence falsum : Sentence)
    (diagonalMeaning : holds sentence ↔ ¬ provable sentence)
    (soundAtSentence : provable sentence → holds sentence)
    (consistent : ¬ provable falsum) (falseFalsum : ¬ holds falsum)
    {Coordinate : Type v} (coordinate : Sentence → Coordinate)
    (adequate : Recovers (fun s => (provable s, coordinate s)) holds) :
    coordinate sentence ≠ coordinate falsum :=
  added_coordinate_must_split _ _
    (godelProvabilitySeam provable holds sentence falsum diagonalMeaning
      soundAtSentence consistent falseFalsum) coordinate adequate

theorem essential_godel_coordinate_is_not_recoverable_from_status
    (provable holds : Sentence → Prop) (sentence falsum : Sentence)
    (diagonalMeaning : holds sentence ↔ ¬ provable sentence)
    (soundAtSentence : provable sentence → holds sentence)
    (consistent : ¬ provable falsum) (falseFalsum : ¬ holds falsum)
    {Coordinate : Type v} (coordinate : Sentence → Coordinate)
    (adequate : Recovers (fun s => (provable s, coordinate s)) holds) :
    ¬ Recovers provable coordinate :=
  old_readout_cannot_supply_essential_coordinate _ _
    (godelProvabilitySeam provable holds sentence falsum diagonalMeaning
      soundAtSentence consistent falseFalsum) coordinate adequate

theorem unprovability_does_not_imply_falsity
    (provable holds : Sentence → Prop) (sentence : Sentence)
    (diagonalMeaning : holds sentence ↔ ¬ provable sentence)
    (soundAtSentence : provable sentence → holds sentence) :
    ¬ (∀ s, ¬ provable s → ¬ holds s) := by
  intro negativeCompleteness
  exact negativeCompleteness sentence
    (semantic_diagonal_is_unprovable provable holds sentence diagonalMeaning soundAtSentence)
    (semantic_diagonal_is_true provable holds sentence diagonalMeaning soundAtSentence)

theorem truth_retention_does_not_change_old_unprovability
    (provable holds : Sentence → Prop) (sentence : Sentence)
    (diagonalMeaning : holds sentence ↔ ¬ provable sentence)
    (soundAtSentence : provable sentence → holds sentence) :
    Recovers (fun s => (provable s, holds s)) holds ∧ ¬ provable sentence :=
  ⟨retaining_target_gives_recovery provable holds,
    semantic_diagonal_is_unprovable provable holds sentence diagonalMeaning soundAtSentence⟩

/-- The complete checked bridge from the coding receipts to the existing seam. -/
def seamFromDiagonalInterpretation
    {Code : Type v} {Unary : Type w}
    (frame : DiagonalInterpretation Sentence Code Unary) (falsum : Sentence)
    (soundAtSentence : frame.provable (constructedGodelSentence frame) →
      frame.holds (constructedGodelSentence frame))
    (consistent : ¬ frame.provable falsum) (falseFalsum : ¬ frame.holds falsum) :
    SeamCertificate frame.provable frame.holds :=
  godelProvabilitySeam _ _ _ falsum (constructed_sentence_has_diagonal_meaning frame)
    soundAtSentence consistent falseFalsum

theorem quotation_to_recovery_obstruction
    {Code : Type v} {Unary : Type w}
    (frame : DiagonalInterpretation Sentence Code Unary) (falsum : Sentence)
    (soundAtSentence : frame.provable (constructedGodelSentence frame) →
      frame.holds (constructedGodelSentence frame))
    (consistent : ¬ frame.provable falsum) (falseFalsum : ¬ frame.holds falsum) :
    ¬ Recovers frame.provable frame.holds :=
  seam_certificate_closes_decoder_class _ _
    (seamFromDiagonalInterpretation frame falsum soundAtSentence consistent falseFalsum)

/-! Retain BOTH positive and negative proof status, not only one proof bit. -/

def signedProofStatus (provable : Sentence → Prop) (negate : Sentence → Sentence)
    (sentence : Sentence) : Prop × Prop :=
  (provable sentence, provable (negate sentence))

theorem semantic_diagonal_negation_is_unprovable
    (provable holds : Sentence → Prop) (negate : Sentence → Sentence)
    (sentence : Sentence) (diagonalMeaning : holds sentence ↔ ¬ provable sentence)
    (soundAtSentence : provable sentence → holds sentence)
    (negativeMeaning : holds (negate sentence) ↔ ¬ holds sentence)
    (soundAtNegation : provable (negate sentence) → holds (negate sentence)) :
    ¬ provable (negate sentence) := by
  intro proof
  exact negativeMeaning.1 (soundAtNegation proof)
    (semantic_diagonal_is_true provable holds sentence diagonalMeaning soundAtSentence)

def godelSignedProofSeam
    (provable holds : Sentence → Prop) (negate : Sentence → Sentence)
    (sentence : Sentence) (diagonalMeaning : holds sentence ↔ ¬ provable sentence)
    (soundAtSentence : provable sentence → holds sentence)
    (negativeMeaning : holds (negate sentence) ↔ ¬ holds sentence)
    (soundAtNegation : provable (negate sentence) → holds (negate sentence))
    (doubleNegationElimination : provable (negate (negate sentence)) → provable sentence) :
    SeamCertificate (signedProofStatus provable negate) holds where
  left := sentence
  right := negate sentence
  sameReading := by
    have noPositive := semantic_diagonal_is_unprovable provable holds sentence
      diagonalMeaning soundAtSentence
    have noNegative := semantic_diagonal_negation_is_unprovable provable holds negate
      sentence diagonalMeaning soundAtSentence negativeMeaning soundAtNegation
    have noDouble : ¬ provable (negate (negate sentence)) :=
      fun proof => noPositive (doubleNegationElimination proof)
    apply Prod.ext
    · exact propext ⟨fun proof => False.elim (noPositive proof),
        fun proof => False.elim (noNegative proof)⟩
    · exact propext ⟨fun proof => False.elim (noNegative proof),
        fun proof => False.elim (noDouble proof)⟩
  distinctTargets := by
    have positive := semantic_diagonal_is_true provable holds sentence
      diagonalMeaning soundAtSentence
    intro same
    exact negativeMeaning.1 (same.mp positive) positive

theorem signed_proof_status_cannot_recover_truth
    (provable holds : Sentence → Prop) (negate : Sentence → Sentence)
    (sentence : Sentence) (diagonalMeaning : holds sentence ↔ ¬ provable sentence)
    (soundAtSentence : provable sentence → holds sentence)
    (negativeMeaning : holds (negate sentence) ↔ ¬ holds sentence)
    (soundAtNegation : provable (negate sentence) → holds (negate sentence))
    (doubleNegationElimination : provable (negate (negate sentence)) → provable sentence) :
    ¬ Recovers (signedProofStatus provable negate) holds :=
  seam_certificate_closes_decoder_class _ _
    (godelSignedProofSeam provable holds negate sentence diagonalMeaning soundAtSentence
      negativeMeaning soundAtNegation doubleNegationElimination)

theorem adequate_signed_refinement_must_split
    (provable holds : Sentence → Prop) (negate : Sentence → Sentence)
    (sentence : Sentence) (diagonalMeaning : holds sentence ↔ ¬ provable sentence)
    (soundAtSentence : provable sentence → holds sentence)
    (negativeMeaning : holds (negate sentence) ↔ ¬ holds sentence)
    (soundAtNegation : provable (negate sentence) → holds (negate sentence))
    (doubleNegationElimination : provable (negate (negate sentence)) → provable sentence)
    {Coordinate : Type v} (coordinate : Sentence → Coordinate)
    (adequate : Recovers (fun s => (signedProofStatus provable negate s, coordinate s)) holds) :
    coordinate sentence ≠ coordinate (negate sentence) :=
  added_coordinate_must_split _ _
    (godelSignedProofSeam provable holds negate sentence diagonalMeaning soundAtSentence
      negativeMeaning soundAtNegation doubleNegationElimination) coordinate adequate

def signedSeamFromDiagonalInterpretation
    {Code : Type v} {Unary : Type w}
    (frame : DiagonalInterpretation Sentence Code Unary) (negate : Sentence → Sentence)
    (soundAtSentence : frame.provable (constructedGodelSentence frame) →
      frame.holds (constructedGodelSentence frame))
    (negativeMeaning : frame.holds (negate (constructedGodelSentence frame)) ↔
      ¬ frame.holds (constructedGodelSentence frame))
    (soundAtNegation : frame.provable (negate (constructedGodelSentence frame)) →
      frame.holds (negate (constructedGodelSentence frame)))
    (doubleNegationElimination :
      frame.provable (negate (negate (constructedGodelSentence frame))) →
      frame.provable (constructedGodelSentence frame)) :
    SeamCertificate (signedProofStatus frame.provable negate) frame.holds :=
  godelSignedProofSeam _ _ negate _ (constructed_sentence_has_diagonal_meaning frame)
    soundAtSentence negativeMeaning soundAtNegation doubleNegationElimination

theorem quotation_to_signed_recovery_obstruction
    {Code : Type v} {Unary : Type w}
    (frame : DiagonalInterpretation Sentence Code Unary) (negate : Sentence → Sentence)
    (soundAtSentence : frame.provable (constructedGodelSentence frame) →
      frame.holds (constructedGodelSentence frame))
    (negativeMeaning : frame.holds (negate (constructedGodelSentence frame)) ↔
      ¬ frame.holds (constructedGodelSentence frame))
    (soundAtNegation : frame.provable (negate (constructedGodelSentence frame)) →
      frame.holds (negate (constructedGodelSentence frame)))
    (doubleNegationElimination :
      frame.provable (negate (negate (constructedGodelSentence frame))) →
      frame.provable (constructedGodelSentence frame)) :
    ¬ Recovers (signedProofStatus frame.provable negate) frame.holds :=
  seam_certificate_closes_decoder_class _ _
    (signedSeamFromDiagonalInterpretation frame negate soundAtSentence negativeMeaning
      soundAtNegation doubleNegationElimination)

end DiagonalSeamBridge
