import BlackValueBridge

/-!
Driven left half, 23 October 2026. Claude, with Lu Semita, on the reviewed bridge (Review R2).

The left half-line driven at its right boundary by a signal b (`lh b`, from Rule30Bridge) has its own
light cone, left edge and left-permutivity, so Jen's adjacent-column argument runs inside it. This file
proves that, and from it:
* for every admissible drive (black at time 0), the drive and the edge column are never both eventually
  periodic;
* the black-value obstruction holds for drives that are eventually all black (the base case);
* under maintained black values, the first m columns of the left half are pinned by the drive alone at
  every time that starts a run of m black drive cells. Jen's argument run with the period-p block map
  needs p columns pinned at one phase; a drive with one white cell per period pins p - 1, and the
  missing column carries the white-cell value by exclusive or. That is where the next case sits.
-/

namespace DrivenLeft

open Rule30Bridge Rule30Application BlackValueBridge

/-- One step of the driven left half, read off the definition. -/
theorem lh_step (b : Nat → Bool) (t m : Nat) :
    lh b (t + 1) (m + 1) = Bool.xor (lh b t (m + 2)) (lh b t (m + 1) || lh b t m) := rfl

theorem lh_zero (b : Nat → Bool) (t : Nat) : lh b t 0 = b t := by
  cases t <;> rfl

/-- Light cone: position -m is white before time m. -/
theorem lh_cone (b : Nat → Bool) : ∀ t m, t < m → lh b t m = false := by
  intro t
  induction t with
  | zero =>
    intro m hm
    cases m with
    | zero => omega
    | succ m => rfl
  | succ t ih =>
    intro m hm
    cases m with
    | zero => omega
    | succ m =>
      rw [lh_step, ih (m + 2) (by omega), ih (m + 1) (by omega), ih m (by omega)]
      rfl

/-- Left edge: when the drive is black at time 0, position -t is black at time t. -/
theorem lh_edge (b : Nat → Bool) (h0 : b 0 = true) : ∀ t, lh b t t = true := by
  intro t
  induction t with
  | zero => rw [lh_zero]; exact h0
  | succ t ih =>
    rw [lh_step, lh_cone b t (t + 2) (by omega), lh_cone b t (t + 1) (by omega), ih]
    rfl

/-- Left-permutivity inside the driven half. -/
theorem lh_sideways (b : Nat → Bool) (t m : Nat) :
    lh b t (m + 2) = Bool.xor (lh b (t + 1) (m + 1)) (lh b t (m + 1) || lh b t m) := by
  rw [lh_step]
  generalize lh b t (m + 2) = a
  generalize (lh b t (m + 1) || lh b t m) = c
  cases a <;> cases c <;> rfl

theorem lh_inherit (b : Nat → Bool) (N p j : Nat)
    (h0 : PeriodicFrom (fun t => lh b t j) N p) (h1 : PeriodicFrom (fun t => lh b t (j + 1)) N p) :
    PeriodicFrom (fun t => lh b t (j + 2)) N p := by
  intro t ht
  show lh b (t + p) (j + 2) = lh b t (j + 2)
  rw [lh_sideways b (t + p) j, lh_sideways b t j]
  have a : lh b (t + 1 + p) (j + 1) = lh b (t + 1) (j + 1) := h1 (t + 1) (by omega)
  have c : lh b (t + p) (j + 1) = lh b t (j + 1) := h1 t ht
  have d : lh b (t + p) j = lh b t j := h0 t ht
  rw [show t + p + 1 = t + 1 + p by omega, a, c, d]

theorem lh_inherit_all (b : Nat → Bool) (N p j : Nat)
    (h0 : PeriodicFrom (fun t => lh b t j) N p) (h1 : PeriodicFrom (fun t => lh b t (j + 1)) N p) :
    ∀ n, PeriodicFrom (fun t => lh b t (j + n)) N p ∧ PeriodicFrom (fun t => lh b t (j + n + 1)) N p := by
  intro n
  induction n with
  | zero => exact ⟨h0, h1⟩
  | succ n ih =>
    refine ⟨ih.2, ?_⟩
    have h := lh_inherit b N p (j + n) ih.1 ih.2
    rw [show j + (n + 1) + 1 = j + n + 2 by omega]
    exact h

/-- Jen's argument inside the driven left half: two adjacent columns periodic from the same time with
the same period are impossible, when the drive is black at time 0. -/
theorem lh_jen (b : Nat → Bool) (h0 : b 0 = true) (N p j : Nat) (hp : 0 < p)
    (hj : PeriodicFrom (fun t => lh b t j) N p) (hj1 : PeriodicFrom (fun t => lh b t (j + 1)) N p) :
    False := by
  have hcol := (lh_inherit_all b N p j hj hj1 (N + p)).1
  have per : lh b (N + j + p) (j + (N + p)) = lh b (N + j) (j + (N + p)) := hcol (N + j) (by omega)
  rw [show N + j + p = j + (N + p) by omega, lh_edge b h0,
    lh_cone b (N + j) (j + (N + p)) (by omega)] at per
  exact Bool.noConfusion per

/-- For every admissible drive, the drive and the edge column are never both eventually periodic. -/
theorem drive_and_edge_not_both_periodic (b : Nat → Bool) (h0 : b 0 = true) :
    ¬ (EventuallyPeriodic b ∧ EventuallyPeriodic (fun t => lh b t 1)) := by
  rintro ⟨⟨N1, p1, hp1, h1⟩, ⟨N2, p2, hp2, h2⟩⟩
  have a : PeriodicFrom (fun t => lh b t 0) (N1 + N2) (p1 * p2) := by
    have base : PeriodicFrom (fun t => lh b t 0) N1 p1 := by
      intro t ht
      show lh b (t + p1) 0 = lh b t 0
      rw [lh_zero, lh_zero]
      exact h1 t ht
    exact periodicFrom_mono (periodicFrom_mul base p2) (Nat.le_add_right N1 N2)
  have c : PeriodicFrom (fun t => lh b t (0 + 1)) (N1 + N2) (p1 * p2) := by
    have base : PeriodicFrom (fun t => lh b t 1) N2 p2 := h2
    have m := periodicFrom_mono (periodicFrom_mul base p1) (Nat.le_add_left N2 N1)
    rw [Nat.mul_comm] at m
    exact m
  exact lh_jen b h0 (N1 + N2) (p1 * p2) 0 (Nat.mul_pos hp1 hp2) a c

/-- The base case of the black-value obstruction: a drive that is eventually all black cannot keep the
black values. They would make the edge column eventually white, against Jen's argument. -/
theorem black_value_obstruction_eventually_black (b : Nat → Bool) (N : Nat) (h0 : b 0 = true)
    (hblack : ∃ M, ∀ t, M ≤ t → b t = true) :
    ¬ (∀ t, N ≤ t → b t = true → lh b t 1 = !(b (t + 1))) := by
  intro values
  obtain ⟨M, hM⟩ := hblack
  have white : ∀ t, N + M ≤ t → lh b t 1 = false := by
    intro t ht
    rw [values t (by omega) (hM t (by omega)), hM (t + 1) (by omega)]
    rfl
  have c0 : PeriodicFrom (fun t => lh b t 0) (N + M) 1 := by
    intro t ht
    show lh b (t + 1) 0 = lh b t 0
    rw [lh_zero, lh_zero, hM (t + 1) (by omega), hM t (by omega)]
  have c1 : PeriodicFrom (fun t => lh b t (0 + 1)) (N + M) 1 := by
    intro t ht
    show lh b (t + 1) 1 = lh b t 1
    rw [white (t + 1) (by omega), white t ht]
  exact lh_jen b h0 (N + M) 1 0 (by decide) c0 c1

/-! ## Columns pinned by the black values -/

/-- The left half's columns as the drive alone would give them: column 0 is the drive, column 1 the
black value, and the rest by left-permutivity. -/
def pinned (b : Nat → Bool) : Nat → Nat → Bool
  | t, 0 => b t
  | t, 1 => !(b (t + 1))
  | t, m + 2 => Bool.xor (pinned b (t + 1) (m + 1)) (pinned b t (m + 1) || pinned b t m)

/-- Under maintained black values, column m at a time t ≥ N that starts a run of m black drive cells
is pinned by the drive alone. -/
theorem lh_pinned (b : Nat → Bool) (N : Nat)
    (values : ∀ t, N ≤ t → b t = true → lh b t 1 = !(b (t + 1))) :
    ∀ m t, N ≤ t → (∀ i, i < m → b (t + i) = true) → lh b t m = pinned b t m := by
  intro m
  induction m using Nat.strongRecOn with
  | ind m ih =>
    intro t ht run
    match m, ih, run with
    | 0, _, _ => rw [lh_zero]; rfl
    | 1, _, run =>
      rw [values t ht (by simpa using run 0 (by omega))]
      rfl
    | m + 2, ih, run =>
      rw [lh_sideways]
      have r1 : lh b (t + 1) (m + 1) = pinned b (t + 1) (m + 1) :=
        ih (m + 1) (by omega) (t + 1) (by omega) (fun i hi => by
          rw [show t + 1 + i = t + (i + 1) by omega]; exact run (i + 1) (by omega))
      have r2 : lh b t (m + 1) = pinned b t (m + 1) :=
        ih (m + 1) (by omega) t ht (fun i hi => run i (by omega))
      have r3 : lh b t m = pinned b t m :=
        ih m (by omega) t ht (fun i hi => run i (by omega))
      rw [r1, r2, r3]
      rfl

/-- So the pinned columns repeat with the drive: if the drive has period p from N, every column pinned
at a run start is periodic along that phase. -/
theorem pinned_periodic (b : Nat → Bool) (N p : Nat) (periodic : PeriodicFrom b N p) :
    ∀ m t, N ≤ t → pinned b (t + p) m = pinned b t m := by
  intro m
  induction m using Nat.strongRecOn with
  | ind m ih =>
    intro t ht
    match m, ih with
    | 0, _ => exact periodic t ht
    | 1, _ =>
      show (!(b (t + p + 1))) = !(b (t + 1))
      rw [show t + p + 1 = t + 1 + p by omega, periodic (t + 1) (by omega)]
    | m + 2, ih =>
      show Bool.xor (pinned b (t + p + 1) (m + 1)) (pinned b (t + p) (m + 1) || pinned b (t + p) m) =
        Bool.xor (pinned b (t + 1) (m + 1)) (pinned b t (m + 1) || pinned b t m)
      rw [show t + p + 1 = t + 1 + p by omega, ih (m + 1) (by omega) (t + 1) (by omega),
        ih (m + 1) (by omega) t ht, ih m (by omega) t ht]

/-- The edge column's deviation from the black value at time t. -/
def dev (b : Nat → Bool) (t : Nat) : Bool := Bool.xor (lh b t 1) (!(b (t + 1)))

/-- One column short. Under maintained black values, at a time t ≥ N where the drive is black for m
cells, column m + 1 equals its pinned value xor the edge column's deviation at time t + m. When the drive
is white at t + m and black at t + m + 1, that deviation is the edge column's value at the white cell. -/
theorem lh_off_by_one (b : Nat → Bool) (N : Nat)
    (values : ∀ t, N ≤ t → b t = true → lh b t 1 = !(b (t + 1))) :
    ∀ m t, N ≤ t → (∀ i, i < m → b (t + i) = true) →
      lh b t (m + 1) = Bool.xor (pinned b t (m + 1)) (dev b (t + m)) := by
  intro m
  induction m using Nat.strongRecOn with
  | ind m ih =>
    intro t ht run
    match m, ih, run with
    | 0, _, _ =>
      show lh b t 1 = Bool.xor (!(b (t + 1))) (Bool.xor (lh b t 1) (!(b (t + 0 + 1))))
      rw [Nat.add_zero]
      generalize lh b t 1 = a
      generalize (!(b (t + 1))) = c
      cases a <;> cases c <;> rfl
    | m + 1, ih, run =>
      rw [lh_sideways]
      have r1 : lh b (t + 1) (m + 1) = Bool.xor (pinned b (t + 1) (m + 1)) (dev b (t + 1 + m)) :=
        ih m (by omega) (t + 1) (by omega) (fun i hi => by
          rw [show t + 1 + i = t + (i + 1) by omega]; exact run (i + 1) (by omega))
      have r2 : lh b t (m + 1) = pinned b t (m + 1) :=
        lh_pinned b N values (m + 1) t ht (fun i hi => run i (by omega))
      have r3 : lh b t m = pinned b t m :=
        lh_pinned b N values m t ht (fun i hi => run i (by omega))
      rw [r1, r2, r3, show t + 1 + m = t + (m + 1) by omega]
      show Bool.xor (Bool.xor (pinned b (t + 1) (m + 1)) (dev b (t + (m + 1))))
          (pinned b t (m + 1) || pinned b t m) =
        Bool.xor (Bool.xor (pinned b (t + 1) (m + 1)) (pinned b t (m + 1) || pinned b t m))
          (dev b (t + (m + 1)))
      generalize pinned b (t + 1) (m + 1) = a
      generalize dev b (t + (m + 1)) = d
      generalize (pinned b t (m + 1) || pinned b t m) = c
      cases a <;> cases d <;> cases c <;> rfl

end DrivenLeft
