import ShieldEntry

/-!
Entry bridge, 23 October 2026. Claude, with Lu Semita.

The remaining obligation, `EveryFiniteStartEnters w`, has the form "for every finite start there is a time".
A proof of such a statement has to supply, at least implicitly, a bound on that time as a function of the start
(Kreisel; via Friedman's A-translation for classical proofs). `EntryBound w f` is that bridge made explicit:
every start supported in columns 1..K has its band inside a certificate by time f K. The certificate's width
and period are not bounded here, so a start that has not entered by f K does not by itself refute the bound;
`ClosureCheck.EntryBoundW` bounds them too, and its instances are finite computations.
(Correction of this file's first draft, which said a single failing start refutes `EntryBound w f`.)
-/

namespace EntryBridge

open Rule30Bridge Rule30Application RightHalf UniformWindow ShieldEntry

/-- Every start supported in columns 1..K enters a certificate by time f K. -/
def EntryBound (w : List Bool) (f : Nat → Nat) : Prop :=
  ∀ K (x0 : Nat → Bool), (∀ i, K < i → x0 i = false) →
    ∃ J P t0, ∃ C : Certificate w J P, 0 < J ∧ 0 < P ∧ w.length ∣ P ∧ t0 ≤ f K ∧
      C.R (t0 % P) (bandOf (rhc (pdrive w) x0) J t0)

theorem enters_of_bound (w : List Bool) (f : Nat → Nat) (h : EntryBound w f) :
    EveryFiniteStartEnters w := by
  intro x0 ⟨K, hK⟩
  obtain ⟨J, P, t0, C, hJ, hP, hwP, _, hR⟩ := h K x0 hK
  exact ⟨J, P, t0, C, hJ, hP, hwP, hR⟩

/-- The bridge, end to end: an entry bound for w gives Problem 1 restricted to w. -/
theorem center_avoids_of_bound (w : List Bool) (hw : 0 < w.length) (f : Nat → Nat)
    (h : EntryBound w f) : ¬ EventuallyRepeats center30 w :=
  center_avoids_of_entry w hw (enters_of_bound w f h)

end EntryBridge
