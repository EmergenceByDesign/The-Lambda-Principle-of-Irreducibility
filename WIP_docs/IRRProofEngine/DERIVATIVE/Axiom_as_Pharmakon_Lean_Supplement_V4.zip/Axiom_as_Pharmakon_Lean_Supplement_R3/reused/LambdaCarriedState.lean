import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Real.Pi.Irrational
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Basic.ENNReal.Basic
import Mathlib.Data.Nat.Prime.Basic

/- Lambda R3: carried conditions, access, intervention, and persistence.
   Conditional mathematical contracts; no biological or permanence axiom. -/
namespace LambdaCarriedState

inductive Origin where
  | inherited | acquired | declared | unknown
  deriving DecidableEq, Repr

structure Carried (C R : Type*) where
  condition : C
  record : R
  origin : Origin

-- Updating the descriptive record has an explicitly limited action.
def remark {C R : Type*} (f : R → R) (s : Carried C R) : Carried C R :=
  { s with record := f s.record }

theorem remark_preserves_condition {C R : Type*} (f : R → R) (s : Carried C R) :
    (remark f s).condition = s.condition := rfl

theorem remark_preserves_origin {C R : Type*} (f : R → R) (s : Carried C R) :
    (remark f s).origin = s.origin := rfl

theorem repeated_remarking_preserves_condition {C R : Type*}
    (fs : List (R → R)) (s : Carried C R) :
    (fs.foldl (fun st f => remark f st) s).condition = s.condition := by
  induction fs generalizing s with
  | nil => rfl
  | cons f fs ih => exact ih (remark f s)

theorem recording_inherited_state_does_not_rewrite_origin {C R : Type*}
    (s : Carried C R) (h : s.origin = .inherited) (f : R → R) :
    (remark f s).origin = .inherited := h

def Recovers {X Y Z : Type*} (observe : X → Y) (target : X → Z) : Prop :=
  ∃ decode : Y → Z, ∀ x, decode (observe x) = target x

theorem equal_observation_blocks_target {X Y Z : Type*}
    (observe : X → Y) (target : X → Z) {a b : X}
    (same : observe a = observe b) (different : target a ≠ target b) :
    ¬ Recovers observe target := by
  rintro ⟨decode, exactness⟩
  apply different
  calc target a = decode (observe a) := (exactness a).symm
       _ = decode (observe b) := congrArg decode same
       _ = target b := exactness b

theorem identical_descriptions_can_hide_distinct_conditions :
    ¬ Recovers (fun s : Carried Bool Unit => s.record) (fun s => s.condition) := by
  apply equal_observation_blocks_target _ _
    (a := ⟨false, (), .unknown⟩) (b := ⟨true, (), .unknown⟩)
  · rfl
  · decide

theorem content_does_not_determine_origin :
    ¬ Recovers (fun s : Carried Unit Unit => s.record) (fun s => s.origin) := by
  apply equal_observation_blocks_target _ _
    (a := ⟨(), (), .inherited⟩) (b := ⟨(), (), .declared⟩)
  · rfl
  · decide

theorem enlarged_observation_can_recover_condition {C R : Type*} :
    Recovers (fun s : Carried C R => (s.record, s.condition)) (fun s => s.condition) := by
  exact ⟨Prod.snd, fun _ => rfl⟩

def CanChange {X A : Type*} (act : A → X → X) (x : X) : Prop :=
  ∃ a, act a x ≠ x

theorem exact_access_does_not_supply_intervention :
    Recovers (id : Bool → Bool) id ∧
      ∀ x : Bool, ¬ CanChange (fun (_ : Unit) (s : Bool) => s) x := by
  constructor
  · exact ⟨id, fun _ => rfl⟩
  · intro x h
    rcases h with ⟨a, ha⟩
    exact ha rfl

theorem intervention_does_not_supply_exact_access :
    (∀ x : Bool, CanChange (fun (_ : Unit) (s : Bool) => !s) x) ∧
      ¬ Recovers (fun _ : Bool => ()) id := by
  constructor
  · intro x
    exact ⟨(), by cases x <;> decide⟩
  · apply equal_observation_blocks_target _ _ (a := false) (b := true)
    · rfl
    · decide

-- Available interventions may have a multi-step path.
def applyActions {X A : Type*} (act : A → X → X) (x : X) (as : List A) : X :=
  as.foldl (fun s a => act a s) x

theorem invariant_survives_available_interventions {X A : Type*}
    (act : A → X → X) (p : X → Prop)
    (preserved : ∀ a x, p x → p (act a x)) (x : X) (initial : p x) (as : List A) :
    p (applyActions act x as) := by
  induction as generalizing x with
  | nil => exact initial
  | cons a as ih => exact ih (act a x) (preserved a x initial)

theorem invariant_obstructs_revision_path {X A : Type*}
    (act : A → X → X) (p : X → Prop)
    (preserved : ∀ a x, p x → p (act a x)) (x y : X)
    (initial : p x) (excluded : ¬ p y) :
    ¬ ∃ as, applyActions act x as = y := by
  rintro ⟨as, h⟩
  apply excluded
  rw [← h]
  exact invariant_survives_available_interventions act p preserved x initial as

-- Time is an index. Observation and decoder may change between carriers.
def ExactAt {X S Z : Type*} (encode : Nat → X → S)
    (decode : Nat → S → Z) (target : X → Z) (t : Nat) : Prop :=
  ∀ x, decode t (encode t x) = target x

def Through {X S Z : Type*} (encode : Nat → X → S)
    (decode : Nat → S → Z) (target : X → Z) (N : Nat) : Prop :=
  ∀ t, t ≤ N → ExactAt encode decode target t

theorem recovery_horizon_can_be_shortened {X S Z : Type*}
    (encode : Nat → X → S) (decode : Nat → S → Z) (target : X → Z)
    {M N : Nat} (h : Through encode decode target N) (bound : M ≤ N) :
    Through encode decode target M := by
  intro t ht
  exact h t (Nat.le_trans ht bound)

theorem target_preserving_transfer_gives_successor_recovery {X S T Z : Type*}
    (old : X → S) (next : X → T) (transfer : S → T)
    (oldDecode : S → Z) (nextDecode : T → Z) (q : X → Z)
    (route : ∀ x, next x = transfer (old x))
    (faithful : ∀ x, nextDecode (transfer (old x)) = oldDecode (old x))
    (exactness : ∀ x, oldDecode (old x) = q x) :
    ∀ x, nextDecode (next x) = q x := by
  intro x
  rw [route x, faithful x, exactness x]

theorem maintenance_contract_extends_recovery {X S Z : Type*}
    (encode : Nat → X → S) (decode : Nat → S → Z) (target : X → Z)
    (initial : ExactAt encode decode target 0)
    (step : ∀ t, ExactAt encode decode target t → ExactAt encode decode target (t+1)) :
    ∀ t, ExactAt encode decode target t := by
  intro t
  induction t with
  | zero => exact initial
  | succ t ih => exact step t ih

theorem maintained_hypotheses_give_conditional_continuity
    (sound maintained : Nat → Prop) (initial : sound 0)
    (step : ∀ t, sound t → maintained t → sound (t+1)) :
    (∀ t, maintained t) → ∀ t, sound t := by
  intro all t
  induction t with
  | zero => exact initial
  | succ t ih => exact step t ih (all t)

-- A finite successful prefix is compatible with later loss.
def expiresAfter (N t : Nat) (x : Bool) : Bool :=
  if t ≤ N then x else false

theorem finite_successful_prefix (N : Nat) :
    Through (expiresAfter N) (fun _ => id) id N := by
  intro t ht x
  simp [expiresAfter, ht]

theorem prefix_agreement_can_hide_later_divergence (N : Nat) :
    (∀ t, t ≤ N → ∀ x : Bool, expiresAfter N t x = x) ∧
      expiresAfter N (N+1) true ≠ true := by
  constructor
  · intro t ht x
    simp [expiresAfter, ht]
  · simp [expiresAfter]

theorem loss_after_horizon_has_no_replacement_decoder (N : Nat) :
    ¬ Recovers (expiresAfter N (N+1)) id := by
  apply equal_observation_blocks_target _ _ (a := false) (b := true)
  · simp [expiresAfter]
  · decide

theorem no_finite_prefix_certificate_of_permanence (N : Nat) :
    ¬ (∀ encode : Nat → Bool → Bool,
      Through encode (fun _ => id) id N →
      ∀ t, ExactAt encode (fun _ => id) id t) := by
  intro certificate
  have h := certificate (expiresAfter N) (finite_successful_prefix N) (N+1) true
  simp [expiresAfter] at h

theorem permanent_ideal_model_is_also_consistent_with_prefix :
    ∃ encode : Nat → Bool → Bool, ∀ t, ExactAt encode (fun _ => id) id t := by
  exact ⟨fun _ => id, fun _ _ => rfl⟩

theorem collision_survives_later_transfer {X S T Z : Type*}
    (encode : X → S) (transfer : S → T) (target : X → Z) {a b : X}
    (same : encode a = encode b) (different : target a ≠ target b) :
    ¬ Recovers (transfer ∘ encode) target := by
  exact equal_observation_blocks_target _ _ (congrArg transfer same) different

-- Unit-cost commitments: feasibility can force omission without selecting priority.
theorem budget_forces_an_omitted_commitment {I : Type*} [DecidableEq I]
    (required retained : Finset I) (B : Nat)
    (feasible : retained.card ≤ B) (overBudget : B < required.card) :
    ∃ i ∈ required, i ∉ retained := by
  by_contra h
  have subset : required ⊆ retained := by
    intro i hi
    by_contra missing
    exact h ⟨i, hi, missing⟩
  have size := Finset.card_le_card subset
  omega

theorem equal_budget_does_not_select_priority :
    ∃ a b : Finset Bool, a.card ≤ 1 ∧ b.card ≤ 1 ∧ a ≠ b := by
  exact ⟨{false}, {true}, by decide, by decide, by decide⟩

theorem exact_target_requires_sufficient_carrier_states {X S : Type*}
    [Fintype X] [Fintype S] (encode : X → S) (decode : S → X)
    (exactness : ∀ x, decode (encode x) = x) :
    Fintype.card X ≤ Fintype.card S := by
  apply Fintype.card_le_of_injective encode
  intro a b h
  calc a = decode (encode a) := (exactness a).symm
       _ = decode (encode b) := congrArg decode h
       _ = b := exactness b

theorem finite_carrier_can_preserve_selected_target {R : Type*} :
    Recovers (fun h : Bool × R => h.1) (fun h => h.1) := by
  exact ⟨id, fun _ => rfl⟩

end LambdaCarriedState

#eval Lean.versionString
set_option pp.universes false
#check @LambdaCarriedState.remark_preserves_condition
#print axioms LambdaCarriedState.remark_preserves_condition
#check @LambdaCarriedState.remark_preserves_origin
#print axioms LambdaCarriedState.remark_preserves_origin
#check @LambdaCarriedState.repeated_remarking_preserves_condition
#print axioms LambdaCarriedState.repeated_remarking_preserves_condition
#check @LambdaCarriedState.recording_inherited_state_does_not_rewrite_origin
#print axioms LambdaCarriedState.recording_inherited_state_does_not_rewrite_origin
#check @LambdaCarriedState.equal_observation_blocks_target
#print axioms LambdaCarriedState.equal_observation_blocks_target
#check @LambdaCarriedState.identical_descriptions_can_hide_distinct_conditions
#print axioms LambdaCarriedState.identical_descriptions_can_hide_distinct_conditions
#check @LambdaCarriedState.content_does_not_determine_origin
#print axioms LambdaCarriedState.content_does_not_determine_origin
#check @LambdaCarriedState.enlarged_observation_can_recover_condition
#print axioms LambdaCarriedState.enlarged_observation_can_recover_condition
#check @LambdaCarriedState.exact_access_does_not_supply_intervention
#print axioms LambdaCarriedState.exact_access_does_not_supply_intervention
#check @LambdaCarriedState.intervention_does_not_supply_exact_access
#print axioms LambdaCarriedState.intervention_does_not_supply_exact_access
#check @LambdaCarriedState.invariant_survives_available_interventions
#print axioms LambdaCarriedState.invariant_survives_available_interventions
#check @LambdaCarriedState.invariant_obstructs_revision_path
#print axioms LambdaCarriedState.invariant_obstructs_revision_path
#check @LambdaCarriedState.recovery_horizon_can_be_shortened
#print axioms LambdaCarriedState.recovery_horizon_can_be_shortened
#check @LambdaCarriedState.target_preserving_transfer_gives_successor_recovery
#print axioms LambdaCarriedState.target_preserving_transfer_gives_successor_recovery
#check @LambdaCarriedState.maintenance_contract_extends_recovery
#print axioms LambdaCarriedState.maintenance_contract_extends_recovery
#check @LambdaCarriedState.maintained_hypotheses_give_conditional_continuity
#print axioms LambdaCarriedState.maintained_hypotheses_give_conditional_continuity
#check @LambdaCarriedState.finite_successful_prefix
#print axioms LambdaCarriedState.finite_successful_prefix
#check @LambdaCarriedState.prefix_agreement_can_hide_later_divergence
#print axioms LambdaCarriedState.prefix_agreement_can_hide_later_divergence
#check @LambdaCarriedState.loss_after_horizon_has_no_replacement_decoder
#print axioms LambdaCarriedState.loss_after_horizon_has_no_replacement_decoder
#check @LambdaCarriedState.no_finite_prefix_certificate_of_permanence
#print axioms LambdaCarriedState.no_finite_prefix_certificate_of_permanence
#check @LambdaCarriedState.permanent_ideal_model_is_also_consistent_with_prefix
#print axioms LambdaCarriedState.permanent_ideal_model_is_also_consistent_with_prefix
#check @LambdaCarriedState.collision_survives_later_transfer
#print axioms LambdaCarriedState.collision_survives_later_transfer
#check @LambdaCarriedState.budget_forces_an_omitted_commitment
#print axioms LambdaCarriedState.budget_forces_an_omitted_commitment
#check @LambdaCarriedState.equal_budget_does_not_select_priority
#print axioms LambdaCarriedState.equal_budget_does_not_select_priority
#check @LambdaCarriedState.exact_target_requires_sufficient_carrier_states
#print axioms LambdaCarriedState.exact_target_requires_sufficient_carrier_states
#check @LambdaCarriedState.finite_carrier_can_preserve_selected_target
#print axioms LambdaCarriedState.finite_carrier_can_preserve_selected_target

#eval "LAMBDA_R3_END_OF_CHECK"

#eval Lean.versionString
#eval "LAMBDA_R4_CARRIEDSTATE_END"
