import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Real.Pi.Irrational
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Basic.ENNReal.Basic
import Mathlib.Data.Nat.Prime.Basic

/-!
# Lambda: conveyance, carried commitments, and the shared accumulator
Lu Semita / EmergenceByDesign. Successor R2, 2026-09-13.

Theorems concern the explicit types and protocols below. No theorem identifies
all meaningful reference, consciousness, or physical memory with these types.
No termination theorem follows merely from the presence of role positions.
-/
namespace LambdaConstitutive

-- A. Roles and conveyance. Distinct positions need not have distinct carriers.
inductive Role where
  | source | target
  deriving DecidableEq

theorem role_positions_differ : Role.source ≠ Role.target := by decide

theorem one_carrier_can_fill_both_roles {X : Type*} (x : X) :
    ∃ placement : Role → X, placement .source = placement .target :=
  ⟨fun _ => x, rfl⟩

def Preserves {X Y : Type*} (f : X → Y) (p : X → Prop) (q : Y → Prop) : Prop :=
  ∀ x, p x ↔ q (f x)

theorem translation_composes {X Y Z : Type*} (f : X → Y) (g : Y → Z)
    (p : X → Prop) (q : Y → Prop) (r : Z → Prop)
    (first : Preserves f p q) (second : Preserves g q r) :
    Preserves (g ∘ f) p r := fun x => (first x).trans (second (f x))

theorem preserved_predicate_survives_roundtrip {X Y : Type*}
    (f : X → Y) (g : Y → X) (p : X → Prop) (q : Y → Prop)
    (forward : Preserves f p q) (backward : Preserves g q p) :
    ∀ x, p x ↔ p (g (f x)) := translation_composes f g p q p forward backward

theorem changed_middle_predicate_breaks_composition :
    ∃ (f g : Bool → Bool) (p q₁ q₂ r : Bool → Prop),
      Preserves f p q₁ ∧ Preserves g q₂ r ∧ ¬ Preserves (g ∘ f) p r := by
  refine ⟨id, fun _ => false, (· = true), (· = true),
    (fun _ => True), (fun _ => True), ?_, ?_, ?_⟩
  · intro x; rfl
  · intro x; rfl
  · intro h
    have impossible : false = true := (h false).mpr trivial
    cases impossible

theorem conveyance_collision_blocks_target {X Y Z : Type*}
    (message : X → Y) (target : X → Z) {a b : X}
    (same : message a = message b) (split : target a ≠ target b) :
    ¬ ∃ interpret : Y → Z, ∀ x, interpret (message x) = target x := by
  rintro ⟨interpret, h⟩
  exact split ((h a).symm.trans ((congrArg interpret same).trans (h b)))

theorem metadescription_cannot_split_equal_messages {X Y Z : Type*}
    (message : X → Y) (redescribe : Y → Z) {a b : X}
    (same : message a = message b) : redescribe (message a) = redescribe (message b) :=
  congrArg redescribe same

-- B. Iteration: continuation-space, retained data, and termination differ.
theorem erased_depth_has_no_decoder :
    ¬ ∃ decode : Unit → ℕ, ∀ n : ℕ, decode () = n := by
  rintro ⟨decode, h⟩
  have h0 := h 0
  have h1 := h 1
  omega

theorem threaded_depth_has_decoder :
    ∃ decode : Unit × ℕ → ℕ, ∀ n, decode ((), n) = n :=
  ⟨Prod.snd, fun _ => rfl⟩

theorem retained_argument_can_recover_depth :
    ∃ decode : ℕ → ℕ, ∀ n, decode n = n := ⟨id, fun _ => rfl⟩

def countdown : ℕ → List ℕ
  | 0 => []
  | n + 1 => n :: countdown n

theorem terminating_countdown_has_input_sized_trace (n : ℕ) :
    (countdown n).length = n := by
  induction n with
  | zero => rfl
  | succ n ih => simp [countdown, ih]

theorem no_uniform_trace_bound_for_terminating_countdown :
    ¬ ∃ B : ℕ, ∀ n, (countdown n).length ≤ B := by
  rintro ⟨B, h⟩
  have bad := h (B + 1)
  rw [terminating_countdown_has_input_sized_trace] at bad
  omega

theorem finite_state_can_continue_without_halting :
    ∃ (step : Unit → Unit) (halt : Unit → Prop),
      ∀ n : ℕ, ¬ halt ((step^[n]) ()) := by
  exact ⟨id, fun _ => False, fun _ h => h⟩

-- C. Exact finite-state accounting, measured in distinguishable states.
theorem exact_recovery_requires_enough_states {X S : Type*}
    [Fintype X] [Fintype S] (encode : X → S) (decode : S → X)
    (exactness : ∀ x, decode (encode x) = x) :
    Fintype.card X ≤ Fintype.card S := by
  apply Fintype.card_le_of_injective encode
  intro x y same
  rw [← exactness x, ← exactness y, same]

theorem exact_subset_memory_requires_all_subsets (k : ℕ) {S : Type*}
    [Fintype S] (encode : (Fin k → Bool) → S) (decode : S → Fin k → Bool)
    (exactness : ∀ x, decode (encode x) = x) :
    2 ^ k ≤ Fintype.card S := by
  have h := exact_recovery_requires_enough_states encode decode exactness
  simpa using h

theorem exact_depth_through_N_requires_N_plus_one_states (N : ℕ) {S : Type*}
    [Fintype S] (encode : Fin (N + 1) → S) (decode : S → Fin (N + 1))
    (exactness : ∀ n, decode (encode n) = n) :
    N + 1 ≤ Fintype.card S := by
  simpa using exact_recovery_requires_enough_states encode decode exactness

theorem no_fixed_finite_state_recovers_unbounded_depth {S : Type*}
    [Fintype S] (encode : ℕ → S) :
    ¬ ∃ decode : S → ℕ, ∀ n, decode (encode n) = n := by
  rintro ⟨decode, h⟩
  let N := Fintype.card S
  have injective : Function.Injective (fun n : Fin (N + 1) => encode n.val) := by
    intro x y same
    apply Fin.ext
    exact (h x.val).symm.trans ((congrArg decode same).trans (h y.val))
  have bad := Fintype.card_le_of_injective _ injective
  simp only [Fintype.card_fin] at bad
  change N + 1 ≤ N at bad
  omega

-- D. An online accumulator must commute with the declared history extension.
def run {E S : Type*} (update : S → E → S) (initial : S) (events : List E) : S :=
  events.foldl update initial

def AppendCompatible {E S : Type*} (encode : List E → S) : Prop :=
  ∀ h k e, encode h = encode k → encode (h ++ [e]) = encode (k ++ [e])

theorem online_update_implies_append_compatibility {E S : Type*}
    (encode : List E → S) (update : S → E → S)
    (commutes : ∀ h e, update (encode h) e = encode (h ++ [e])) :
    AppendCompatible encode := by
  intro h k e same
  rw [← commutes h e, ← commutes k e, same]

theorem append_compatibility_supplies_online_update {E S : Type*}
    [Nonempty S] (encode : List E → S) (compatible : AppendCompatible encode) :
    ∃ update : S → E → S, ∀ h e, update (encode h) e = encode (h ++ [e]) := by
  classical
  let update : S → E → S := fun s e =>
    if witness : ∃ h, encode h = s then
      encode (Classical.choose witness ++ [e])
    else Classical.choice inferInstance
  refine ⟨update, ?_⟩
  intro h e
  have witness : ∃ k, encode k = encode h := ⟨h, rfl⟩
  simp only [update, dite_eq_left witness]
  exact compatible _ h e (Classical.choose_spec witness)

theorem run_preserves_history_encoding {E S : Type*}
    (encode : List E → S) (update : S → E → S)
    (commutes : ∀ h e, update (encode h) e = encode (h ++ [e]))
    (h : List E) : run update (encode []) h = encode h := by
  induction h using List.reverseRecOn with
  | nil => rfl
  | append_singleton h e ih =>
    change (h ++ [e]).foldl update (encode []) = _
    rw [List.foldl_append]
    change update (run update (encode []) h) e = _
    rw [ih, commutes]

theorem online_target_recovery {E S Z : Type*}
    (encode : List E → S) (update : S → E → S) (decode : S → Z)
    (target : List E → Z)
    (commutes : ∀ h e, update (encode h) e = encode (h ++ [e]))
    (exactness : ∀ h, decode (encode h) = target h) :
    ∀ h, decode (run update (encode []) h) = target h := by
  intro h
  rw [run_preserves_history_encoding encode update commutes, exactness]

def hasTwo (h : List Unit) : Bool := decide (2 ≤ h.length)

theorem snapshot_target_can_fail_online_update :
    (∃ decode : Bool → Bool, ∀ h, decode (hasTwo h) = hasTwo h) ∧
      ¬ AppendCompatible hasTwo := by
  constructor
  · exact ⟨id, fun _ => rfl⟩
  · intro compatible
    have bad := compatible [] [()] () (by decide)
    have unequal : hasTwo ([] ++ [()]) ≠ hasTwo ([()] ++ [()]) := by decide
    exact unequal bad

-- E. Recognition and continuation need different queries.
structure Cache where
  result : ℕ
  returned : Bool
  deriving DecidableEq

theorem cached_result_does_not_recover_return :
    ¬ ∃ d : ℕ → Bool, ∀ c : Cache, d c.result = c.returned := by
  rintro ⟨d, h⟩
  have h0 := h ⟨7, false⟩
  have h1 := h ⟨7, true⟩
  exact Bool.noConfusion (h0.symm.trans h1)

theorem return_mark_does_not_recover_cached_result :
    ¬ ∃ d : Bool → ℕ, ∀ c : Cache, d c.returned = c.result := by
  rintro ⟨d, h⟩
  have h0 := h ⟨0, true⟩
  have h1 := h ⟨1, true⟩
  change d true = 0 at h0
  change d true = 1 at h1
  omega

theorem joint_record_recovers_both_cache_queries :
    ∃ d : Cache → ℕ × Bool, ∀ c, d c = (c.result, c.returned) :=
  ⟨fun c => (c.result, c.returned), fun _ => rfl⟩

-- F. Scope, provenance, and warrants are separately carried coordinates.
inductive Origin where
  | declared | derived | unknown
  deriving DecidableEq

structure Entry where
  holder : String
  scope : String
  basis : String
  claim : String
  origin : Origin
  deriving DecidableEq

def Reuse (old new : Entry) : Prop :=
  new.holder = old.holder ∧ new.scope = old.scope ∧ new.basis = old.basis ∧
    new.claim = old.claim ∧ new.origin = old.origin

theorem unchanged_reuse_preserves_entry {old new : Entry} (h : Reuse old new) :
    new = old := by
  cases old with
  | mk oh os ob oc oo =>
    cases new with
    | mk nh ns nb nc no =>
      rcases h with ⟨hh, hs, hb, hc, ho⟩
      simp_all

theorem unknown_origin_stays_unknown_under_reuse {old new : Entry}
    (h : Reuse old new) (unknown : old.origin = .unknown) : new.origin = .unknown :=
  h.2.2.2.2.trans unknown

theorem changed_scope_is_not_unchanged_reuse {old new : Entry}
    (changed : new.scope ≠ old.scope) : ¬ Reuse old new := fun h => changed h.2.1

theorem result_label_cannot_recover_origin :
    ¬ ∃ decode : String → Origin, ∀ e : Entry, decode e.claim = e.origin := by
  rintro ⟨decode, h⟩
  have hd := h ⟨"holder", "scope", "basis", "P", .declared⟩
  have hf := h ⟨"holder", "scope", "basis", "P", .derived⟩
  exact Origin.noConfusion (hd.symm.trans hf)

structure Warrant (Scope Claim : Type*) (holds : Scope → Claim → Prop) where
  scope : Scope
  claim : Claim
  receipt : holds scope claim

theorem warranted_reuse_needs_scope_preservation {Scope Claim : Type*}
    {holds : Scope → Claim → Prop} (w : Warrant Scope Claim holds)
    (nextScope : Scope) (same : nextScope = w.scope) : holds nextScope w.claim := by
  rw [same]
  exact w.receipt

theorem warranted_translation_needs_a_bridge {S T C D : Type*}
    {holds : S → C → Prop} {nextHolds : T → D → Prop}
    (scopeMap : S → T) (claimMap : C → D)
    (bridge : ∀ s c, holds s c → nextHolds (scopeMap s) (claimMap c))
    (w : Warrant S C holds) : nextHolds (scopeMap w.scope) (claimMap w.claim) :=
  bridge w.scope w.claim w.receipt

theorem declared_basis_allows_derived_conclusion (P Q : Prop)
    (adopted : P) (derivation : P → Q) : Q := derivation adopted

theorem derived_tag_alone_does_not_prove_claim :
    ¬ ∀ (P : Prop) (tag : Origin), tag = .derived → P := by
  intro h
  exact h False .derived rfl

-- G. Refinements and protocol changes retain predecessors.
def appendRecord {R : Type*} (history : List R) (record : R) : List R :=
  history ++ [record]

theorem append_record_preserves_prefix {R : Type*} (history : List R) (record : R) :
    (appendRecord history record).take history.length = history := by
  simp [appendRecord]

structure ProtocolEntry (R : Type*) where
  holder : String
  protocol : String
  payload : R

theorem recording_protocol_has_a_holder {R : Type*} (e : ProtocolEntry R) :
    ∃ holder : String, holder = e.holder := ⟨e.holder, rfl⟩

theorem different_origin_rankings_need_no_absolute_comparator :
    ∃ (first second : Bool → ℕ), first false < first true ∧ second true < second false :=
  ⟨(fun b => if b then 1 else 0), (fun b => if b then 0 else 1), by decide, by decide⟩

end LambdaConstitutive

-- Complete statement and transitive dependency receipts.
#check LambdaConstitutive.role_positions_differ
#print axioms LambdaConstitutive.role_positions_differ
#check LambdaConstitutive.one_carrier_can_fill_both_roles
#print axioms LambdaConstitutive.one_carrier_can_fill_both_roles
#check LambdaConstitutive.translation_composes
#print axioms LambdaConstitutive.translation_composes
#check LambdaConstitutive.preserved_predicate_survives_roundtrip
#print axioms LambdaConstitutive.preserved_predicate_survives_roundtrip
#check LambdaConstitutive.changed_middle_predicate_breaks_composition
#print axioms LambdaConstitutive.changed_middle_predicate_breaks_composition
#check LambdaConstitutive.conveyance_collision_blocks_target
#print axioms LambdaConstitutive.conveyance_collision_blocks_target
#check LambdaConstitutive.metadescription_cannot_split_equal_messages
#print axioms LambdaConstitutive.metadescription_cannot_split_equal_messages
#check LambdaConstitutive.erased_depth_has_no_decoder
#print axioms LambdaConstitutive.erased_depth_has_no_decoder
#check LambdaConstitutive.threaded_depth_has_decoder
#print axioms LambdaConstitutive.threaded_depth_has_decoder
#check LambdaConstitutive.retained_argument_can_recover_depth
#print axioms LambdaConstitutive.retained_argument_can_recover_depth
#check LambdaConstitutive.terminating_countdown_has_input_sized_trace
#print axioms LambdaConstitutive.terminating_countdown_has_input_sized_trace
#check LambdaConstitutive.no_uniform_trace_bound_for_terminating_countdown
#print axioms LambdaConstitutive.no_uniform_trace_bound_for_terminating_countdown
#check LambdaConstitutive.finite_state_can_continue_without_halting
#print axioms LambdaConstitutive.finite_state_can_continue_without_halting
#check LambdaConstitutive.exact_recovery_requires_enough_states
#print axioms LambdaConstitutive.exact_recovery_requires_enough_states
#check LambdaConstitutive.exact_subset_memory_requires_all_subsets
#print axioms LambdaConstitutive.exact_subset_memory_requires_all_subsets
#check LambdaConstitutive.exact_depth_through_N_requires_N_plus_one_states
#print axioms LambdaConstitutive.exact_depth_through_N_requires_N_plus_one_states
#check LambdaConstitutive.no_fixed_finite_state_recovers_unbounded_depth
#print axioms LambdaConstitutive.no_fixed_finite_state_recovers_unbounded_depth
#check LambdaConstitutive.online_update_implies_append_compatibility
#print axioms LambdaConstitutive.online_update_implies_append_compatibility
#check LambdaConstitutive.append_compatibility_supplies_online_update
#print axioms LambdaConstitutive.append_compatibility_supplies_online_update
#check LambdaConstitutive.run_preserves_history_encoding
#print axioms LambdaConstitutive.run_preserves_history_encoding
#check LambdaConstitutive.online_target_recovery
#print axioms LambdaConstitutive.online_target_recovery
#check LambdaConstitutive.snapshot_target_can_fail_online_update
#print axioms LambdaConstitutive.snapshot_target_can_fail_online_update
#check LambdaConstitutive.cached_result_does_not_recover_return
#print axioms LambdaConstitutive.cached_result_does_not_recover_return
#check LambdaConstitutive.return_mark_does_not_recover_cached_result
#print axioms LambdaConstitutive.return_mark_does_not_recover_cached_result
#check LambdaConstitutive.joint_record_recovers_both_cache_queries
#print axioms LambdaConstitutive.joint_record_recovers_both_cache_queries
#check LambdaConstitutive.unchanged_reuse_preserves_entry
#print axioms LambdaConstitutive.unchanged_reuse_preserves_entry
#check LambdaConstitutive.unknown_origin_stays_unknown_under_reuse
#print axioms LambdaConstitutive.unknown_origin_stays_unknown_under_reuse
#check LambdaConstitutive.changed_scope_is_not_unchanged_reuse
#print axioms LambdaConstitutive.changed_scope_is_not_unchanged_reuse
#check LambdaConstitutive.result_label_cannot_recover_origin
#print axioms LambdaConstitutive.result_label_cannot_recover_origin
#check LambdaConstitutive.warranted_reuse_needs_scope_preservation
#print axioms LambdaConstitutive.warranted_reuse_needs_scope_preservation
#check LambdaConstitutive.warranted_translation_needs_a_bridge
#print axioms LambdaConstitutive.warranted_translation_needs_a_bridge
#check LambdaConstitutive.declared_basis_allows_derived_conclusion
#print axioms LambdaConstitutive.declared_basis_allows_derived_conclusion
#check LambdaConstitutive.derived_tag_alone_does_not_prove_claim
#print axioms LambdaConstitutive.derived_tag_alone_does_not_prove_claim
#check LambdaConstitutive.append_record_preserves_prefix
#print axioms LambdaConstitutive.append_record_preserves_prefix
#check LambdaConstitutive.recording_protocol_has_a_holder
#print axioms LambdaConstitutive.recording_protocol_has_a_holder
#check LambdaConstitutive.different_origin_rankings_need_no_absolute_comparator
#print axioms LambdaConstitutive.different_origin_rankings_need_no_absolute_comparator
#eval Lean.versionString
#eval "LAMBDA_CONSTITUTIVE_R2_COMPLETE"

#eval Lean.versionString
#eval "LAMBDA_R4_CONSTITUTIVE_END"
