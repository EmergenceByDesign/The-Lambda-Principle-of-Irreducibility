import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Real.Pi.Irrational
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Basic.ENNReal.Basic
import Mathlib.Data.Nat.Prime.Basic

/-!
# Institutional signals: declared models, not findings about an institution

These results expose assumptions needed to move between public recognition,
eligibility, mathematical truth, and a causal claim about acceptance.
No predicate below certifies Clay eligibility or describes actual human behavior.
-/
namespace LambdaInstitutionalSignals

def thresholdAccepts (evidence signal threshold : Nat) : Prop :=
  threshold ≤ evidence + signal

/-- Under the displayed threshold premises, adding the signal changes the decision. -/
theorem signal_crosses_declared_threshold (evidence signal threshold : Nat)
    (below : evidence < threshold) (enough : threshold ≤ evidence + signal) :
    ¬ thresholdAccepts evidence 0 threshold ∧
      thresholdAccepts evidence signal threshold := by
  unfold thresholdAccepts
  constructor
  · omega
  · exact enough

def observedAcceptance (response : Bool → Bool) : Bool := response true

def SignalDependent (response : Bool → Bool) : Prop :=
  response true ≠ response false

/-- The same observed acceptance is compatible with dependence and independence. -/
theorem observed_acceptance_does_not_identify_dependence :
    ∃ f g : Bool → Bool,
      observedAcceptance f = observedAcceptance g ∧
      SignalDependent f ∧ ¬ SignalDependent g := by
  refine ⟨id, (fun _ => true), rfl, ?_, ?_⟩
  · change (true : Bool) ≠ false
    decide
  · simp [SignalDependent]

/-- No decoder of that observation alone recovers signal-dependence for every response. -/
theorem no_dependence_decoder_from_observed_acceptance :
    ¬ ∃ decode : Bool → Bool, ∀ response : Bool → Bool,
      decode (observedAcceptance response) =
        decide (response true ≠ response false) := by
  rintro ⟨decode, h⟩
  have yes : decode true = true := by
    simpa [observedAcceptance] using h id
  have no := h (fun _ => true)
  simp [observedAcceptance, yes] at no

structure AssessmentCoordinates where
  claimTruth : Bool
  eligible : Bool
  publicRecognition : Bool

/-- Without a bridge, recognition does not recover either of the other coordinates. -/
theorem recognition_does_not_determine_truth_or_eligibility :
    ∃ a b : AssessmentCoordinates,
      a.publicRecognition = b.publicRecognition ∧
      a.claimTruth ≠ b.claimTruth ∧ a.eligible ≠ b.eligible := by
  exact ⟨⟨false, false, true⟩, ⟨true, true, true⟩, rfl, by decide, by decide⟩

end LambdaInstitutionalSignals

#check @LambdaInstitutionalSignals.signal_crosses_declared_threshold
#print axioms LambdaInstitutionalSignals.signal_crosses_declared_threshold
#check @LambdaInstitutionalSignals.observed_acceptance_does_not_identify_dependence
#print axioms LambdaInstitutionalSignals.observed_acceptance_does_not_identify_dependence
#check @LambdaInstitutionalSignals.no_dependence_decoder_from_observed_acceptance
#print axioms LambdaInstitutionalSignals.no_dependence_decoder_from_observed_acceptance
#check @LambdaInstitutionalSignals.recognition_does_not_determine_truth_or_eligibility
#print axioms LambdaInstitutionalSignals.recognition_does_not_determine_truth_or_eligibility
#eval Lean.versionString
#eval "LAMBDA_R4_INSTITUTIONALSIGNALS_END"
