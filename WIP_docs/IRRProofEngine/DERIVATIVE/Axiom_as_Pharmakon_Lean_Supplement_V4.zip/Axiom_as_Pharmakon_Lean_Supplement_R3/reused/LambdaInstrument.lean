import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Real.Pi.Irrational
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Basic.ENNReal.Basic
import Mathlib.Data.Nat.Prime.Basic

/-!
# Lambda: the equal-standard instrument, successor R1
Authorial program: Lu Semita / EmergenceByDesign. Consolidated 2026-09-13.
This file proves the declared mathematical contracts. Case parameters do not
silently import a PDE, a quantum field theory, or an arithmetic equivalence.
The source and receipt, together, delimit the meaning of `verified`.
-/
namespace LambdaInstrument

-- A. Information, target recovery, and declared changes.
def Recoverable {X Y Z : Type*} (read : X → Y) (target : X → Z) : Prop :=
  ∃ decode : Y → Z, ∀ x, decode (read x) = target x

theorem recovery_iff_fibre_constancy {X Y Z : Type*} [Nonempty Z]
    (read : X → Y) (target : X → Z) :
    Recoverable read target ↔
      ∀ x y, read x = read y → target x = target y := by
  classical
  constructor
  · rintro ⟨d, hd⟩ x y h
    rw [← hd x, ← hd y, h]
  · intro h
    let d : Y → Z := fun y => if hy : ∃ x, read x = y
      then target (Classical.choose hy) else Classical.choice inferInstance
    refine ⟨d, ?_⟩
    intro x
    have hx : ∃ a, read a = read x := ⟨x, rfl⟩
    simp only [d, dite_eq_left hx]
    exact h _ x (Classical.choose_spec hx)

theorem collision_blocks_recovery {X Y Z : Type*}
    (read : X → Y) (target : X → Z) {a b : X}
    (same : read a = read b) (split : target a ≠ target b) :
    ¬ Recoverable read target := by
  rintro ⟨d, hd⟩
  apply split
  rw [← hd a, ← hd b, same]

theorem postprocessing_preserves_collision {X Y Z : Type*}
    (read : X → Y) (post : Y → Z) {a b : X}
    (h : read a = read b) : post (read a) = post (read b) := congrArg post h

theorem enriched_readout_recovers_target {X Y Z : Type*}
    (read : X → Y) (target : X → Z) :
    Recoverable (fun x => (read x, target x)) target := ⟨Prod.snd, fun _ => rfl⟩

theorem one_sided_certificate_contract {X Y : Type*}
    (read : X → Y) (fires : Y → Prop) (target : X → Prop) :
    (∀ x, fires (read x) → target x) ↔
      {x | fires (read x)} ⊆ {x | target x} := Iff.rfl

theorem entailed_condition_preserves_acceptance {X : Type*}
    (accept condition : X → Prop) (h : ∀ x, accept x → condition x) :
    ∀ x, (accept x ∧ condition x) ↔ accept x := by
  intro x
  exact ⟨And.left, fun ha => ⟨ha, h x ha⟩⟩

theorem new_condition_changes_acceptance {X : Type*}
    (accept condition : X → Prop) {x : X}
    (ha : accept x) (hc : ¬ condition x) :
    ¬ (∀ y, (accept y ∧ condition y) ↔ accept y) := by
  intro h
  exact hc ((h x).mpr ha).2

theorem equal_declared_inputs_equal_outputs {X Y Z : Type*}
    (read : X → Y) (judge : X → Z) (h : Recoverable read judge)
    {a b : X} (same : read a = read b) : judge a = judge b := by
  obtain ⟨d, hd⟩ := h
  rw [← hd a, ← hd b, same]

theorem different_outputs_require_distinction {X Y Z : Type*}
    (read : X → Y) (judge : X → Z) (h : Recoverable read judge)
    {a b : X} (split : judge a ≠ judge b) : read a ≠ read b := by
  intro same
  exact split (equal_declared_inputs_equal_outputs read judge h same)

-- B. Burden reversal: missing refutation versus a proof of existence.
theorem no_refutation_is_not_a_general_proof :
    ¬ (∀ (certified : Prop → Prop) (P : Prop),
      (∀ Q, certified Q → Q) → ¬ certified (¬ P) → P) := by
  intro h
  exact h (fun _ => False) False (fun _ hf => hf.elim) (fun hf => hf)

theorem completeness_licenses_reversal
    (certified : Prop → Prop) (P : Prop)
    (completeAtNegation : (¬ P) → certified (¬ P))
    (noRefutation : ¬ certified (¬ P)) : P := by
  classical
  by_contra h
  exact noRefutation (completeAtNegation h)

theorem existential_claim_needs_no_closed_form {X : Type*} (P : X → Prop)
    (construction : ∃ x, P x) : ¬ (∀ x, ¬ P x) := by
  rintro h
  obtain ⟨x, hx⟩ := construction
  exact h x hx

theorem residual_equation_has_witness {X F : Type*} (residual : X → F) (x : X) :
    ∃ f, f = residual x := ⟨residual x, rfl⟩

theorem residual_admissibility_is_the_obligation {X F : Type*}
    (residual : X → F) (admitted : F → Prop) (x : X) :
    (∃ f, f = residual x ∧ admitted f) ↔ admitted (residual x) := by
  constructor
  · rintro ⟨f, rfl, hf⟩
    exact hf
  · intro h
    exact ⟨residual x, rfl, h⟩

-- C. Finite observation and an all-stage target.
def AllStages (P : ℕ → Prop) : Prop := ∀ n, P n
def Window (N : ℕ) (P : ℕ → Prop) : Prop := ∀ n, n < N → P n

theorem finite_window_has_opposite_extensions (N : ℕ) :
    ∃ good bad : ℕ → Prop,
      Window N good ∧ Window N bad ∧ AllStages good ∧ ¬ AllStages bad := by
  refine ⟨fun _ => True, fun n => n < N, ?_, ?_, ?_, ?_⟩
  · intro n hn; trivial
  · intro n hn; exact hn
  · intro n; trivial
  · intro h; exact Nat.lt_irrefl N (h N)

theorem no_fixed_window_decides_unrestricted_tail (N : ℕ) :
    ¬ (∀ P : ℕ → Prop, Window N P → AllStages P) := by
  intro h
  exact Nat.lt_irrefl N (h (fun n => n < N) (fun _ hn => hn) N)

theorem universal_proof_closes_all_windows (P : ℕ → Prop)
    (h : AllStages P) : ∀ N, Window N P := fun _ n _ => h n

theorem all_windows_iff_all_stages (P : ℕ → Prop) :
    (∀ N, Window N P) ↔ AllStages P := by
  constructor
  · intro h n; exact h (n + 1) n (Nat.lt_succ_self n)
  · exact universal_proof_closes_all_windows P

theorem actual_failure_refutes_tail (P : ℕ → Prop) {n : ℕ}
    (failure : ¬ P n) : ¬ AllStages P := fun h => failure (h n)

theorem tail_negation_has_failure (P : ℕ → Prop) :
    ¬ AllStages P ↔ ∃ n, ¬ P n := by
  classical
  simp [AllStages]

-- D. Navier-Stokes: the official force-quantifier relationship, abstract carrier.
def NSGlobal {D F : Type*} (admD : D → Prop) (global : D → F → Prop)
    (zeroForce : F) : Prop := ∀ d, admD d → global d zeroForce
def NSForcedFailure {D F : Type*} (admD : D → Prop) (admF : F → Prop)
    (global : D → F → Prop) : Prop :=
  ∃ d f, admD d ∧ admF f ∧ ¬ global d f

theorem unforced_failure_is_admitted_forced_failure {D F : Type*}
    (admD : D → Prop) (admF : F → Prop) (global : D → F → Prop)
    (zeroForce : F) (zeroAdmitted : admF zeroForce)
    (failure : ¬ NSGlobal admD global zeroForce) :
    NSForcedFailure admD admF global := by
  classical
  unfold NSGlobal at failure
  push Not at failure
  obtain ⟨d, hd, hn⟩ := failure
  exact ⟨d, zeroForce, hd, zeroAdmitted, hn⟩

theorem forced_failure_can_coexist_with_unforced_global :
    ∃ global : Unit → Bool → Prop,
      NSGlobal (fun _ => True) global false ∧
      NSForcedFailure (fun _ => True) (fun _ => True) global := by
  refine ⟨fun _ f => f = false, ?_, ?_⟩
  · intro d hd; rfl
  · exact ⟨(), true, trivial, trivial, Bool.noConfusion⟩

def NSRegular {D : Type*} (regularWindow : D → ℕ → Prop) (d : D) : Prop :=
  ∀ n, regularWindow d n
def NSBlowup {D Time : Type*} (before : D → Time → Prop)
    (size : D → Time → ℝ) (d : D) : Prop :=
  ∀ M : ℝ, ∃ t, before d t ∧ M < size d t

theorem ns_regularity_requires_each_window {D : Type*}
    (window : D → ℕ → Prop) (d : D) :
    NSRegular window d ↔ ∀ N, Window N (window d) :=
  (all_windows_iff_all_stages (window d)).symm

theorem ns_uniform_bound_excludes_encoded_blowup {D Time : Type*}
    (before : D → Time → Prop) (size : D → Time → ℝ) (d : D)
    (bound : ∃ K, ∀ t, before d t → size d t ≤ K) :
    ¬ NSBlowup before size d := by
  rintro h
  obtain ⟨K, hK⟩ := bound
  obtain ⟨t, ht, hb⟩ := h K
  exact (not_lt_of_ge (hK t ht)) hb

theorem invariant_exact_classifier {X : Type*} (move : X → X)
    (H B : X → Prop) (equiv : ∀ x, H x ↔ B x)
    (inv : ∀ x, B (move x) ↔ B x) : ∀ x, H (move x) ↔ H x := by
  intro x
  exact (equiv (move x)).trans ((inv x).trans (equiv x).symm)

theorem sufficient_condition_need_not_be_invariant :
    ∃ H B : Bool → Prop,
      (∀ x, H x → B x) ∧ (∀ x, B (!x) ↔ B x) ∧
      ¬ (H (!false) ↔ H false) := by
  refine ⟨fun b => b = false, fun _ => True, ?_, ?_, ?_⟩
  · intro x hx; trivial
  · intro x; rfl
  · simp

-- E. Riemann: direct zero predicate and an explicitly bridged tail coding.
def RHForm {Zero : Type*} (nontrivial onLine : Zero → Prop) : Prop :=
  ∀ z, nontrivial z → onLine z

theorem rh_counterexample_duality {Zero : Type*} (nontrivial onLine : Zero → Prop) :
    ¬ RHForm nontrivial onLine ↔ ∃ z, nontrivial z ∧ ¬ onLine z := by
  classical
  simp [RHForm]

theorem rh_tail_transport {Zero : Type*} (nontrivial onLine : Zero → Prop)
    (test : ℕ → Prop) (bridge : RHForm nontrivial onLine ↔ AllStages test)
    (closure : ∀ n, test n) : RHForm nontrivial onLine := bridge.mpr closure

-- F. Yang-Mills: one common positive bound and the continuum theory obligation.
def UniformGap {State : Type*} (excited : State → Prop) (energy : State → ℝ) : Prop :=
  ∃ δ : ℝ, 0 < δ ∧ ∀ s, excited s → δ ≤ energy s
def YMForm {Group Theory State : Type*} (admissibleGroup : Group → Prop)
    (validTheory : Group → Theory → Prop)
    (excited : Theory → State → Prop) (energy : Theory → State → ℝ) : Prop :=
  ∀ g, admissibleGroup g → ∃ t, validTheory g t ∧ UniformGap (excited t) (energy t)

theorem uniform_gap_implies_pointwise_positive {State : Type*}
    (excited : State → Prop) (energy : State → ℝ)
    (h : UniformGap excited energy) : ∀ s, excited s → 0 < energy s := by
  obtain ⟨δ, hδ, hs⟩ := h
  intro s he
  exact lt_of_lt_of_le hδ (hs s he)

theorem pointwise_positive_need_not_have_uniform_gap :
    (∀ x : {r : ℝ // 0 < r}, 0 < x.val) ∧
    ¬ UniformGap (fun _ : {r : ℝ // 0 < r} => True) (fun x => x.val) := by
  refine ⟨fun x => x.property, ?_⟩
  rintro ⟨δ, hδ, hs⟩
  have h := hs ⟨δ / 2, by linarith⟩ trivial
  dsimp at h
  linarith

theorem common_gap_survives_order_limit {State : Type*}
    (excited : State → Prop) (energy : State → ℝ) (approx : ℕ → State → ℝ)
    (δ : ℝ) (positive : 0 < δ)
    (bounds : ∀ n s, excited s → δ ≤ approx n s)
    (passToLimit : ∀ s, (∀ n, δ ≤ approx n s) → δ ≤ energy s) :
    UniformGap excited energy := by
  refine ⟨δ, positive, ?_⟩
  intro s hs
  exact passToLimit s (fun n => bounds n s hs)

-- G. Hodge: exact cycle-class image, finite witness, global quantifier.
def HodgeForm {Instance Cycle : Type*} (admitted : Instance → Prop)
    (represents : Cycle → Instance → Prop) : Prop :=
  ∀ i, admitted i → ∃ c, represents c i

theorem hodge_actual_cycle_closes_instance {Instance Cycle : Type*}
    (represents : Cycle → Instance → Prop) (i : Instance) (c : Cycle)
    (certificate : represents c i) : ∃ w, represents w i := ⟨c, certificate⟩

theorem hodge_nonmembership_requires_all_cycles {Instance Cycle : Type*}
    (represents : Cycle → Instance → Prop) (i : Instance) :
    (¬ ∃ c, represents c i) ↔ ∀ c, ¬ represents c i := by simp

theorem hodge_separating_invariant_closes_nonmembership {Instance Cycle : Type*}
    (represents : Cycle → Instance → Prop) (invariant : Instance → Prop)
    (sound : ∀ c i, represents c i → invariant i) {i : Instance}
    (separates : ¬ invariant i) : ¬ ∃ c, represents c i := by
  rintro ⟨c, hc⟩
  exact separates (sound c i hc)

theorem hodge_finite_empty_search_not_universal (S : Finset ℕ) :
    ∃ witness : ℕ → Prop, (∀ n ∈ S, ¬ witness n) ∧ ∃ n, witness n := by
  let m := S.sup id + 1
  have hm : m ∉ S := by
    intro h
    have hh := Finset.le_sup (f := id) h
    dsimp [m] at *
    omega
  refine ⟨fun n => n = m, ?_, m, rfl⟩
  intro n hn heq
  exact hm (heq ▸ hn)

-- H. P versus NP: candidates include a machine and a polynomial clock.
def PolyCandidateForm {Candidate Input : Type*} (correct : Candidate → Input → Prop) : Prop :=
  ∃ c, ∀ x, correct c x

theorem pnp_quantifier_duality {Candidate Input : Type*}
    (correct : Candidate → Input → Prop) :
    ¬ PolyCandidateForm correct ↔ ∀ c, ∃ x, ¬ correct c x := by
  classical
  simp [PolyCandidateForm]

theorem pnp_candidate_with_all_input_proof_closes {Candidate Input : Type*}
    (correct : Candidate → Input → Prop) (c : Candidate)
    (allInputs : ∀ x, correct c x) : PolyCandidateForm correct := ⟨c, allInputs⟩

theorem bounded_tests_do_not_prove_candidate (N : ℕ) :
    ∃ correct : Unit → ℕ → Prop,
      (∀ n, n < N → correct () n) ∧ ¬ PolyCandidateForm correct := by
  refine ⟨fun _ n => n < N, fun _ h => h, ?_⟩
  rintro ⟨c, h⟩
  exact Nat.lt_irrefl N (h N)

-- I. BSD: rank comparison, analytic order, and product identification.
def BSDRankForm {Curve : Type*} (algRank anRank : Curve → ℕ) : Prop :=
  ∀ E, algRank E = anRank E
def ExactOrder (coefficient : ℕ → ℝ) (r : ℕ) : Prop :=
  (∀ n, n < r → coefficient n = 0) ∧ coefficient r ≠ 0

theorem bsd_matching_bounds_close_rank (rank lower upper : ℕ)
    (hl : lower ≤ rank) (hu : rank ≤ upper) (meet : lower = upper) :
    rank = lower := by omega

theorem bsd_matching_certificates_close_instance (alg an lower upper : ℕ)
    (hl : lower ≤ alg) (hu : alg ≤ upper) (meet : lower = upper)
    (analytic : an = lower) : alg = an := by omega

theorem exact_order_unique (a : ℕ → ℝ) {r s : ℕ}
    (hr : ExactOrder a r) (hs : ExactOrder a s) : r = s := by
  by_contra h
  rcases lt_or_gt_of_ne h with hlt | hgt
  · exact hr.2 (hs.1 r hlt)
  · exact hs.2 (hr.1 s hgt)

theorem nonzero_term_alone_not_exact_order :
    ∃ a : ℕ → ℝ, a 1 ≠ 0 ∧ ¬ ExactOrder a 1 := by
  refine ⟨fun _ => 1, one_ne_zero, ?_⟩
  intro h
  exact one_ne_zero (h.1 0 (by omega))

theorem product_readout_loses_factor :
    ¬ Recoverable (fun p : ℝ × ℝ => p.1 * p.2) Prod.fst := by
  apply collision_blocks_recovery _ _ (a := (1, 6)) (b := (2, 3))
  · norm_num
  · norm_num

theorem anchored_product_recovers_factor (a b c : ℝ) (ha : a ≠ 0)
    (h : a * b = a * c) : b = c := (mul_left_cancel₀ ha) h

-- J. Pi and e: exact representation classes and a substantive positive control.
theorem pi_outside_rational_image : ¬ ∃ q : ℚ, (q : ℝ) = Real.pi := by
  rintro ⟨q, hq⟩
  exact irrational_pi ⟨q, hq⟩

theorem pi_no_finite_base_fraction (a : ℤ) (b n : ℕ) :
    Real.pi ≠ (a : ℝ) / (b : ℝ) ^ n := by
  have h := irrational_pi.ne_rational a (b ^ n)
  simpa only [Int.cast_pow, Int.cast_natCast] using h

theorem irrational_can_have_arbitrarily_close_rationals (x : ℝ) (ε : ℝ)
    (hε : 0 < ε) : ∃ q : ℚ, 0 < (q : ℝ) - x ∧ (q : ℝ) - x < ε := by
  obtain ⟨q, hq₁, hq₂⟩ := exists_rat_btwn (show x < x + ε by linarith)
  exact ⟨q, by linarith, by linarith⟩

theorem transcendental_excludes_algebraic_representation (x : ℝ)
    (hx : Transcendental ℚ x) :
    ¬ ∃ y : ℝ, IsAlgebraic ℚ y ∧ y = x := by
  rintro ⟨y, hy, rfl⟩
  exact hx hy

theorem enlarged_real_polynomials_have_exact_root (x : ℝ) :
    ∃ p : Polynomial ℝ, p ≠ 0 ∧ p.eval x = 0 := by
  refine ⟨Polynomial.X - Polynomial.C x, ?_, ?_⟩
  · intro h
    have hc := congrArg (fun p : Polynomial ℝ => p.coeff 1) h
    simp at hc
  · simp

theorem e_exceeds_every_finite_factorial_sum (n : ℕ) :
    (∑ i ∈ Finset.range n, (1 : ℝ) / i.factorial) < Real.exp 1 := by
  have h := Real.sum_le_exp_of_nonneg (show (0 : ℝ) ≤ 1 by norm_num) (n + 1)
  simp only [Finset.sum_range_succ, one_pow] at h
  have hp : (0 : ℝ) < 1 / (n.factorial : ℝ) := by positivity
  linarith

theorem e_algebraic_class_closure_contract (h : Transcendental ℚ (Real.exp 1)) :
    ∀ p : Polynomial ℚ, p ≠ 0 → Polynomial.aeval (Real.exp 1) p ≠ 0 := by
  intro p hp he
  exact hp ((transcendental_iff.mp h) p he)

-- K. Reader instrument. Status completeness is a declared datatype contract.
inductive Status where
  | accepted | rejected | open | scopeChange
  deriving DecidableEq, Repr

structure Assessment (Claim Scope Evidence : Type*) where
  claim : Claim
  scope : Scope
  evidence : Evidence
  rule : Scope → Evidence → Status
  verdict : Status
  receipt : rule scope evidence = verdict

theorem consideration_has_an_applied_rule {C S E : Type*}
    (a : Assessment C S E) :
    ∃ rule : S → E → Status, rule a.scope a.evidence = a.verdict := ⟨a.rule, a.receipt⟩

theorem challenge_is_an_instance {C S E : Type*}
    (a : Assessment C S E) (rejects : a.verdict = Status.rejected) :
    a.rule a.scope a.evidence = Status.rejected := a.receipt.trans rejects

theorem shared_rule_scope_evidence_force_shared_status {C S E : Type*}
    (a b : Assessment C S E) (hr : a.rule = b.rule)
    (hs : a.scope = b.scope) (he : a.evidence = b.evidence) :
    a.verdict = b.verdict := by rw [← a.receipt, ← b.receipt, hr, hs, he]

theorem same_evidence_can_support_different_declared_rules :
    ∃ a b : Assessment Unit Unit Unit,
      a.claim = b.claim ∧ a.scope = b.scope ∧ a.evidence = b.evidence ∧
      a.verdict ≠ b.verdict := by
  refine ⟨⟨(), (), (), fun _ _ => .accepted, .accepted, rfl⟩,
    ⟨(), (), (), fun _ _ => .rejected, .rejected, rfl⟩, rfl, rfl, rfl, ?_⟩
  intro h; cases h

theorem receipt_does_not_certify_rule_soundness :
    ∃ a : Assessment Prop Unit Unit,
      a.claim = False ∧ a.verdict = Status.accepted :=
  ⟨⟨False, (), (), fun _ _ => .accepted, .accepted, rfl⟩, rfl, rfl⟩

theorem a_sound_rejection_can_defeat_a_claim (P : Prop)
    (soundRejection : ¬ P) : ¬ P := soundRejection

structure Record where
  text : String
  status : Status
  scope : String
  reason : String
  actor : String
  parent : Option ℕ
  deriving Repr

def append (history : List Record) (r : Record) : List Record := history ++ [r]

theorem any_finite_comment_can_be_registered (s : String) :
    ∃ r : Record, r.text = s := ⟨⟨s, .open, "unassigned", "awaiting classification", "unassigned", none⟩, rfl⟩

theorem append_preserves_earlier_records (history : List Record) (r old : Record)
    (h : old ∈ history) : old ∈ append history r := by simp [append, h]

theorem finite_registry_has_no_fixed_capacity (history : List Record) (r : Record) :
    (append history r).length = history.length + 1 := by simp [append]

theorem declared_statuses_exhaustive (s : Status) :
    s = .accepted ∨ s = .rejected ∨ s = .open ∨ s = .scopeChange := by cases s <;> simp

inductive StopMode (Actor : Type*) where
  | effective (testRan : Bool) (checked : testRan = true)
  | declared (actor : Actor)

theorem stop_mode_contract {Actor : Type*} (s : StopMode Actor) :
    (∃ b h, s = StopMode.effective b h) ∨
      (∃ actor, s = StopMode.declared actor) := by
  cases s with
  | effective b h => exact Or.inl ⟨b, h, rfl⟩
  | declared actor => exact Or.inr ⟨actor, rfl⟩

end LambdaInstrument

-- Exact theorem statements and transitive axiom dependencies.
#check LambdaInstrument.recovery_iff_fibre_constancy
#print axioms LambdaInstrument.recovery_iff_fibre_constancy
#check LambdaInstrument.collision_blocks_recovery
#print axioms LambdaInstrument.collision_blocks_recovery
#check LambdaInstrument.postprocessing_preserves_collision
#print axioms LambdaInstrument.postprocessing_preserves_collision
#check LambdaInstrument.enriched_readout_recovers_target
#print axioms LambdaInstrument.enriched_readout_recovers_target
#check LambdaInstrument.one_sided_certificate_contract
#print axioms LambdaInstrument.one_sided_certificate_contract
#check LambdaInstrument.entailed_condition_preserves_acceptance
#print axioms LambdaInstrument.entailed_condition_preserves_acceptance
#check LambdaInstrument.new_condition_changes_acceptance
#print axioms LambdaInstrument.new_condition_changes_acceptance
#check LambdaInstrument.equal_declared_inputs_equal_outputs
#print axioms LambdaInstrument.equal_declared_inputs_equal_outputs
#check LambdaInstrument.different_outputs_require_distinction
#print axioms LambdaInstrument.different_outputs_require_distinction
#check LambdaInstrument.no_refutation_is_not_a_general_proof
#print axioms LambdaInstrument.no_refutation_is_not_a_general_proof
#check LambdaInstrument.completeness_licenses_reversal
#print axioms LambdaInstrument.completeness_licenses_reversal
#check LambdaInstrument.existential_claim_needs_no_closed_form
#print axioms LambdaInstrument.existential_claim_needs_no_closed_form
#check LambdaInstrument.residual_equation_has_witness
#print axioms LambdaInstrument.residual_equation_has_witness
#check LambdaInstrument.residual_admissibility_is_the_obligation
#print axioms LambdaInstrument.residual_admissibility_is_the_obligation
#check LambdaInstrument.finite_window_has_opposite_extensions
#print axioms LambdaInstrument.finite_window_has_opposite_extensions
#check LambdaInstrument.no_fixed_window_decides_unrestricted_tail
#print axioms LambdaInstrument.no_fixed_window_decides_unrestricted_tail
#check LambdaInstrument.universal_proof_closes_all_windows
#print axioms LambdaInstrument.universal_proof_closes_all_windows
#check LambdaInstrument.all_windows_iff_all_stages
#print axioms LambdaInstrument.all_windows_iff_all_stages
#check LambdaInstrument.actual_failure_refutes_tail
#print axioms LambdaInstrument.actual_failure_refutes_tail
#check LambdaInstrument.tail_negation_has_failure
#print axioms LambdaInstrument.tail_negation_has_failure
#check LambdaInstrument.unforced_failure_is_admitted_forced_failure
#print axioms LambdaInstrument.unforced_failure_is_admitted_forced_failure
#check LambdaInstrument.forced_failure_can_coexist_with_unforced_global
#print axioms LambdaInstrument.forced_failure_can_coexist_with_unforced_global
#check LambdaInstrument.ns_regularity_requires_each_window
#print axioms LambdaInstrument.ns_regularity_requires_each_window
#check LambdaInstrument.ns_uniform_bound_excludes_encoded_blowup
#print axioms LambdaInstrument.ns_uniform_bound_excludes_encoded_blowup
#check LambdaInstrument.invariant_exact_classifier
#print axioms LambdaInstrument.invariant_exact_classifier
#check LambdaInstrument.sufficient_condition_need_not_be_invariant
#print axioms LambdaInstrument.sufficient_condition_need_not_be_invariant
#check LambdaInstrument.rh_counterexample_duality
#print axioms LambdaInstrument.rh_counterexample_duality
#check LambdaInstrument.rh_tail_transport
#print axioms LambdaInstrument.rh_tail_transport
#check LambdaInstrument.uniform_gap_implies_pointwise_positive
#print axioms LambdaInstrument.uniform_gap_implies_pointwise_positive
#check LambdaInstrument.pointwise_positive_need_not_have_uniform_gap
#print axioms LambdaInstrument.pointwise_positive_need_not_have_uniform_gap
#check LambdaInstrument.common_gap_survives_order_limit
#print axioms LambdaInstrument.common_gap_survives_order_limit
#check LambdaInstrument.hodge_actual_cycle_closes_instance
#print axioms LambdaInstrument.hodge_actual_cycle_closes_instance
#check LambdaInstrument.hodge_nonmembership_requires_all_cycles
#print axioms LambdaInstrument.hodge_nonmembership_requires_all_cycles
#check LambdaInstrument.hodge_separating_invariant_closes_nonmembership
#print axioms LambdaInstrument.hodge_separating_invariant_closes_nonmembership
#check LambdaInstrument.hodge_finite_empty_search_not_universal
#print axioms LambdaInstrument.hodge_finite_empty_search_not_universal
#check LambdaInstrument.pnp_quantifier_duality
#print axioms LambdaInstrument.pnp_quantifier_duality
#check LambdaInstrument.pnp_candidate_with_all_input_proof_closes
#print axioms LambdaInstrument.pnp_candidate_with_all_input_proof_closes
#check LambdaInstrument.bounded_tests_do_not_prove_candidate
#print axioms LambdaInstrument.bounded_tests_do_not_prove_candidate
#check LambdaInstrument.bsd_matching_bounds_close_rank
#print axioms LambdaInstrument.bsd_matching_bounds_close_rank
#check LambdaInstrument.bsd_matching_certificates_close_instance
#print axioms LambdaInstrument.bsd_matching_certificates_close_instance
#check LambdaInstrument.exact_order_unique
#print axioms LambdaInstrument.exact_order_unique
#check LambdaInstrument.nonzero_term_alone_not_exact_order
#print axioms LambdaInstrument.nonzero_term_alone_not_exact_order
#check LambdaInstrument.product_readout_loses_factor
#print axioms LambdaInstrument.product_readout_loses_factor
#check LambdaInstrument.anchored_product_recovers_factor
#print axioms LambdaInstrument.anchored_product_recovers_factor
#check LambdaInstrument.pi_outside_rational_image
#print axioms LambdaInstrument.pi_outside_rational_image
#check LambdaInstrument.pi_no_finite_base_fraction
#print axioms LambdaInstrument.pi_no_finite_base_fraction
#check LambdaInstrument.irrational_can_have_arbitrarily_close_rationals
#print axioms LambdaInstrument.irrational_can_have_arbitrarily_close_rationals
#check LambdaInstrument.transcendental_excludes_algebraic_representation
#print axioms LambdaInstrument.transcendental_excludes_algebraic_representation
#check LambdaInstrument.enlarged_real_polynomials_have_exact_root
#print axioms LambdaInstrument.enlarged_real_polynomials_have_exact_root
#check LambdaInstrument.e_exceeds_every_finite_factorial_sum
#print axioms LambdaInstrument.e_exceeds_every_finite_factorial_sum
#check LambdaInstrument.e_algebraic_class_closure_contract
#print axioms LambdaInstrument.e_algebraic_class_closure_contract
#check LambdaInstrument.consideration_has_an_applied_rule
#print axioms LambdaInstrument.consideration_has_an_applied_rule
#check LambdaInstrument.challenge_is_an_instance
#print axioms LambdaInstrument.challenge_is_an_instance
#check LambdaInstrument.shared_rule_scope_evidence_force_shared_status
#print axioms LambdaInstrument.shared_rule_scope_evidence_force_shared_status
#check LambdaInstrument.same_evidence_can_support_different_declared_rules
#print axioms LambdaInstrument.same_evidence_can_support_different_declared_rules
#check LambdaInstrument.receipt_does_not_certify_rule_soundness
#print axioms LambdaInstrument.receipt_does_not_certify_rule_soundness
#check LambdaInstrument.a_sound_rejection_can_defeat_a_claim
#print axioms LambdaInstrument.a_sound_rejection_can_defeat_a_claim
#check LambdaInstrument.any_finite_comment_can_be_registered
#print axioms LambdaInstrument.any_finite_comment_can_be_registered
#check LambdaInstrument.append_preserves_earlier_records
#print axioms LambdaInstrument.append_preserves_earlier_records
#check LambdaInstrument.finite_registry_has_no_fixed_capacity
#print axioms LambdaInstrument.finite_registry_has_no_fixed_capacity
#check LambdaInstrument.declared_statuses_exhaustive
#print axioms LambdaInstrument.declared_statuses_exhaustive
#check LambdaInstrument.stop_mode_contract
#print axioms LambdaInstrument.stop_mode_contract
#eval Lean.versionString
#eval "LAMBDA_INSTRUMENT_R1"
