import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Real.Pi.Irrational
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Basic.ENNReal.Basic
import Mathlib.Data.Nat.Prime.Basic

/-!
Part II: exact arithmetic, spectral projection, and indexed residue.
The ledger in the paper gives the scope of each declaration.
-/
namespace EnumerativeEnergy

theorem prime_iff_no_intermediate_divisor (n : ℕ) (hn : 2 ≤ n) :
    Nat.Prime n ↔ ¬ ∃ d : ℕ, d ∣ n ∧ 2 ≤ d ∧ d < n := by
  constructor
  · intro hp
    rintro ⟨d, hd, htwo, hlt⟩
    have hne : d ≠ 1 := by omega
    have heq := (hp.dvd_iff_eq hne).mp hd
    omega
  · intro h
    by_contra hnp
    exact h (Nat.exists_dvd_of_not_prime2 hn hnp)

theorem prime_step_gcd_one (p k : ℕ) (hp : Nat.Prime p)
    (hk : 0 < k) (hkp : k < p) : Nat.gcd p k = 1 := by
  exact (Nat.coprime_of_lt_prime (Nat.ne_of_gt hk) hkp hp).gcd_eq_one

theorem shared_divisibility (n m d : ℕ) :
    d ∣ Nat.gcd n m ↔ d ∣ n ∧ d ∣ m := by
  exact Nat.dvd_gcd_iff

theorem simultaneous_return (n m t : ℕ) :
    Nat.lcm n m ∣ t ↔ n ∣ t ∧ m ∣ t := by
  exact Nat.lcm_dvd_iff

def orbit {A : Type*} (f : A → A) : ℕ → A → A
  | 0, x => x
  | n + 1, x => f (orbit f n x)

theorem relabeling_preserves_orbit {A B : Type*}
    (e : A ≃ B) (f : A → A) (n : ℕ) (x : A) :
    orbit (fun y => e (f (e.symm y))) n (e x) = e (orbit f n x) := by
  induction n with
  | zero => rfl
  | succ n ih =>
    simp only [orbit, ih, Equiv.symm_apply_apply]

theorem relabeling_preserves_return {A B : Type*}
    (e : A ≃ B) (f : A → A) (n : ℕ) (x : A) :
    orbit (fun y => e (f (e.symm y))) n (e x) = e x ↔ orbit f n x = x := by
  rw [relabeling_preserves_orbit]
  exact e.injective.eq_iff

noncomputable def spectralRead (z : ℂ) : ℂ := 2 - z - z⁻¹

theorem inversion_preserves_spectral_read (z : ℂ) :
    spectralRead z⁻¹ = spectralRead z := by
  simp only [spectralRead, inv_inv]
  ring

theorem spectral_collision_has_two_branches (z w : ℂ)
    (hz : z ≠ 0) (hw : w ≠ 0) (h : spectralRead z = spectralRead w) :
    z = w ∨ z * w = 1 := by
  have hid : (spectralRead z - spectralRead w) * (z * w) =
      -(z - w) * (z * w - 1) := by
    dsimp [spectralRead]
    field_simp
    ring
  rw [h, sub_self, zero_mul] at hid
  have hp : (z - w) * (z * w - 1) = 0 := by
    linear_combination hid
  rcases mul_eq_zero.mp hp with heq | hinv
  · exact Or.inl (sub_eq_zero.mp heq)
  · exact Or.inr (sub_eq_zero.mp hinv)

theorem spectral_read_cannot_recover_phase (z : ℂ) (hz : z ≠ 0)
    (hd : z ≠ z⁻¹) :
    ¬ ∃ f : ℂ → ℂ, ∀ w : ℂ, w ≠ 0 → f (spectralRead w) = w := by
  rintro ⟨f, hf⟩
  have h1 := hf z hz
  have h2 := hf z⁻¹ (inv_ne_zero hz)
  rw [inversion_preserves_spectral_read] at h2
  exact hd (h1.symm.trans h2)

theorem ordered_count_from_union_data {A : Type*} [DecidableEq A]
    (s t : Finset A) (g f : ℕ)
    (hs : s.card = g) (ht : t.card = g) (hi : (s ∩ t).card = f) :
    (s ∪ t).card = 2 * g - f := by
  have h := Finset.card_union_add_card_inter s t
  omega

theorem common_energy_shift_preserves_gaps (a b offset : ℝ) :
    (a + offset) - (b + offset) = a - b := by ring

theorem calibration_rescaling_preserves_phase (scale energy time : ℝ)
    (hs : scale ≠ 0) :
    (scale * energy) * (time / scale) = energy * time := by
  field_simp

noncomputable def indexedResidue {A : Type*} (S : Set A) (cost : A → ENNReal) : ENNReal :=
  sInf (cost '' S)

theorem residue_monotone {A : Type*} (S T : Set A)
    (cost : A → ENNReal) (h : S ⊆ T) :
    indexedResidue T cost ≤ indexedResidue S cost := by
  unfold indexedResidue
  apply sInf_le_sInf
  rintro y ⟨x, hx, rfl⟩
  exact ⟨x, h hx, rfl⟩

theorem conservative_representation_preserves_theorems {P T : Type*}
    (R0 R1 : Set P) (conclusion : P → T) (expand : P → P)
    (hin : R0 ⊆ R1)
    (hex : ∀ p ∈ R1, expand p ∈ R0 ∧ conclusion (expand p) = conclusion p)
    (target : T) :
    (∃ p ∈ R0, conclusion p = target) ↔ (∃ p ∈ R1, conclusion p = target) := by
  constructor
  · rintro ⟨p, hp, hc⟩
    exact ⟨p, hin hp, hc⟩
  · rintro ⟨p, hp, hc⟩
    obtain ⟨he, ht⟩ := hex p hp
    exact ⟨expand p, he, ht.trans hc⟩

theorem pointwise_positivity_not_uniform :
    (∀ x : ℝ, 0 < x → 0 < x) ∧
    ¬ ∃ epsilon : ℝ, 0 < epsilon ∧ ∀ x : ℝ, 0 < x → epsilon ≤ x := by
  constructor
  · intro x hx
    exact hx
  · rintro ⟨epsilon, he, hbound⟩
    have hhalf : 0 < epsilon / 2 := by linarith
    have hh := hbound (epsilon / 2) hhalf
    linarith

end EnumerativeEnergy

namespace LambdaPhysical

def boostTime (g b T x : ℝ) : ℝ := g * (T - b * x)
def boostSpace (g b T x : ℝ) : ℝ := g * (x - b * T)
def interval (T x : ℝ) : ℝ := x ^ 2 - T ^ 2

theorem boosted_time_needs_space (g b : ℝ) (hg : g ≠ 0) (hb : b ≠ 0) :
    ¬ ∃ f : ℝ → ℝ, ∀ T x, f T = boostTime g b T x := by
  rintro ⟨f, hf⟩
  have h0 := hf 0 0
  have h1 := hf 0 1
  simp only [boostTime, mul_zero, sub_zero] at h0
  simp only [boostTime, mul_one, zero_sub] at h1
  have hgb : g * b = 0 := by nlinarith
  exact (mul_ne_zero hg hb) hgb

theorem boosted_space_needs_time (g b : ℝ) (hg : g ≠ 0) (hb : b ≠ 0) :
    ¬ ∃ f : ℝ → ℝ, ∀ T x, f x = boostSpace g b T x := by
  rintro ⟨f, hf⟩
  have h0 := hf 0 0
  have h1 := hf 1 0
  simp only [boostSpace, mul_zero, sub_zero] at h0
  simp only [boostSpace, mul_one, zero_sub] at h1
  have hgb : g * b = 0 := by nlinarith
  exact (mul_ne_zero hg hb) hgb

theorem lorentz_interval_preserved (g b T x : ℝ)
    (hn : g ^ 2 * (1 - b ^ 2) = 1) :
    interval (boostTime g b T x) (boostSpace g b T x) = interval T x := by
  unfold interval boostTime boostSpace
  calc
    (g * (x - b * T)) ^ 2 - (g * (T - b * x)) ^ 2 =
        (g ^ 2 * (1 - b ^ 2)) * (x ^ 2 - T ^ 2) := by ring
    _ = x ^ 2 - T ^ 2 := by rw [hn]; ring

theorem lorentz_null_preserved (g b T x : ℝ)
    (hn : g ^ 2 * (1 - b ^ 2) = 1) :
    (interval (boostTime g b T x) (boostSpace g b T x) = 0) ↔
    interval T x = 0 := by
  rw [lorentz_interval_preserved g b T x hn]

theorem timelike_not_time_only :
    ¬ ∃ P : ℝ → Prop, ∀ T x, P T ↔ interval T x < 0 := by
  rintro ⟨P, h⟩
  have hp : P 1 := (h 1 0).mpr (by norm_num [interval])
  have hn := (h 1 2).mp hp
  norm_num [interval] at hn

theorem timelike_not_space_only :
    ¬ ∃ P : ℝ → Prop, ∀ T x, P x ↔ interval T x < 0 := by
  rintro ⟨P, h⟩
  have hp : P 1 := (h 2 1).mpr (by norm_num [interval])
  have hn := (h 0 1).mp hp
  norm_num [interval] at hn

theorem fixed_c_couples_unit_rescaling (c L U : ℝ)
    (hc : c ≠ 0) (hL : L ≠ 0) (h : c * U / L = c) : L = U := by
  have he : c * U = c * L := (div_eq_iff hL).mp h
  exact (mul_left_cancel₀ hc he).symm

theorem calibrated_ratios_determine_values {I : Type*}
    (r E F : I → ℝ) (anchor : ℝ)
    (hE : ∀ i, E i = r i * anchor)
    (hF : ∀ i, F i = r i * anchor) : E = F := by
  funext i
  exact (hE i).trans (hF i).symm


end LambdaPhysical

#check EnumerativeEnergy.prime_iff_no_intermediate_divisor
#check EnumerativeEnergy.prime_step_gcd_one
#check EnumerativeEnergy.shared_divisibility
#check EnumerativeEnergy.simultaneous_return
#check EnumerativeEnergy.relabeling_preserves_orbit
#check EnumerativeEnergy.relabeling_preserves_return
#check EnumerativeEnergy.inversion_preserves_spectral_read
#check EnumerativeEnergy.spectral_collision_has_two_branches
#check EnumerativeEnergy.spectral_read_cannot_recover_phase
#check EnumerativeEnergy.ordered_count_from_union_data
#check EnumerativeEnergy.common_energy_shift_preserves_gaps
#check EnumerativeEnergy.calibration_rescaling_preserves_phase
#check EnumerativeEnergy.residue_monotone
#check EnumerativeEnergy.conservative_representation_preserves_theorems
#check EnumerativeEnergy.pointwise_positivity_not_uniform
#check LambdaPhysical.boosted_time_needs_space
#check LambdaPhysical.boosted_space_needs_time
#check LambdaPhysical.lorentz_interval_preserved
#check LambdaPhysical.lorentz_null_preserved
#check LambdaPhysical.timelike_not_time_only
#check LambdaPhysical.timelike_not_space_only
#check LambdaPhysical.fixed_c_couples_unit_rescaling
#check LambdaPhysical.calibrated_ratios_determine_values
#print axioms EnumerativeEnergy.prime_iff_no_intermediate_divisor
#print axioms EnumerativeEnergy.prime_step_gcd_one
#print axioms EnumerativeEnergy.shared_divisibility
#print axioms EnumerativeEnergy.simultaneous_return
#print axioms EnumerativeEnergy.relabeling_preserves_orbit
#print axioms EnumerativeEnergy.relabeling_preserves_return
#print axioms EnumerativeEnergy.inversion_preserves_spectral_read
#print axioms EnumerativeEnergy.spectral_collision_has_two_branches
#print axioms EnumerativeEnergy.spectral_read_cannot_recover_phase
#print axioms EnumerativeEnergy.ordered_count_from_union_data
#print axioms EnumerativeEnergy.common_energy_shift_preserves_gaps
#print axioms EnumerativeEnergy.calibration_rescaling_preserves_phase
#print axioms EnumerativeEnergy.residue_monotone
#print axioms EnumerativeEnergy.conservative_representation_preserves_theorems
#print axioms EnumerativeEnergy.pointwise_positivity_not_uniform
#print axioms LambdaPhysical.boosted_time_needs_space
#print axioms LambdaPhysical.boosted_space_needs_time
#print axioms LambdaPhysical.lorentz_interval_preserved
#print axioms LambdaPhysical.lorentz_null_preserved
#print axioms LambdaPhysical.timelike_not_time_only
#print axioms LambdaPhysical.timelike_not_space_only
#print axioms LambdaPhysical.fixed_c_couples_unit_rescaling
#print axioms LambdaPhysical.calibrated_ratios_determine_values
#eval Lean.versionString
#eval "LAMBDA_PART_II_AUDIT_COMPLETE"
