import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Real.Pi.Irrational
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Analysis.Complex.Exponential
import Mathlib.Data.Fintype.Pigeonhole
import Mathlib.Basic.ENNReal.Basic
import Mathlib.Data.Nat.Prime.Basic

/-!
# Lambda Part III — Successor Discipline, the Collision Dichotomy, and Hypothesis Necessity

Formal kernel for the companion paper.

SCOPE. This file checks only the propositions encoded below. The terms `scope`,
`absolute`, `priority`, `resource`, `criterion`, `handshake`, and `successor`
receive only the formal roles explicitly assigned here. Physical, linguistic,
institutional, and ontological readings require separate bridge arguments in the
paper, which are not encoded.

STATUS. Submitted source. The execution receipt is PENDING until a run is
captured. No acceptance is asserted by the presence of this file.
-/

namespace LambdaIII

/-! ## Section 1. The collision dichotomy

Part I K08/K09 and Part II Proposition 2.1 state one direction of this pair.
L03/L04 supply the converse, turning a one-sided obstruction into a dichotomy.
-/

/-- `Q` is recoverable from the readout `P`. -/
def FactorsThrough {X Y Z : Type*} (P : X → Y) (Q : X → Z) : Prop :=
  ∃ g : Y → Z, ∀ x, g (P x) = Q x

/-- L01. A collision in `P` across which `Q` differs blocks every decoder. -/
theorem collision_blocks_factorization {X Y Z : Type*}
    (P : X → Y) (Q : X → Z) {x₁ x₂ : X}
    (hP : P x₁ = P x₂) (hQ : Q x₁ ≠ Q x₂) :
    ¬ FactorsThrough P Q := by
  rintro ⟨g, hg⟩
  exact hQ (by rw [← hg x₁, ← hg x₂, hP])

/-- L02. Recovering the identity target forces injectivity. -/
theorem id_factors_implies_injective {X Y : Type*} (P : X → Y)
    (h : FactorsThrough P (id : X → X)) : Function.Injective P := by
  obtain ⟨g, hg⟩ := h
  intro a b hab
  have ha : g (P a) = a := hg a
  have hb : g (P b) = b := hg b
  rw [← ha, ← hb, hab]

/-- L03. An injective readout recovers every target. -/
theorem injective_factors_all {X Y Z : Type*} [Nonempty X]
    (P : X → Y) (hinj : Function.Injective P) (Q : X → Z) :
    FactorsThrough P Q :=
  ⟨fun y => Q (Function.invFun P y), fun x => by
    exact congrArg Q (Function.leftInverse_invFun hinj x)⟩

/-- L04. THE DICHOTOMY. A readout either loses nothing or has a collision witness. -/
theorem factorization_dichotomy {X Y : Type*} [Nonempty X] (P : X → Y) :
    Function.Injective P ↔ FactorsThrough P (id : X → X) :=
  ⟨fun h => injective_factors_all P h id, id_factors_implies_injective P⟩

/-- L05. Failure of injectivity is always witnessed by a named pair. -/
theorem not_injective_iff_collision {X Y : Type*} (P : X → Y) :
    ¬ Function.Injective P ↔ ∃ x₁ x₂, P x₁ = P x₂ ∧ x₁ ≠ x₂ := by
  constructor
  · intro h
    by_contra hc
    push Not at hc
    exact h (fun a b hab => hc a b hab)
  · rintro ⟨x₁, x₂, heq, hne⟩ h
    exact hne (h heq)

/-! ## Section 2. Scope retention and the asymmetry of revision

The safe direction of revision is not a house rule. It follows from Section 1.
-/

/-- A claim carried together with the scope index under which it was established. -/
structure ScopedClaim (P S : Type*) where
  prop : P
  scope : S

/-- L06. A successor that retains the scope index leaves the predecessor recoverable. -/
theorem scope_retained_is_recoverable {P S : Type*} :
    FactorsThrough (fun c : ScopedClaim P S => (c.prop, c.scope)) (fun c => c.scope) :=
  ⟨fun p => p.2, fun _ => rfl⟩

/-- L07. A successor that forgets the scope index is irrecoverable, by L01. -/
theorem scope_forgotten_is_not_recoverable {P S : Type*}
    (p : P) {s₁ s₂ : S} (hs : s₁ ≠ s₂) :
    ¬ FactorsThrough (fun c : ScopedClaim P S => c.prop) (fun c => c.scope) :=
  collision_blocks_factorization
    (fun c : ScopedClaim P S => c.prop) (fun c => c.scope)
    (x₁ := ⟨p, s₁⟩) (x₂ := ⟨p, s₂⟩) rfl hs

/-! ## Section 3. The successor taxonomy as a checkable object -/

/-- The admitted successor operations of the revision policy. `obstructionProved`
was added on review: L01, L53 and the imported symmetry obstruction all deliver
exactly that outcome, and the Before-the-Bridge charter names it among the
acceptable returns, but the original seven had no category for it. -/
inductive SuccessorKind where
  | error
  | redundantHypothesis
  | scopeCorrection
  | bridgeRevision
  | absorption
  | supersession
  | warrantLapse
  | obstructionProved
  deriving DecidableEq, Repr

/-- Which successor operations retract a previously accepted formal result. -/
def RetractsFormalResult : SuccessorKind → Bool
  | .error => true
  | _ => false

/-- L08. Exactly one successor category reaches back into an accepted result. -/
theorem only_error_retracts (k : SuccessorKind) :
    RetractsFormalResult k = true ↔ k = SuccessorKind.error := by
  cases k <;> simp [RetractsFormalResult]

/-- L09. Warrant lapse does not retract the formal result. -/
theorem warrant_lapse_does_not_retract :
    RetractsFormalResult SuccessorKind.warrantLapse = false := rfl

/-! ## Section 4. Criteria, exclusion, and the classical boundary -/

def SelfSide {X : Type*} (criterion : X → Bool) (x : X) : Prop := criterion x = true
def OtherSide {X : Type*} (criterion : X → Bool) (x : X) : Prop := criterion x = false
def ExcludedBy {X : Type*} (criterion : X → Prop) (x : X) : Prop := ¬ criterion x

/-- L10. The two sides of a Boolean criterion are exhaustive. -/
theorem criterion_sides_exhaustive {X : Type*} (c : X → Bool) (x : X) :
    SelfSide c x ∨ OtherSide c x := by
  simp only [SelfSide, OtherSide]
  cases hc : c x
  · exact Or.inr rfl
  · exact Or.inl rfl

/-- L11. The two sides of a Boolean criterion are exclusive. -/
theorem criterion_sides_exclusive {X : Type*} (c : X → Bool) (x : X) :
    ¬ (SelfSide c x ∧ OtherSide c x) := by
  rintro ⟨h1, h2⟩
  simp only [SelfSide] at h1
  simp only [OtherSide] at h2
  rw [h1] at h2
  exact Bool.noConfusion h2

/-- L12. Double exclusion is double negation, with no axiom cost. -/
theorem double_exclusion_is_double_negation {X : Type*} (P : X → Prop) (x : X) :
    ExcludedBy (ExcludedBy P) x ↔ ¬ ¬ P x := Iff.rfl

/-- L13. Collapsing double exclusion is the classical step. The axiom report on
this declaration, compared with L12, is the intended marker. -/
theorem double_exclusion_collapse {X : Type*} (P : X → Prop) (x : X) :
    ExcludedBy (ExcludedBy P) x ↔ P x := not_not

/-- L14. BINARY INADEQUACY. On a domain with more than two states, every Boolean
criterion has a collision, hence fails to recover the identity target. -/
theorem binary_criterion_has_collision {X : Type*} [Fintype X]
    (c : X → Bool) (hcard : 2 < Fintype.card X) :
    ∃ x₁ x₂ : X, c x₁ = c x₂ ∧ x₁ ≠ x₂ := by
  have hlt : Fintype.card Bool < Fintype.card X := by simpa using hcard
  obtain ⟨x₁, x₂, hne, heq⟩ := Fintype.exists_ne_map_eq_of_card_lt c hlt
  exact ⟨x₁, x₂, heq, hne⟩

/-- L15. The corresponding non-recovery statement. -/
theorem binary_criterion_not_faithful {X : Type*} [Fintype X]
    (c : X → Bool) (hcard : 2 < Fintype.card X) :
    ¬ FactorsThrough c (id : X → X) := by
  obtain ⟨x₁, x₂, heq, hne⟩ := binary_criterion_has_collision c hcard
  exact collision_blocks_factorization c id heq (by simpa using hne)

/-! ## Section 5. Absolute labels -/

/-- L16. A predicate carrying both an introduction and an elimination rule is the
identity predicate, hence contributes no content. Strengthens Part I K17. -/
theorem absolute_with_both_rules_is_identity
    (A : Prop → Prop) (hintro : ∀ p, p → A p) (helim : ∀ p, A p → p) :
    A = id := by
  funext p
  show A p = p
  exact propext ⟨helim p, hintro p⟩

/-! ## Section 6. The n-ary no-first-position result

Part I K15 is the n = 2 case of L18 below.
-/

def AbsolutePriority {C : Type*} (Priority UsesComplement : C → Prop) (c : C) : Prop :=
  Priority c ∧ ¬ UsesComplement c

/-- L17. Generic absolute-priority obstruction, restated for reference. -/
theorem complement_requirement_blocks_absolute_priority
    {C : Type*} (Priority UsesComplement : C → Prop)
    (hbridge : ∀ c, Priority c → UsesComplement c) :
    ¬ ∃ c, AbsolutePriority Priority UsesComplement c := by
  rintro ⟨c, hp, hnot⟩
  exact hnot (hbridge c hp)

/-- A cyclic chain of descriptive resources: a priority claim at station `i`
uses the resource at station `i + 1`. -/
structure ResourceChain (n : ℕ) [NeZero n] (Claim : Type*) where
  Priority : Fin n → Claim → Prop
  Uses : Fin n → Claim → Prop
  chain : ∀ (i : Fin n) (c : Claim), Priority i c → Uses (i + 1) c

def AbsolutePriorityAt {n : ℕ} [NeZero n] {Claim : Type*} (R : ResourceChain n Claim)
    (i : Fin n) (c : Claim) : Prop :=
  AbsolutePriority (R.Priority i) (R.Uses (i + 1)) c

/-- L18. N-ARY NO-FIRST-POSITION. In a cyclic resource chain of any length, no
station holds complement-free absolute priority. -/
theorem no_first_position_cyclic {n : ℕ} [NeZero n] {Claim : Type*}
    (R : ResourceChain n Claim) (i : Fin n) :
    ¬ ∃ c, AbsolutePriorityAt R i c :=
  complement_requirement_blocks_absolute_priority
    (R.Priority i) (R.Uses (i + 1)) (R.chain i)

/-! ## Section 7. Handshake closure

Part I K20 proves composition. L19–L22 prove closure under the propositional
connectives, so a verified handshake on atoms extends to their Boolean closure.
-/

def PreservesPredicate {A B : Type*} (f : A → B) (P : A → Prop) (Q : B → Prop) : Prop :=
  ∀ a, P a ↔ Q (f a)

theorem preserves_and {A B : Type*} (f : A → B) (P₁ P₂ : A → Prop) (Q₁ Q₂ : B → Prop)
    (h₁ : PreservesPredicate f P₁ Q₁) (h₂ : PreservesPredicate f P₂ Q₂) :
    PreservesPredicate f (fun a => P₁ a ∧ P₂ a) (fun b => Q₁ b ∧ Q₂ b) :=
  fun a => and_congr (h₁ a) (h₂ a)

theorem preserves_or {A B : Type*} (f : A → B) (P₁ P₂ : A → Prop) (Q₁ Q₂ : B → Prop)
    (h₁ : PreservesPredicate f P₁ Q₁) (h₂ : PreservesPredicate f P₂ Q₂) :
    PreservesPredicate f (fun a => P₁ a ∨ P₂ a) (fun b => Q₁ b ∨ Q₂ b) :=
  fun a => or_congr (h₁ a) (h₂ a)

theorem preserves_not {A B : Type*} (f : A → B) (P : A → Prop) (Q : B → Prop)
    (h : PreservesPredicate f P Q) :
    PreservesPredicate f (fun a => ¬ P a) (fun b => ¬ Q b) :=
  fun a => not_congr (h a)

theorem preserves_imp {A B : Type*} (f : A → B) (P₁ P₂ : A → Prop) (Q₁ Q₂ : B → Prop)
    (h₁ : PreservesPredicate f P₁ Q₁) (h₂ : PreservesPredicate f P₂ Q₂) :
    PreservesPredicate f (fun a => P₁ a → P₂ a) (fun b => Q₁ b → Q₂ b) :=
  fun a => imp_congr (h₁ a) (h₂ a)

/-- L23. Noncommuting translations still agree on a preserved predicate.
This is the exact formal content of Part I section 18: test the predicate before
declaring a contradiction. -/
theorem preserved_predicate_agrees_despite_noncommutation
    {A B C : Type*} (AB : A → B) (BC : B → C) (AC : A → C)
    (P : A → Prop) (Q : B → Prop) (R : C → Prop)
    (hAB : PreservesPredicate AB P Q) (hBC : PreservesPredicate BC Q R)
    (hAC : PreservesPredicate AC P R) (a : A) :
    R (AC a) ↔ R (BC (AB a)) :=
  (hAC a).symm.trans ((hAB a).trans (hBC (AB a)))

/-! ## Section 8. Finite budget, n tasks -/

/-- L24. Part I K22 generalized from two demands to a finite family. -/
theorem finite_budget_forces_tradeoff_n {ι : Type*} (s : Finset ι)
    (cost alloc : ι → ℕ) (budget : ℕ)
    (hDemand : budget < ∑ i ∈ s, cost i)
    (hBudget : ∑ i ∈ s, alloc i ≤ budget)
    (hFull : ∀ i ∈ s, cost i ≤ alloc i) : False := by
  have hsum : ∑ i ∈ s, cost i ≤ ∑ i ∈ s, alloc i := Finset.sum_le_sum hFull
  omega

/-! ## Section 9. Interpretation is not fixed by finite metadata -/

/-- L25. Part I K23 says non-uniqueness of interpretation is possible. L25 says
no finite body of pointwise metadata removes it. -/
theorem finite_metadata_leaves_freedom (s : Finset ℕ) :
    ∃ I₀ I₁ : ℕ → Bool, (∀ n ∈ s, I₀ n = I₁ n) ∧ I₀ ≠ I₁ := by
  classical
  let m := s.sup id + 1
  have hm : m ∉ s := by
    intro hmem
    have hle : m ≤ s.sup id := Finset.le_sup (f := id) hmem
    dsimp [m] at hle
    omega
  refine ⟨fun n => decide (n ∈ s), fun n => decide (n ∈ s ∨ n = m), ?_, ?_⟩
  · intro n hn; simp [hn]
  · intro hcontra
    have hm' := congrFun hcontra m
    simp [hm] at hm'

/-! ## Section 10. Discrete registries attain their minimum

Part II E15 shows a real-valued cost can be everywhere positive with zero
infimum. L26 supplies the complement for natural-number cost.
-/

/-- L26. A nonempty natural-number cost registry attains its infimum. -/
theorem nat_cost_registry_attains_minimum (S : Set ℕ) (cost : ℕ → ℕ)
    (hne : ∃ x, x ∈ S) :
    ∃ x ∈ S, ∀ y ∈ S, cost x ≤ cost y := by
  classical
  obtain ⟨x₀, hx₀⟩ := hne
  have hex : ∃ n, ∃ x ∈ S, cost x = n := ⟨cost x₀, x₀, hx₀, rfl⟩
  obtain ⟨x, hxS, hxeq⟩ := Nat.find_spec hex
  refine ⟨x, hxS, fun y hy => ?_⟩
  rw [hxeq]
  exact Nat.find_le ⟨y, hy, rfl⟩

/-! ## Section 11. Spectral and calibration results -/

/-- L27. Part II E11 converse: gap data determines the spectrum up to one
additive constant. -/
theorem gaps_determine_up_to_shift {I : Type*} (E F : I → ℝ) (i₀ : I)
    (hgap : ∀ i j, E i - E j = F i - F j) (i : I) :
    F i = E i + (F i₀ - E i₀) := by
  have h := hgap i i₀
  linarith

/-- L28. The affine calibration of a spectrum is unique once two values differ. -/
theorem affine_calibration_unique {I : Type*} (E : I → ℝ) (a a' b b' : ℝ) (i j : I)
    (hij : E i ≠ E j) (h : ∀ k, a * E k + b = a' * E k + b') :
    a = a' ∧ b = b' := by
  have hi := h i
  have hj := h j
  have hfac : (a - a') * (E i - E j) = 0 := by linear_combination hi - hj
  have ha : a = a' := by
    rcases mul_eq_zero.mp hfac with h1 | h2
    · linarith
    · exact absurd (sub_eq_zero.mp h2) hij
  refine ⟨ha, ?_⟩
  rw [ha] at hi
  linarith

/-- L29. The distinct-count parity identity used by Part II Theorem 6.2.
Closes the arithmetic half of the gap that Part II section 14.2 discloses. -/
theorem distinct_count_parity (g : ℕ) :
    (g + Nat.gcd g 2) / 2 = g / 2 + 1 := by
  have hdvd : Nat.gcd g 2 ∣ 2 := Nat.gcd_dvd_right g 2
  rcases (Nat.dvd_prime Nat.prime_two).mp hdvd with h1 | h2
  · have hnd : ¬ (2 : ℕ) ∣ g := by
      intro hd
      have h2g : (2 : ℕ) ∣ Nat.gcd g 2 := Nat.dvd_gcd hd dvd_rfl
      rw [h1] at h2g
      omega
    rw [h1]
    omega
  · have hd : (2 : ℕ) ∣ g := by
      have hgl := Nat.gcd_dvd_left g 2
      rwa [h2] at hgl
    rw [h2]
    omega

/-! ## Section 12. Lorentz orientation and rigidity -/

def boostTime (g b T x : ℝ) : ℝ := g * (T - b * x)
def boostSpace (g b T x : ℝ) : ℝ := g * (x - b * T)
def interval (T x : ℝ) : ℝ := x ^ 2 - T ^ 2

/-- L30. A physical boost preserves time orientation on the timelike set.
Part II states time orientation as additional data; on timelike separations it
is preserved rather than independently assumed. -/
theorem boost_preserves_time_orientation (g b T x : ℝ)
    (hg : 0 < g) (hb1 : -1 < b) (hb2 : b < 1)
    (htl : x ^ 2 < T ^ 2) (hT : 0 < T) :
    0 < boostTime g b T x := by
  have hxu : x < T := by
    by_contra hcon
    push Not at hcon
    nlinarith [mul_nonneg (by linarith : (0:ℝ) ≤ x - T) (by linarith : (0:ℝ) ≤ x + T)]
  have hxl : -T < x := by
    by_contra hcon
    push Not at hcon
    nlinarith [mul_nonneg (by linarith : (0:ℝ) ≤ -T - x) (by linarith : (0:ℝ) ≤ T - x)]
  have hbx : b * x < T := by
    nlinarith [mul_pos (by linarith : (0:ℝ) < 1 - b) (by linarith : (0:ℝ) < T + x),
               mul_pos (by linarith : (0:ℝ) < 1 + b) (by linarith : (0:ℝ) < T - x)]
  have hpos : 0 < T - b * x := by linarith
  exact mul_pos hg hpos

/-- L31. Boost composition: the Lorentz normalization is closed under the
velocity addition law. Stated without division; the existence of the composed
parameter `b` requires `1 + b₁ * b₂ ≠ 0`, which is a hypothesis on the model,
not on this identity. -/
theorem boost_normalization_composes (b₁ b₂ b g₁ g₂ g : ℝ)
    (h₁ : g₁ ^ 2 * (1 - b₁ ^ 2) = 1) (h₂ : g₂ ^ 2 * (1 - b₂ ^ 2) = 1)
    (hb : b * (1 + b₁ * b₂) = b₁ + b₂)
    (hgg : g = g₁ * g₂ * (1 + b₁ * b₂)) :
    g ^ 2 * (1 - b ^ 2) = 1 := by
  subst hgg
  have key : (g₁ * g₂ * (1 + b₁ * b₂)) ^ 2 * (1 - b ^ 2)
      = (g₁ ^ 2 * (1 - b₁ ^ 2)) * (g₂ ^ 2 * (1 - b₂ ^ 2)) := by
    linear_combination (-(g₁ ^ 2 * g₂ ^ 2) * (b * (1 + b₁ * b₂) + (b₁ + b₂))) * hb
  rw [key, h₁, h₂]
  ring

/-- L32. PLANCK RIGIDITY. Fixing the numerical values of c, h and G leaves only
the trivial rescaling of the length, time and mass units. -/
theorem planck_rescaling_rigid (c h G L U M : ℝ)
    (hc : c ≠ 0) (hh : h ≠ 0) (hG : G ≠ 0)
    (hL : 0 < L) (hU : 0 < U) (_hM : 0 < M)
    (ec : c * U = c * L)
    (eh : h * U = h * (L ^ 2 * M))
    (eG : G * U ^ 2 * M = G * L ^ 3) :
    L = 1 ∧ U = 1 ∧ M = 1 := by
  have e1 : U = L := mul_left_cancel₀ hc ec
  subst e1
  have e2 : U = U ^ 2 * M := mul_left_cancel₀ hh eh
  have e3 : U ^ 2 * M = U ^ 3 :=
    mul_left_cancel₀ hG (by linear_combination eG)
  have e4 : U = U ^ 3 := e2.trans e3
  have hU1 : U = 1 := by
    have hfac : U * ((U - 1) * (U + 1)) = 0 := by linear_combination (-1 : ℝ) * e4
    rcases mul_eq_zero.mp hfac with h1 | h1
    · exact absurd h1 (ne_of_gt hU)
    · rcases mul_eq_zero.mp h1 with h' | h'
      · linarith
      · linarith
  subst hU1
  refine ⟨rfl, rfl, ?_⟩
  have : (1 : ℝ) = M := by linear_combination e2
  linarith

/-! ## Section 13. Hypothesis necessity

Each declaration below exhibits a countermodel showing that a hypothesis of a
previously accepted theorem is load-bearing. These are not corrections. They
establish that the predecessor's hypotheses cannot be dropped.
-/

/-- L33. The two SpatiotemporalBridge premises of Part I K15 are necessary. -/
theorem no_first_position_premises_necessary :
    ∃ (Priority UsesComplement : Bool → Prop) (c : Bool),
      AbsolutePriority Priority UsesComplement c :=
  ⟨fun _ => True, fun _ => False, true, trivial, not_false⟩

/-- L34. The normalization hypothesis of Part II P03 is necessary. -/
theorem lorentz_normalization_necessary :
    ∃ g b T x : ℝ,
      interval (boostTime g b T x) (boostSpace g b T x) ≠ interval T x := by
  refine ⟨2, 0, 0, 1, ?_⟩
  norm_num [interval, boostTime, boostSpace]

/-- L35. The demand hypothesis of Part I K22 is necessary. -/
theorem budget_demand_hypothesis_necessary :
    ∃ costA costB allocA allocB budget : ℕ,
      ¬ (budget < costA + costB) ∧ allocA + allocB ≤ budget ∧
        costA ≤ allocA ∧ costB ≤ allocB :=
  ⟨1, 1, 1, 1, 2, by omega, by omega, by omega, by omega⟩

/-- L36. The nontriviality hypothesis of Part I K05 is necessary. -/
theorem nontriviality_hypothesis_necessary :
    ∃ c : Bool → Bool, ¬ ∃ x, SelfSide c x := by
  refine ⟨fun _ => false, ?_⟩
  rintro ⟨x, hx⟩
  simp [SelfSide] at hx

/-- L37. The velocity bound in L30 is necessary: a superluminal parameter
reverses orientation on a timelike separation. -/
theorem velocity_bound_necessary :
    ∃ g b T x : ℝ, 0 < g ∧ 0 < T ∧ x ^ 2 < T ^ 2 ∧ boostTime g b T x < 0 := by
  refine ⟨1, 4, 2, 1, ?_, ?_, ?_, ?_⟩ <;> norm_num [boostTime]

/-! ## Section 14. Findings against the accepted predecessor sources

These are stated as theorems so that the findings are checkable rather than
editorial. Each is a redundant-hypothesis finding: the predecessor theorem
remains true and is merely stated with more hypotheses than it needs.
-/

/-- F01. Part II E09: the hypothesis `hz : z ≠ 0` is derivable from `hd`. -/
theorem E09_nonzero_hypothesis_redundant (z : ℂ) (hd : z ≠ z⁻¹) : z ≠ 0 := by
  rintro rfl
  simp at hd

/-- F03. Part II P07: the hypothesis `hL : L ≠ 0` is derivable from `hc` and `h`. -/
theorem P07_length_hypothesis_redundant (c L U : ℝ) (hc : c ≠ 0)
    (h : c * U / L = c) : L ≠ 0 := by
  rintro rfl
  rw [div_zero] at h
  exact hc h.symm

/-- F04. Part II E15: the first conjunct is provable with no hypothesis and
carries no content. Recorded so that the finding is checkable, not editorial. -/
theorem E15_first_conjunct_is_contentless : ∀ x : ℝ, 0 < x → 0 < x :=
  fun _ h => h


/-! ## Section 15. The assertion reading: discharging K15's premises

Part III section 14 recorded the achievement reading of `SpaceFirst` as making
Part I K15 vacuous in the 1+1 model, and recorded the assertion reading as OPEN.
This section constructs the assertion reading.

WHAT IS PROVED: that the two bridge premises of a spatiotemporal bridge become
THEOREMS about priority claims, and that the claim class is inhabited.

WHAT IS NOT PROVED, AND IS NOT ELIMINATED: the identification of directed order
with a temporal-type resource and of individuation with a spatial-type resource.
That is Part I bridge B03. It is not discharged here. It is relocated: it now
carries the entire physical content of the no-first-position result by itself.
-/

/-- A priority claim: an assertion that one relatum is prior to another.
Distinctness of the relata is part of what it is to be a priority claim. -/
structure PriorityClaim (R : Type*) where
  prior : R
  posterior : R
  distinct : prior ≠ posterior

/-- The claim obtained by exchanging the two relata. -/
def exchangeRelata {R : Type*} (c : PriorityClaim R) : PriorityClaim R :=
  ⟨c.posterior, c.prior, fun h => c.distinct h.symm⟩

/-- Individuation: the claim distinguishes its relata. -/
def UsesIndividuation {R : Type*} (c : PriorityClaim R) : Prop :=
  c.prior ≠ c.posterior

/-- Directed order: the claim is not invariant under exchanging its relata. -/
def UsesDirectedOrder {R : Type*} (c : PriorityClaim R) : Prop :=
  c ≠ exchangeRelata c

/-- L41. Every priority claim uses individuation. Proved, not stipulated. -/
theorem priority_claim_uses_individuation {R : Type*} (c : PriorityClaim R) :
    UsesIndividuation c := c.distinct

/-- L42. Every priority claim uses directed order. Proved, not stipulated. -/
theorem priority_claim_uses_directed_order {R : Type*} (c : PriorityClaim R) :
    UsesDirectedOrder c := by
  intro h
  exact c.distinct (congrArg PriorityClaim.prior h)

/-- Part I's bridge structure, restated here so this document's kernel is
self-contained. -/
structure SpatiotemporalBridgeIII (Claim : Type*) where
  SpaceFirst : Claim → Prop
  TimeFirst : Claim → Prop
  UsesTemporalResource : Claim → Prop
  UsesSpatialResource : Claim → Prop
  spaceFirstUsesTemporal : ∀ c, SpaceFirst c → UsesTemporalResource c
  timeFirstUsesSpatial : ∀ c, TimeFirst c → UsesSpatialResource c

inductive SpaceTime where
  | space
  | time
  deriving DecidableEq, Repr

def IsSpaceFirst (c : PriorityClaim SpaceTime) : Prop := c.prior = SpaceTime.space
def IsTimeFirst (c : PriorityClaim SpaceTime) : Prop := c.prior = SpaceTime.time

def spaceFirstClaim : PriorityClaim SpaceTime :=
  ⟨SpaceTime.space, SpaceTime.time, by decide⟩
def timeFirstClaim : PriorityClaim SpaceTime :=
  ⟨SpaceTime.time, SpaceTime.space, by decide⟩

/-- The assertion-reading bridge. Both premise fields are DISCHARGED BY PROOF
(L41, L42) rather than stipulated. Bridge B03 is assumed in the choice of the
two `Uses` fields and is not proved anywhere in this file. -/
def assertionBridge : SpatiotemporalBridgeIII (PriorityClaim SpaceTime) where
  SpaceFirst := IsSpaceFirst
  TimeFirst := IsTimeFirst
  UsesTemporalResource := UsesDirectedOrder
  UsesSpatialResource := UsesIndividuation
  spaceFirstUsesTemporal := fun c _ => priority_claim_uses_directed_order c
  timeFirstUsesSpatial := fun c _ => priority_claim_uses_individuation c

/-- L43. The assertion-reading claim class is INHABITED on both sides. This is
what the achievement reading fails to provide, and it is why the resulting
no-first-position statement is not vacuous. -/
theorem assertion_bridge_nonvacuous :
    (∃ c, assertionBridge.SpaceFirst c) ∧ (∃ c, assertionBridge.TimeFirst c) :=
  ⟨⟨spaceFirstClaim, rfl⟩, ⟨timeFirstClaim, rfl⟩⟩

/-- L44. No-first-position under the assertion reading, with premises proved
rather than assumed. -/
theorem no_first_position_assertion_reading :
    (¬ ∃ c, AbsolutePriority assertionBridge.SpaceFirst
        assertionBridge.UsesTemporalResource c) ∧
    (¬ ∃ c, AbsolutePriority assertionBridge.TimeFirst
        assertionBridge.UsesSpatialResource c) :=
  ⟨complement_requirement_blocks_absolute_priority _ _
      assertionBridge.spaceFirstUsesTemporal,
   complement_requirement_blocks_absolute_priority _ _
      assertionBridge.timeFirstUsesSpatial⟩

/-- L45. The contrast case, restated from Part II P05: no predicate of the time
coordinate alone gives the causal classification. -/
theorem timelike_not_time_only :
    ¬ ∃ P : ℝ → Prop, ∀ T x, P T ↔ interval T x < 0 := by
  rintro ⟨P, h⟩
  have hp : P 1 := (h 1 0).mpr (by norm_num [interval])
  have hn := (h 1 2).mp hp
  norm_num [interval] at hn

/-- L46. The contrast case, restated from Part II P06. With L45 this is why the
ACHIEVEMENT reading makes K15 vacuous in the 1+1 model: the predicate whose
existence would inhabit `SpaceFirst` does not exist. -/
theorem timelike_not_space_only :
    ¬ ∃ P : ℝ → Prop, ∀ T x, P x ↔ interval T x < 0 := by
  rintro ⟨P, h⟩
  have hp : P 1 := (h 2 1).mpr (by norm_num [interval])
  have hn := (h 0 1).mp hp
  norm_num [interval] at hn

/-! ## Section 16. Further self-application and necessity -/

/-- L47. The taxonomy's own retraction encoding is lossy. `RetractsFormalResult`
collides on six of seven categories, so by L01 the category cannot be recovered
from the footprint. The compression warned about in Part I section 10, performed
by this document on its own policy object. -/
theorem taxonomy_encoding_is_lossy :
    ¬ FactorsThrough RetractsFormalResult (id : SuccessorKind → SuccessorKind) :=
  collision_blocks_factorization RetractsFormalResult id
    (x₁ := SuccessorKind.absorption) (x₂ := SuccessorKind.supersession)
    rfl (by decide)

/-- L48. The third constant in L32 is necessary: fixing the numerical values of
c and h alone leaves a nontrivial rescaling family. Witness (L,U,M) = (2,2,1/2). -/
theorem planck_two_constants_insufficient (c h : ℝ) :
    ∃ L U M : ℝ, 0 < L ∧ 0 < U ∧ 0 < M ∧ ¬ (L = 1 ∧ U = 1 ∧ M = 1) ∧
      c * U = c * L ∧ h * U = h * (L ^ 2 * M) :=
  ⟨2, 2, 1/2, by norm_num, by norm_num, by norm_num, by norm_num, by ring, by norm_num⟩

/-! ## Section 17. Quantifying the spectral loss -/

noncomputable def spectralRead (z : ℂ) : ℂ := 2 - z - z⁻¹

/-- L49. The spectral readout is invariant under inversion. -/
theorem spectral_read_inversion_invariant (z : ℂ) :
    spectralRead z⁻¹ = spectralRead z := by
  simp only [spectralRead, inv_inv]
  ring

/-- L50. Each nonzero fibre of the spectral readout contains at most the pair
{z, z⁻¹}. With L51 this quantifies the loss exactly: at most one bit. -/
theorem spectral_fibre_at_most_pair (z w : ℂ) (hz : z ≠ 0) (hw : w ≠ 0)
    (h : spectralRead z = spectralRead w) : w = z ∨ w = z⁻¹ := by
  have hzi : z * z⁻¹ = 1 := mul_inv_cancel₀ hz
  have hwi : w * w⁻¹ = 1 := mul_inv_cancel₀ hw
  have hid : (spectralRead z - spectralRead w) * (z * w) =
      -(z - w) * (z * w - 1) := by
    simp only [spectralRead]
    linear_combination z * hwi - w * hzi
  rw [h, sub_self, zero_mul] at hid
  have hp : (z - w) * (z * w - 1) = 0 := by linear_combination hid
  rcases mul_eq_zero.mp hp with heq | hinv
  · exact Or.inl (sub_eq_zero.mp heq).symm
  · right
    have hzw : z * w = 1 := sub_eq_zero.mp hinv
    calc w = 1 * w := (one_mul w).symm
      _ = (z⁻¹ * z) * w := by rw [inv_mul_cancel₀ hz]
      _ = z⁻¹ * (z * w) := by ring
      _ = z⁻¹ * 1 := by rw [hzw]
      _ = z⁻¹ := mul_one _

/-- L51. The fibre collapses to a singleton exactly at the square roots of unity.
So the loss is exactly one bit off those points and zero bits on them. -/
theorem spectral_fibre_singleton_iff (z : ℂ) (hz : z ≠ 0) :
    z = z⁻¹ ↔ z ^ 2 = 1 := by
  constructor
  · intro hzz
    field_simp at hzz
    linear_combination hzz
  · intro hsq
    field_simp
    linear_combination hsq


/-! ## Section 18. Cardinality inadequacy in general (O3)

L14 proves the Boolean case. L52 proves the general cardinality statement, of
which the Boolean and `Fin k` cases are instances.

TERMINOLOGICAL NOTE. "Inadequate" here means exactly: fails to recover the
identity target. By I:K10 target adequacy and source exhaustion are different
predicates, so a criterion named inadequate by L52 may be perfectly adequate for
the target it was built for. The word is scoped to the identity target and
carries no further evaluation.
-/

/-- L52. A readout into a strictly smaller finite codomain always collides. -/
theorem cardinality_forces_collision {X Y : Type*} [Fintype X] [Fintype Y]
    (c : X → Y) (hcard : Fintype.card Y < Fintype.card X) :
    ∃ x₁ x₂ : X, c x₁ = c x₂ ∧ x₁ ≠ x₂ := by
  obtain ⟨x₁, x₂, hne, heq⟩ := Fintype.exists_ne_map_eq_of_card_lt c hcard
  exact ⟨x₁, x₂, heq, hne⟩

/-- L53. The corresponding non-recovery statement, in full generality. -/
theorem cardinality_forces_unfaithfulness {X Y : Type*} [Fintype X] [Fintype Y]
    (c : X → Y) (hcard : Fintype.card Y < Fintype.card X) :
    ¬ FactorsThrough c (id : X → X) := by
  obtain ⟨x₁, x₂, heq, hne⟩ := cardinality_forces_collision c hcard
  exact collision_blocks_factorization c id heq (by simpa using hne)

/-- L54. K-ARY INADEQUACY (O3). A `k`-valued criterion on a domain of more than
`k` states has a collision. L14 is the case `k = 2`. -/
theorem kary_criterion_has_collision {X : Type*} [Fintype X] {k : ℕ}
    (c : X → Fin k) (hcard : k < Fintype.card X) :
    ∃ x₁ x₂ : X, c x₁ = c x₂ ∧ x₁ ≠ x₂ := by
  refine cardinality_forces_collision c ?_
  simpa using hcard

/-- L55. K-ary criteria are unfaithful to the identity target. -/
theorem kary_criterion_not_faithful {X : Type*} [Fintype X] {k : ℕ}
    (c : X → Fin k) (hcard : k < Fintype.card X) :
    ¬ FactorsThrough c (id : X → X) := by
  obtain ⟨x₁, x₂, heq, hne⟩ := kary_criterion_has_collision c hcard
  exact collision_blocks_factorization c id heq (by simpa using hne)

/-! ## Section 19. Conservative expansion with strictly lower cost (O7)

Part II section 2.3 states in prose that a proof registry may lower represented
cost through reusable lemmas or compressed descriptions without thereby proving
a previously unprovable statement. II:E13 gives the cost inequality and II:E14
the theorem-set identity, but neither exhibits a case where the cost falls
STRICTLY while the theorem set is unmoved. L57 supplies that
witness.

TERMINOLOGICAL NOTE. "Conservative" is used in its proof-theoretic sense:
the expansion adds no theorems. The `expand` hypothesis below IS that condition,
made explicit as a conclusion-preserving retraction of the larger registry into
the smaller. The name is faithful provided the hypothesis is read as the
definition rather than as a consequence.
-/

noncomputable def indexedResidue {A : Type*} (S : Set A) (cost : A → ENNReal) : ENNReal :=
  sInf (cost '' S)

/-- L56. II:E13 restated: enlarging the admitted set cannot raise the residue. -/
theorem residue_monotone {A : Type*} (S T : Set A)
    (cost : A → ENNReal) (h : S ⊆ T) :
    indexedResidue T cost ≤ indexedResidue S cost := by
  unfold indexedResidue
  apply sInf_le_sInf
  rintro y ⟨x, hx, rfl⟩
  exact ⟨x, h hx, rfl⟩

/-- L57. O7. A conservative expansion can lower the residue STRICTLY while the
the theorem set is unchanged for every target.
Witness: R0 = {1}, R1 = {0,1},
cost = the numeral, expand = the constant 1. -/
theorem conservative_expansion_can_lower_cost_strictly :
    ∃ (R0 R1 : Set ℕ) (cost : ℕ → ENNReal) (conclusion : ℕ → Unit) (expand : ℕ → ℕ),
      R0 ⊆ R1 ∧
      (∀ p ∈ R1, expand p ∈ R0 ∧ conclusion (expand p) = conclusion p) ∧
      (∀ target : Unit,
        (∃ p ∈ R0, conclusion p = target) ↔ (∃ p ∈ R1, conclusion p = target)) ∧
      indexedResidue R1 cost < indexedResidue R0 cost := by
  classical
  refine ⟨{1}, {0, 1}, fun n => (n : ENNReal), fun _ => (), fun _ => 1,
    ?_, ?_, ?_, ?_⟩
  · intro x hx
    simp only [Set.mem_singleton_iff] at hx
    simp [hx]
  · intro p _
    exact ⟨rfl, rfl⟩
  · intro target
    constructor
    · rintro ⟨p, _, _⟩
      exact ⟨1, by simp, Subsingleton.elim _ _⟩
    · rintro ⟨p, _, _⟩
      exact ⟨1, rfl, Subsingleton.elim _ _⟩
  · have h1 : indexedResidue ({1} : Set ℕ) (fun n => (n : ENNReal)) = 1 := by
      unfold indexedResidue
      rw [Set.image_singleton]
      simp
    have h0 : indexedResidue ({0, 1} : Set ℕ) (fun n => (n : ENNReal)) = 0 := by
      unfold indexedResidue
      refine le_antisymm ?_ zero_le
      refine sInf_le ⟨0, by simp, by simp⟩
    rw [h0, h1]
    exact zero_lt_one

/-- L58. The two halves of O7 are independent: the residue can also fall to the
same value, so strictness is a property of the particular expansion and not a
consequence of conservativity. -/
theorem conservative_expansion_need_not_lower_cost :
    ∃ (R0 R1 : Set ℕ) (cost : ℕ → ENNReal),
      R0 ⊆ R1 ∧ indexedResidue R1 cost = indexedResidue R0 cost := by
  refine ⟨{1}, {1}, fun n => (n : ENNReal), subset_rfl, rfl⟩


/-! ## Section 20. Review-driven additions

L59 converts a stated hypothesis into a countermodel. L60 makes checkable the
claim that L44 is trivial if B03 is denied. L61 and L62 restate two results over
a general carrier so that a SINGLE run tests the axiom-profile prediction of the
supplement rather than requiring a baseline run followed by a second one.
-/

/-- L59. The nonemptiness hypothesis of L03 and L04 is necessary. Over an empty
domain every map is vacuously injective, yet factorization can fail outright
because the decoder itself cannot be constructed. -/
theorem dichotomy_nonemptiness_necessary :
    ∃ P : Empty → Unit, Function.Injective P ∧
      ¬ FactorsThrough P (id : Empty → Empty) := by
  refine ⟨fun e => e.elim, ?_, ?_⟩
  · intro a b _
    exact a.elim
  · rintro ⟨g, _⟩
    exact (g ()).elim

/-- L60. What the no-first-position result becomes if bridge B03 is denied.
With `UsesDirectedOrder` and `UsesIndividuation` read as bare logical properties
carrying no spatiotemporal import, L44's content is non-contradiction and
nothing else. The proof is `fun h1 h2 => h2 h1`, which is the point: this
declaration exists to make the triviality inspectable rather than asserted. -/
theorem no_first_position_without_B03_is_trivial {R : Type*} :
    (¬ ∃ c : PriorityClaim R, UsesDirectedOrder c ∧ ¬ UsesDirectedOrder c) ∧
    (¬ ∃ c : PriorityClaim R, UsesIndividuation c ∧ ¬ UsesIndividuation c) := by
  constructor
  · rintro ⟨c, h1, h2⟩
    exact h2 h1
  · rintro ⟨c, h1, h2⟩
    exact h2 h1

/-- L61. L27 over a commutative ring. Compare the axiom report with L27's. -/
theorem gaps_determine_up_to_shift_ring {K : Type*} [CommRing K] {I : Type*}
    (E F : I → K) (i₀ : I) (hgap : ∀ i j, E i - E j = F i - F j) (i : I) :
    F i = E i + (F i₀ - E i₀) := by
  linear_combination -(hgap i i₀)

/-- L62. L28 over an arbitrary field, with no order used. Compare the axiom
report with L28's. -/
theorem affine_calibration_unique_field {K : Type*} [Field K] {I : Type*}
    (E : I → K) (a a' b b' : K) (i j : I) (hij : E i ≠ E j)
    (h : ∀ k, a * E k + b = a' * E k + b') :
    a = a' ∧ b = b' := by
  have hi := h i
  have hj := h j
  have hfac : (a - a') * (E i - E j) = 0 := by linear_combination hi - hj
  have ha : a = a' := by
    rcases mul_eq_zero.mp hfac with h1 | h2
    · exact sub_eq_zero.mp h1
    · exact absurd (sub_eq_zero.mp h2) hij
  refine ⟨ha, ?_⟩
  rw [ha] at hi
  exact add_left_cancel hi


/-! ## Section 21. The pharmakon of critique

A critique that refutes a strengthened version of a claim is a VALID refutation.
Its validity is what conceals the misfire: the operation is correct and the
target is wrong, and soundness alone does not distinguish the two cases. This is
the pharmakon applied to scrutiny itself — the remedy and the poison are the
same operation.
-/

structure Critique (Claim : Type*) where
  target : Claim
  valid : Bool

/-- L63. STRAW MAN. Refuting a strictly stronger claim leaves the original
standing. The refutation is sound; it is sound about something else. -/
theorem straw_man_leaves_claim_standing :
    ∃ c cPlus : Prop, (cPlus → c) ∧ ¬ cPlus ∧ c :=
  ⟨True, False, fun h => h.elim, not_false, trivial⟩

/-- L64. The dual. Establishing a weakened version does not establish the
original. Straw man and motte-and-bailey are one countermodel read twice. -/
theorem motte_bailey_does_not_establish_claim :
    ∃ c cMinus : Prop, (c → cMinus) ∧ cMinus ∧ ¬ c :=
  ⟨False, True, fun h => h.elim, trivial, not_false⟩

/-- L65. The validity of a critique does not recover which claim it was a
critique of. Two critiques, both valid, different targets, same readout. -/
theorem critique_validity_does_not_recover_target
    {Claim : Type*} {c₁ c₂ : Claim} (hne : c₁ ≠ c₂) :
    ¬ FactorsThrough (fun k : Critique Claim => k.valid) (fun k => k.target) :=
  collision_blocks_factorization _ _
    (x₁ := ⟨c₁, true⟩) (x₂ := ⟨c₂, true⟩) rfl hne

/-- L66. THE PHARMAKON, EXACTLY. Critique is target-exact for its own validity
and non-injective on what it was aimed at — I:K10's shape, instantiated on the
act of scrutiny. The critique genuinely establishes something. What it
establishes does not include its own aim. -/
theorem critique_is_pharmakon {Claim : Type*} {c₁ c₂ : Claim} (hne : c₁ ≠ c₂) :
    FactorsThrough (fun k : Critique Claim => k.valid) (fun k => k.valid) ∧
    ¬ FactorsThrough (fun k : Critique Claim => k.valid) (fun k => k.target) :=
  ⟨⟨id, fun _ => rfl⟩, critique_validity_does_not_recover_target hne⟩

/-! ## Section 22. Delegation relocates residual will, and conceals it

External certification does not remove the act of selection. It moves it — into
the choice of verifier, and into that verifier's declared axiom basis — where it
is less apparent. L70 is the concealment half and is the substantive one.
-/

def UniqueOutcome {J S : Type*} (Admissible : J → Prop) (outcome : J → S) : Prop :=
  ∃ s : S, ∀ j, Admissible j → outcome j = s

def ResidualWill {J S : Type*} (Admissible : J → Prop) (outcome : J → S)
    (chosen : J) : Prop :=
  Admissible chosen ∧ ¬ UniqueOutcome Admissible outcome

/-- L67. I:K11 restated for self-containment. -/
theorem residual_selection {J S : Type*} (Admissible : J → Prop) (outcome : J → S)
    {j₁ j₂ : J} (h₁ : Admissible j₁) (h₂ : Admissible j₂)
    (hdiff : outcome j₁ ≠ outcome j₂) :
    ¬ UniqueOutcome Admissible outcome := by
  rintro ⟨s, hs⟩
  exact hdiff ((hs j₁ h₁).trans (hs j₂ h₂).symm)

structure Verifier (Basis Claim : Type*) where
  basis : Basis
  verdict : Claim → Bool

/-- L68. Two admissible verifiers disagreeing on one claim defeat unique
outcome. Delegation does not, by itself, force a verdict. -/
theorem competing_verifiers_defeat_unique_outcome
    {Basis Claim : Type*} (Admissible : Verifier Basis Claim → Prop) (c : Claim)
    {v₁ v₂ : Verifier Basis Claim}
    (h₁ : Admissible v₁) (h₂ : Admissible v₂)
    (hdiff : v₁.verdict c ≠ v₂.verdict c) :
    ¬ UniqueOutcome Admissible (fun v => v.verdict c) :=
  residual_selection Admissible (fun v => v.verdict c) h₁ h₂ hdiff

/-- L69. DELEGATION PRESERVES RESIDUAL WILL. Choosing an admissible verifier in
a registry that does not force one verdict satisfies the project definition of
will. Certification by an outside party is a relocation of the selection, not an
elimination of it. -/
theorem delegation_preserves_residual_will
    {Basis Claim : Type*} (Admissible : Verifier Basis Claim → Prop) (c : Claim)
    {chosen v₂ : Verifier Basis Claim}
    (hchosen : Admissible chosen) (h₂ : Admissible v₂)
    (hdiff : chosen.verdict c ≠ v₂.verdict c) :
    ResidualWill Admissible (fun v => v.verdict c) chosen :=
  ⟨hchosen, competing_verifiers_defeat_unique_outcome Admissible c hchosen h₂ hdiff⟩

/-- The public certificate: what a consumer of a verdict actually sees. -/
def certificateLabel {Basis Claim : Type*} (_ : Verifier Basis Claim) : String :=
  "certified"

/-- L70. THE RELOCATION IS ALSO A CONCEALMENT. Two verifiers with different
declared axiom bases expose the same public certificate label, so the label does
not recover the basis. The act of will moved upstream into the choice of
admitted axioms and became less apparent in the same step. This is I:K19 applied
to certification, and it is why a receipt must carry its basis explicitly: the
badge cannot. -/
theorem certificate_does_not_recover_basis
    {Basis Claim : Type*} {b₁ b₂ : Basis} (hb : b₁ ≠ b₂) (f : Claim → Bool) :
    ¬ FactorsThrough (fun v : Verifier Basis Claim => certificateLabel v)
      (fun v => v.basis) :=
  collision_blocks_factorization _ _
    (x₁ := ⟨b₁, f⟩) (x₂ := ⟨b₂, f⟩) rfl hb

/-- L71. DISCHARGE TRANSFERS, IT DOES NOT REDUCE. Proving a previously adopted
premise from a new one leaves the adopted count unchanged. The obligation moves;
it does not vanish. This is the accounting form of positional-recoverability
Remark 5.4 and of the bridge relocation recorded at section 14.3. -/
theorem discharge_does_not_reduce_adoptions {α : Type*} [DecidableEq α]
    (S : Finset α) (b p : α) (hb : b ∈ S) (hp : p ∉ S) :
    (insert p (S.erase b)).card = S.card := by
  have hpe : p ∉ S.erase b := fun h => hp (Finset.mem_of_mem_erase h)
  have hcard : (S.erase b).card = S.card - 1 := Finset.card_erase_of_mem hb
  have hpos : 0 < S.card := Finset.card_pos.mpr ⟨b, hb⟩
  rw [Finset.card_insert_of_notMem hpe, hcard]
  omega


/-! ## Section 23. The symmetry obstruction (imported, not derived)

PROVENANCE. This is `positional_recoverability` Theorem 5.1, restated here in
the vocabulary of this kernel so the file is self-contained. It is **not** a
result of this document. The canonical statement, its quantifier analysis
(Remark 5.2), its costing (Corollary 5.3, "orientation is never free"), and the
admission-accounting remark (Remark 5.4) belong to that paper and are cited, not
re-derived.

WHY IT MATTERS HERE. Sections 1-4 use only the COLLISION route, which requires
exhibiting a pair. The symmetry route requires no witness at all: a symmetry of
the declared vocabulary suffices. It is the stronger of the two, and its absence
from the earlier sections was a real omission.

NOT ENCODED. Corollary 5.3's lower bound is a statement about minimisation over
all layouts and all decoders. That machinery is not present in this file and is
not simulated here. Cite the source.
-/

/-- L72. SYMMETRY BLOCKS RECOVERY. If a readout is invariant under a symmetry
that moves the target, no decoder recovers the target. No collision pair need be
exhibited by the caller: the symmetry supplies it. -/
theorem symmetry_blocks_recovery {X Y Z : Type*}
    (P : X → Y) (Q : X → Z) (σ : X → X)
    (hP : ∀ x, P (σ x) = P x) {x₀ : X} (hQ : Q (σ x₀) ≠ Q x₀) :
    ¬ FactorsThrough P Q :=
  collision_blocks_factorization P Q (hP x₀) hQ

/-- L73. The exchange involution on priority claims instantiates L72: any readout
invariant under exchanging the relata fails to recover which relatum is prior.
Section 14's L42 is this instance, and the corpus had the general form first. -/
theorem exchange_invariant_readout_loses_priority
    {R Y : Type*} (P : PriorityClaim R → Y)
    (hP : ∀ c, P (exchangeRelata c) = P c) (c₀ : PriorityClaim R) :
    ¬ FactorsThrough P (fun c => c.prior) :=
  symmetry_blocks_recovery P (fun c => c.prior) exchangeRelata hP
    (x₀ := c₀) (Ne.symm c₀.distinct)


/-! ## Section 24. Equal-standard adjudication

Two constructions are adjudicated by a standard. This section encodes what
follows when they agree on every DECLARED criterion and receive different
verdicts. It takes no position on whether either construction is correct.
-/

/-- The criteria a standard declares itself to be using. -/
structure DeclaredCriteria where
  estimatesClose : Bool
  residualControlled : Bool
  witnessExhibited : Bool
  familyAdmissible : Bool
  deriving DecidableEq, Repr

/-- A standard is FAIR when its verdict is a function of the declared criteria
and of nothing else. -/
def FairStandard {C : Type*} (criteria : C → DeclaredCriteria)
    (verdict : C → Bool) : Prop :=
  FactorsThrough criteria verdict

/-- L74. FORCED ACCEPTANCE. Under a fair standard, two constructions agreeing on
every declared criterion receive the same verdict. Accepting one forces
accepting the other. -/
theorem equal_criteria_forces_equal_verdict {C : Type*}
    (criteria : C → DeclaredCriteria) (verdict : C → Bool)
    (hfair : FairStandard criteria verdict) {c₁ c₂ : C}
    (hsame : criteria c₁ = criteria c₂) :
    verdict c₁ = verdict c₂ := by
  obtain ⟨g, hg⟩ := hfair
  rw [← hg c₁, ← hg c₂, hsame]

/-- L75. DIFFERENTIAL TREATMENT EXPOSES AN UNDECLARED CRITERION. If the declared
criteria agree and the verdicts differ, the verdict does not factor through the
declared criteria, so some input outside them is doing the work. This says
nothing about what that input is, only that it exists and was not declared. -/
theorem differing_verdicts_defeat_fairness {C : Type*}
    (criteria : C → DeclaredCriteria) (verdict : C → Bool)
    {c₁ c₂ : C} (hsame : criteria c₁ = criteria c₂)
    (hdiff : verdict c₁ ≠ verdict c₂) :
    ¬ FairStandard criteria verdict :=
  collision_blocks_factorization criteria verdict hsame hdiff

/-- L76. THE TRICHOTOMY. For any standard and any two constructions agreeing on
the declared criteria: both accepted, both rejected, or the standard has an
undeclared criterion. There is no fourth option. -/
theorem equal_standard_trichotomy {C : Type*}
    (criteria : C → DeclaredCriteria) (verdict : C → Bool)
    (c₁ c₂ : C) (hsame : criteria c₁ = criteria c₂) :
    (verdict c₁ = true ∧ verdict c₂ = true) ∨
    (verdict c₁ = false ∧ verdict c₂ = false) ∨
    ¬ FairStandard criteria verdict := by
  by_cases h : verdict c₁ = verdict c₂
  · cases hv : verdict c₁ with
    | false => exact Or.inr (Or.inl ⟨rfl, by rw [← h]; exact hv⟩)
    | true  => exact Or.inl ⟨rfl, by rw [← h]; exact hv⟩
  · exact Or.inr (Or.inr (differing_verdicts_defeat_fairness criteria verdict hsame h))

/-! ## Section 25. One term, two readings, and the label that carries neither

The deflation case, encoded here for the term at issue. Lean certifies both
readings, certifies that they are incompatible, and certifies that the shared
public term does not recover which was used.
-/

/-- Two readings of one term. The forced reading admits a constructed forcing
term; the unforced reading requires it to vanish. -/
inductive SingularityReading where
  | forcedAdmitted
  | forcingMustVanish
  deriving DecidableEq, Repr

/-- What each reading requires of the forcing term. -/
def requiresZeroForcing : SingularityReading → Bool
  | .forcedAdmitted => false
  | .forcingMustVanish => true

/-- The public term exposed by both readings. -/
def publicTerm (_ : SingularityReading) : String := "singularity"

/-- L77. Both readings expose the same public term. -/
theorem singularity_term_shared :
    publicTerm .forcedAdmitted = publicTerm .forcingMustVanish := rfl

/-- L78. ONE TERM CANNOT CARRY BOTH. The readings agree on the public term and
disagree on what they require of the forcing, so no single claim satisfies both. -/
theorem singularity_readings_incompatible :
    publicTerm .forcedAdmitted = publicTerm .forcingMustVanish ∧
    requiresZeroForcing .forcedAdmitted ≠ requiresZeroForcing .forcingMustVanish := by
  refine ⟨rfl, by decide⟩

/-- L79. The public term does not recover the reading. A reader who sees only the
term cannot determine which requirement was in force — and neither can a
certificate that reports only the term. -/
theorem singularity_term_does_not_recover_reading :
    ¬ FactorsThrough publicTerm requiresZeroForcing :=
  collision_blocks_factorization publicTerm requiresZeroForcing
    (x₁ := SingularityReading.forcedAdmitted)
    (x₂ := SingularityReading.forcingMustVanish) rfl (by decide)

/-- L80. THE ESCAPE IS CLOSED. A standard cannot rescue differential treatment by
appealing to certification, because the certificate's public report does not
recover which proposition was encoded (L70, L79). Adding "certified" to the
declared criteria therefore adds a field whose value is the same for both
readings, leaving L75 in force. -/
theorem certification_does_not_separate_readings
    (report : SingularityReading → String)
    (hreport : ∀ r, report r = publicTerm r) :
    ¬ FactorsThrough report requiresZeroForcing := by
  have hfun : report = publicTerm := funext hreport
  rw [hfun]
  exact singularity_term_does_not_recover_reading


/-! ## Section 26. Quantifier structure, parity, and priority

Everything in this section is encoded at the level of QUANTIFIER STRUCTURE: what
form a claim takes, not whether it is correct. No declaration here asserts that
any construction is valid, invalid, better, or worse. Each field below is a
sourced, checkable property of a published artifact.
-/

/-- The logical form of a finite-time-blowup claim, at the level that decides
what kind of verification it admits. -/
structure BlowupClaim where
  /-- The family of admissible configurations is declared. -/
  familyDeclared : Bool
  /-- A single configuration is exhibited in closed form for direct term-by-term
      substitution into the equations. -/
  witnessExhibited : Bool
  /-- The property is established by estimates closing over the family. -/
  estimatesClose : Bool
  /-- The forcing term is permitted to be nonzero. -/
  forcingAdmitted : Bool
  deriving DecidableEq, Repr

/-- L81. PARITY OF QUANTIFIER STRUCTURE. Two claims agreeing on every structural
field are indistinguishable to any standard that reads only those fields. A
standard separating them is reading something else. -/
theorem same_structure_same_verdict
    (structureOf : BlowupClaim → BlowupClaim) (verdict : BlowupClaim → Bool)
    (hfair : FactorsThrough structureOf verdict)
    {c₁ c₂ : BlowupClaim} (hsame : structureOf c₁ = structureOf c₂) :
    verdict c₁ = verdict c₂ := by
  obtain ⟨g, hg⟩ := hfair
  rw [← hg c₁, ← hg c₂, hsame]

/-- L82. BOTH OR NEITHER. Restricted to the shared structural fields — family
declared, no closed-form witness exhibited, established by estimates — any fair
standard returns the same verdict on both. Accepting one while rejecting the
other requires a criterion outside those fields, and that criterion is then
undeclared until stated. -/
theorem parity_on_shared_fields
    (verdict : BlowupClaim → Bool)
    (hfair : FactorsThrough
      (fun c : BlowupClaim => (c.familyDeclared, c.witnessExhibited, c.estimatesClose)) verdict)
    {c₁ c₂ : BlowupClaim}
    (hF : c₁.familyDeclared = c₂.familyDeclared)
    (hW : c₁.witnessExhibited = c₂.witnessExhibited)
    (hE : c₁.estimatesClose = c₂.estimatesClose) :
    verdict c₁ = verdict c₂ := by
  obtain ⟨g, hg⟩ := hfair
  have hs : (c₁.familyDeclared, c₁.witnessExhibited, c₁.estimatesClose) =
      (c₂.familyDeclared, c₂.witnessExhibited, c₂.estimatesClose) := by rw [hF, hW, hE]
  rw [← hg c₁, ← hg c₂]
  exact congrArg g hs

/-! ### The two artifacts, by their own statements

Every field below is sourced. The `forcingAdmitted` values are the decisive
difference and are taken from each paper's own theorem statement.
-/

/-- Archived 2025-09-12. Claims Option C with forcing required to vanish. -/
def claimA : BlowupClaim :=
  { familyDeclared := true, witnessExhibited := false,
    estimatesClose := true, forcingAdmitted := false }

/-- Published 2026-09-08. Its Theorem 1.1 asserts the existence of a force
f in C-infinity-compact; its section 2 defines that force as the residual of the
constructed flow. -/
def claimB : BlowupClaim :=
  { familyDeclared := true, witnessExhibited := false,
    estimatesClose := true, forcingAdmitted := true }

/-- L83. The two claims agree on every field except forcing. In particular
neither exhibits a closed-form configuration for direct substitution. -/
theorem claims_agree_off_forcing :
    claimA.familyDeclared = claimB.familyDeclared ∧
    claimA.witnessExhibited = claimB.witnessExhibited ∧
    claimA.estimatesClose = claimB.estimatesClose ∧
    claimA.forcingAdmitted ≠ claimB.forcingAdmitted := by
  refine ⟨rfl, rfl, rfl, by decide⟩

/-- L84. FORCED PARITY. Any standard whose verdict reads only the three shared
structural fields returns the same verdict on both. -/
theorem parity_forced (verdict : BlowupClaim → Bool)
    (hfair : FactorsThrough
      (fun c => (c.familyDeclared, c.witnessExhibited, c.estimatesClose)) verdict) :
    verdict claimA = verdict claimB := by
  obtain ⟨g, hg⟩ := hfair
  rw [← hg claimA, ← hg claimB]
  rfl

/-! ### Scope: which Clay alternative is established -/

inductive ClayAlternative where
  | AB_unforced
  | CD_forced
  deriving DecidableEq, Repr

def alternativeOf (c : BlowupClaim) : ClayAlternative :=
  if c.forcingAdmitted then .CD_forced else .AB_unforced

/-- L85. The alternatives are distinct. A result establishing one does not
establish the other. -/
theorem alternatives_distinct :
    ClayAlternative.AB_unforced ≠ ClayAlternative.CD_forced := by decide

/-- L86. RESCOPING IS FORCED BY THE ARTIFACT'S OWN STATEMENT. A claim admitting a
nonzero forcing establishes the forced alternative and not the unforced one. -/
theorem forced_claim_establishes_only_CD (c : BlowupClaim)
    (h : c.forcingAdmitted = true) :
    alternativeOf c = ClayAlternative.CD_forced ∧
    alternativeOf c ≠ ClayAlternative.AB_unforced := by
  constructor
  · simp [alternativeOf, h]
  · simp [alternativeOf, h]

/-- L87. The public headline does not recover the alternative. Both alternatives
are reported under one phrase, so no reader of the phrase can determine which was
established — and no certificate reporting only the phrase can either. -/
def headline (_ : ClayAlternative) : String := "the Navier-Stokes problem"

theorem headline_does_not_recover_alternative :
    ¬ FactorsThrough headline (fun a => a) :=
  collision_blocks_factorization headline (fun a => a)
    (x₁ := ClayAlternative.AB_unforced) (x₂ := ClayAlternative.CD_forced)
    rfl (by decide)

/-! ### Priority of the claim -/

/-- A dated public claim. Dates are encoded as ordinals on a single timeline. -/
structure DatedClaim where
  day : Nat
  claim : BlowupClaim

/-- 2025-09-12, archived publicly. -/
def datedA : DatedClaim := { day := 20250912, claim := claimA }
/-- 2026-09-08, published publicly. -/
def datedB : DatedClaim := { day := 20260908, claim := claimB }

/-- L88. PRIORITY IS A TOTAL ORDER FACT. The earlier public claim is earlier.
This asserts nothing about correctness, method, or influence. -/
theorem priority_of_public_claim : datedA.day < datedB.day := by decide

/-- L89. Priority does not factor through the verdict: a standard's acceptance
decision carries no information about which claim was public first, so acceptance
can never establish or remove priority. -/
theorem verdict_does_not_recover_priority (verdict : DatedClaim → Bool)
    (hconst : ∀ d, verdict d = true) :
    ¬ FactorsThrough verdict (fun d => d.day) := by
  intro hfac
  obtain ⟨g, hg⟩ := hfac
  have h1 := hg datedA
  have h2 := hg datedB
  rw [hconst datedA] at h1
  rw [hconst datedB] at h2
  have : datedA.day = datedB.day := h1.symm.trans h2
  exact absurd this (by decide)

end LambdaIII

section AuditChecks
open LambdaIII

#check @collision_blocks_factorization
#check @id_factors_implies_injective
#check @injective_factors_all
#check @factorization_dichotomy
#check @not_injective_iff_collision
#check @scope_retained_is_recoverable
#check @scope_forgotten_is_not_recoverable
#check @only_error_retracts
#check @warrant_lapse_does_not_retract
#check @criterion_sides_exhaustive
#check @criterion_sides_exclusive
#check @double_exclusion_is_double_negation
#check @double_exclusion_collapse
#check @binary_criterion_has_collision
#check @binary_criterion_not_faithful
#check @absolute_with_both_rules_is_identity
#check @complement_requirement_blocks_absolute_priority
#check @no_first_position_cyclic
#check @preserves_and
#check @preserves_or
#check @preserves_not
#check @preserves_imp
#check @preserved_predicate_agrees_despite_noncommutation
#check @finite_budget_forces_tradeoff_n
#check @finite_metadata_leaves_freedom
#check @nat_cost_registry_attains_minimum
#check @gaps_determine_up_to_shift
#check @affine_calibration_unique
#check @distinct_count_parity
#check @boost_preserves_time_orientation
#check @boost_normalization_composes
#check @planck_rescaling_rigid
#check @no_first_position_premises_necessary
#check @lorentz_normalization_necessary
#check @budget_demand_hypothesis_necessary
#check @nontriviality_hypothesis_necessary
#check @velocity_bound_necessary
#check @E09_nonzero_hypothesis_redundant
#check @P07_length_hypothesis_redundant
#check @E15_first_conjunct_is_contentless
#check @priority_claim_uses_individuation
#check @priority_claim_uses_directed_order
#check @assertion_bridge_nonvacuous
#check @no_first_position_assertion_reading
#check @timelike_not_time_only
#check @timelike_not_space_only
#check @taxonomy_encoding_is_lossy
#check @planck_two_constants_insufficient
#check @spectral_read_inversion_invariant
#check @spectral_fibre_at_most_pair
#check @spectral_fibre_singleton_iff
#check @cardinality_forces_collision
#check @cardinality_forces_unfaithfulness
#check @kary_criterion_has_collision
#check @kary_criterion_not_faithful
#check @residue_monotone
#check @conservative_expansion_can_lower_cost_strictly
#check @conservative_expansion_need_not_lower_cost
#check @dichotomy_nonemptiness_necessary
#check @no_first_position_without_B03_is_trivial
#check @gaps_determine_up_to_shift_ring
#check @affine_calibration_unique_field
#check @straw_man_leaves_claim_standing
#check @motte_bailey_does_not_establish_claim
#check @critique_validity_does_not_recover_target
#check @critique_is_pharmakon
#check @residual_selection
#check @competing_verifiers_defeat_unique_outcome
#check @delegation_preserves_residual_will
#check @certificate_does_not_recover_basis
#check @discharge_does_not_reduce_adoptions
#check @symmetry_blocks_recovery
#check @exchange_invariant_readout_loses_priority
#check @equal_criteria_forces_equal_verdict
#check @differing_verdicts_defeat_fairness
#check @equal_standard_trichotomy
#check @singularity_term_shared
#check @singularity_readings_incompatible
#check @singularity_term_does_not_recover_reading
#check @certification_does_not_separate_readings
#check @same_structure_same_verdict
#check @parity_on_shared_fields
#check @claims_agree_off_forcing
#check @parity_forced
#check @alternatives_distinct
#check @forced_claim_establishes_only_CD
#check @headline_does_not_recover_alternative
#check @priority_of_public_claim
#check @verdict_does_not_recover_priority

#print axioms collision_blocks_factorization
#print axioms id_factors_implies_injective
#print axioms injective_factors_all
#print axioms factorization_dichotomy
#print axioms not_injective_iff_collision
#print axioms scope_retained_is_recoverable
#print axioms scope_forgotten_is_not_recoverable
#print axioms only_error_retracts
#print axioms warrant_lapse_does_not_retract
#print axioms criterion_sides_exhaustive
#print axioms criterion_sides_exclusive
#print axioms double_exclusion_is_double_negation
#print axioms double_exclusion_collapse
#print axioms binary_criterion_has_collision
#print axioms binary_criterion_not_faithful
#print axioms absolute_with_both_rules_is_identity
#print axioms complement_requirement_blocks_absolute_priority
#print axioms no_first_position_cyclic
#print axioms preserves_and
#print axioms preserves_or
#print axioms preserves_not
#print axioms preserves_imp
#print axioms preserved_predicate_agrees_despite_noncommutation
#print axioms finite_budget_forces_tradeoff_n
#print axioms finite_metadata_leaves_freedom
#print axioms nat_cost_registry_attains_minimum
#print axioms gaps_determine_up_to_shift
#print axioms affine_calibration_unique
#print axioms distinct_count_parity
#print axioms boost_preserves_time_orientation
#print axioms boost_normalization_composes
#print axioms planck_rescaling_rigid
#print axioms no_first_position_premises_necessary
#print axioms lorentz_normalization_necessary
#print axioms budget_demand_hypothesis_necessary
#print axioms nontriviality_hypothesis_necessary
#print axioms velocity_bound_necessary
#print axioms E09_nonzero_hypothesis_redundant
#print axioms P07_length_hypothesis_redundant
#print axioms E15_first_conjunct_is_contentless
#print axioms priority_claim_uses_individuation
#print axioms priority_claim_uses_directed_order
#print axioms assertion_bridge_nonvacuous
#print axioms no_first_position_assertion_reading
#print axioms timelike_not_time_only
#print axioms timelike_not_space_only
#print axioms taxonomy_encoding_is_lossy
#print axioms planck_two_constants_insufficient
#print axioms spectral_read_inversion_invariant
#print axioms spectral_fibre_at_most_pair
#print axioms spectral_fibre_singleton_iff
#print axioms cardinality_forces_collision
#print axioms cardinality_forces_unfaithfulness
#print axioms kary_criterion_has_collision
#print axioms kary_criterion_not_faithful
#print axioms residue_monotone
#print axioms conservative_expansion_can_lower_cost_strictly
#print axioms conservative_expansion_need_not_lower_cost
#print axioms dichotomy_nonemptiness_necessary
#print axioms no_first_position_without_B03_is_trivial
#print axioms gaps_determine_up_to_shift_ring
#print axioms affine_calibration_unique_field
#print axioms straw_man_leaves_claim_standing
#print axioms motte_bailey_does_not_establish_claim
#print axioms critique_validity_does_not_recover_target
#print axioms critique_is_pharmakon
#print axioms residual_selection
#print axioms competing_verifiers_defeat_unique_outcome
#print axioms delegation_preserves_residual_will
#print axioms certificate_does_not_recover_basis
#print axioms discharge_does_not_reduce_adoptions
#print axioms symmetry_blocks_recovery
#print axioms exchange_invariant_readout_loses_priority
#print axioms equal_criteria_forces_equal_verdict
#print axioms differing_verdicts_defeat_fairness
#print axioms equal_standard_trichotomy
#print axioms singularity_term_shared
#print axioms singularity_readings_incompatible
#print axioms singularity_term_does_not_recover_reading
#print axioms certification_does_not_separate_readings
#print axioms same_structure_same_verdict
#print axioms parity_on_shared_fields
#print axioms claims_agree_off_forcing
#print axioms parity_forced
#print axioms alternatives_distinct
#print axioms forced_claim_establishes_only_CD
#print axioms headline_does_not_recover_alternative
#print axioms priority_of_public_claim
#print axioms verdict_does_not_recover_priority

#eval Lean.versionString
#eval "LAMBDA_PART_III_SUCCESSOR_R1"

end AuditChecks

#eval Lean.versionString
#eval "LAMBDA_R4_PARTIII_END"
