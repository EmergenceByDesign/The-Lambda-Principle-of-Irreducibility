import Lean

/-!
# Lambda, Reference, and the Spatiotemporal Descriptive Frame
Formal kernel for the companion paper.

Scope:
This file checks only the propositions encoded below.  The terms `self`, `other`,
`space`, `time`, `will`, `absolute`, and `meaning` receive only the formal roles
explicitly assigned here.  Physical, phenomenological, linguistic, or ontological
interpretations require separate bridge arguments in the paper.
-/

namespace LambdaSpatiotemporal

/-! ## 1. Reference polarity -/

inductive RefRole where
  | source
  | target
  deriving DecidableEq, Repr

structure RoleTagged (X : Type) where
  carrier : X
  role : RefRole
  deriving DecidableEq, Repr

def asSource {X : Type} (x : X) : RoleTagged X := ⟨x, .source⟩
def asTarget {X : Type} (x : X) : RoleTagged X := ⟨x, .target⟩

theorem source_target_roles_distinct : RefRole.source ≠ RefRole.target := by
  intro h
  cases h

theorem reference_polarity {X : Type} (x y : X) :
    asSource x ≠ asTarget y := by
  intro h
  have hr : RefRole.source = RefRole.target := congrArg RoleTagged.role h
  exact source_target_roles_distinct hr

/-- Even when the carrier is the same, referring and referred-to roles remain distinct. -/
theorem reflexive_reference_preserves_role_distinction {X : Type} (x : X) :
    asSource x ≠ asTarget x :=
  reference_polarity x x

/-- Repeating the tagging operation at any indexed station preserves role polarity. -/
theorem iterated_reference_polarity {X : Type} (x : X) (n : Nat) :
    (n, asSource x) ≠ (n, asTarget x) := by
  intro h
  have ht : asSource x = asTarget x := congrArg Prod.snd h
  exact reflexive_reference_preserves_role_distinction x ht

/-! ## 2. Binary partition and self/other bridge -/

def SelfSide {X : Type} (criterion : X → Bool) (x : X) : Prop := criterion x = true
def OtherSide {X : Type} (criterion : X → Bool) (x : X) : Prop := criterion x = false

def NontrivialCriterion {X : Type} (criterion : X → Bool) : Prop :=
  (∃ x, SelfSide criterion x) ∧ (∃ y, OtherSide criterion y)

theorem nontrivial_criterion_exhibits_poles {X : Type} (criterion : X → Bool)
    (h : NontrivialCriterion criterion) :
    ∃ x y, SelfSide criterion x ∧ OtherSide criterion y := by
  rcases h with ⟨⟨x, hx⟩, ⟨y, hy⟩⟩
  exact ⟨x, y, hx, hy⟩

theorem nontrivial_criterion_exhibits_distinct_states {X : Type} (criterion : X → Bool)
    (h : NontrivialCriterion criterion) :
    ∃ x y : X, x ≠ y := by
  rcases h with ⟨⟨x, hx⟩, ⟨y, hy⟩⟩
  refine ⟨x, y, ?_⟩
  intro hxy
  subst y
  have : true = false := hx.symm.trans hy
  cases this

/-! ## 3. Exclusion is indexed to a criterion -/

def ExcludedBy {X : Type} (criterion : X → Prop) (x : X) : Prop := ¬ criterion x

theorem exclusion_is_criterion_relative {X : Type} (criterion : X → Prop) (x : X) :
    ExcludedBy criterion x ↔ ¬ criterion x :=
  Iff.rfl

/-! ## 4. Lambda projection / fibre obstruction -/

theorem postprocessing_cannot_split_fibre
    {X Y Z : Type} (projection : X → Y) (g : Y → Z) {x₁ x₂ : X}
    (h : projection x₁ = projection x₂) :
    g (projection x₁) = g (projection x₂) :=
  congrArg g h

def FactorsThrough {X Y Z : Type} (projection : X → Y) (target : X → Z) : Prop :=
  ∃ g : Y → Z, ∀ x, g (projection x) = target x

theorem target_difference_blocks_factorization
    {X Y Z : Type} (projection : X → Y) (target : X → Z)
    {x₁ x₂ : X} (hproj : projection x₁ = projection x₂)
    (htarget : target x₁ ≠ target x₂) :
    ¬ FactorsThrough projection target := by
  intro hfac
  rcases hfac with ⟨g, hg⟩
  apply htarget
  calc
    target x₁ = g (projection x₁) := (hg x₁).symm
    _ = g (projection x₂) := congrArg g hproj
    _ = target x₂ := hg x₂

/-! ## 5. Compression may be exact for a target while remaining non-injective -/

def InjectiveMap {X Y : Type} (f : X → Y) : Prop :=
  ∀ ⦃x y⦄, f x = f y → x = y

theorem target_exact_compression_can_lose_other_distinctions :
    ∃ (compress : Bool × Bool → Bool) (target : Bool × Bool → Bool),
      FactorsThrough compress target ∧ ¬ InjectiveMap compress := by
  let compress : Bool × Bool → Bool := fun p => p.1
  let target : Bool × Bool → Bool := fun p => p.1
  refine ⟨compress, target, ?_, ?_⟩
  · refine ⟨(fun b => b), ?_⟩
    intro x
    rfl
  · intro hinj
    have hpair : (false, false) = (false, true) := hinj rfl
    have hsnd : false = true := congrArg Prod.snd hpair
    cases hsnd

/-! ## 6. Residual selection / will kernel -/

def UniqueOutcome {J S : Type} (Admissible : J → Prop) (outcome : J → S) : Prop :=
  ∃ s : S, ∀ j, Admissible j → outcome j = s

theorem residual_selection
    {J S : Type} (Admissible : J → Prop) (outcome : J → S)
    {j₁ j₂ : J} (h₁ : Admissible j₁) (h₂ : Admissible j₂)
    (hdiff : outcome j₁ ≠ outcome j₂) :
    ¬ UniqueOutcome Admissible outcome := by
  intro huniq
  rcases huniq with ⟨s, hs⟩
  apply hdiff
  calc
    outcome j₁ = s := hs j₁ h₁
    _ = outcome j₂ := (hs j₂ h₂).symm

/-- Formal role used by the paper's term `will`: an admissible selected procedure
    in a registry whose admissible procedures do not determine one unique outcome. -/
def ResidualWill {J S : Type} (Admissible : J → Prop) (outcome : J → S) (chosen : J) : Prop :=
  Admissible chosen ∧ ¬ UniqueOutcome Admissible outcome

theorem residual_will_from_competing_admissible_procedures
    {J S : Type} (Admissible : J → Prop) (outcome : J → S)
    {chosen j₂ : J} (hchosen : Admissible chosen) (h₂ : Admissible j₂)
    (hdiff : outcome chosen ≠ outcome j₂) :
    ResidualWill Admissible outcome chosen := by
  exact ⟨hchosen, residual_selection Admissible outcome hchosen h₂ hdiff⟩

/-- A selected procedure can index a criterion without the criterion being uniquely forced by
    the predecessor registry.  The substantive premise is that two admissible procedures induce
    different criteria. -/
def SelectedCriterion {J X : Type} (criterionOf : J → X → Bool) (chosen : J) : X → Bool :=
  criterionOf chosen

theorem competing_admissible_criteria_not_uniquely_forced
    {J X : Type} (Admissible : J → Prop) (criterionOf : J → X → Bool)
    {j₁ j₂ : J} (h₁ : Admissible j₁) (h₂ : Admissible j₂)
    (hdiff : criterionOf j₁ ≠ criterionOf j₂) :
    ¬ UniqueOutcome Admissible criterionOf :=
  residual_selection Admissible criterionOf h₁ h₂ hdiff

/-! ## 7. Absolute-priority schema and no-first-position kernel -/

def AbsolutePriority {C : Type} (Priority UsesComplement : C → Prop) (c : C) : Prop :=
  Priority c ∧ ¬ UsesComplement c

theorem complement_requirement_blocks_absolute_priority
    {C : Type} (Priority UsesComplement : C → Prop)
    (hbridge : ∀ c, Priority c → UsesComplement c) :
    ¬ ∃ c, AbsolutePriority Priority UsesComplement c := by
  intro h
  rcases h with ⟨c, hp, hnot⟩
  exact hnot (hbridge c hp)

structure SpatiotemporalBridge (Claim : Type) where
  SpaceFirst : Claim → Prop
  TimeFirst : Claim → Prop
  UsesTemporalResource : Claim → Prop
  UsesSpatialResource : Claim → Prop
  spaceFirstUsesTemporal : ∀ c, SpaceFirst c → UsesTemporalResource c
  timeFirstUsesSpatial : ∀ c, TimeFirst c → UsesSpatialResource c

def AbsoluteSpaceFirst {Claim : Type} (B : SpatiotemporalBridge Claim) (c : Claim) : Prop :=
  AbsolutePriority B.SpaceFirst B.UsesTemporalResource c

def AbsoluteTimeFirst {Claim : Type} (B : SpatiotemporalBridge Claim) (c : Claim) : Prop :=
  AbsolutePriority B.TimeFirst B.UsesSpatialResource c

theorem no_first_position {Claim : Type} (B : SpatiotemporalBridge Claim) :
    (¬ ∃ c, AbsoluteSpaceFirst B c) ∧ (¬ ∃ c, AbsoluteTimeFirst B c) := by
  constructor
  · exact complement_requirement_blocks_absolute_priority
      B.SpaceFirst B.UsesTemporalResource B.spaceFirstUsesTemporal
  · exact complement_requirement_blocks_absolute_priority
      B.TimeFirst B.UsesSpatialResource B.timeFirstUsesSpatial

/-! ## 8. Frame-local warrant does not self-promote to universal warrant -/

inductive TwoFrame where
  | local
  | other
  deriving DecidableEq, Repr

def SampleWarrant : TwoFrame → Prop
  | .local => True
  | .other => False

def UniversalWarrant {F : Type} (Warrant : F → Prop) : Prop := ∀ f, Warrant f

theorem local_warrant_not_universal_in_general :
    SampleWarrant .local ∧ ¬ UniversalWarrant SampleWarrant := by
  constructor
  · exact True.intro
  · intro hall
    exact hall .other

/-- A predicate named or intended as `absolute` has no elimination rule by logic alone. -/
theorem absolute_label_does_not_self_license :
    ¬ (∀ (Absolute : Prop → Prop) (p : Prop), Absolute p → p) := by
  intro h
  have hfalse : False := h (fun _ => True) False True.intro
  exact hfalse

/-! ## 9. Public-label compression can suppress operative meaning -/

inductive Usage where
  | original
  | extended
  deriving DecidableEq, Repr

inductive TinyState where
  | bare
  | marked
  deriving DecidableEq, Repr

def tinyMeaning : Usage → TinyState → Bool
  | .original, .bare => true
  | .original, .marked => false
  | .extended, _ => true

def publicLabel (_ : Usage) : String := "singularity"

theorem same_public_label : publicLabel .original = publicLabel .extended := rfl

theorem same_label_can_hide_different_meanings :
    publicLabel .original = publicLabel .extended ∧
    tinyMeaning .original .marked ≠ tinyMeaning .extended .marked := by
  constructor
  · rfl
  · decide

/-! ## 10. Translation bridges: preservation and noncommutation -/

def PreservesPredicate {A B : Type} (f : A → B) (P : A → Prop) (Q : B → Prop) : Prop :=
  ∀ a, P a ↔ Q (f a)

theorem predicate_preservation_composes
    {A B C : Type} (f : A → B) (g : B → C)
    (P : A → Prop) (Q : B → Prop) (R : C → Prop)
    (hAB : PreservesPredicate f P Q)
    (hBC : PreservesPredicate g Q R) :
    PreservesPredicate (fun a => g (f a)) P R := by
  intro a
  exact Iff.trans (hAB a) (hBC (f a))

theorem translations_need_not_commute :
    ∃ (AB BC AC : Bool → Bool) (x : Bool), AC x ≠ BC (AB x) := by
  refine ⟨(fun b => b), (fun b => b), Bool.not, false, ?_⟩
  decide

/-! ## 11. Finite resource budget forces a tradeoff when full demand exceeds it -/

theorem finite_budget_forces_tradeoff
    (costA costB allocA allocB budget : Nat)
    (hDemand : budget < costA + costB)
    (hBudget : allocA + allocB ≤ budget)
    (hA : costA ≤ allocA)
    (hB : costB ≤ allocB) : False := by
  have hsum : costA + costB ≤ allocA + allocB := Nat.add_le_add hA hB
  have hfit : costA + costB ≤ budget := Nat.le_trans hsum hBudget
  exact (Nat.not_le_of_lt hDemand) hfit

/-! ## 12. Frozen inscription does not by logic alone freeze interpretation -/

theorem same_input_can_receive_different_interpretations :
    ∃ (I₀ I₁ : Bool → Bool) (r : Bool), I₀ r ≠ I₁ r := by
  refine ⟨(fun b => b), Bool.not, false, ?_⟩
  decide

/-! ## 13. Audit checks -/

#check source_target_roles_distinct
#check reference_polarity
#check reflexive_reference_preserves_role_distinction
#check iterated_reference_polarity
#check nontrivial_criterion_exhibits_poles
#check nontrivial_criterion_exhibits_distinct_states
#check exclusion_is_criterion_relative
#check postprocessing_cannot_split_fibre
#check target_difference_blocks_factorization
#check target_exact_compression_can_lose_other_distinctions
#check residual_selection
#check residual_will_from_competing_admissible_procedures
#check SelectedCriterion
#check competing_admissible_criteria_not_uniquely_forced
#check complement_requirement_blocks_absolute_priority
#check no_first_position
#check local_warrant_not_universal_in_general
#check absolute_label_does_not_self_license
#check same_public_label
#check same_label_can_hide_different_meanings
#check predicate_preservation_composes
#check translations_need_not_commute
#check finite_budget_forces_tradeoff
#check same_input_can_receive_different_interpretations

#print axioms source_target_roles_distinct
#print axioms reference_polarity
#print axioms reflexive_reference_preserves_role_distinction
#print axioms iterated_reference_polarity
#print axioms nontrivial_criterion_exhibits_poles
#print axioms nontrivial_criterion_exhibits_distinct_states
#print axioms exclusion_is_criterion_relative
#print axioms postprocessing_cannot_split_fibre
#print axioms target_difference_blocks_factorization
#print axioms target_exact_compression_can_lose_other_distinctions
#print axioms residual_selection
#print axioms residual_will_from_competing_admissible_procedures
#print axioms competing_admissible_criteria_not_uniquely_forced
#print axioms complement_requirement_blocks_absolute_priority
#print axioms no_first_position
#print axioms local_warrant_not_universal_in_general
#print axioms absolute_label_does_not_self_license
#print axioms same_public_label
#print axioms same_label_can_hide_different_meanings
#print axioms predicate_preservation_composes
#print axioms translations_need_not_commute
#print axioms finite_budget_forces_tradeoff
#print axioms same_input_can_receive_different_interpretations

#eval Lean.versionString
#eval "LAMBDA_SPATIOTEMPORAL_TRANSLATION_AUDIT_COMPLETE"

end LambdaSpatiotemporal
