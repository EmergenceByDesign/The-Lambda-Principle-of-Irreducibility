import DrivenLeft

/-!
Right half and the period-pattern reduction, 23 October 2026. Claude, with Lu Semita.

The right half of Rule 30 is the right half-line driven at its left boundary by the center column, just
as the left half is driven at its right boundary. Combined with Jen's theorem this gives a reduction for
any repeating pattern w: if every drive that eventually repeats w makes the right half's first column
eventually periodic, then the center column never eventually repeats w. The hypothesis is a statement
about the right half alone; it is stated here, not assumed.
-/

namespace RightHalf

open Rule30Bridge Rule30Application

/-- The right half-line driven at its left boundary by b. Index m ≥ 1 stands for position m and index 0
is the drive itself; zero start. -/
def rh (b : Nat → Bool) : Nat → Nat → Bool
  | t, 0 => b t
  | 0, _ + 1 => false
  | t + 1, m + 1 => Bool.xor (rh b t m) (rh b t (m + 1) || rh b t (m + 2))

/-- Rule 30's right half is exactly the right half-line driven by the center column. -/
theorem rh_center30 : ∀ (t m : Nat), rh center30 t m = cell30 t (m : Int) := by
  intro t
  induction t with
  | zero =>
    intro m
    cases m with
    | zero => rfl
    | succ m =>
      simp only [rh]
      unfold cell30
      rw [cellF_zero]
      symm
      simp only [decide_eq_false_iff_not]
      omega
  | succ t ih =>
    intro m
    cases m with
    | zero =>
      simp only [rh]
      unfold center30
      rfl
    | succ m =>
      simp only [rh]
      rw [ih m, ih (m + 1), ih (m + 2)]
      unfold cell30
      rw [cellF_succ]
      rw [show (((m + 1 : Nat) : Int)) - 1 = ((m : Nat) : Int) by omega,
        show (((m + 1 : Nat) : Int)) + 1 = ((m + 2 : Nat) : Int) by omega]
      rfl

/-- b eventually repeats the nonempty word w. -/
def EventuallyRepeats (b : Nat → Bool) (w : List Bool) : Prop :=
  ∃ N, ∀ t, N ≤ t → b t = w.getD ((t - N) % w.length) false

theorem repeats_periodic (b : Nat → Bool) (w : List Bool) (hw : 0 < w.length)
    (h : EventuallyRepeats b w) : EventuallyPeriodic b := by
  obtain ⟨N, hN⟩ := h
  refine ⟨N, w.length, hw, fun t ht => ?_⟩
  rw [hN (t + w.length) (by omega), hN t ht]
  rw [show t + w.length - N = (t - N) + w.length by omega, Nat.add_mod_right]

/-- The reduction for a repeating pattern: if the right half settles under every drive that eventually
repeats w, the center column never eventually repeats w. -/
theorem center_avoids_pattern_of_right_settles (w : List Bool) (hw : 0 < w.length)
    (settles : ∀ b : Nat → Bool, b 0 = true → EventuallyRepeats b w →
      EventuallyPeriodic (fun t => rh b t 1)) :
    ¬ EventuallyRepeats center30 w := by
  intro hc
  have hR := settles center30 rfl hc
  have hR' : EventuallyPeriodic right30 := by
    have e : (fun t => rh center30 t 1) = right30 := by
      funext t
      rw [rh_center30]
      rfl
    rw [e] at hR
    exact hR
  exact jen30 ⟨repeats_periodic center30 w hw hc, hR'⟩

end RightHalf
