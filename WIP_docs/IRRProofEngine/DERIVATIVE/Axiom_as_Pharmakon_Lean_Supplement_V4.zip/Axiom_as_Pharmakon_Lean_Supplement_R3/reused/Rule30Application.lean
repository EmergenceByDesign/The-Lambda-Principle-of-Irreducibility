import SeamClosure

/-!
Rule 30 application repairs, 23 October 2026.
This extends the established double-edged standard; it does not reopen it.
New results concern explicit readouts, clock integration, and tail typing.
The model-theoretic consequences remain conditional on their stated bridges.
-/

namespace Rule30Application

open SeamClosure

abbrev PairWord := List (Bool × Bool)
def bit (b : Bool) : Nat := if b then 1 else 0

def weightLeft : PairWord → Nat
  | [] => 0
  | p :: ps => bit p.1 + weightLeft ps
def weightRight : PairWord → Nat
  | [] => 0
  | p :: ps => bit p.2 + weightRight ps
def weightXor : PairWord → Nat
  | [] => 0
  | p :: ps => bit (Bool.xor p.1 p.2) + weightXor ps
def weightAnd : PairWord → Nat
  | [] => 0
  | p :: ps => bit (p.1 && p.2) + weightAnd ps
def weightOr : PairWord → Nat
  | [] => 0
  | p :: ps => bit (p.1 || p.2) + weightOr ps

theorem bit_carry (a b : Bool) :
    bit a + bit b = bit (Bool.xor a b) + 2 * bit (a && b) := by
  cases a <;> cases b <;> rfl

theorem bit_xor_parity (a b : Bool) :
    bit (Bool.xor a b) = (bit a + bit b) % 2 := by
  cases a <;> cases b <;> rfl

theorem xor_overlap_identity (w : PairWord) :
    weightLeft w + weightRight w = weightXor w + 2 * weightAnd w := by
  induction w with
  | nil => rfl
  | cons p ps ih =>
    rcases p with ⟨a,b⟩
    cases a <;> cases b <;>
      simp_all [weightLeft, weightRight, weightXor, weightAnd, bit] <;> omega

theorem or_overlap_identity (w : PairWord) :
    weightOr w + weightAnd w = weightLeft w + weightRight w := by
  induction w with
  | nil => rfl
  | cons p ps ih =>
    rcases p with ⟨a,b⟩
    cases a <;> cases b <;>
      simp_all [weightLeft, weightRight, weightOr, weightAnd, bit] <;> omega

theorem rule30_parity_uses_overlap (w : PairWord) :
    weightOr w % 2 = (weightLeft w + weightRight w + weightAnd w) % 2 := by
  have h := or_overlap_identity w
  omega

theorem rule150_parity_uses_marginals (w : PairWord) :
    weightXor w % 2 = (weightLeft w + weightRight w) % 2 := by
  have h := xor_overlap_identity w
  omega

def Marginals (w : PairWord) : Nat × Nat := (weightLeft w, weightRight w)
def Marginals4 (w : PairWord) : Nat × Nat := (weightLeft w % 4, weightRight w % 4)
def Joint4 (w : PairWord) : Nat × Nat × Nat :=
  (weightLeft w % 4, weightRight w % 4, weightXor w % 4)
def DecodeOverlap (r : Nat × Nat × Nat) : Nat :=
  ((r.1 + r.2.1 + 4 - r.2.2) % 4) / 2
def DecodeOrParity (r : Nat × Nat × Nat) : Nat :=
  (r.1 + r.2.1 + DecodeOverlap r) % 2
def OrParity (w : PairWord) : Nat := weightOr w % 2

theorem overlap_parity_from_joint_mod4 (w : PairWord) :
    DecodeOverlap (Joint4 w) = weightAnd w % 2 := by
  have h := xor_overlap_identity w
  simp only [DecodeOverlap, Joint4]
  omega

theorem explicit_joint_decoder (w : PairWord) :
    DecodeOrParity (Joint4 w) = OrParity w := by
  unfold DecodeOrParity
  rw [overlap_parity_from_joint_mod4]
  have h := rule30_parity_uses_overlap w
  simp only [Joint4, OrParity]
  omega

theorem joint_mod4_recovers_forcing_parity : Recovers Joint4 OrParity :=
  ⟨DecodeOrParity, explicit_joint_decoder⟩

def Coincident : PairWord :=
  [(true,true),(true,true),(false,false),(false,false)]
def Shifted : PairWord :=
  [(true,true),(true,false),(false,true),(false,false)]

theorem exact_marginal_collision : Marginals Coincident = Marginals Shifted := by decide
theorem mod4_marginal_collision : Marginals4 Coincident = Marginals4 Shifted := by decide
theorem different_or_parity : OrParity Coincident ≠ OrParity Shifted := by decide

theorem exact_marginals_do_not_recover_forcing_parity : ¬ Recovers Marginals OrParity :=
  collision_excludes_every_decoder _ _ exact_marginal_collision different_or_parity

theorem mod4_marginals_do_not_recover_forcing_parity : ¬ Recovers Marginals4 OrParity :=
  collision_excludes_every_decoder _ _ mod4_marginal_collision different_or_parity

theorem joint_restoration_is_constructive :
    (¬ Recovers Marginals4 OrParity) ∧ Recovers Joint4 OrParity :=
  ⟨mod4_marginals_do_not_recover_forcing_parity, joint_mod4_recovers_forcing_parity⟩

/-! Infinite-time clock integration. A period is exhibited; minimality is not
claimed for an arbitrary P. The standard dyadic minimal-period argument is
an additional elementary bridge stated in the reading document. -/

def Integral (g : Nat → Bool) : Nat → Bool
  | 0 => false
  | t + 1 => Bool.xor (Integral g t) (g t)

theorem integral_shift (g : Nat → Bool) (P : Nat)
    (periodic : ∀ t, g (t + P) = g t) (t : Nat) :
    Integral g (t + P) = Bool.xor (Integral g t) (Integral g P) := by
  induction t with
  | zero => simp [Integral]
  | succ t ih =>
    rw [Nat.succ_add]
    simp only [Integral, ih, periodic]
    cases Integral g t <;> cases Integral g P <;> cases g t <;> rfl

theorem integral_double_period (g : Nat → Bool) (P : Nat)
    (periodic : ∀ t, g (t + P) = g t) (t : Nat) :
    Integral g (t + 2 * P) = Integral g t := by
  have index : t + 2 * P = (t + P) + P := by omega
  rw [index, integral_shift g P periodic, integral_shift g P periodic]
  cases Integral g t <;> cases Integral g P <;> rfl

theorem integral_period_when_even (g : Nat → Bool) (P : Nat)
    (periodic : ∀ t, g (t + P) = g t) (even : Integral g P = false) (t : Nat) :
    Integral g (t + P) = Integral g t := by
  rw [integral_shift g P periodic, even]
  cases Integral g t <;> rfl

theorem integral_period_fails_when_odd (g : Nat → Bool) (P : Nat)
    (periodic : ∀ t, g (t + P) = g t) (odd : Integral g P = true) (t : Nat) :
    Integral g (t + P) ≠ Integral g t := by
  rw [integral_shift g P periodic, odd]
  cases Integral g t <;> decide

def SamplePrefix (a b : Nat → Bool) : Nat → PairWord
  | 0 => []
  | n + 1 => (a n,b n) :: SamplePrefix a b n

theorem prefix_parity_certifies_integral_residue (a b : Nat → Bool) (P : Nat) :
    bit (Integral (fun t => a t || b t) P) = OrParity (SamplePrefix a b P) := by
  induction P with
  | zero => rfl
  | succ n ih =>
    simp only [Integral, bit_xor_parity, ih, OrParity, SamplePrefix, weightOr]
    omega

theorem joint_readout_determines_integral_shift (a b : Nat → Bool) (P : Nat)
    (periodic : ∀ t, (a (t + P) || b (t + P)) = (a t || b t)) (t : Nat) :
    bit (Integral (fun s => a s || b s) (t + P)) =
      (bit (Integral (fun s => a s || b s) t) +
        DecodeOrParity (Joint4 (SamplePrefix a b P))) % 2 := by
  rw [integral_shift _ P periodic, bit_xor_parity,
      prefix_parity_certifies_integral_residue a b P, explicit_joint_decoder]

/-! Tail predicates. The positive and witness-bearing opposite are defined
separately so a classical equivalence is not silently used constructively. -/

def EventuallyPeriodic (c : Nat → Bool) : Prop :=
  ∃ N p, 0 < p ∧ ∀ t, N ≤ t → c (t + p) = c t
def NonPeriodic (c : Nat → Bool) : Prop :=
  ∀ N p, 0 < p → ∃ t, N ≤ t ∧ c (t + p) ≠ c t
def NegativeTranslation (c : Nat → Bool) : Prop :=
  ∀ N p, 0 < p → ¬¬ (∃ t, N ≤ t ∧ c (t + p) ≠ c t)

def BoundedBreak (c : Nat → Bool) (N p B : Nat) : Prop :=
  ∃ t, N ≤ t ∧ t ≤ B ∧ c (t + p) ≠ c t

theorem nonperiodicity_iff_all_break_searches_terminate (c : Nat → Bool) :
    NonPeriodic c ↔ ∀ N p, 0 < p → ∃ B, BoundedBreak c N p B := by
  constructor
  · intro h N p hp
    obtain ⟨t,ht,different⟩ := h N p hp
    exact ⟨t,t,ht,Nat.le_refl t,different⟩
  · intro h N p hp
    obtain ⟨B,t,ht,_,different⟩ := h N p hp
    exact ⟨t,ht,different⟩

def SearchSuccess (c : Nat → Bool) (N p : Nat) : Nat → Bool
  | 0 => decide (N ≤ 0 ∧ c (0 + p) ≠ c 0)
  | B + 1 => SearchSuccess c N p B ||
      decide (N ≤ B + 1 ∧ c (B + 1 + p) ≠ c (B + 1))

theorem search_success_iff_bounded_break (c : Nat → Bool) (N p B : Nat) :
    SearchSuccess c N p B = true ↔ BoundedBreak c N p B := by
  induction B with
  | zero =>
    simp only [SearchSuccess, decide_eq_true_eq, BoundedBreak]
    constructor
    · intro h
      exact ⟨0,h.1,Nat.le_refl 0,h.2⟩
    · rintro ⟨t,ht,htB,different⟩
      have zero : t = 0 := by omega
      subst t
      exact ⟨ht,different⟩
  | succ B ih =>
    simp only [SearchSuccess, Bool.or_eq_true, decide_eq_true_eq, ih]
    constructor
    · rintro (earlier | last)
      · obtain ⟨t,ht,htB,different⟩ := earlier
        exact ⟨t,ht,by omega,different⟩
      · exact ⟨B+1,last.1,Nat.le_refl _,last.2⟩
    · rintro ⟨t,ht,htB,different⟩
      by_cases earlier : t ≤ B
      · exact Or.inl ⟨t,ht,earlier,different⟩
      · have last : t = B + 1 := by omega
        subst t
        exact Or.inr ⟨ht,different⟩

theorem search_totality_characterizes_nonperiodicity (c : Nat → Bool) :
    NonPeriodic c ↔ ∀ N p, 0 < p → ∃ B, SearchSuccess c N p B = true := by
  rw [nonperiodicity_iff_all_break_searches_terminate]
  constructor
  · intro h N p hp
    obtain ⟨B,hB⟩ := h N p hp
    exact ⟨B,(search_success_iff_bounded_break c N p B).mpr hB⟩
  · intro h N p hp
    obtain ⟨B,hB⟩ := h N p hp
    exact ⟨B,(search_success_iff_bounded_break c N p B).mp hB⟩

theorem nonperiodic_excludes_eventual_periodicity (c : Nat → Bool)
    (h : NonPeriodic c) : ¬ EventuallyPeriodic c := by
  rintro ⟨N,p,hp,periodic⟩
  obtain ⟨t,ht,different⟩ := h N p hp
  exact different (periodic t ht)

theorem eventual_periodicity_excludes_nonperiodic (c : Nat → Bool)
    (h : EventuallyPeriodic c) : ¬ NonPeriodic c :=
  fun hn => nonperiodic_excludes_eventual_periodicity c hn h

theorem not_eventually_periodic_implies_nonperiodic_classically (c : Nat → Bool)
    (h : ¬ EventuallyPeriodic c) : NonPeriodic c := by
  classical
  intro N p hp
  apply Classical.byContradiction
  intro missing
  apply h
  refine ⟨N,p,hp,?_⟩
  intro t ht
  apply Classical.byContradiction
  intro different
  exact missing ⟨t,ht,different⟩

theorem not_nonperiodic_implies_eventual_periodicity_classically (c : Nat → Bool)
    (h : ¬ NonPeriodic c) : EventuallyPeriodic c := by
  classical
  apply Classical.byContradiction
  intro missing
  exact h (not_eventually_periodic_implies_nonperiodic_classically c missing)

theorem nonperiodic_implies_negative_translation (c : Nat → Bool)
    (h : NonPeriodic c) : NegativeTranslation c :=
  fun N p hp notWitness => notWitness (h N p hp)

theorem refuting_negative_translation_refutes_nonperiodic (c : Nat → Bool)
    (h : ¬ NegativeTranslation c) : ¬ NonPeriodic c :=
  fun hn => h (nonperiodic_implies_negative_translation c hn)

theorem constant_column_has_explicit_period (b : Bool) :
    EventuallyPeriodic (fun _ => b) :=
  ⟨0,1,by decide,fun _ _ => rfl⟩

/-! Application of the established scope rule to model classes. These
conditional theorems do not themselves construct arithmetical models. -/

theorem opposite_admitted_models_close_uniform_entailment
    {M : Type} (admitted : M → Prop) (claim : M → Prop)
    (yes : ∃ m, admitted m ∧ claim m)
    (no : ∃ m, admitted m ∧ ¬ claim m) :
    (¬ Supports admitted claim) ∧ (¬ Supports admitted (fun m => ¬ claim m)) := by
  obtain ⟨a,ha,hyes⟩ := yes
  obtain ⟨b,hb,hno⟩ := no
  exact ⟨fun all => hno (all b hb), fun all => all a ha hyes⟩

theorem full_observation_recovery_can_embed_arbitrary_given_target (q : Nat → Bool) :
    Recovers (fun n : Nat => n) q :=
  ⟨q,fun _ => rfl⟩


/-! Recorded finite witnesses: their weights are kernel-checked below. Their
Rule 30 provenance is independently checked against direct cell simulation
by reproduction/check_application.py, rather than assumed by these literals. -/

def RecordedRung5 : PairWord := [
  (false,false),
  (false,false),
  (true,true),
  (false,true),
  (true,false),
  (true,false),
  (false,true),
  (true,true)]

def RecordedRung9 : PairWord := [
  (false,false),
  (false,false),
  (false,false),
  (false,false),
  (true,true),
  (false,true),
  (true,false),
  (true,false),
  (true,true),
  (false,false),
  (true,true),
  (false,false),
  (false,true),
  (true,false),
  (true,true),
  (false,false),
  (true,true),
  (false,true),
  (true,true),
  (false,true),
  (true,false),
  (true,false),
  (false,true),
  (true,true),
  (false,false),
  (true,true),
  (false,false),
  (true,true),
  (false,false),
  (true,true),
  (false,false),
  (true,true)]

theorem recorded_rung_weights :
    (weightLeft RecordedRung5, weightRight RecordedRung5, weightXor RecordedRung5,
      weightAnd RecordedRung5, OrParity RecordedRung5) = (4,4,4,2,0) ∧
    (weightLeft RecordedRung9, weightRight RecordedRung9, weightXor RecordedRung9,
      weightAnd RecordedRung9, OrParity RecordedRung9) = (16,16,10,11,1) := by decide

theorem recorded_rungs_certify_mod4_collision :
    Marginals4 RecordedRung5 = Marginals4 RecordedRung9 ∧
    OrParity RecordedRung5 ≠ OrParity RecordedRung9 ∧
    Joint4 RecordedRung5 ≠ Joint4 RecordedRung9 := by decide

theorem recorded_rungs_expose_extra_verdict_input :
    ¬ DeclaredStandard Marginals4 OrParity :=
  different_verdicts_expose_extra_input _ _
    recorded_rungs_certify_mod4_collision.1 recorded_rungs_certify_mod4_collision.2.1

end Rule30Application
