import Rule30Application

/-!
Rule 30 bridge, 23 October 2026. Claude, with Lu Semita, building on the R2 packet.

The R2 packet proves its count and clock identities over arbitrary words and sequences, and links
them to Rule 30 by finite checks. This file supplies the universal link. It defines the automaton
itself, from one black cell, for every rule  new = left xor F(center, right)  with F(0,0) = 0, and
proves, for all times:
* the light cone and the two edges;
* left-permutivity and Jen's adjacent-column theorem: no two adjacent columns are both eventually
  periodic (Jen 1986, as reported in A New Kind of Science, notes to p. 871; proof reconstructed here);
* for Rule 30, the diagonal recurrence, each diagonal as the packet's `Integral` of the OR of the two
  diagonals to its right, a power-of-2 period for every diagonal (Theorem 1), and the first-turn
  reading (Theorem 2);
* for rule 150, mirror symmetry and a constant center column;
* the remaining gap for Problem 1 as one implication, and that implication's failure for rule 150.
-/

namespace Rule30Bridge

open Rule30Application

/-! ## The automaton -/

/-- One black cell at position 0; the new value is left xor F(center, right). -/
def cellF (F : Bool → Bool → Bool) : Nat → Int → Bool
  | 0, x => decide (x = 0)
  | t + 1, x => Bool.xor (cellF F t (x - 1)) (F (cellF F t x) (cellF F t (x + 1)))

theorem cellF_zero (F : Bool → Bool → Bool) (x : Int) : cellF F 0 x = decide (x = 0) := rfl

theorem cellF_succ (F : Bool → Bool → Bool) (t : Nat) (x : Int) :
    cellF F (t + 1) x = Bool.xor (cellF F t (x - 1)) (F (cellF F t x) (cellF F t (x + 1))) := rfl

/-- Cells to the right of the light cone are white. -/
theorem cone_right (F : Bool → Bool → Bool) (h00 : F false false = false) :
    ∀ (t : Nat) (x : Int), (t : Int) < x → cellF F t x = false := by
  intro t
  induction t with
  | zero =>
    intro x hx
    rw [cellF_zero]
    simp only [decide_eq_false_iff_not]
    omega
  | succ t ih =>
    intro x hx
    rw [cellF_succ, ih (x - 1) (by omega), ih x (by omega), ih (x + 1) (by omega), h00]
    rfl

/-- Cells to the left of the light cone are white. -/
theorem cone_left (F : Bool → Bool → Bool) (h00 : F false false = false) :
    ∀ (t : Nat) (x : Int), x < -(t : Int) → cellF F t x = false := by
  intro t
  induction t with
  | zero =>
    intro x hx
    rw [cellF_zero]
    simp only [decide_eq_false_iff_not]
    omega
  | succ t ih =>
    intro x hx
    rw [cellF_succ, ih (x - 1) (by omega), ih x (by omega), ih (x + 1) (by omega), h00]
    rfl

/-- The right edge of the cone is black. -/
theorem right_edge (F : Bool → Bool → Bool) (h00 : F false false = false) :
    ∀ t : Nat, cellF F t (t : Int) = true := by
  intro t
  induction t with
  | zero => rw [cellF_zero]; decide
  | succ t ih =>
    rw [cellF_succ]
    have e : ((t + 1 : Nat) : Int) - 1 = (t : Int) := by omega
    rw [e, ih, cone_right F h00 t _ (by omega), cone_right F h00 t _ (by omega), h00]
    rfl

/-- The left edge of the cone is black when F(0, 1) = 1. -/
theorem left_edge (F : Bool → Bool → Bool) (h00 : F false false = false)
    (h01 : F false true = true) : ∀ t : Nat, cellF F t (-(t : Int)) = true := by
  intro t
  induction t with
  | zero => rw [cellF_zero]; decide
  | succ t ih =>
    rw [cellF_succ]
    have e : -((t + 1 : Nat) : Int) + 1 = -(t : Int) := by omega
    rw [cone_left F h00 t _ (by omega), cone_left F h00 t _ (by omega), e, ih, h01]
    rfl

/-- Left-permutivity: the column to the left is read off two columns and the next row. -/
theorem left_permutive (F : Bool → Bool → Bool) (t : Nat) (x : Int) :
    cellF F t (x - 1) = Bool.xor (cellF F (t + 1) x) (F (cellF F t x) (cellF F t (x + 1))) := by
  rw [cellF_succ]
  cases cellF F t (x - 1) <;> cases F (cellF F t x) (cellF F t (x + 1)) <;> rfl

/-! ## Jen's adjacent-column theorem -/

/-- Periodic with period p from time N on. -/
def PeriodicFrom (f : Nat → Bool) (N p : Nat) : Prop := ∀ t, N ≤ t → f (t + p) = f t

theorem periodicFrom_mono {f : Nat → Bool} {N N' p : Nat} (h : PeriodicFrom f N p) (hN : N ≤ N') :
    PeriodicFrom f N' p := fun t ht => h t (Nat.le_trans hN ht)

theorem periodicFrom_mul {f : Nat → Bool} {N p : Nat} (h : PeriodicFrom f N p) :
    ∀ n : Nat, PeriodicFrom f N (p * n) := by
  intro n
  induction n with
  | zero => intro t _; simp
  | succ n ih =>
    intro t ht
    have e : t + p * (n + 1) = (t + p * n) + p := by rw [Nat.mul_succ, Nat.add_assoc]
    rw [e, h (t + p * n) (by omega), ih t ht]

theorem inherit_left (F : Bool → Bool → Bool) (N p : Nat) (j : Int)
    (hj : PeriodicFrom (fun t => cellF F t j) N p)
    (hj1 : PeriodicFrom (fun t => cellF F t (j + 1)) N p) :
    PeriodicFrom (fun t => cellF F t (j - 1)) N p := by
  intro t ht
  show cellF F (t + p) (j - 1) = cellF F t (j - 1)
  rw [left_permutive F (t + p) j, left_permutive F t j]
  have a : cellF F (t + 1 + p) j = cellF F (t + 1) j := hj (t + 1) (by omega)
  have b : cellF F (t + p) j = cellF F t j := hj t ht
  have c : cellF F (t + p) (j + 1) = cellF F t (j + 1) := hj1 t ht
  rw [show t + p + 1 = t + 1 + p by omega, a, b, c]

theorem inherit_all (F : Bool → Bool → Bool) (N p : Nat) (j : Int)
    (hj : PeriodicFrom (fun t => cellF F t j) N p)
    (hj1 : PeriodicFrom (fun t => cellF F t (j + 1)) N p) :
    ∀ m : Nat, PeriodicFrom (fun t => cellF F t (j - m)) N p ∧
      PeriodicFrom (fun t => cellF F t (j - m + 1)) N p := by
  intro m
  induction m with
  | zero =>
    have e1 : j - ((0 : Nat) : Int) = j := by omega
    rw [e1]
    exact ⟨hj, hj1⟩
  | succ m ih =>
    obtain ⟨h0, h1⟩ := ih
    have new := inherit_left F N p (j - m) h0 h1
    have e1 : j - ((m + 1 : Nat) : Int) = j - (m : Int) - 1 := by omega
    have e2 : j - ((m + 1 : Nat) : Int) + 1 = j - (m : Int) := by omega
    rw [e1, show j - (m : Int) - 1 + 1 = j - (m : Int) by omega]
    exact ⟨new, h0⟩

/-- Two adjacent columns that are periodic from the same time with the same period: impossible. -/
theorem adjacent_columns_not_jointly_periodic (F : Bool → Bool → Bool)
    (h00 : F false false = false) (h01 : F false true = true)
    (j : Int) (N p : Nat) (hp : 0 < p)
    (hj : PeriodicFrom (fun t => cellF F t j) N p)
    (hj1 : PeriodicFrom (fun t => cellF F t (j + 1)) N p) : False := by
  -- Go to a column far enough left that the left edge reaches it after time N + p.
  have hcol := (inherit_all F N p j hj hj1 (j.toNat + N + p)).1
  have hjle : j ≤ (j.toNat : Int) := Int.self_le_toNat j
  -- T is the time at which the left edge reaches that column.
  let T : Nat := ((j.toNat + N + p : Nat) - j).toNat
  have hT : (T : Int) = ((j.toNat + N + p : Nat) : Int) - j := by
    show (((((j.toNat + N + p : Nat) : Int) - j).toNat : Nat) : Int) = _
    rw [Int.toNat_of_nonneg (by omega)]
  have hTge : N + p ≤ T := by omega
  have black : cellF F T (j - ((j.toNat + N + p : Nat) : Int)) = true := by
    have h := left_edge F h00 h01 T
    rw [hT, show -(((j.toNat + N + p : Nat) : Int) - j) = j - ((j.toNat + N + p : Nat) : Int) by omega] at h
    exact h
  have white : cellF F (T - p) (j - ((j.toNat + N + p : Nat) : Int)) = false := by
    apply cone_left F h00
    omega
  have per : cellF F (T - p + p) (j - ((j.toNat + N + p : Nat) : Int)) =
      cellF F (T - p) (j - ((j.toNat + N + p : Nat) : Int)) := hcol (T - p) (by omega)
  rw [show T - p + p = T by omega, black, white] at per
  exact Bool.noConfusion per

theorem eventuallyPeriodic_to_from {f : Nat → Bool} (h : EventuallyPeriodic f) :
    ∃ N p, 0 < p ∧ PeriodicFrom f N p := by
  obtain ⟨N, p, hp, hper⟩ := h
  exact ⟨N, p, hp, hper⟩

/-- Jen's theorem for adjacent columns: they are never both eventually periodic. -/
theorem jen_adjacent (F : Bool → Bool → Bool) (h00 : F false false = false)
    (h01 : F false true = true) (j : Int) :
    ¬ (EventuallyPeriodic (fun t => cellF F t j) ∧
        EventuallyPeriodic (fun t => cellF F t (j + 1))) := by
  rintro ⟨⟨N1, p1, hp1, h1⟩, ⟨N2, p2, hp2, h2⟩⟩
  have a : PeriodicFrom (fun t => cellF F t j) (N1 + N2) (p1 * p2) :=
    periodicFrom_mono (periodicFrom_mul (show PeriodicFrom (fun t => cellF F t j) N1 p1 from h1) p2) (Nat.le_add_right N1 N2)
  have b0 : PeriodicFrom (fun t => cellF F t (j + 1)) (N1 + N2) (p2 * p1) :=
    periodicFrom_mono (periodicFrom_mul (show PeriodicFrom (fun t => cellF F t (j + 1)) N2 p2 from h2) p1) (Nat.le_add_left N2 N1)
  have b : PeriodicFrom (fun t => cellF F t (j + 1)) (N1 + N2) (p1 * p2) := by
    rw [Nat.mul_comm]; exact b0
  exact adjacent_columns_not_jointly_periodic F h00 h01 j (N1 + N2) (p1 * p2)
    (Nat.mul_pos hp1 hp2) a b

/-! ## Rule 30 -/

def or30 : Bool → Bool → Bool := fun m r => m || r
theorem or30_00 : or30 false false = false := rfl
theorem or30_01 : or30 false true = true := rfl

def cell30 : Nat → Int → Bool := cellF or30
/-- The center column. -/
def center30 (t : Nat) : Bool := cell30 t 0
/-- The column just right of the center. -/
def right30 (t : Nat) : Bool := cell30 t 1

/-- Diagonal k counted in from the right edge: D(k, t) = cell(t, t − k). -/
def diag30 (k : Int) (t : Nat) : Bool := cell30 t ((t : Int) - k)

theorem diag30_recurrence (k : Int) (t : Nat) :
    diag30 k (t + 1) = Bool.xor (diag30 k t) (diag30 (k - 1) t || diag30 (k - 2) t) := by
  unfold diag30 cell30
  rw [cellF_succ]
  have e1 : ((t + 1 : Nat) : Int) - k - 1 = (t : Int) - k := by omega
  have e2 : ((t + 1 : Nat) : Int) - k = (t : Int) - (k - 1) := by omega
  have e3 : ((t + 1 : Nat) : Int) - k + 1 = (t : Int) - (k - 2) := by omega
  rw [e3, e1, e2]
  rfl

theorem diag30_zero (t : Nat) : diag30 0 t = true := by
  unfold diag30 cell30
  rw [show (t : Int) - 0 = (t : Int) by omega]
  exact right_edge or30 or30_00 t

theorem diag30_neg (k : Int) (hk : k < 0) (t : Nat) : diag30 k t = false := by
  unfold diag30 cell30
  exact cone_right or30 or30_00 t _ (by omega)

theorem diag30_start (k : Int) (hk : 0 < k) : diag30 k 0 = false := by
  unfold diag30 cell30
  rw [cellF_zero]
  simp only [decide_eq_false_iff_not]
  omega

/-- Each diagonal right of the edge is the packet's Integral of the OR of the two to its right. -/
theorem diag30_is_integral (k : Int) (hk : 0 < k) :
    ∀ t : Nat, diag30 k t = Integral (fun s => diag30 (k - 1) s || diag30 (k - 2) s) t := by
  intro t
  induction t with
  | zero => rw [diag30_start k hk]; rfl
  | succ t ih => rw [diag30_recurrence, ih]; rfl

theorem center30_is_diag (t : Nat) : center30 t = diag30 t t := by
  unfold center30 diag30
  rw [show (t : Int) - (t : Int) = 0 by omega]

theorem right30_is_diag (t : Nat) : right30 (t + 1) = diag30 t (t + 1) := by
  unfold right30 diag30
  rw [show ((t + 1 : Nat) : Int) - (t : Int) = 1 by omega]

/-- Purely periodic with period P from time 0. -/
def Per (f : Nat → Bool) (P : Nat) : Prop := ∀ t, f (t + P) = f t

theorem per_mul {f : Nat → Bool} {P : Nat} (h : Per f P) : ∀ n, Per f (P * n) := by
  intro n
  induction n with
  | zero => intro t; simp
  | succ n ih =>
    intro t
    have e : t + P * (n + 1) = (t + P * n) + P := by rw [Nat.mul_succ, Nat.add_assoc]
    rw [e, h, ih]

theorem per_pow_le {f : Nat → Bool} {a b : Nat} (h : Per f (2 ^ a)) (hab : a ≤ b) :
    Per f (2 ^ b) := by
  have e : 2 ^ b = 2 ^ a * 2 ^ (b - a) := by
    rw [← Nat.pow_add, Nat.add_sub_cancel' hab]
  rw [e]
  exact per_mul h _

/-- Theorem 1 (existence form): every right diagonal of Rule 30 is purely periodic with a power of 2
as a period. Minimality is not claimed here. -/
theorem diag30_dyadic : ∀ k : Nat,
    (∃ e : Nat, Per (diag30 (k : Int)) (2 ^ e)) ∧ (∃ e : Nat, Per (diag30 ((k + 1 : Nat) : Int)) (2 ^ e)) := by
  intro k
  induction k with
  | zero =>
    refine ⟨⟨0, fun t => ?_⟩, ⟨1, fun t => ?_⟩⟩
    · show diag30 0 (t + 1) = diag30 0 t
      rw [diag30_zero, diag30_zero]
    · have g1 : ∀ s, (fun s => diag30 ((1 : Nat) - 1 : Int) s || diag30 ((1 : Nat) - 2 : Int) s) (s + 1) =
          (fun s => diag30 ((1 : Nat) - 1 : Int) s || diag30 ((1 : Nat) - 2 : Int) s) s := by
        intro s
        show (diag30 ((1 : Nat) - 1 : Int) (s + 1) || _) = (diag30 ((1 : Nat) - 1 : Int) s || _)
        rw [show (((1 : Nat) : Int) - 1) = 0 by omega, diag30_zero, diag30_zero]
        rfl
      show diag30 ((0 + 1 : Nat) : Int) (t + 2 ^ 1) = diag30 ((0 + 1 : Nat) : Int) t
      have hk : (0 : Int) < ((0 + 1 : Nat) : Int) := by omega
      rw [diag30_is_integral _ hk, diag30_is_integral _ hk]
      have := integral_double_period
        (fun s => diag30 ((1 : Nat) - 1 : Int) s || diag30 ((1 : Nat) - 2 : Int) s) 1 g1 t
      simpa using this
  | succ k ih =>
    obtain ⟨⟨e1, h1⟩, ⟨e2, h2⟩⟩ := ih
    refine ⟨⟨e2, h2⟩, ⟨max e1 e2 + 1, fun t => ?_⟩⟩
    have p1 : Per (diag30 (k : Int)) (2 ^ max e1 e2) := per_pow_le h1 (Nat.le_max_left _ _)
    have p2 : Per (diag30 ((k + 1 : Nat) : Int)) (2 ^ max e1 e2) := per_pow_le h2 (Nat.le_max_right _ _)
    have hk : (0 : Int) < ((k + 1 + 1 : Nat) : Int) := by omega
    have a1 : ((k + 1 + 1 : Nat) : Int) - 1 = ((k + 1 : Nat) : Int) := by omega
    have a2 : ((k + 1 + 1 : Nat) : Int) - 2 = (k : Int) := by omega
    have gper : ∀ s, (fun s => diag30 (((k + 1 + 1 : Nat) : Int) - 1) s ||
        diag30 (((k + 1 + 1 : Nat) : Int) - 2) s) (s + 2 ^ max e1 e2) =
        (fun s => diag30 (((k + 1 + 1 : Nat) : Int) - 1) s ||
        diag30 (((k + 1 + 1 : Nat) : Int) - 2) s) s := by
      intro s
      show (diag30 (((k + 1 + 1 : Nat) : Int) - 1) (s + 2 ^ max e1 e2) ||
          diag30 (((k + 1 + 1 : Nat) : Int) - 2) (s + 2 ^ max e1 e2)) =
          (diag30 (((k + 1 + 1 : Nat) : Int) - 1) s || diag30 (((k + 1 + 1 : Nat) : Int) - 2) s)
      rw [a1, a2, p1 s, p2 s]
    rw [diag30_is_integral _ hk, diag30_is_integral _ hk]
    have e : t + 2 ^ (max e1 e2 + 1) = t + 2 * 2 ^ max e1 e2 := by
      rw [Nat.pow_succ, Nat.mul_comm]
    rw [e]
    exact integral_double_period _ _ gper t

/-- The two leftmost cells of the cone are black for Rule 30. -/
theorem left_edge_inner30 : ∀ s : Nat, cell30 (s + 1) (-(s : Int)) = true := by
  intro s
  unfold cell30
  rw [cellF_succ, cone_left or30 or30_00 s _ (by omega), left_edge or30 or30_00 or30_01 s]
  rfl

/-- White before the cone reaches the diagonal. -/
theorem diag30_white (k : Int) (s : Nat) (h : 2 * (s : Int) < k) : diag30 k s = false := by
  unfold diag30 cell30
  exact cone_left or30 or30_00 s _ (by omega)

/-- Black on entering the cone. -/
theorem diag30_entry (t : Nat) : diag30 (t : Int) ((t + 1) / 2) = true := by
  unfold diag30
  rcases Nat.mod_two_eq_zero_or_one t with h | h
  · -- t even (t = 0 included): the entry cell is the left edge at time t / 2
    have e : (((t + 1) / 2 : Nat) : Int) - (t : Int) = -(((t + 1) / 2 : Nat) : Int) := by omega
    rw [e]
    unfold cell30
    exact left_edge or30 or30_00 or30_01 _
  · -- t odd: the entry cell is the second cell from the left edge at time t / 2 + 1
    have q : (t + 1) / 2 = t / 2 + 1 := by omega
    rw [q, show (((t / 2 + 1 : Nat) : Int) - (t : Int)) = -((t / 2 : Nat) : Int) by omega]
    exact left_edge_inner30 (t / 2)

/-- Theorem 2: if c(t) = 1, every period of diagonal t exceeds t. -/
theorem first_turn_reading30 (t : Nat) (hc : center30 t = true) (p : Nat) (hp : 0 < p)
    (hper : Per (diag30 (t : Int)) p) : t < p := by
  rcases Nat.lt_or_ge t p with hlt | hge
  · exact hlt
  · exfalso
    -- every period exceeds the entry time
    have hentry : (t + 1) / 2 < p := by
      rcases Nat.lt_or_ge ((t + 1) / 2) p with h | h
      · exact h
      · exfalso
        have back := hper ((t + 1) / 2 - p)
        rw [show (t + 1) / 2 - p + p = (t + 1) / 2 by omega, diag30_entry t,
          diag30_white (t : Int) ((t + 1) / 2 - p) (by omega)] at back
        exact Bool.noConfusion back
    have back := hper (t - p)
    rw [show t - p + p = t by omega, ← center30_is_diag, hc,
      diag30_white (t : Int) (t - p) (by omega)] at back
    exact Bool.noConfusion back

/-! ## Rule 150: the control -/

def xor150 : Bool → Bool → Bool := fun m r => Bool.xor m r
theorem xor150_00 : xor150 false false = false := rfl
theorem xor150_01 : xor150 false true = true := rfl

def cell150 : Nat → Int → Bool := cellF xor150
def center150 (t : Nat) : Bool := cell150 t 0
def right150 (t : Nat) : Bool := cell150 t 1

theorem cell150_symm : ∀ (t : Nat) (x : Int), cell150 t (-x) = cell150 t x := by
  intro t
  induction t with
  | zero =>
    intro x
    unfold cell150
    rw [cellF_zero, cellF_zero]
    by_cases h : x = 0
    · subst h; rfl
    · have h' : -x ≠ 0 := by omega
      simp [h, h']
  | succ t ih =>
    intro x
    unfold cell150 at *
    rw [cellF_succ, cellF_succ]
    rw [show -x - 1 = -(x + 1) by omega, show -x + 1 = -(x - 1) by omega, ih (x + 1), ih x, ih (x - 1)]
    generalize cellF xor150 t (x + 1) = a
    generalize cellF xor150 t x = b
    generalize cellF xor150 t (x - 1) = c
    cases a <;> cases b <;> cases c <;> rfl

/-- Rule 150's center column is constant black: its two neighbours are mirror images and cancel. -/
theorem center150_constant : ∀ t : Nat, center150 t = true := by
  intro t
  induction t with
  | zero => decide
  | succ t ih =>
    unfold center150 at *
    have s := cell150_symm t 1
    unfold cell150 at *
    rw [cellF_succ, show (0 : Int) - 1 = -1 by decide, show (0 : Int) + 1 = 1 by decide, s, ih]
    generalize cellF xor150 t 1 = a
    cases a <;> rfl

theorem center150_eventually_periodic : EventuallyPeriodic center150 :=
  ⟨0, 1, by decide, fun t _ => by rw [center150_constant, center150_constant]⟩

/-! ## The gap -/

/-- Jen's theorem at the center of Rule 30: the center column and its right neighbour are never both
eventually periodic. -/
theorem jen30 : ¬ (EventuallyPeriodic center30 ∧ EventuallyPeriodic right30) := by
  have h := jen_adjacent or30 or30_00 or30_01 0
  exact h

/-- Problem 1 for Rule 30 (as ¬ eventually periodic) is equivalent to one implication: if the center
column is eventually periodic, so is the column just right of it. Constructive in both directions. -/
theorem rule30_problem1_iff_marginal_step :
    ¬ EventuallyPeriodic center30 ↔ (EventuallyPeriodic center30 → EventuallyPeriodic right30) := by
  constructor
  · intro h hc
    exact absurd hc h
  · intro step hc
    exact jen30 ⟨hc, step hc⟩

/-- The same implication fails for rule 150: its center is periodic and its right neighbour is not.
So any proof of the step must use what separates Rule 30 from rule 150. -/
theorem rule150_marginal_step_fails :
    EventuallyPeriodic center150 ∧ ¬ EventuallyPeriodic right150 := by
  refine ⟨center150_eventually_periodic, fun hr => ?_⟩
  have h := jen_adjacent xor150 xor150_00 xor150_01 0
  apply h
  refine ⟨?_, ?_⟩
  · exact center150_eventually_periodic
  · exact hr


/-! ## Where the AND acts at the center -/

/-- The column just left of the center. -/
def left30 (t : Nat) : Bool := cell30 t (-1)

/-- Read sideways at the center: L(t) = c(t + 1) xor (c(t) or R(t)). -/
theorem left30_sideways (t : Nat) :
    left30 t = Bool.xor (center30 (t + 1)) (center30 t || right30 t) := by
  unfold left30 center30 right30 cell30
  have h := left_permutive or30 t 0
  rw [show (0 : Int) - 1 = -1 by decide, show (0 : Int) + 1 = 1 by decide] at h
  exact h

/-- Masking. If the center column had period p from time N, then from N on the left neighbour's
failures of period p occur only at white center cells, and there they coincide with the right
neighbour's: at a black center cell the OR hides the right neighbour completely. For rule 150 the
corresponding identity has no mask. -/
theorem masking30 (N p : Nat) (hc : PeriodicFrom center30 N p) (t : Nat) (ht : N ≤ t) :
    Bool.xor (left30 (t + p)) (left30 t) =
      (!center30 t && Bool.xor (right30 (t + p)) (right30 t)) := by
  rw [left30_sideways (t + p), left30_sideways t]
  have h1 : center30 (t + p + 1) = center30 (t + 1) := by
    rw [show t + p + 1 = t + 1 + p by omega]; exact hc (t + 1) (by omega)
  have h0 : center30 (t + p) = center30 t := hc t ht
  rw [h1, h0]
  generalize center30 (t + 1) = a
  generalize center30 t = b
  generalize right30 (t + p) = r1
  generalize right30 t = r0
  cases a <;> cases b <;> cases r1 <;> cases r0 <;> rfl

/-- So under a periodic center, the left neighbour keeps the period at every black center cell. -/
theorem left_keeps_period_at_black (N p : Nat) (hc : PeriodicFrom center30 N p) (t : Nat)
    (ht : N ≤ t) (black : center30 t = true) : left30 (t + p) = left30 t := by
  have h := masking30 N p hc t ht
  rw [black] at h
  simp only [Bool.not_true, Bool.false_and] at h
  generalize left30 (t + p) = a at h ⊢
  generalize left30 t = b at h ⊢
  cases a <;> cases b <;> first | rfl | exact absurd h (by decide)

/-! ## The center is never eventually constant -/

theorem center30_succ (t : Nat) :
    center30 (t + 1) = Bool.xor (left30 t) (center30 t || right30 t) := by
  unfold center30 left30 right30 cell30
  rw [cellF_succ, show (0 : Int) - 1 = -1 by decide, show (0 : Int) + 1 = 1 by decide]
  rfl

theorem right30_succ (t : Nat) :
    right30 (t + 1) = Bool.xor (center30 t) (right30 t || cell30 t 2) := by
  unfold center30 right30 cell30
  rw [cellF_succ, show (1 : Int) - 1 = 0 by decide, show (1 : Int) + 1 = 2 by decide]
  rfl

/-- The center column is not eventually white: if it were, the right neighbour would only ever switch
on (R(t+1) = R(t) or cell(t,2)), so it would settle too, against Jen's theorem. -/
theorem center30_not_eventually_white : ¬ ∃ M, ∀ t, M ≤ t → center30 t = false := by
  rintro ⟨M, hM⟩
  have hcEP : EventuallyPeriodic center30 :=
    ⟨M, 1, by decide, fun t ht => by rw [hM (t + 1) (by omega), hM t ht]⟩
  have mono : ∀ t, M ≤ t → right30 t = true → right30 (t + 1) = true := by
    intro t ht h
    rw [right30_succ, hM t ht, h]
    rfl
  have nn : ¬¬ EventuallyPeriodic right30 := by
    intro hnot
    have no_true : ∀ t, M ≤ t → right30 t = false := by
      intro t ht
      cases hR : right30 t with
      | false => rfl
      | true =>
        exfalso
        apply hnot
        have all_true : ∀ n, right30 (t + n) = true := by
          intro n
          induction n with
          | zero => exact hR
          | succ n ih => exact mono (t + n) (by omega) ih
        refine ⟨t, 1, by decide, fun s hs => ?_⟩
        have a := all_true (s + 1 - t)
        have b := all_true (s - t)
        rw [show t + (s + 1 - t) = s + 1 by omega] at a
        rw [show t + (s - t) = s by omega] at b
        rw [a, b]
    exact hnot ⟨M, 1, by decide, fun t ht => by rw [no_true (t + 1) (by omega), no_true t ht]⟩
  exact nn (fun hR => jen30 ⟨hcEP, hR⟩)

/-- The center column is not eventually black: at a black center cell c(t+1) = not L(t), so the left
neighbour would be eventually white, against Jen's theorem for the columns -1 and 0. -/
theorem center30_not_eventually_black : ¬ ∃ M, ∀ t, M ≤ t → center30 t = true := by
  rintro ⟨M, hM⟩
  have hcEP : EventuallyPeriodic center30 :=
    ⟨M, 1, by decide, fun t ht => by rw [hM (t + 1) (by omega), hM t ht]⟩
  have hL : ∀ t, M ≤ t → left30 t = false := by
    intro t ht
    have h := center30_succ t
    rw [hM (t + 1) (by omega), hM t ht] at h
    generalize left30 t = a at h ⊢
    generalize right30 t = r at h
    cases a <;> cases r <;> first | rfl | exact absurd h (by decide)
  have hLEP : EventuallyPeriodic left30 :=
    ⟨M, 1, by decide, fun t ht => by rw [hL (t + 1) (by omega), hL t ht]⟩
  have h := jen_adjacent or30 or30_00 or30_01 (-1)
  apply h
  refine ⟨?_, ?_⟩
  · exact hLEP
  · rw [show (-1 : Int) + 1 = 0 by decide]
    exact hcEP

/-! ## The left half, driven by the center alone -/

/-- The left half-line driven at its right boundary by b. Index m ≥ 1 stands for position -m and
index 0 is the drive itself; zero start. -/
def lh (b : Nat → Bool) : Nat → Nat → Bool
  | t, 0 => b t
  | 0, _ + 1 => false
  | t + 1, m + 1 => Bool.xor (lh b t (m + 2)) (lh b t (m + 1) || lh b t m)

/-- Rule 30's left half is exactly the left half-line driven by the center column. -/
theorem lh_center30 : ∀ (t m : Nat), lh center30 t m = cell30 t (-(m : Int)) := by
  intro t
  induction t with
  | zero =>
    intro m
    cases m with
    | zero => rfl
    | succ m =>
      simp only [lh]
      unfold cell30
      rw [cellF_zero]
      symm
      simp only [decide_eq_false_iff_not]
      omega
  | succ t ih =>
    intro m
    cases m with
    | zero =>
      simp only [lh]
      unfold center30
      rfl
    | succ m =>
      simp only [lh]
      rw [ih (m + 2), ih (m + 1), ih m]
      unfold cell30
      rw [cellF_succ]
      rw [show -(((m + 1 : Nat) : Int)) - 1 = -(((m + 2 : Nat) : Int)) by omega,
        show -(((m + 1 : Nat) : Int)) + 1 = -((m : Nat) : Int) by omega]
      rfl

/-- A sufficient condition stated on the left half alone: a left half-line driven by an eventually
periodic signal that is black at time 0 and not eventually white never keeps its edge column
periodic at all of the signal's black cells. -/
def LeftHalfBreaksAtBlack : Prop :=
  ∀ (b : Nat → Bool) (N p : Nat), 0 < p → b 0 = true → PeriodicFrom b N p →
    (¬ ∃ M, ∀ t, M ≤ t → b t = false) →
    ¬ (∀ t, N ≤ t → b t = true → lh b (t + p) 1 = lh b t 1)

/-- The reduction: the left-half condition implies Problem 1 (as not eventually periodic). -/
theorem problem1_of_left_half_breaks (h : LeftHalfBreaksAtBlack) :
    ¬ EventuallyPeriodic center30 := by
  rintro ⟨N, p, hp, hper⟩
  apply h center30 N p hp rfl hper center30_not_eventually_white
  intro t ht black
  rw [lh_center30, lh_center30]
  have k := left_keeps_period_at_black N p hper t ht black
  simpa [left30] using k

end Rule30Bridge
