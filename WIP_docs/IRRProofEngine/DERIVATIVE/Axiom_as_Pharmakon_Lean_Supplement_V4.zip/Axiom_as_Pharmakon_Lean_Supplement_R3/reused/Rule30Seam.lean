import ClosureCheck
import SeamIntegration

/-!
Rule 30 phase/output factorization is exactly the existing ReachDet condition.
This identifies a technical shield seam with the recovery structure used by
Lambda. It does not assert that every finite initial row has such a conflict,
or that a fixed-width failure survives changing the admissible width.
-/

namespace Rule30Seam

open SeamClosure SeamIntegration ClosureCheck ShieldEntry

variable {w : List Bool} {J P f0 : Nat} {S0 : Fin J → Bool}

def ReachableBand (w : List Bool) (J P f0 : Nat) (S0 : Fin J → Bool) :=
  {q : Nat × (Fin J → Bool) // Reach w J P f0 S0 q.1 q.2}

def phase (q : ReachableBand w J P f0 S0) : Nat := q.val.1

def output (hJ : 0 < J) (q : ReachableBand w J P f0 S0) : Bool :=
  q.val.2 ⟨0, hJ⟩

theorem reachDet_iff_fibre_constant (hJ : 0 < J) :
    ReachDet w J P f0 S0 ↔
      FibreConstant (@phase w J P f0 S0) (output hJ) := by
  constructor
  · intro det a b same
    obtain ⟨⟨f, S⟩, hs⟩ := a
    obtain ⟨⟨g, T⟩, ht⟩ := b
    change f = g at same
    subst g
    exact det hJ f S T hs ht
  · intro constant hJ' f S T hs ht
    exact constant ⟨(f, S), hs⟩ ⟨(f, T), ht⟩ rfl

/-- The converse uses the canonical reachable path, with no choice axiom. -/
theorem reachDet_iff_phase_recovers_output
    (hJ : 0 < J) (hP : 0 < P) (hf0 : f0 < P) :
    ReachDet w J P f0 S0 ↔
      Recovers (@phase w J P f0 S0) (output hJ) := by
  constructor
  · intro det
    let C := certOfReach hJ hP hf0 det
    refine ⟨C.value, ?_⟩
    intro q
    exact (C.det q.val.1 q.val.2 hJ
      (reach_sub C Reach.base q.val.1 q.val.2 q.property)).symm
  · intro recovery
    exact (reachDet_iff_fibre_constant hJ).2
      (recovery_requires_fibre_constancy _ _ recovery)

theorem certificate_iff_phase_decoder
    (hJ : 0 < J) (hP : 0 < P) (hf0 : f0 < P) :
    (∃ C : Certificate w J P, C.R f0 S0) ↔
      Recovers (@phase w J P f0 S0) (output hJ) :=
  (cert_iff_reachDet hJ hP hf0).trans
    (reachDet_iff_phase_recovers_output hJ hP hf0)

def edgeConflictSeam (hJ : 0 < J) (f : Nat) (S T : Fin J → Bool)
    (hs : Reach w J P f0 S0 f S) (ht : Reach w J P f0 S0 f T)
    (different : S ⟨0, hJ⟩ ≠ T ⟨0, hJ⟩) :
    SeamCertificate (@phase w J P f0 S0) (output hJ) where
  left := ⟨(f, S), hs⟩
  right := ⟨(f, T), ht⟩
  sameReading := rfl
  distinctTargets := different

theorem edge_conflict_excludes_every_phase_decoder
    (hJ : 0 < J) (f : Nat) (S T : Fin J → Bool)
    (hs : Reach w J P f0 S0 f S) (ht : Reach w J P f0 S0 f T)
    (different : S ⟨0, hJ⟩ ≠ T ⟨0, hJ⟩) :
    ¬ Recovers (@phase w J P f0 S0) (output hJ) :=
  seam_certificate_closes_decoder_class _ _ (edgeConflictSeam hJ f S T hs ht different)

theorem edge_conflict_excludes_every_certificate
    (hJ : 0 < J) (f : Nat) (S T : Fin J → Bool)
    (hs : Reach w J P f0 S0 f S) (ht : Reach w J P f0 S0 f T)
    (different : S ⟨0, hJ⟩ ≠ T ⟨0, hJ⟩) :
    ¬ (∃ C : Certificate w J P, C.R f0 S0) := by
  intro existsC
  obtain ⟨C, hc⟩ := existsC
  exact different (reachDet_of_cert C hc hJ f S T hs ht)

theorem adequate_readout_must_split_edge_conflict
    {R : Type} (hJ : 0 < J) (f : Nat) (S T : Fin J → Bool)
    (hs : Reach w J P f0 S0 f S) (ht : Reach w J P f0 S0 f T)
    (different : S ⟨0, hJ⟩ ≠ T ⟨0, hJ⟩)
    (fine : ReachableBand w J P f0 S0 → R) (adequate : Recovers fine (output hJ)) :
    fine ⟨(f, S), hs⟩ ≠ fine ⟨(f, T), ht⟩ :=
  adequate_readout_splits_seam _ _ (edgeConflictSeam hJ f S T hs ht different) fine adequate

theorem adequate_added_coordinate_must_split_edge_conflict
    {R : Type} (hJ : 0 < J) (f : Nat) (S T : Fin J → Bool)
    (hs : Reach w J P f0 S0 f S) (ht : Reach w J P f0 S0 f T)
    (different : S ⟨0, hJ⟩ ≠ T ⟨0, hJ⟩)
    (coordinate : ReachableBand w J P f0 S0 → R)
    (adequate : Recovers (fun q => (phase q, coordinate q)) (output hJ)) :
    coordinate ⟨(f, S), hs⟩ ≠ coordinate ⟨(f, T), ht⟩ :=
  added_coordinate_must_split _ _ (edgeConflictSeam hJ f S T hs ht different) coordinate adequate

end Rule30Seam
