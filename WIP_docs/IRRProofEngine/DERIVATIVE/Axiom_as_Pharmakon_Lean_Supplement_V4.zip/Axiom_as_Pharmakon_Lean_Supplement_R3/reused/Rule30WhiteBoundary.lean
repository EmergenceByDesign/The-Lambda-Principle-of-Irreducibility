import CertificateResidueBridge

/-!
A complete Rule 30 half-line case: constant-white left boundary.
The positive half-line is an all-white invariant residue, or its leftmost
black cell advances one column per step until the first cell locks black.
The white residue never enters any finite free-edge shield, at any period,
yet is explicit, internally described, and has a period-one output.
-/

namespace Rule30WhiteBoundary

open SeamClosure Rule30Bridge Rule30Application RightHalf UniformWindow ShieldEntry ClosureCheck
open CertificateResidueBridge

def whiteWord : List Bool := [false]
def zeroStart (_ : Nat) : Bool := false
def spikeStart (K m : Nat) : Bool := decide (m = K + 1)
def evolve (s : Nat → Bool) : Nat → Nat → Bool := rhc (fun _ => false) s
def WhiteResidue (s : Nat → Bool) : Prop := ∀ m, 0 < m → s m = false
def FirstBlack (s : Nat → Bool) (n : Nat) : Prop :=
  0 < n ∧ s n = true ∧ ∀ m, 0 < m → m < n → s m = false
def zeroBand (J : Nat) : Fin J → Bool := fun _ => false

theorem white_drive : pdrive whiteWord = (fun _ => false) := by
  funext t
  change ([false] : List Bool).getD (t % 1) false = false
  rw [Nat.mod_one]
  rfl

theorem white_residue_stays_white (s : Nat → Bool) (white : WhiteResidue s) :
    ∀ t m, evolve s t m = false := by
  intro t
  induction t with
  | zero =>
    intro m
    cases m with
    | zero => rfl
    | succ m => exact white (m + 1) (by omega)
  | succ t ih =>
    intro m
    cases m with
    | zero => rfl
    | succ m =>
      change Bool.xor (evolve s t m) (evolve s t (m + 1) || evolve s t (m + 2)) = false
      rw [ih m, ih (m + 1), ih (m + 2)]
      rfl

theorem zero_stays_zero : ∀ t m, evolve zeroStart t m = false :=
  white_residue_stays_white zeroStart (fun _ _ => rfl)

/-- The leading front is protected by zeros to its left, whatever follows it. -/
theorem first_black_front (s : Nat → Bool) (n : Nat) (first : FirstBlack s n) :
    ∀ t, (∀ m, m + t < n → evolve s t m = false) ∧
      (∀ m, 0 < m → m + t = n → evolve s t m = true) := by
  intro t
  induction t with
  | zero =>
    constructor
    · intro m hm
      cases m with
      | zero => rfl
      | succ m => exact first.2.2 (m + 1) (by omega) (by omega)
    · intro m hm hn
      cases m with
      | zero => omega
      | succ m =>
        change s (m + 1) = true
        have eqn : m + 1 = n := by omega
        rw [eqn]
        exact first.2.1
  | succ t ih =>
    constructor
    · intro m hm
      cases m with
      | zero => rfl
      | succ m =>
        change Bool.xor (evolve s t m) (evolve s t (m + 1) || evolve s t (m + 2)) = false
        rw [ih.1 m (by omega), ih.1 (m + 1) (by omega), ih.1 (m + 2) (by omega)]
        rfl
    · intro m hm hn
      cases m with
      | zero => omega
      | succ m =>
        change Bool.xor (evolve s t m) (evolve s t (m + 1) || evolve s t (m + 2)) = true
        rw [ih.1 m (by omega), ih.1 (m + 1) (by omega), ih.2 (m + 2) (by omega) (by omega)]
        rfl

theorem spike_has_first_black (K : Nat) : FirstBlack (spikeStart K) (K + 1) := by
  refine ⟨by omega, ?_, ?_⟩
  · simp [spikeStart]
  · intro m _ hm
    simp [spikeStart, Nat.ne_of_lt hm]

theorem spike_reaches_column_one (K : Nat) : evolve (spikeStart K) K 1 = true :=
  (first_black_front _ _ (spike_has_first_black K) K).2 1 (by omega) (by omega)

/-- Constructive finite scan: no classical choice of a first black cell. -/
theorem finite_prefix_dichotomy (s : Nat → Bool) :
    ∀ K, (∀ m, 0 < m → m ≤ K → s m = false) ∨
      ∃ n, n ≤ K ∧ FirstBlack s n := by
  intro K
  induction K with
  | zero =>
    exact Or.inl (fun _ hm hK => False.elim (by omega))
  | succ K ih =>
    obtain white | ⟨n, hn, first⟩ := ih
    · cases hlast : s (K + 1) with
      | false =>
        left
        intro m hm hK
        by_cases before : m ≤ K
        · exact white m hm before
        · have last : m = K + 1 := by omega
          rw [last]
          exact hlast
      | true =>
        right
        refine ⟨K + 1, Nat.le_refl _, by omega, hlast, ?_⟩
        intro m hm before
        exact white m hm (by omega)
    · exact Or.inr ⟨n, by omega, first⟩

theorem finite_start_dichotomy (s : Nat → Bool) (finite : FiniteStart s) :
    WhiteResidue s ∨ ∃ n, FirstBlack s n := by
  obtain ⟨K, support⟩ := finite
  obtain white | ⟨n, _, first⟩ := finite_prefix_dichotomy s K
  · left
    intro m hm
    by_cases hK : m ≤ K
    · exact white m hm hK
    · exact support m (by omega)
  · exact Or.inr ⟨n, first⟩

def blackShield : Certificate whiteWord 1 1 where
  R := fun _ S => S ⟨0, by decide⟩ = true
  closed := by
    intro f S black e
    change bandStep 1 S (whiteWord.getD (f % whiteWord.length) false) e ⟨0, by decide⟩ = true
    have drive : whiteWord.getD (f % whiteWord.length) false = false := by
      change ([false] : List Bool).getD (f % 1) false = false
      rw [Nat.mod_one]
      rfl
    rw [drive]
    change Bool.xor false (S ⟨0, by decide⟩ || e) = true
    rw [black]
    rfl
  value := fun _ => true
  det := fun _ _ _ black => black

theorem first_black_enters_shield (s : Nat → Bool) (n : Nat) (first : FirstBlack s n) :
    EntersShield whiteWord s := by
  refine ⟨1, 1, n - 1, blackShield, by decide, by decide, by simp [whiteWord], ?_⟩
  change rhc (pdrive whiteWord) s (n - 1) 1 = true
  rw [white_drive]
  exact (first_black_front s n first (n - 1)).2 1 (by omega) (by have := first.1; omega)

theorem black_forever_after_first (s : Nat → Bool) (n : Nat) (first : FirstBlack s n) :
    ∀ t, n - 1 ≤ t → evolve s t 1 = true := by
  have start : blackShield.R ((n - 1) % 1)
      (bandOf (rhc (pdrive whiteWord) s) 1 (n - 1)) := by
    change rhc (pdrive whiteWord) s (n - 1) 1 = true
    rw [white_drive]
    exact (first_black_front s n first (n - 1)).2 1 (by omega) (by have := first.1; omega)
  intro t ht
  have stays := shield whiteWord 1 1 (by simp [whiteWord]) blackShield s (n - 1) start t ht
  change rhc (pdrive whiteWord) s t 1 = true at stays
  rw [white_drive] at stays
  exact stays

theorem exact_finite_start_trace_dichotomy (s : Nat → Bool) (finite : FiniteStart s) :
    (∀ t, evolve s t 1 = false) ∨
      ∃ n, 0 < n ∧ (∀ t, t < n - 1 → evolve s t 1 = false) ∧
        (∀ t, n - 1 ≤ t → evolve s t 1 = true) := by
  obtain white | ⟨n, first⟩ := finite_start_dichotomy s finite
  · exact Or.inl (fun t => white_residue_stays_white s white t 1)
  · right
    refine ⟨n, first.1, ?_, black_forever_after_first s n first⟩
    intro t ht
    exact (first_black_front s n first t).1 1 (by have := first.1; omega)

theorem certificate_or_white_residue_cover :
    ∀ s, FiniteStart s → EntersShield whiteWord s ∨ WhiteResidue s := by
  intro s finite
  obtain white | ⟨n, first⟩ := finite_start_dichotomy s finite
  · exact Or.inr white
  · exact Or.inl (first_black_enters_shield s n first)

theorem white_residue_settles (s : Nat → Bool) (white : WhiteResidue s) :
    EventuallyPeriodic (fun t => rhc (pdrive whiteWord) s t 1) := by
  refine ⟨0, 1, by decide, ?_⟩
  intro t _
  rw [white_drive]
  change evolve s (t + 1) 1 = evolve s t 1
  rw [white_residue_stays_white s white, white_residue_stays_white s white]

theorem every_finite_white_start_settles : EveryFiniteStartSettles whiteWord :=
  settles_of_certificate_or_residue whiteWord WhiteResidue certificate_or_white_residue_cover
    (fun s _ white => white_residue_settles s white)

/-- A complete worked bridge to one actual center-column pattern exclusion. -/
theorem center_avoids_white_via_residue : ¬ EventuallyRepeats center30 whiteWord :=
  center_avoids_of_certificate_or_residue whiteWord (by simp [whiteWord]) WhiteResidue
    certificate_or_white_residue_cover (fun s _ white => white_residue_settles s white)

/-- Both actual finite starts have the same initial J-column band. -/
theorem zero_initial_band (J : Nat) : bandOf (evolve zeroStart) J 0 = zeroBand J := by
  funext i
  rfl

theorem spike_initial_band (J : Nat) : bandOf (evolve (spikeStart J)) J 0 = zeroBand J := by
  funext i
  have different : i.val ≠ J := Nat.ne_of_lt i.isLt
  simp [bandOf, evolve, rhc, spikeStart, zeroBand, different]

theorem actual_band_reachable (J P f0 : Nat) (hf0 : f0 < P) (s : Nat → Bool)
    (initial : bandOf (evolve s) J 0 = zeroBand J) :
    ∀ t, Reach whiteWord J P f0 (zeroBand J) ((f0 + t) % P) (bandOf (evolve s) J t) := by
  intro t
  induction t with
  | zero =>
    rw [Nat.add_zero, Nat.mod_eq_of_lt hf0, initial]
    exact Reach.base
  | succ t ih =>
    have step := Reach.step (e := evolve s t (J + 1)) ih
    have drive : whiteWord.getD (((f0 + t) % P) % whiteWord.length) false = false := by
      change ([false] : List Bool).getD (((f0 + t) % P) % 1) false = false
      rw [Nat.mod_one]
      rfl
    rw [drive, Nat.mod_add_mod] at step
    have band := bandOf_succ (fun _ => false) s J t
    change bandOf (evolve s) J (t + 1) =
      bandStep J (bandOf (evolve s) J t) false (evolve s t (J + 1)) at band
    rw [← band] at step
    exact step

/-- All widths and periods are excluded by actual, finite tail perturbations. -/
theorem no_white_zero_band_certificate (J P f0 : Nat) (hJ : 0 < J) (hf0 : f0 < P) :
    ¬ (∃ C : Certificate whiteWord J P, C.R f0 (zeroBand J)) := by
  intro entry
  obtain ⟨C, hC⟩ := entry
  have zeroReach := actual_band_reachable J P f0 hf0 zeroStart (zero_initial_band J) J
  have spikeReach := actual_band_reachable J P f0 hf0 (spikeStart J) (spike_initial_band J) J
  have conflict := reachDet_of_cert C hC hJ ((f0 + J) % P) _ _ zeroReach spikeReach
  change evolve zeroStart J 1 = evolve (spikeStart J) J 1 at conflict
  rw [zero_stays_zero, spike_reaches_column_one] at conflict
  exact Bool.noConfusion conflict

theorem white_residue_never_enters (s : Nat → Bool) (white : WhiteResidue s) :
    NeverEnters whiteWord s := by
  intro entry
  obtain ⟨J, P, t0, C, hJ, hP, _, hC⟩ := entry
  have band : bandOf (rhc (pdrive whiteWord) s) J t0 = zeroBand J := by
    funext i
    rw [white_drive]
    exact white_residue_stays_white s white t0 (i.val + 1)
  rw [band] at hC
  exact no_white_zero_band_certificate J P (t0 % P) hJ (Nat.mod_lt _ hP) ⟨C, hC⟩

theorem finite_nonentry_iff_white_residue (s : Nat → Bool) (finite : FiniteStart s) :
    NeverEnters whiteWord s ↔ WhiteResidue s := by
  constructor
  · intro never
    obtain white | ⟨n, first⟩ := finite_start_dichotomy s finite
    · exact white
    · exact False.elim (never (first_black_enters_shield s n first))
  · exact white_residue_never_enters s

theorem zero_start_never_enters : NeverEnters whiteWord zeroStart :=
  white_residue_never_enters zeroStart (fun _ _ => rfl)

theorem universal_white_entry_is_false : ¬ EveryFiniteStartEnters whiteWord := by
  intro allEntry
  exact zero_start_never_enters (allEntry zeroStart ⟨0, fun _ _ => rfl⟩)

theorem every_bounded_white_entry_is_false (f g p : Nat → Nat) :
    ¬ EntryBoundW whiteWord f g p := by
  intro bound
  exact universal_white_entry_is_false
    (EntryBridge.enters_of_bound whiteWord f (bound_of_boundW whiteWord f g p bound))

theorem settling_is_strictly_weaker_than_shield_entry :
    EveryFiniteStartSettles whiteWord ∧ ¬ EveryFiniteStartEnters whiteWord :=
  ⟨every_finite_white_start_settles, universal_white_entry_is_false⟩

/-- A finite admitted state remains inside its reachability frame without a shield. -/
theorem admitted_root_without_any_certificate (J P f0 : Nat) (hJ : 0 < J) (hf0 : f0 < P) :
    (∃ q : Rule30Seam.ReachableBand whiteWord J P f0 (zeroBand J), Rule30Seam.phase q = f0) ∧
      ¬ (∃ C : Certificate whiteWord J P, C.R f0 (zeroBand J)) :=
  ⟨⟨⟨(f0, zeroBand J), Reach.base⟩, rfl⟩,
    no_white_zero_band_certificate J P f0 hJ hf0⟩

/-- Actual Rule 30 finite-start prefix seams for the entire output trace. -/
def FiniteInitial := {s : Nat → Bool // FiniteStart s}
def finiteZero : FiniteInitial := ⟨zeroStart, ⟨0, fun _ _ => rfl⟩⟩
def finiteSpike (J : Nat) : FiniteInitial := ⟨spikeStart J, J + 1, by
  intro i hi
  simp [spikeStart, Nat.ne_of_gt hi]⟩
def initialPrefix (J : Nat) (s : FiniteInitial) : Fin J → Bool := fun i => s.val (i.val + 1)
def columnTrace (s : FiniteInitial) : Nat → Bool := fun t => evolve s.val t 1

def actualPrefixSeam (J : Nat) : SeamCertificate (initialPrefix J) columnTrace where
  left := finiteZero
  right := finiteSpike J
  sameReading := by
    funext i
    have different : i.val ≠ J := Nat.ne_of_lt i.isLt
    simp [initialPrefix, finiteZero, finiteSpike, zeroStart, spikeStart, different]
  distinctTargets := by
    intro same
    have conflict := congrArg (fun trace : Nat → Bool => trace J) same
    change evolve zeroStart J 1 = evolve (spikeStart J) J 1 at conflict
    rw [zero_stays_zero, spike_reaches_column_one] at conflict
    exact Bool.noConfusion conflict

theorem no_fixed_prefix_recovers_all_finite_start_traces (J : Nat) :
    ¬ Recovers (initialPrefix J) columnTrace :=
  seam_certificate_closes_decoder_class _ _ (actualPrefixSeam J)

end Rule30WhiteBoundary
