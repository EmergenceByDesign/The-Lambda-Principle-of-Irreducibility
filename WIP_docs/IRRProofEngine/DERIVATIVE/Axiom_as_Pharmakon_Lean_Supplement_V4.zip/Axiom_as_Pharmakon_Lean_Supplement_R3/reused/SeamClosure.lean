import Lean

/-!
Closure at the Seam - R1, 23 October 2026.
EmergenceByDesign / MetaLabe, developed in this conversation with ChatGPT.

This is a standalone reconstruction and extension of scoped claims in
Tail Predicates v0.6 and Lambda at the Point of Adjudication R4.
No Mathlib dependency. No custom axioms. The ambient logic and any standard
axiom dependencies are reported for every theorem in Audit.lean.

The types below are selected formal representations, not a claim that the
world, consciousness, or every possible logic has these types. In particular,
the finite Boolean examples do not impose a universal binary ontology.
-/

namespace SeamClosure

universe u v w r
variable {X : Type u} {Y : Type v} {Z : Type w}

/-! 1. Readouts, targets, and exact closure of an observational obstruction. -/

def Recovers (observe : X → Y) (target : X → Z) : Prop :=
  ∃ decode : Y → Z, ∀ x, decode (observe x) = target x

def FibreConstant (observe : X → Y) (target : X → Z) : Prop :=
  ∀ x x', observe x = observe x' → target x = target x'

def Reachable (observe : X → Y) := {y : Y // ∃ x, observe x = y}

def RecoversOnImage (observe : X → Y) (target : X → Z) : Prop :=
  ∃ decode : Reachable observe → Z,
    ∀ x, decode ⟨observe x, ⟨x, rfl⟩⟩ = target x

theorem recovery_requires_fibre_constancy (observe : X → Y) (target : X → Z)
    (h : Recovers observe target) : FibreConstant observe target := by
  obtain ⟨decode, hd⟩ := h
  intro x x' same
  exact (hd x).symm.trans ((congrArg decode same).trans (hd x'))

theorem collision_excludes_every_decoder (observe : X → Y) (target : X → Z)
    {x x' : X} (same : observe x = observe x') (different : target x ≠ target x') :
    ¬ Recovers observe target := by
  intro h
  exact different (recovery_requires_fibre_constancy observe target h x x' same)

theorem image_recovery_requires_fibre_constancy (observe : X → Y) (target : X → Z)
    (h : RecoversOnImage observe target) : FibreConstant observe target := by
  obtain ⟨decode, hd⟩ := h
  intro x x' same
  have hr : (⟨observe x, ⟨x, rfl⟩⟩ : Reachable observe) =
      ⟨observe x', ⟨x', rfl⟩⟩ := Subtype.ext same
  exact (hd x).symm.trans ((congrArg decode hr).trans (hd x'))

theorem fibre_constancy_gives_image_decoder (observe : X → Y) (target : X → Z)
    (h : FibreConstant observe target) : RecoversOnImage observe target := by
  classical
  let witness : Reachable observe → X := fun y => Classical.choose y.property
  refine ⟨fun y => target (witness y), ?_⟩
  intro x
  apply h
  exact Classical.choose_spec (show ∃ x', observe x' = observe x from ⟨x, rfl⟩)

theorem exact_image_recovery_iff (observe : X → Y) (target : X → Z) :
    RecoversOnImage observe target ↔ FibreConstant observe target :=
  ⟨image_recovery_requires_fibre_constancy observe target,
   fibre_constancy_gives_image_decoder observe target⟩

theorem fibre_constancy_gives_total_decoder (observe : X → Y) (target : X → Z)
    (defaultValue : Z) (h : FibreConstant observe target) : Recovers observe target := by
  classical
  let decode : Y → Z := fun y =>
    if hy : ∃ x, observe x = y then target (Classical.choose hy) else defaultValue
  refine ⟨decode, ?_⟩
  intro x
  have hx : ∃ x', observe x' = observe x := ⟨x, rfl⟩
  change (if hy : ∃ x', observe x' = observe x then
    target (Classical.choose hy) else defaultValue) = target x
  rw [dif_pos hx]
  exact h _ _ (Classical.choose_spec hx)

theorem total_recovery_iff_with_default (observe : X → Y) (target : X → Z)
    (defaultValue : Z) : Recovers observe target ↔ FibreConstant observe target :=
  ⟨recovery_requires_fibre_constancy observe target,
   fibre_constancy_gives_total_decoder observe target defaultValue⟩

theorem postprocessing_preserves_collision (observe : X → Y) (target : X → Z)
    {R : Type r} (post : Y → R) {x x' : X}
    (same : observe x = observe x') (different : target x ≠ target x') :
    ¬ Recovers (fun a => post (observe a)) target :=
  collision_excludes_every_decoder _ _ (congrArg post same) different

theorem refinement_preserves_recovery (coarse : X → Y) (target : X → Z)
    {R : Type r} (fine : X → R) (forget : R → Y)
    (retained : ∀ x, forget (fine x) = coarse x) (h : Recovers coarse target) :
    Recovers fine target := by
  obtain ⟨decode, hd⟩ := h
  refine ⟨fun r => decode (forget r), ?_⟩
  intro x
  change decode (forget (fine x)) = target x
  rw [retained x]
  exact hd x

theorem joint_readout_preserves_recovery (observe : X → Y) (target : X → Z)
    {R : Type r} (selector : X → R) (h : Recovers observe target) :
    Recovers (fun x => (observe x, selector x)) target :=
  refinement_preserves_recovery observe target _ Prod.fst (fun _ => rfl) h

theorem full_state_recovers_target (target : X → Z) : Recovers (fun x : X => x) target :=
  ⟨target, fun _ => rfl⟩

theorem constant_readout_cannot_recover_bit :
    ¬ Recovers (fun _ : Bool => ()) (fun b : Bool => b) :=
  collision_excludes_every_decoder _ _ (x := false) (x' := true) rfl (by decide)

theorem enlargement_can_resolve_scoped_obstruction :
    (¬ Recovers (fun _ : Bool => ()) (fun b : Bool => b)) ∧
      Recovers (fun b : Bool => ((), b)) (fun b : Bool => b) :=
  ⟨constant_readout_cannot_recover_bit, ⟨Prod.snd, fun _ => rfl⟩⟩

/-! A proved obstruction is a metalevel closure, alongside target non-recovery.
This construction does not assert that P and not P hold in one unchanged scope. -/
structure SeamCertificate (observe : X → Y) (target : X → Z) where
  left : X
  right : X
  sameReading : observe left = observe right
  distinctTargets : target left ≠ target right

theorem seam_certificate_closes_decoder_class (observe : X → Y) (target : X → Z)
    (certificate : SeamCertificate observe target) : ¬ Recovers observe target :=
  collision_excludes_every_decoder observe target certificate.sameReading certificate.distinctTargets

theorem seam_certificate_survives_any_relabelling (observe : X → Y) (target : X → Z)
    {R : Type r} (post : Y → R) (certificate : SeamCertificate observe target) :
    ¬ Recovers (fun x => post (observe x)) target :=
  postprocessing_preserves_collision observe target post
    certificate.sameReading certificate.distinctTargets

/-! 2. Scope transport, non-promotion, and foundational non-uniqueness. -/

def Supports (admitted : X → Prop) (claim : X → Prop) : Prop :=
  ∀ x, admitted x → claim x

theorem narrower_domain_preserves_support (A B claim : X → Prop)
    (bridge : ∀ x, B x → A x) (h : Supports A claim) : Supports B claim :=
  fun x hx => h x (bridge x hx)

theorem target_preserving_bridge_transports_support
    (A : X → Prop) (B : Y → Prop) (claim : X → Prop) (target : Y → Prop)
    (bridge : Y → X) (admissible : ∀ y, B y → A (bridge y))
    (meaning : ∀ y, B y → claim (bridge y) → target y) (h : Supports A claim) :
    Supports B target := fun y hy => meaning y hy (h (bridge y) (admissible y hy))

theorem scope_promotion_fails_in_a_countermodel :
    Supports (fun b : Bool => b = false) (fun b => b = false) ∧
      ¬ Supports (fun _ : Bool => True) (fun b => b = false) := by
  constructor
  · exact fun _ h => h
  · intro h
    exact Bool.noConfusion (h true True.intro)

def BasisA (x : Bool × Bool) : Prop := x.1 = false ∧ x.2 = true
def BasisB (x : Bool × Bool) : Prop := x.1 = true ∧ x.2 = true
def SharedConsequence (x : Bool × Bool) : Prop := x.2 = true

theorem distinct_bases_support_same_nonconstant_claim :
    BasisA ≠ BasisB ∧ Supports BasisA SharedConsequence ∧ Supports BasisB SharedConsequence := by
  refine ⟨?_, (fun _ h => h.2), (fun _ h => h.2)⟩
  intro same
  have hA : BasisA (false, true) := ⟨rfl, rfl⟩
  have hB : BasisB (false, true) := by rw [← same]; exact hA
  exact Bool.noConfusion hB.1

theorem shared_consequence_is_nonconstant :
    SharedConsequence (false, true) ∧ ¬ SharedConsequence (false, false) := by
  constructor
  · rfl
  · intro h
    exact Bool.noConfusion h

theorem derivation_does_not_supply_unique_basis :
    ¬ (∀ A B : Bool × Bool → Prop,
      Supports A SharedConsequence → Supports B SharedConsequence → A = B) := by
  intro uniqueness
  obtain ⟨different, hA, hB⟩ := distinct_bases_support_same_nonconstant_claim
  exact different (uniqueness BasisA BasisB hA hB)

/-! 3. Equal criteria, reflexive burden, and non-vindication. -/

def DeclaredStandard {Claim Criteria Verdict : Type}
    (criteria : Claim → Criteria) (verdict : Claim → Verdict) : Prop :=
  ∃ rule : Criteria → Verdict, ∀ c, verdict c = rule (criteria c)

theorem equal_declared_criteria_require_equal_verdicts {Claim Criteria Verdict : Type}
    (criteria : Claim → Criteria) (verdict : Claim → Verdict)
    (standard : DeclaredStandard criteria verdict) {a b : Claim}
    (same : criteria a = criteria b) : verdict a = verdict b := by
  obtain ⟨rule, hr⟩ := standard
  exact (hr a).trans ((congrArg rule same).trans (hr b).symm)

theorem different_verdicts_expose_extra_input {Claim Criteria Verdict : Type}
    (criteria : Claim → Criteria) (verdict : Claim → Verdict) {a b : Claim}
    (same : criteria a = criteria b) (different : verdict a ≠ verdict b) :
    ¬ DeclaredStandard criteria verdict :=
  fun standard => different (equal_declared_criteria_require_equal_verdicts criteria verdict standard same)

theorem equal_standard_is_symmetric {Claim Criteria Verdict : Type}
    (criteria : Claim → Criteria) (verdict : Claim → Verdict)
    (standard : DeclaredStandard criteria verdict) {a b : Claim}
    (same : criteria a = criteria b) : verdict b = verdict a :=
  (equal_declared_criteria_require_equal_verdicts criteria verdict standard same).symm

theorem critic_has_no_rule_exemption {Claim : Type} (defect rejected : Claim → Prop)
    (rule : ∀ c, defect c → rejected c) (critic : Claim) (ownDefect : defect critic) :
    rejected critic := rule critic ownDefect

theorem equal_defect_can_be_applied_to_both {Claim : Type} (defect rejected : Claim → Prop)
    (rule : ∀ c, defect c → rejected c) (a b : Claim) (ha : defect a) (hb : defect b) :
    rejected a ∧ rejected b := ⟨rule a ha, rule b hb⟩

theorem receipt_rule_applies_to_its_own_named_record {Claim : Type}
    (meetsStandard accepted : Claim → Prop) (rule : ∀ c, accepted c → meetsStandard c)
    (ownRecord : Claim) (h : accepted ownRecord) : meetsStandard ownRecord := rule ownRecord h

theorem invalid_rejection_does_not_establish_claim :
    ¬ (∀ claim negativeReceipt : Prop, ¬ negativeReceipt → claim) := by
  intro upgrade
  exact upgrade False False (fun h => h)

theorem missing_positive_receipt_does_not_establish_negation :
    ¬ (∀ claim positiveReceipt : Prop, ¬ positiveReceipt → ¬ claim) := by
  intro upgrade
  exact upgrade True False (fun h => h) True.intro

theorem different_verdicts_do_not_identify_motive :
    ¬ Recovers (fun _ : Bool => (false, true)) (fun motive : Bool => motive) :=
  collision_excludes_every_decoder _ _ (x := false) (x' := true) rfl (by decide)

/-! 4. Finite tails and uniform closure. -/

def PrefixAgreement (N : Nat) (p q : Nat → Prop) : Prop :=
  ∀ n, n < N → (p n ↔ q n)

theorem every_finite_window_admits_opposite_all_stage_status (N : Nat) :
    ∃ p q : Nat → Prop, PrefixAgreement N p q ∧ (∀ n, p n) ∧ ¬ (∀ n, q n) := by
  refine ⟨fun _ => True, fun n => n ≠ N, ?_, (fun _ => True.intro), ?_⟩
  · intro n hn
    exact ⟨fun _ => Nat.ne_of_lt hn, fun _ => True.intro⟩
  · intro h
    exact h N rfl

theorem no_unrestricted_finite_window_rule_closes_every_tail (N : Nat) :
    ¬ (∀ p q : Nat → Prop, PrefixAgreement N p q → (∀ n, p n) → ∀ n, q n) := by
  intro rule
  obtain ⟨p, q, same, allP, notAllQ⟩ := every_finite_window_admits_opposite_all_stage_status N
  exact notAllQ (rule p q same allP)

theorem all_stage_proof_closes_each_finite_window (p : Nat → Prop)
    (proof : ∀ n, p n) (N : Nat) : ∀ n, n < N → p n := fun n _ => proof n

theorem invariant_closes_an_unbounded_tail (p : Nat → Prop)
    (start : p 0) (step : ∀ n, p n → p (n + 1)) : ∀ n, p n := by
  intro n
  induction n with
  | zero => exact start
  | succ n ih => exact step n ih

/-! No Rule 30 recurrence is assumed by the next countermodel. It identifies
what follows from periodic rows alone, even with power-of-two periods. -/
def ClockArray (period : Nat → Nat) (a : Nat → Bool) (k t : Nat) : Bool :=
  a (t % period k)

theorem every_clock_row_repeats (period : Nat → Nat) (a : Nat → Bool) (k t : Nat) :
    ClockArray period a k (t + period k) = ClockArray period a k t := by
  simp only [ClockArray, Nat.add_mod, Nat.mod_self, Nat.add_zero, Nat.mod_mod]

theorem clock_diagonal_preserves_arbitrary_readings (period : Nat → Nat)
    (a : Nat → Bool) (longEnough : ∀ n, n < period n) (n : Nat) :
    ClockArray period a n n = a n := by
  exact congrArg a (Nat.mod_eq_of_lt (longEnough n))

theorem dyadic_period_exceeds_diagonal_index (n : Nat) : n < 2 ^ (n + 1) := by
  induction n with
  | zero => decide
  | succ n ih =>
    have positive : 0 < 2 ^ (n + 1) := Nat.pow_pos (by decide)
    have step : 2 ^ (n + 1 + 1) = 2 ^ (n + 1) * 2 := Nat.pow_succ 2 (n + 1)
    change n + 1 < 2 ^ (n + 1 + 1)
    rw [step]
    omega

theorem dyadic_rows_allow_any_center_sequence (a : Nat → Bool) :
    (∀ k t, ClockArray (fun k => 2 ^ (k + 1)) a k (t + 2 ^ (k + 1)) =
      ClockArray (fun k => 2 ^ (k + 1)) a k t) ∧
    (∀ n, ClockArray (fun k => 2 ^ (k + 1)) a n n = a n) :=
  ⟨every_clock_row_repeats _ a,
   clock_diagonal_preserves_arbitrary_readings _ a dyadic_period_exceeds_diagonal_index⟩

/-! 5. Selection and decisions do not require unique determination. -/

def UniqueOutcome {I A : Type} (admissible : I → Prop) (outcome : I → A) : Prop :=
  ∃ a, ∀ i, admissible i → outcome i = a

theorem competing_admissible_outcomes_exclude_unique_selection {I A : Type}
    (admissible : I → Prop) (outcome : I → A) {i j : I}
    (hi : admissible i) (hj : admissible j) (different : outcome i ≠ outcome j) :
    ¬ UniqueOutcome admissible outcome := by
  intro unique
  obtain ⟨a, ha⟩ := unique
  exact different ((ha i hi).trans (ha j hj).symm)

theorem an_admissible_choice_can_coexist_with_nonuniqueness :
    (∃ chosen : Bool, chosen = false) ∧ ¬ UniqueOutcome (fun _ : Bool => True) (fun b : Bool => b) := by
  refine ⟨⟨false, rfl⟩, ?_⟩
  exact competing_admissible_outcomes_exclude_unique_selection _ _
    (i := false) (j := true) True.intro True.intro (by decide)

theorem acting_can_coexist_with_unrecovered_target :
    (∃ policy : Unit → Bool, policy () = false) ∧
      ¬ Recovers (fun _ : Bool => ()) (fun b : Bool => b) :=
  ⟨⟨fun _ => false, rfl⟩, constant_readout_cannot_recover_bit⟩

theorem every_policy_fails_on_some_indistinguishable_case :
    ∀ policy : Unit → Bool, ∃ world : Bool, policy () ≠ world := by
  intro policy
  cases policy () with
  | false => exact ⟨true, by decide⟩
  | true => exact ⟨false, by decide⟩

/-! 6. Context, observer roles, and reopening a constitutive dependency. -/

def Situated {Observer Other Conditions Readout : Type}
    (observe : Observer → Other → Conditions → Readout) :
    Observer × Other × Conditions → Readout := fun x => observe x.1 x.2.1 x.2.2

theorem situated_observation_has_no_decoder_exemption
    {Observer Other Conditions Readout Target : Type}
    (observe : Observer → Other → Conditions → Readout)
    (target : Observer × Other × Conditions → Target)
    {a b : Observer × Other × Conditions}
    (same : Situated observe a = Situated observe b) (different : target a ≠ target b) :
    ¬ Recovers (Situated observe) target :=
  collision_excludes_every_decoder _ _ same different

theorem one_carrier_can_fill_both_registered_roles (x : X) :
    (x, x).1 = (x, x).2 := rfl

theorem erasing_an_enabling_coordinate_can_remove_recovery :
    Recovers (fun x : Bool × Bool => x) (fun x => x.2) ∧
      ¬ Recovers (fun x : Bool × Bool => x.1) (fun x => x.2) := by
  refine ⟨⟨Prod.snd, fun _ => rfl⟩, ?_⟩
  exact collision_excludes_every_decoder _ _
    (x := (false, false)) (x' := (false, true)) rfl (by decide)

theorem restoring_the_coordinate_restores_recovery :
    Recovers (fun x : Bool × Bool => (x.1, x.2)) (fun x => x.2) :=
  ⟨Prod.snd, fun _ => rfl⟩

theorem the_same_target_has_an_alternative_encoding :
    Recovers (fun x : Bool × Bool => x.2) (fun x => x.2) := ⟨id, fun _ => rfl⟩

theorem stable_calibration_preserves_target {Observer Other Reading Target : Type}
    (observe : Observer → Other → Reading) (target : Other → Target)
    (decode : Reading → Target) (calibrated : ∀ s o, decode (observe s o) = target o)
    (s s' : Observer) (o : Other) : decode (observe s o) = decode (observe s' o) :=
  (calibrated s o).trans (calibrated s' o).symm

/-! 7. A finite seam: phase return, sign reversal, and twelve-state return.
The long doubling orbits modulo 65 have this twelve-cycle structure.
No dynamics of consciousness, institutions, or physical chirality are assumed. -/

def Phase (x : Fin 12) : Fin 6 := ⟨x.val % 6, Nat.mod_lt _ (by decide)⟩
def Sign (x : Fin 12) : Bool := decide (6 ≤ x.val)
def HalfTurn (x : Fin 12) : Fin 12 := ⟨(x.val + 6) % 12, Nat.mod_lt _ (by decide)⟩
def FullTurn (x : Fin 12) : Fin 12 := ⟨(x.val + 12) % 12, Nat.mod_lt _ (by decide)⟩
def PhaseAndSign (x : Fin 12) : Fin 6 × Bool := (Phase x, Sign x)
def DecodePhaseAndSign (p : Fin 6 × Bool) : Fin 12 :=
  ⟨p.1.val + (if p.2 then 6 else 0), by
    have bound := p.1.isLt
    split <;> omega⟩

theorem half_turn_closes_phase : ∀ x : Fin 12, Phase (HalfTurn x) = Phase x := by decide
theorem half_turn_reverses_sign : ∀ x : Fin 12, Sign (HalfTurn x) = !(Sign x) := by decide
theorem half_turn_does_not_restore_full_state : ∀ x : Fin 12, HalfTurn x ≠ x := by decide
theorem full_turn_restores_state : ∀ x : Fin 12, FullTurn x = x := by decide
theorem two_half_turns_restore_state : ∀ x : Fin 12, HalfTurn (HalfTurn x) = x := by decide

theorem phase_omits_a_distinction :
    Phase (0 : Fin 12) = Phase (6 : Fin 12) ∧ Sign (0 : Fin 12) ≠ Sign (6 : Fin 12) := by decide

theorem phase_has_no_sign_decoder : ¬ Recovers Phase Sign :=
  collision_excludes_every_decoder Phase Sign phase_omits_a_distinction.1 phase_omits_a_distinction.2

theorem phase_has_no_full_state_decoder : ¬ Recovers Phase (fun x : Fin 12 => x) :=
  collision_excludes_every_decoder Phase _ (x := 0) (x' := 6) (by decide) (by decide)

theorem phase_and_sign_are_injective :
    ∀ x y : Fin 12, PhaseAndSign x = PhaseAndSign y → x = y := by decide

theorem explicit_selector_decoder_restores_state :
    ∀ x : Fin 12, DecodePhaseAndSign (PhaseAndSign x) = x := by decide

theorem phase_and_sign_restore_full_state : Recovers PhaseAndSign (fun x : Fin 12 => x) := by
  exact ⟨DecodePhaseAndSign, explicit_selector_decoder_restores_state⟩

theorem one_transition_has_two_registered_closure_statuses (x : Fin 12) :
    Phase (HalfTurn x) = Phase x ∧ HalfTurn x ≠ x :=
  ⟨half_turn_closes_phase x, half_turn_does_not_restore_full_state x⟩

theorem sign_nonrecovery_coexists_with_refined_recovery :
    (¬ Recovers Phase Sign) ∧ Recovers PhaseAndSign (fun x : Fin 12 => x) :=
  ⟨phase_has_no_sign_decoder, phase_and_sign_restore_full_state⟩

end SeamClosure
