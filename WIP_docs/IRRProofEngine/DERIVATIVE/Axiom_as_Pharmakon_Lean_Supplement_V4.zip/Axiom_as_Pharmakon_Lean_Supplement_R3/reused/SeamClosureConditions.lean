import Rule30Seam

/-!
R4: closure of a decoder class, adequacy of a lift, and preservation of the
original target. Cooperative continuation, 23 October 2026.

These theorems retain the completed R2 seam obstruction. Finite countermodels
test two further implications: independence does not ensure adequate target
recovery, and even adequate recovery does not force a dynamical entry claim.
The registration rule for adjudication is made explicit, with no exemption
for the critic and no inference from registration alone to a claim's truth.
-/

namespace SeamClosureConditions

open SeamClosure SeamIntegration ClosureCheck ShieldEntry Rule30Seam

universe u v w r
variable {X : Type u} {Y : Type v} {Z : Type w} {R : Type r}

/-- A completed lift carrying the positive receipt required for recovery. -/
structure AdequateLift (observe : X → Y) (target : X → Z) (R : Type r) where
  coordinate : X → R
  decode : Y × R → Z
  correct : ∀ x, decode (observe x, coordinate x) = target x

theorem adequate_lift_supplies_recovery (observe : X → Y) (target : X → Z)
    (lift : AdequateLift observe target R) :
    Recovers (fun x => (observe x, lift.coordinate x)) target :=
  ⟨lift.decode, lift.correct⟩

theorem adequate_lift_splits_every_certified_seam (observe : X → Y) (target : X → Z)
    (lift : AdequateLift observe target R) (seam : SeamCertificate observe target) :
    lift.coordinate seam.left ≠ lift.coordinate seam.right :=
  added_coordinate_must_split observe target seam lift.coordinate
    (adequate_lift_supplies_recovery observe target lift)

/-- Splitting all conflicting target fibres is stronger than independence. -/
def SplitsEverySeam (observe : X → Y) (coordinate : X → R) (target : X → Z) : Prop :=
  ∀ seam : SeamCertificate observe target, coordinate seam.left ≠ coordinate seam.right

theorem recovery_splits_every_seam (observe : X → Y) (coordinate : X → R)
    (target : X → Z) (adequate : Recovers (fun x => (observe x, coordinate x)) target) :
    SplitsEverySeam observe coordinate target :=
  fun seam => added_coordinate_must_split observe target seam coordinate adequate

theorem splits_every_seam_iff_fibre_constant [DecidableEq Z]
    (observe : X → Y) (coordinate : X → R) (target : X → Z) :
    SplitsEverySeam observe coordinate target ↔
      FibreConstant (fun x => (observe x, coordinate x)) target := by
  constructor
  · intro split a b same
    by_cases sameTarget : target a = target b
    · exact sameTarget
    · let seam : SeamCertificate observe target :=
        ⟨a, b, congrArg Prod.fst same, sameTarget⟩
      exact False.elim ((split seam) (congrArg Prod.snd same))
  · intro constant seam sameCoordinate
    exact seam.distinctTargets
      (constant seam.left seam.right (Prod.ext seam.sameReading sameCoordinate))

/-- Four states suffice to refute independence => adequate recovery. -/
def squareObserve (_ : Bool × Bool) : Unit := ()
def squareCoordinate (x : Bool × Bool) : Bool := x.1
def squareTarget (x : Bool × Bool) : Bool := x.2

def diagonalSeam : SeamCertificate squareObserve squareTarget where
  left := (false, false)
  right := (true, true)
  sameReading := rfl
  distinctTargets := by decide

theorem square_coordinate_is_independent : ¬ Recovers squareObserve squareCoordinate :=
  collision_excludes_every_decoder _ _
    (x := (false, false)) (x' := (true, false)) rfl (by decide)

theorem square_coordinate_splits_diagonal_seam :
    squareCoordinate diagonalSeam.left ≠ squareCoordinate diagonalSeam.right := by decide

theorem square_refinement_still_loses_target :
    ¬ Recovers (fun x => (squareObserve x, squareCoordinate x)) squareTarget :=
  collision_excludes_every_decoder _ _
    (x := (false, false)) (x' := (false, true)) rfl (by decide)

theorem independent_coordinate_and_one_split_are_insufficient :
    (¬ Recovers squareObserve squareCoordinate) ∧
    squareCoordinate diagonalSeam.left ≠ squareCoordinate diagonalSeam.right ∧
    ¬ Recovers (fun x => (squareObserve x, squareCoordinate x)) squareTarget :=
  ⟨square_coordinate_is_independent, square_coordinate_splits_diagonal_seam,
    square_refinement_still_loses_target⟩

/-- Complete state knowledge does not move a frozen orbit into a target set. -/
def bitObserve (_ : Bool) : Unit := ()
def bitTarget (x : Bool) : Bool := x
def frozenTrace (start : Bool) (_ : Nat) : Bool := start
def UniversalFrozenEntry : Prop := ∀ start : Bool, ∃ t : Nat, frozenTrace start t = true

theorem bit_coarse_readout_has_seam : ¬ Recovers bitObserve bitTarget :=
  collision_excludes_every_decoder _ _ (x := false) (x' := true) rfl (by decide)

def completeBitLift : AdequateLift bitObserve bitTarget Bool where
  coordinate := bitTarget
  decode := Prod.snd
  correct := fun _ => rfl

theorem frozen_system_does_not_have_universal_entry : ¬ UniversalFrozenEntry := by
  intro allEntry
  obtain ⟨t, ht⟩ := allEntry false
  exact Bool.noConfusion ht

theorem complete_recovery_does_not_force_universal_entry :
    (¬ Recovers bitObserve bitTarget) ∧
      Recovers (fun x => (bitObserve x, completeBitLift.coordinate x)) bitTarget ∧
      ¬ UniversalFrozenEntry :=
  ⟨bit_coarse_readout_has_seam,
    adequate_lift_supplies_recovery _ _ completeBitLift,
    frozen_system_does_not_have_universal_entry⟩

/-- The original Rule 30 shield predicate is unchanged by storing its output. -/
theorem rule30_target_retention_coexists_with_original_certificate_failure
    {w : List Bool} {J P f0 : Nat} {S0 : Fin J → Bool}
    (hJ : 0 < J) (f : Nat) (S T : Fin J → Bool)
    (hs : Reach w J P f0 S0 f S) (ht : Reach w J P f0 S0 f T)
    (different : S ⟨0, hJ⟩ ≠ T ⟨0, hJ⟩) :
    Recovers (fun q : ReachableBand w J P f0 S0 => (phase q, output hJ q)) (output hJ) ∧
      ¬ (∃ C : Certificate w J P, C.R f0 S0) :=
  ⟨retaining_target_gives_recovery _ _,
    edge_conflict_excludes_every_certificate hJ f S T hs ht different⟩

/-- Periodicity transfers if both components of the refined reading repeat. -/
def HasPeriod (trace : Nat → Z) (P : Nat) : Prop := ∀ t, trace (t + P) = trace t

theorem output_period_follows_from_both_refined_periods
    (observe : Nat → Y) (coordinate : Nat → R) (target : Nat → Z)
    (decode : Y × R → Z) (correct : ∀ t, decode (observe t, coordinate t) = target t)
    (P : Nat) (observePeriodic : HasPeriod observe P)
    (coordinatePeriodic : HasPeriod coordinate P) : HasPeriod target P := by
  intro t
  calc
    target (t + P) = decode (observe (t + P), coordinate (t + P)) := (correct _).symm
    _ = decode (observe t, coordinate t) := by rw [observePeriodic t, coordinatePeriodic t]
    _ = target t := correct t

def alternatingBit (t : Nat) : Bool := decide (t % 2 = 1)

theorem constant_phase_has_period_one : HasPeriod (fun _ : Nat => ()) 1 := fun _ => rfl

theorem alternating_bit_does_not_have_period_one : ¬ HasPeriod alternatingBit 1 := by
  intro periodic
  have different : alternatingBit (0 + 1) ≠ alternatingBit 0 := by decide
  exact different (periodic 0)

theorem full_trace_recovery_does_not_force_phase_period :
    HasPeriod (fun _ : Nat => ()) 1 ∧
      Recovers (fun t : Nat => ((), alternatingBit t)) alternatingBit ∧
      ¬ HasPeriod alternatingBit 1 :=
  ⟨constant_phase_has_period_one, ⟨Prod.snd, fun _ => rfl⟩,
    alternating_bit_does_not_have_period_one⟩

/-- The observer-inclusive registration rule, applied without an exemption. -/
inductive ReviewSource | situatedReview deriving DecidableEq
inductive ReviewCriterion | explicitFiniteCountermodel deriving DecidableEq

structure JudgmentRecord where
  source : Option ReviewSource
  criterion : Option ReviewCriterion
  deriving DecidableEq

def Located (record : JudgmentRecord) : Prop :=
  record.source ≠ none ∧ record.criterion ≠ none

def Nullself (record : JudgmentRecord) : Prop :=
  record.source = none ∧ record.criterion = none

theorem nullself_cannot_be_located (record : JudgmentRecord) (null : Nullself record) :
    ¬ Located record := fun located => located.1 null.1

theorem nullself_cannot_supply_registered_certification
    (certified : JudgmentRecord → Prop)
    (registrationRule : ∀ record, certified record → Located record)
    (record : JudgmentRecord) (null : Nullself record) : ¬ certified record :=
  fun accepted => nullself_cannot_be_located record null (registrationRule record accepted)

def situatedCountermodelRecord : JudgmentRecord :=
  ⟨some .situatedReview, some .explicitFiniteCountermodel⟩

theorem countermodel_record_is_located : Located situatedCountermodelRecord := by
  simp [Located, situatedCountermodelRecord]

theorem countermodel_record_is_not_nullself : ¬ Nullself situatedCountermodelRecord := by
  simp [Nullself, situatedCountermodelRecord]

/-- A registered critique can accept the seam and reject the proposed upgrade. -/
theorem situated_countermodel_accepts_seam_and_refutes_general_entry_upgrade :
    Located situatedCountermodelRecord ∧ ¬ Nullself situatedCountermodelRecord ∧
      (¬ Recovers bitObserve bitTarget) ∧
      Recovers (fun x => (bitObserve x, completeBitLift.coordinate x)) bitTarget ∧
      ¬ UniversalFrozenEntry :=
  ⟨countermodel_record_is_located, countermodel_record_is_not_nullself,
    complete_recovery_does_not_force_universal_entry⟩

end SeamClosureConditions
