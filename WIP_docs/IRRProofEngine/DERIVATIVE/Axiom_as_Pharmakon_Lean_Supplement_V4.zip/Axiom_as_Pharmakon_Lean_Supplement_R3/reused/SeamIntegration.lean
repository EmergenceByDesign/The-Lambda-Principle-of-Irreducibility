import SeamClosure

/-!
Seam Integration R2, 23 October 2026.
Observer/cut parameters and a strict ladder of retained distinctions.
The results concern explicitly given readouts and targets. They do not
postulate an ontology of consciousness, a causal model of will, or that the
remaining Rule 30 entry conjecture is undecidable.
-/

namespace SeamIntegration

open SeamClosure

universe u v w r
variable {X : Type u} {Y : Type v} {Z : Type w} {R : Type r}

/-- Fine retains coarse if forgetting a fine reading gives the coarse one. -/
def Refines (fine : X → R) (coarse : X → Y) : Prop :=
  ∃ forget : R → Y, ∀ x, forget (fine x) = coarse x

theorem recovery_composes (observe : X → Y) (middle : X → R) (target : X → Z)
    (hm : Recovers observe middle) (ht : Recovers middle target) :
    Recovers observe target := by
  obtain ⟨dm, hdm⟩ := hm
  obtain ⟨dt, hdt⟩ := ht
  refine ⟨fun y => dt (dm y), ?_⟩
  intro x
  change dt (dm (observe x)) = target x
  rw [hdm x]
  exact hdt x

theorem adequate_readout_splits_seam (observe : X → Y) (target : X → Z)
    (seam : SeamCertificate observe target) (fine : X → R)
    (adequate : Recovers fine target) : fine seam.left ≠ fine seam.right := by
  intro same
  exact seam.distinctTargets
    (recovery_requires_fibre_constancy fine target adequate _ _ same)

theorem adequate_readout_cannot_factor_through_coarse
    (observe : X → Y) (target : X → Z) (seam : SeamCertificate observe target)
    (fine : X → R) (adequate : Recovers fine target) : ¬ Refines observe fine := by
  intro reverse
  exact seam_certificate_closes_decoder_class observe target seam
    (recovery_composes observe fine target reverse adequate)

theorem added_coordinate_must_split (observe : X → Y) (target : X → Z)
    (seam : SeamCertificate observe target) (coordinate : X → R)
    (adequate : Recovers (fun x => (observe x, coordinate x)) target) :
    coordinate seam.left ≠ coordinate seam.right := by
  intro same
  exact adequate_readout_splits_seam observe target seam _ adequate
    (Prod.ext seam.sameReading same)

theorem old_readout_cannot_supply_essential_coordinate
    (observe : X → Y) (target : X → Z) (seam : SeamCertificate observe target)
    (coordinate : X → R)
    (adequate : Recovers (fun x => (observe x, coordinate x)) target) :
    ¬ Recovers observe coordinate :=
  collision_excludes_every_decoder observe coordinate seam.sameReading
    (added_coordinate_must_split observe target seam coordinate adequate)

theorem joint_readout_retains_coarse (observe : X → Y) (coordinate : X → R) :
    Refines (fun x => (observe x, coordinate x)) observe :=
  ⟨Prod.fst, fun _ => rfl⟩

theorem retaining_target_gives_recovery (observe : X → Y) (target : X → Z) :
    Recovers (fun x => (observe x, target x)) target :=
  ⟨Prod.snd, fun _ => rfl⟩

/-- A varying observer, criterion or cut can be an explicit context input. -/
theorem erasing_cut_parameter_obstructs {C : Type r}
    (observe : X → Y) (cut : C → X → Z) (c d : C) (x : X)
    (different : cut c x ≠ cut d x) :
    ¬ Recovers (fun p : C × X => observe p.2) (fun p => cut p.1 p.2) :=
  collision_excludes_every_decoder _ _ (x := (c, x)) (x' := (d, x)) rfl different

theorem retained_cut_parameter_recovers_with_calibration {C : Type r}
    (observe : X → Y) (cut : C → X → Z) (decode : C → Y → Z)
    (calibrated : ∀ c x, decode c (observe x) = cut c x) :
    Recovers (fun p : C × X => (p.1, observe p.2)) (fun p => cut p.1 p.2) :=
  ⟨fun p => decode p.1 p.2, fun p => calibrated p.1 p.2⟩

/-- A concrete infinite ladder; its domain is unrestricted binary sequences. -/
def Prefix (n : Nat) (x : Nat → Bool) : Fin n → Bool := fun i => x i.val
def NextBit (n : Nat) (x : Nat → Bool) : Bool := x n

def prefixSeam (n : Nat) : SeamCertificate (Prefix n) (NextBit n) where
  left := fun _ => false
  right := fun i => decide (i = n)
  sameReading := by
    funext i
    have different : i.val ≠ n := Nat.ne_of_lt i.isLt
    simp [Prefix, different]
  distinctTargets := by simp [NextBit]

theorem every_finite_prefix_has_next_bit_obstruction (n : Nat) :
    ¬ Recovers (Prefix n) (NextBit n) :=
  seam_certificate_closes_decoder_class _ _ (prefixSeam n)

theorem next_prefix_retains_previous (n : Nat) :
    Refines (Prefix (n + 1)) (Prefix n) := by
  refine ⟨fun s i => s ⟨i.val, Nat.lt.step i.isLt⟩, ?_⟩
  intro x
  rfl

theorem next_prefix_recovers_next_bit (n : Nat) :
    Recovers (Prefix (n + 1)) (NextBit n) :=
  ⟨fun s => s ⟨n, Nat.lt_succ_self n⟩, fun _ => rfl⟩

theorem every_prefix_ladder_step_is_strict (n : Nat) :
    Refines (Prefix (n + 1)) (Prefix n) ∧ ¬ Refines (Prefix n) (Prefix (n + 1)) :=
  ⟨next_prefix_retains_previous n,
    adequate_readout_cannot_factor_through_coarse _ _ (prefixSeam n) _
      (next_prefix_recovers_next_bit n)⟩

end SeamIntegration
