import Lean

/-!
# Deflation of Pharmakon-Based Delusion
A formal example of undisclosed meaning change under one public label.
The finite model illustrates logical structure, not a physical model.
-/
namespace SemanticDeflation

/-- The new use cannot retain every constraint of the old use. -/
theorem deflation
    {X : Type} (A B P : X → Prop)
    (hA : ∀ x, A x → ¬ P x)
    (hB : ∃ x, B x ∧ P x) :
    ¬ (∀ x, B x → A x) := by
  intro hBA
  rcases hB with ⟨x, hBx, hPx⟩
  exact hA x (hBA x hBx) hPx

/-- Identify a witness at which the original definition no longer applies. -/
theorem constraint_loss
    {X : Type} (A B P : X → Prop)
    (hA : ∀ x, A x → ¬ P x)
    (hB : ∃ x, B x ∧ P x) :
    ∃ x, B x ∧ P x ∧ ¬ A x := by
  rcases hB with ⟨x, hBx, hPx⟩
  exact ⟨x, hBx, hPx, fun hAx => hA x hAx hPx⟩

/-- No single predicate can be equivalent to both uses. -/
theorem no_shared_definition
    {X : Type} (A B P : X → Prop)
    (hA : ∀ x, A x → ¬ P x)
    (hB : ∃ x, B x ∧ P x) :
    ¬ ∃ S : X → Prop,
      (∀ x, S x ↔ A x) ∧ (∀ x, S x ↔ B x) := by
  intro h
  rcases h with ⟨S, hSA, hSB⟩
  exact deflation A B P hA hB
    (fun x hBx => (hSA x).mp ((hSB x).mpr hBx))

/-- Forcing both arms onto one unchanged meaning yields False. -/
theorem same_meaning_conflict
    {X : Type} (S P : X → Prop)
    (hNo : ∀ x, S x → ¬ P x)
    (hYes : ∃ x, S x ∧ P x) : False := by
  rcases hYes with ⟨x, hSx, hPx⟩
  exact hNo x hSx hPx

inductive State where
  | bare
  | marked

def HasTrait : State → Prop
  | .bare => False
  | .marked => True

def Original (x : State) : Prop := ¬ HasTrait x
def Extended (_x : State) : Prop := True

inductive Usage where
  | original
  | extended

def meaning : Usage → State → Prop
  | .original => Original
  | .extended => Extended

/-- This public label suppresses which predicate supplies its meaning. -/
def publicLabel (_u : Usage) : String := "singularity"

theorem original_inhabited : ∃ x, Original x := by
  exact ⟨State.bare, fun h => h⟩

theorem original_excludes_trait :
    ∀ x, Original x → ¬ HasTrait x := by
  intro x h
  exact h

theorem extended_admits_trait :
    ∃ x, Extended x ∧ HasTrait x := by
  exact ⟨State.marked, True.intro, True.intro⟩

theorem original_is_extended :
    ∀ x, Original x → Extended x := by
  intro x _
  exact True.intro

/-- Both scoped arms hold, with a nonempty old use and the same public name. -/
theorem two_checked_branches_one_label :
    (∃ x, meaning Usage.original x) ∧
    (∀ x, meaning Usage.original x → ¬ HasTrait x) ∧
    (∃ x, meaning Usage.extended x ∧ HasTrait x) ∧
    publicLabel Usage.original = publicLabel Usage.extended := by
  exact ⟨original_inhabited, original_excludes_trait,
    extended_admits_trait, rfl⟩

/-- Equal printed names do not justify identifying the two definitions. -/
theorem shared_label_does_not_preserve_meaning :
    publicLabel Usage.original = publicLabel Usage.extended ∧
    ¬ (∀ x, meaning Usage.original x ↔ meaning Usage.extended x) := by
  constructor
  · rfl
  · intro h
    exact deflation Original Extended HasTrait
      original_excludes_trait extended_admits_trait
      (fun x hx => (h x).mpr hx)

end SemanticDeflation
