import UniformWindow

/-!
Shield entry, 23 October 2026. Claude, with Lu Semita.

Step (a) as a theorem. A certificate is a phase-indexed set of band states (columns 1..J) that is closed under
the band step for every bit the bulk can send into column J+1, and on which column 1 is a function of the phase.
Once a right half's band enters a certificate, column 1 is periodic forever, whatever the bulk does (`shield`).
So settles(w) — and with it ¬ EventuallyRepeats center30 w — follows from: every finite start's band enters
some certificate (`center_avoids_of_entry`). That hypothesis is the open core; it is not assumed true here.
Certificates themselves are finite objects; the computations in the supplement produce them.
-/

namespace ShieldEntry

open Rule30Bridge Rule30Application RightHalf UniformWindow

/-- The band: columns 1..J at time t. -/
def bandOf (x : Nat → Nat → Bool) (J t : Nat) : Fin J → Bool := fun i => x t (i.val + 1)

/-- One step of the band, with drive bit d entering at column 0 and the bulk's bit e at column J+1. -/
def bandStep (J : Nat) (S : Fin J → Bool) (d e : Bool) : Fin J → Bool := fun i =>
  Bool.xor (if h : i.val = 0 then d else S ⟨i.val - 1, by omega⟩)
    (S i || (if h : i.val + 1 < J then S ⟨i.val + 1, h⟩ else e))

/-- The true band evolves by the band step, with the bulk's actual column J+1 as the edge bit. -/
theorem bandOf_succ (b x0 : Nat → Bool) (J t : Nat) :
    bandOf (rhc b x0) J (t + 1) = bandStep J (bandOf (rhc b x0) J t) (b t) (rhc b x0 t (J + 1)) := by
  funext i
  obtain ⟨k, hk⟩ := i
  simp only [bandOf, bandStep]
  have hL : (if h : k = 0 then b t else rhc b x0 t (k - 1 + 1)) = rhc b x0 t k := by
    by_cases h : k = 0
    · subst h
      simp only [rhc, dite_true]
    · rw [dif_neg h]
      congr 1
      omega
  have hR : (if h : k + 1 < J then rhc b x0 t (k + 1 + 1) else rhc b x0 t (J + 1)) = rhc b x0 t (k + 2) := by
    by_cases h : k + 1 < J
    · rw [dif_pos h]
    · rw [dif_neg h]
      congr 1
      omega
  rw [hL, hR]
  simp only [rhc]

/-- A certificate for the word w at band width J and phase modulus P. -/
structure Certificate (w : List Bool) (J P : Nat) where
  R : Nat → (Fin J → Bool) → Prop
  closed : ∀ f S, R f S → ∀ e : Bool, R ((f + 1) % P) (bandStep J S (w.getD (f % w.length) false) e)
  value : Nat → Bool
  det : ∀ f S (hJ : 0 < J), R f S → S ⟨0, hJ⟩ = value f

theorem pdrive_phase (w : List Bool) (P t : Nat) (hwP : w.length ∣ P) :
    pdrive w t = w.getD ((t % P) % w.length) false := by
  unfold pdrive
  rw [Nat.mod_mod_of_dvd t hwP]

/-- Shield: once the band is in the certificate, it stays there under the true dynamics. -/
theorem shield (w : List Bool) (J P : Nat) (hwP : w.length ∣ P) (C : Certificate w J P)
    (x0 : Nat → Bool) (t0 : Nat) (h0 : C.R (t0 % P) (bandOf (rhc (pdrive w) x0) J t0)) :
    ∀ t, t0 ≤ t → C.R (t % P) (bandOf (rhc (pdrive w) x0) J t) := by
  have key : ∀ n, C.R ((t0 + n) % P) (bandOf (rhc (pdrive w) x0) J (t0 + n)) := by
    intro n
    induction n with
    | zero => exact h0
    | succ n ih =>
      rw [show t0 + (n + 1) = (t0 + n) + 1 from rfl, bandOf_succ, pdrive_phase w P (t0 + n) hwP,
        ← Nat.mod_add_mod (t0 + n) P 1]
      exact C.closed _ _ ih _
  intro t ht
  have := key (t - t0)
  rw [show t0 + (t - t0) = t by omega] at this
  exact this

/-- Shield, read on column 1: periodic with period P from the entry time on. -/
theorem shield_periodic (w : List Bool) (J P : Nat) (hJ : 0 < J) (hP : 0 < P) (hwP : w.length ∣ P)
    (C : Certificate w J P) (x0 : Nat → Bool) (t0 : Nat)
    (h0 : C.R (t0 % P) (bandOf (rhc (pdrive w) x0) J t0)) :
    EventuallyPeriodic (fun t => rhc (pdrive w) x0 t 1) := by
  refine ⟨t0, P, hP, fun t ht => ?_⟩
  have a := C.det _ _ hJ (shield w J P hwP C x0 t0 h0 (t + P) (by omega))
  have c := C.det _ _ hJ (shield w J P hwP C x0 t0 h0 t ht)
  simp only [bandOf] at a c
  show rhc (pdrive w) x0 (t + P) 1 = rhc (pdrive w) x0 t 1
  rw [a, c, Nat.add_mod_right]

/-- The zero-start right half vanishes beyond its light cone. -/
theorem rh_outside (b : Nat → Bool) : ∀ t m, t < m → rh b t m = false := by
  intro t
  induction t with
  | zero =>
    intro m hm
    cases m with
    | zero => omega
    | succ m => simp only [rh]
  | succ t ih =>
    intro m hm
    cases m with
    | zero => omega
    | succ m =>
      simp only [rh]
      rw [ih m (by omega), ih (m + 1) (by omega), ih (m + 2) (by omega)]
      rfl

/-- The open core for a word w: every finite start's band enters some certificate. -/
def EveryFiniteStartEnters (w : List Bool) : Prop :=
  ∀ x0 : Nat → Bool, (∃ K, ∀ i, K < i → x0 i = false) →
    ∃ J P t0, ∃ C : Certificate w J P, 0 < J ∧ 0 < P ∧ w.length ∣ P ∧
      C.R (t0 % P) (bandOf (rhc (pdrive w) x0) J t0)

/-- From the open core to settles(w). -/
theorem settles_of_entry (w : List Bool) (h : EveryFiniteStartEnters w) :
    ∀ b : Nat → Bool, EventuallyRepeats b w → EventuallyPeriodic (fun t => rh b t 1) := by
  intro b hb
  obtain ⟨N, hN⟩ := hb
  have hdrive : (fun u => b (N + u)) = pdrive w := by
    funext u
    rw [hN (N + u) (Nat.le_add_right N u), Nat.add_sub_cancel_left]
    rfl
  have col : ∀ t, rh b (N + t) 1 = rhc (pdrive w) (fun m => rh b N m) t 1 := by
    intro t
    rw [rh_eq_rhc b (N + t) 1, rhc_restart b (fun _ => false) N t 1, hdrive]
    have hX : (fun m => rhc b (fun _ => false) N m) = (fun m => rh b N m) := by
      funext m
      exact (rh_eq_rhc b N m).symm
    rw [hX]
  obtain ⟨J, P, t0, C, hJ, hP, hwP, h0⟩ :=
    h (fun m => rh b N m) ⟨N, fun i hi => rh_outside b N i hi⟩
  obtain ⟨M, p, hp, hper⟩ := shield_periodic w J P hJ hP hwP C _ t0 h0
  refine ⟨N + M, p, hp, fun t ht => ?_⟩
  show rh b (t + p) 1 = rh b t 1
  have e1 : t + p = N + (t - N + p) := by omega
  have e2 : t = N + (t - N) := by omega
  have h3 : rhc (pdrive w) (fun m => rh b N m) (t - N + p) 1 = rhc (pdrive w) (fun m => rh b N m) (t - N) 1 :=
    hper (t - N) (by omega)
  rw [e1, col (t - N + p), h3, ← col (t - N), ← e2]

/-- The bridge for step (a): Problem 1 restricted to w follows from the open core for w. -/
theorem center_avoids_of_entry (w : List Bool) (hw : 0 < w.length) (h : EveryFiniteStartEnters w) :
    ¬ EventuallyRepeats center30 w :=
  center_avoids_pattern_of_right_settles w hw (fun b _ hb => settles_of_entry w h b hb)

end ShieldEntry
