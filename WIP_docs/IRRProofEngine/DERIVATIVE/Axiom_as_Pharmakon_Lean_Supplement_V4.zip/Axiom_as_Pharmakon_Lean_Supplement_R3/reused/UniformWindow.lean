import RightHalf

/-!
Uniform window, 23 October 2026. Claude, with Lu Semita.

The right half-line under a periodic drive, started from an arbitrary configuration. Two facts turn
"the first column settles for every transient" into one finite check:
  (1) restart: the right half from time s on is the right half started from its own configuration at s;
  (2) light cone: column 1 up to time T depends only on the start in columns 1..T+1.
With the drive periodic of period p = w.length, a check that column 1 is q-periodic on one window [B, B+L]
(q + p ≤ L + 1), over every start supported in columns 1..B+L+1, gives q-periodicity of column 1 from time B
on for every start at all; hence `settles` for w, hence the center column never eventually repeats w.
The finite check is a hypothesis here. It is not assumed true, and for small B it is false.
-/

namespace UniformWindow

open Rule30Bridge Rule30Application RightHalf

/-- The right half-line driven by b, started from the configuration x0 (indices m ≥ 1; index 0 is the drive). -/
def rhc (b : Nat → Bool) (x0 : Nat → Bool) : Nat → Nat → Bool
  | t, 0 => b t
  | 0, m + 1 => x0 (m + 1)
  | t + 1, m + 1 => Bool.xor (rhc b x0 t m) (rhc b x0 t (m + 1) || rhc b x0 t (m + 2))

/-- The zero start is the right half used so far. -/
theorem rh_eq_rhc (b : Nat → Bool) : ∀ t m, rh b t m = rhc b (fun _ => false) t m := by
  intro t
  induction t with
  | zero =>
    intro m
    cases m with
    | zero => simp only [rh, rhc]
    | succ m => simp only [rh, rhc]
  | succ t ih =>
    intro m
    cases m with
    | zero => simp only [rh, rhc]
    | succ m => simp only [rh, rhc, ih]

/-- Restart: from time s on, the right half is the right half started from its own configuration at s. -/
theorem rhc_restart (b x0 : Nat → Bool) (s : Nat) :
    ∀ t m, rhc b x0 (s + t) m = rhc (fun u => b (s + u)) (fun m => rhc b x0 s m) t m := by
  intro t
  induction t with
  | zero =>
    intro m
    cases m with
    | zero => simp only [rhc, Nat.add_zero]
    | succ m => simp only [rhc, Nat.add_zero]
  | succ t ih =>
    intro m
    cases m with
    | zero => rfl
    | succ m =>
      rw [show s + (t + 1) = (s + t) + 1 from rfl]
      simp only [rhc, ih]

/-- Light cone: column m ≥ 1 at time t depends only on the drive before t and the start in columns 1..m+t. -/
theorem rhc_cone (b b' x0 y0 : Nat → Bool) :
    ∀ t m, 1 ≤ m → (∀ u, u < t → b u = b' u) → (∀ i, 1 ≤ i → i ≤ m + t → x0 i = y0 i) →
      rhc b x0 t m = rhc b' y0 t m := by
  intro t
  induction t with
  | zero =>
    intro m hm _ hx
    cases m with
    | zero => omega
    | succ m =>
      simp only [rhc]
      exact hx (m + 1) (by omega) (by omega)
  | succ t ih =>
    intro m hm hb hx
    cases m with
    | zero => omega
    | succ m =>
      simp only [rhc]
      have hb' : ∀ u, u < t → b u = b' u := fun u hu => hb u (by omega)
      have e1 : rhc b x0 t m = rhc b' y0 t m := by
        cases m with
        | zero =>
          simp only [rhc]
          exact hb t (by omega)
        | succ m => exact ih (m + 1) (by omega) hb' (fun i hi1 hi2 => hx i hi1 (by omega))
      have e2 : rhc b x0 t (m + 1) = rhc b' y0 t (m + 1) :=
        ih (m + 1) (by omega) hb' (fun i hi1 hi2 => hx i hi1 (by omega))
      have e3 : rhc b x0 t (m + 2) = rhc b' y0 t (m + 2) :=
        ih (m + 2) (by omega) hb' (fun i hi1 hi2 => hx i hi1 (by omega))
      rw [e1, e2, e3]

/-- The periodic drive with word w, phase 0 at time 0. -/
def pdrive (w : List Bool) (u : Nat) : Bool := w.getD (u % w.length) false

theorem pdrive_shift (w : List Bool) (k u : Nat) : pdrive w (w.length * k + u) = pdrive w u := by
  unfold pdrive
  rw [Nat.add_comm (w.length * k) u, Nat.add_mul_mod_self_left]

/-- The finite check, over every start: column 1 is q-periodic on the window [B, B+L]. -/
def WindowHolds (w : List Bool) (q B L : Nat) : Prop :=
  ∀ x0 : Nat → Bool, ∀ t, B ≤ t → t + q ≤ B + L →
    rhc (pdrive w) x0 (t + q) 1 = rhc (pdrive w) x0 t 1

/-- The same check over finitely many starts: those supported in columns 1..B+L+1. This is exactly the
proposition a SAT solver decides (unsatisfiable instance = the check holds). -/
def WindowHoldsFinite (w : List Bool) (q B L : Nat) : Prop :=
  ∀ x0 : Nat → Bool, (∀ i, B + L + 1 < i → x0 i = false) →
    ∀ t, B ≤ t → t + q ≤ B + L → rhc (pdrive w) x0 (t + q) 1 = rhc (pdrive w) x0 t 1

theorem windowHolds_of_finite (w : List Bool) (q B L : Nat) (h : WindowHoldsFinite w q B L) :
    WindowHolds w q B L := by
  intro x0 t ht1 ht2
  let y0 : Nat → Bool := fun i => if i ≤ B + L + 1 then x0 i else false
  have hy : ∀ i, B + L + 1 < i → y0 i = false := by
    intro i hi
    show (if i ≤ B + L + 1 then x0 i else false) = false
    rw [if_neg (by omega)]
  have agree : ∀ s, s ≤ B + L → rhc (pdrive w) x0 s 1 = rhc (pdrive w) y0 s 1 := by
    intro s hs
    refine rhc_cone _ _ _ _ s 1 (Nat.le_refl 1) (fun _ _ => rfl) (fun i _ hi2 => ?_)
    show x0 i = (if i ≤ B + L + 1 then x0 i else false)
    rw [if_pos (by omega)]
  rw [agree (t + q) ht2, agree t (by omega)]
  exact h y0 hy t ht1 ht2

/-- One window decides every transient: if the check holds, column 1 of the right half is eventually
periodic under every drive that eventually repeats w. -/
theorem settles_of_window (w : List Bool) (hw : 0 < w.length) (q B L : Nat) (hq : 0 < q)
    (hL : q + w.length ≤ L + 1) (h : WindowHolds w q B L) :
    ∀ b : Nat → Bool, EventuallyRepeats b w → EventuallyPeriodic (fun t => rh b t 1) := by
  intro b hb
  obtain ⟨N, hN⟩ := hb
  have hdrive : (fun u => b (N + u)) = pdrive w := by
    funext u
    rw [hN (N + u) (Nat.le_add_right N u), Nat.add_sub_cancel_left]
    rfl
  have col : ∀ t, rh b (N + t) 1 = rhc (pdrive w) (fun m => rh b N m) t 1 := by
    intro t
    rw [rh_eq_rhc b (N + t) 1, rhc_restart b (fun _ => false) N t 1, hdrive]
    have hX : (fun m => rhc b (fun _ => false) N m) = (fun m => rh b N m) := by
      funext m
      exact (rh_eq_rhc b N m).symm
    rw [hX]
  have per : ∀ x0 : Nat → Bool, ∀ s, B ≤ s →
      rhc (pdrive w) x0 (s + q) 1 = rhc (pdrive w) x0 s 1 := by
    intro x0 s hs
    obtain ⟨k, r, hs', hr1, hr2⟩ : ∃ k r, s = w.length * k + r ∧ B ≤ r ∧ r + q ≤ B + L := by
      refine ⟨(s - B) / w.length, B + (s - B) % w.length, ?_, ?_, ?_⟩
      · have h1 := Nat.div_add_mod (s - B) w.length
        omega
      · omega
      · have h2 := Nat.mod_lt (s - B) hw
        omega
    have e : ∀ t, rhc (pdrive w) x0 (w.length * k + t) 1 =
        rhc (pdrive w) (fun m => rhc (pdrive w) x0 (w.length * k) m) t 1 := by
      intro t
      rw [rhc_restart (pdrive w) x0 (w.length * k) t 1]
      have hp : (fun u => pdrive w (w.length * k + u)) = pdrive w := by
        funext u
        exact pdrive_shift w k u
      rw [hp]
    rw [hs', Nat.add_assoc, e (r + q), e r]
    exact h _ r hr1 hr2
  refine ⟨N + B, q, hq, fun t ht => ?_⟩
  show rh b (t + q) 1 = rh b t 1
  have e1 : t + q = N + (t - N + q) := by omega
  have e2 : t = N + (t - N) := by omega
  rw [e1, col (t - N + q), per _ (t - N) (by omega), ← col (t - N), ← e2]

/-- The bridge: Problem 1 restricted to a word w follows from one finite check, for any single window. -/
theorem center_avoids_of_window (w : List Bool) (hw : 0 < w.length) (q B L : Nat) (hq : 0 < q)
    (hL : q + w.length ≤ L + 1) (h : WindowHoldsFinite w q B L) : ¬ EventuallyRepeats center30 w :=
  center_avoids_pattern_of_right_settles w hw
    (fun b _ hb => settles_of_window w hw q B L hq hL (windowHolds_of_finite w q B L h) b hb)

end UniformWindow
