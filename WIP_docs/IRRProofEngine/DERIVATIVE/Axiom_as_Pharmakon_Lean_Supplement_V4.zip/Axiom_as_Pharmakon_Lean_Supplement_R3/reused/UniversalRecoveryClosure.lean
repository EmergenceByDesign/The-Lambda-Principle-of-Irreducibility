import Lean

/-!
Universal recovery closure, 24 October 2026.
A self-contained statement of the collision argument already used in the
seam work. The proof excludes the entire declared decoder class at once.
It uses no custom assumptions beyond its explicit theorem hypotheses.
-/

universe u v w r

namespace UniversalRecoveryClosure

theorem no_processing_recovers_erased_distinction
    {X : Type u} {Y : Type v} {Z : Type w}
    (observe : X → Y) (target : X → Z) (a b : X)
    (sameReading : observe a = observe b)
    (differentTargets : target a ≠ target b) :
    ∀ {R : Type r} (process : Y → R) (decode : R → Z),
      ¬ (∀ x, decode (process (observe x)) = target x) := by
  intro R process decode correct
  apply differentTargets
  calc
    target a = decode (process (observe a)) := (correct a).symm
    _ = decode (process (observe b)) := congrArg (fun y => decode (process y)) sameReading
    _ = target b := correct b

theorem no_decoder_recovers_erased_distinction
    {X : Type u} {Y : Type v} {Z : Type w}
    (observe : X → Y) (target : X → Z) (a b : X)
    (sameReading : observe a = observe b)
    (differentTargets : target a ≠ target b) :
    ¬ (∃ decode : Y → Z, ∀ x, decode (observe x) = target x) := by
  intro recovery
  obtain ⟨decode, correct⟩ := recovery
  exact no_processing_recovers_erased_distinction observe target a b
    sameReading differentTargets (fun y => y) decode correct

#print axioms no_processing_recovers_erased_distinction
#print axioms no_decoder_recovers_erased_distinction

end UniversalRecoveryClosure
