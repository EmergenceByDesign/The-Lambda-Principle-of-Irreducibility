CLOSURE AT THE ADJUDICATION SEAM -- R8
Full mathematical treatment and complete proof compilation
24 October 2026

READ FIRST

reports/Closure_at_the_Adjudication_Seam_2026-10-24_R8.pdf is the standalone
treatment. It states and proves universal recovery closure, arbitrary
processing invariance, certified abstention, and the necessary distinction
in any adequate refinement. It also gives exact image factorization,
observer-inclusive criterion parameters, the diagonal connection, worked
Rule 30 seams, the foundational ledger and complete core proof source.

The conclusion is a universal mathematical result: two cases with the same
readout and unequal target values exclude every globally correct decoder of
that readout. No candidate decoder of the quantified type is left outside
the proof. Globally sound stage-indexed attempts must abstain at every stage
on the certified shared reading. That null case has a positive certificate.

THE FULL CORPUS

core/ contains the complete two-file standalone core. All 18 theorems and
25 named declarations report no axiom dependencies in Lean.

applications/diagonal_r6/ contains the complete recovered R6 source packet,
including all 19 imported modules and its original reports and receipts.

applications/parallax_r7/ contains the complete R7 source packet, including
all 22 imported modules, the parallax application and its original receipts.

source_packets/ preserves the original R6 and R7 ZIP files unchanged, and
the named adjudication checkpoint. R6 in turn retains its R5, R4 and earlier
source packets. R7 retains the uploaded parallax report and supplement.

manuscript/ contains editable LaTeX and the generated core axiom report.
receipts/ contains the fresh isolated builds, audits and typesetting logs.
reproduction/ contains the executable verification and document-build scripts.

EXACT VERIFICATION

Fresh target              Modules  Audited theorems  Named declarations
Standalone core                2                18                  25
Diagonal R6 chain             19                24                  34
Parallax R7 chain             22                22                  33
Selected foundations           -                13                  13
Total                        43                77                 105

The module count is the total of isolated source compilations; shared
antecedent modules are rebuilt within each appropriate application version.
Every stage passed official Lean 4.22.0 at trust level 0, with zero compiler
errors and warnings. The core axiom reports are empty. The audited R6 and
R7 application declarations use at most propext and Quot.sound. The exact
image-factorization converse uses Classical.choice, and total extension
with a default also reports propext and Quot.sound. The ledger preserves
these differences rather than applying one axiom label to the whole corpus.

The primary application sources are retained as separate trees because
some shared module names have distinct historical versions. They are never
silently merged into one Lean import path.

REBUILD THE PROOFS

Install official Lean 4.22.0, then run from the extracted packet:

  python3 reproduction/verify_all.py --lean /absolute/path/to/lean
  python3 reproduction/audit_foundations.py --lean /absolute/path/to/lean

The first script compiles all three targets and audits the core and named
application results. The second audits the selected foundational statements,
including the exact converse constructions and their axiom dependencies.
Only bundled Lean libraries are needed; no Mathlib installation is required.
Compiled .olean files are omitted from the distribution and are rebuilt.

For the standalone core alone:

  python3 reproduction/verify_all.py --lean /absolute/path/to/lean --core-only

OPTIONAL RUNTIME COMPATIBILITY

The original restricted runtime needed a small executable-discovery shim,
included as reproduction/proc_self_locator.c. It redirects only the process's
own /proc/PID/exe lookup to /proc/self/exe. The Lean compiler and kernel were
not changed. A normal Linux installation should not need it. If required:

  cc -shared -fPIC reproduction/proc_self_locator.c -ldl -o /tmp/seam_locator.so

Add --compat-shim /tmp/seam_locator.so to the verification commands.

Official Lean release:
  https://github.com/leanprover/lean4/releases/tag/v4.22.0
Official Linux archive SHA-256:
  85097a4d659fe388193a5efb0c413b880e101f1290cc41d00eb60847b18f064e
Lean executable SHA-256:
  cbf5fd536e142ef1beaccf33f788fd8a7f3f29fb214e75c11319a8d8677b4b2b

REBUILD THE DOCUMENT

With pdfLaTeX, the listed standard LaTeX packages, Python and pypdf installed:

  python3 reproduction/build_document.py

The script runs three typesetting passes, verifies cross-references, rejects
overfull boxes and copies the finished PDF to reports/. The document includes
the full standalone Lean core as a typeset appendix. The separate machine-
readable proof files are the authoritative inputs to Lean.

MATHEMATICAL APPLICATIONS

The core theorem excludes the whole decoder class under its stated witness
conditions. The null-case theorem adds explicit global soundness of the
attempt. The exact necessary-refinement result retains the original target.
The Rule 30 applications supply concrete seam witnesses in their stated
domains. Their center-pattern reductions and all-width premises retain their
exact signatures. No open all-width breaking premise is silently treated
as discharged by a readout obstruction.

The manuscript and original application reports distinguish theorem proofs,
conditional reductions and finite computations. Historical large C scans
were not rerun for R8. The complete Lean chains and the stated axiom audits
were freshly checked. R7 preserves its independently reproduced parallax
Python checks and original audit logs.

INTEGRITY AND PROVENANCE

MANIFEST_SHA256.json hashes every distributed payload except itself.
The original source packets retain their own manifests and verification
records. The R8 compilation does not overwrite those versions.

Conceptual programme: Lu Semita / EmergenceByDesign / MetaLabe.
Mathematical exposition, core formal continuation and compilation: ChatGPT.
Prior parallax development: Claude with Lu Semita.
