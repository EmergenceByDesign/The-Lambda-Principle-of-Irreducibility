import LoopTranslation

/-!
The concrete width-13 certificate, checked by ordinary kernel `decide`.
ChatGPT cooperative independent check, 23 October 2026.
Input: Claude's 109 little-endian uint64 keys; phase*8192 + the 13 band bits.
The alternate phase version is derived by shifting phase four places.
No custom axiom, native_decide, or external checker discharges these proofs.
-/
set_option maxRecDepth 100000
set_option maxHeartbeats 20000000

namespace Base109
open UniformWindow ShieldEntry LoopTranslation

def rawKeys : List Nat := [190, 446, 702, 1726, 2750, 3518, 4030, 4286, 4542, 4798, 5822, 6078, 6590, 6846, 7614, 7870, 8126, 8322, 8578, 8834, 9346, 9858, 10882, 11906, 12418, 12674, 12930, 13442, 13954, 14722, 14978, 16002, 16838, 17094, 18118, 19142, 20166, 20422, 20934, 21190, 22214, 22470, 22982, 23238, 24262, 24518, 24682, 25194, 26218, 27242, 28266, 28778, 29290, 30314, 31338, 32362, 32939, 33707, 34731, 35755, 37035, 37803, 38827, 39083, 39851, 40875, 41128, 41384, 42152, 43176, 44456, 45224, 45480, 46248, 47272, 47528, 48296, 49581, 49837, 50349, 51117, 52653, 52909, 53165, 53677, 53933, 54445, 55213, 55725, 55981, 56749, 57261, 57508, 58020, 58532, 59044, 59556, 60068, 61092, 61348, 61604, 62116, 62628, 63140, 63396, 63652, 64164, 65188, 65444]
def phase (k : Nat) : Nat := k / 8192
def bits (k : Nat) : Nat := k % 8192
def shiftedKey (k : Nat) : Nat := ((phase k + 4) % 8) * 8192 + bits k
def keys (a : Bool) : List Nat := if a then rawKeys.map shiftedKey else rawKeys
def decode (k : Nat) : Fin 13 → Bool := fun i => Nat.testBit (bits k) i.val
def value (a : Bool) (f : Nat) : Bool := Nat.testBit (if a then 5 else 80) (f % 8)

def nextKey (k : Nat) (e : Bool) : Nat :=
  ((phase k + 1) % 8) * 8192 +
    ((((bits k <<< 1) + (if col drive (phase k) then 1 else 0)) ^^^
      (bits k ||| ((bits k >>> 1) + (if e then 4096 else 0)))) % 8192)

def TransitionGood (a : Bool) (k : Nat) (e : Bool) : Prop :=
  nextKey k e ∈ keys a ∧
  phase (nextKey k e) = (phase k + 1) % 8 ∧
  ∀ i : Fin 13,
    bandStep 13 (decode k) (col drive (phase k)) e i = decode (nextKey k e) i

def Good (a : Bool) (k : Nat) : Prop :=
  phase k < 8 ∧ decode k ⟨0, by decide⟩ = value a (phase k) ∧
  TransitionGood a k false ∧ TransitionGood a k true

instance (a : Bool) (k : Nat) : Decidable (Good a k) := by
  unfold Good TransitionGood
  infer_instance

/-- Every concrete state and both outgoing bits, in both phase versions. -/
theorem data_checks (a : Bool) :
    (keys a).all (fun k => decide (Good a k)) = true := by
  cases a <;> decide

theorem good_of_mem (a : Bool) (k : Nat) (hk : k ∈ keys a) : Good a k := by
  have h := (List.all_eq_true.mp (data_checks a)) k hk
  exact of_decide_eq_true h

/-- The data are a genuine ShieldEntry.Certificate, not a hypothetical one. -/
def baseCertificate (a : Bool) : Certificate drive 13 8 where
  R := fun f S => ∃ k, k ∈ keys a ∧ f = phase k ∧ S = decode k
  value := value a
  closed := by
    rintro f S ⟨k, hk, rfl, rfl⟩ e
    have h := good_of_mem a k hk
    have ht : TransitionGood a k e := by
      cases e
      · exact h.2.2.1
      · exact h.2.2.2
    obtain ⟨hm, hp, hs⟩ := ht
    refine ⟨nextKey k e, hm, hp.symm, ?_⟩
    exact funext hs
  det := by
    rintro f S _ ⟨k, hk, rfl, rfl⟩
    exact (good_of_mem a k hk).2.1

theorem base_size (a : Bool) : (keys a).length = 109 := by
  cases a <;> decide

theorem base_member (a : Bool) (k : Nat) (hk : k ∈ keys a) :
    (baseCertificate a).R (phase k) (decode k) := ⟨k, hk, rfl, rfl⟩

theorem base_periodic (a : Bool) (f : Nat) :
    (baseCertificate a).value f = (baseCertificate a).value (f % 8) := by
  change value a f = value a (f % 8)
  simp only [value, Nat.mod_mod]

theorem base_pins (a : Bool) :
    (baseCertificate a).value 3 = false ∧ (baseCertificate a).value 7 = false := by
  cases a <;> decide

/-- A finite pattern check with a proved link to the actual certificate. -/
def recognizes (a : Bool) (f : Nat) (S : Fin 13 → Bool) : Bool :=
  (keys a).any fun k => decide (f = phase k ∧ ∀ i, S i = decode k i)

theorem recognizes_iff (a : Bool) (f : Nat) (S : Fin 13 → Bool) :
    recognizes a f S = true ↔ (baseCertificate a).R f S := by
  constructor
  · intro h
    obtain ⟨k, hk, hcheck⟩ := List.any_eq_true.mp h
    have hg : f = phase k ∧ ∀ i, S i = decode k i := of_decide_eq_true hcheck
    exact ⟨k, hk, hg.1, funext hg.2⟩
  · rintro ⟨k, hk, rfl, rfl⟩
    apply List.any_eq_true.mpr
    exact ⟨k, hk, by simp⟩

/-- Existing loop theorem instantiated with the now checked base data. -/
theorem certificates_at_every_loop_width (a : Bool) (L : Nat) :
    ∃ C : Certificate drive (13 + 7 * L) 8,
      (∀ f, C.value f = C.value (f % 8)) ∧ C.value 3 = false ∧ C.value 7 = false :=
  loop_iterate (by decide) (baseCertificate a) (base_periodic a)
    (base_pins a).1 (base_pins a).2 L (13 + 7 * L) rfl

end Base109
