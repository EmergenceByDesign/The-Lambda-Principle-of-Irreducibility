import Base109
import ClosureCheck

/-!
Preserve membership when the loop is prefixed; then certify a finite pattern
recognizer. Existence of wider certificates alone does not identify their R.
This file connects an actual matched band to an actual shield certificate.
-/
namespace LoopMembership
open Rule30Application RightHalf UniformWindow ShieldEntry LoopTranslation Base109

def prefixLoop {J : Nat} (f : Nat) (S : Fin J → Bool) : Fin (J + 7) → Bool :=
  consBand (col L1 f) (consBand (col L2 f) (consBand (col L3 f)
    (consBand (col L3 f) (consBand (col L2 f) (consBand (col L6 f)
      (consBand (col drive f) S))))))

/-- The loop existence result strengthened with the needed membership receipt. -/
theorem loop_step_member {J : Nat} (hJ : 0 < J) (C : Certificate drive J 8)
    (hper : ∀ f, C.value f = C.value (f % 8))
    (h3 : C.value 3 = false) (h7 : C.value 7 = false)
    (f : Nat) (S : Fin J → Bool) (hS : C.R f S) :
    ∃ C' : Certificate drive (J + 7) 8,
      (∀ g, C'.value g = col L1 g) ∧ C'.R f (prefixLoop f S) := by
  let C7 := certCons (w := L6) hJ C (col drive) (fun _ => rfl) (rule_first C hper h3 h7)
  let C6 := certCons (w := L2) (by omega) C7 (col L6) (fun _ => rfl)
    (rule_known L2 L6 drive (by decide) (by decide) (by decide) (by decide))
  let C5 := certCons (w := L3) (by omega) C6 (col L2) (fun _ => rfl)
    (rule_known L3 L2 L6 (by decide) (by decide) (by decide) (by decide))
  let C4 := certCons (w := L3) (by omega) C5 (col L3) (fun _ => rfl)
    (rule_known L3 L3 L2 (by decide) (by decide) (by decide) (by decide))
  let C3 := certCons (w := L2) (by omega) C4 (col L3) (fun _ => rfl)
    (rule_known L2 L3 L3 (by decide) (by decide) (by decide) (by decide))
  let C2 := certCons (w := L1) (by omega) C3 (col L2) (fun _ => rfl)
    (rule_known L1 L2 L3 (by decide) (by decide) (by decide) (by decide))
  let C1 := certCons (w := drive) (by omega) C2 (col L1) (fun _ => rfl)
    (rule_known drive L1 L2 (by decide) (by decide) (by decide) (by decide))
  let S7 := consBand (col drive f) S
  let S6 := consBand (col L6 f) S7
  let S5 := consBand (col L2 f) S6
  let S4 := consBand (col L3 f) S5
  let S3 := consBand (col L3 f) S4
  let S2 := consBand (col L2 f) S3
  have hS7 : C7.R f S7 := ⟨S, hS, rfl⟩
  have hS6 : C6.R f S6 := ⟨S7, hS7, rfl⟩
  have hS5 : C5.R f S5 := ⟨S6, hS6, rfl⟩
  have hS4 : C4.R f S4 := ⟨S5, hS5, rfl⟩
  have hS3 : C3.R f S3 := ⟨S4, hS4, rfl⟩
  have hS2 : C2.R f S2 := ⟨S3, hS3, rfl⟩
  exact ⟨C1, fun _ => rfl, ⟨S2, hS2, rfl⟩⟩

inductive Pattern (a : Bool) (f : Nat) : (J : Nat) → (Fin J → Bool) → Prop
  | base (k : Nat) (hk : k ∈ keys a) (hf : f = phase k) : Pattern a f 13 (decode k)
  | loop {J : Nat} {S : Fin J → Bool} :
      Pattern a f J S → Pattern a f (J + 7) (prefixLoop f S)

theorem pattern_positive {a f J S} (h : Pattern a f J S) : 0 < J := by
  induction h with
  | base => decide
  | loop _ ih => omega

/-- Every finite loop pattern carries a certificate containing that same band. -/
theorem pattern_certificate {a f J S} (h : Pattern a f J S) :
    ∃ C : Certificate drive J 8, C.R f S ∧
      (∀ g, C.value g = C.value (g % 8)) ∧ C.value 3 = false ∧ C.value 7 = false := by
  induction h with
  | base k hk hf =>
    subst hf
    exact ⟨baseCertificate a, base_member a k hk, base_periodic a,
      (base_pins a).1, (base_pins a).2⟩
  | loop h ih =>
    obtain ⟨C, hC, hp, h3, h7⟩ := ih
    obtain ⟨C', hv, hm⟩ := loop_step_member (pattern_positive h) C hp h3 h7 _ _ hC
    refine ⟨C', hm, fun g => ?_, ?_, ?_⟩
    · rw [hv g, hv (g % 8)]; exact L1_pins.1 g
    · rw [hv 3]; exact L1_pins.2.1
    · rw [hv 7]; exact L1_pins.2.2

def loopWidth : Nat → Nat
  | 0 => 13
  | L + 1 => loopWidth L + 7

theorem loopWidth_eq (L : Nat) : loopWidth L = 13 + 7 * L := by
  induction L with
  | zero => rfl
  | succ L ih => simp only [loopWidth, ih]; omega

def loopBand (f k : Nat) : (L : Nat) → (Fin (loopWidth L) → Bool)
  | 0 => decode k
  | L + 1 => prefixLoop f (loopBand f k L)

theorem loopBand_pattern (a : Bool) (f k : Nat) (hk : k ∈ keys a) (hf : f = phase k) :
    ∀ L, Pattern a f (loopWidth L) (loopBand f k L) := by
  intro L
  induction L with
  | zero => exact Pattern.base k hk hf
  | succ L ih => exact Pattern.loop ih

def recognizesLoop (a : Bool) (L f : Nat) (S : Fin (loopWidth L) → Bool) : Bool :=
  (keys a).any fun k => decide (f = phase k ∧ ∀ i, S i = loopBand f k L i)

/-- A successful finite pattern check supplies the missing membership bridge. -/
theorem recognizesLoop_sound (a : Bool) (L f : Nat) (S : Fin (loopWidth L) → Bool)
    (h : recognizesLoop a L f S = true) :
    ∃ C : Certificate drive (loopWidth L) 8, C.R f S := by
  obtain ⟨k, hk, hcheck⟩ := List.any_eq_true.mp h
  have hg : f = phase k ∧ ∀ i, S i = loopBand f k L i := of_decide_eq_true hcheck
  have heq : S = loopBand f k L := funext hg.2
  obtain ⟨C, hm, _⟩ := pattern_certificate (loopBand_pattern a f k hk hg.1 L)
  rw [heq]
  exact ⟨C, hm⟩

/-- End to end, a matched band in the actual driven half-line settles forever. -/
theorem matched_band_settles (a : Bool) (L : Nat) (x0 : Nat → Bool) (t0 : Nat)
    (h : recognizesLoop a L (t0 % 8)
      (bandOf (rhc (pdrive drive) x0) (loopWidth L) t0) = true) :
    EventuallyPeriodic (fun t => rhc (pdrive drive) x0 t 1) := by
  obtain ⟨C, hm⟩ := recognizesLoop_sound a L (t0 % 8) _ h
  have hJ : 0 < loopWidth L := by rw [loopWidth_eq]; omega
  exact shield_periodic drive (loopWidth L) 8 hJ (by decide) (by decide) C x0 t0 hm

/-- The exact period and onset, not merely an unspecified eventual period. -/
theorem matched_band_periodic_from (a : Bool) (L : Nat) (x0 : Nat → Bool) (t0 : Nat)
    (h : recognizesLoop a L (t0 % 8)
      (bandOf (rhc (pdrive drive) x0) (loopWidth L) t0) = true) :
    Rule30Bridge.PeriodicFrom (fun t => rhc (pdrive drive) x0 t 1) t0 8 := by
  obtain ⟨C, hm⟩ := recognizesLoop_sound a L (t0 % 8) _ h
  have hJ : 0 < loopWidth L := by rw [loopWidth_eq]; omega
  intro t ht
  have a := C.det _ _ hJ (shield drive (loopWidth L) 8 (by decide) C x0 t0 hm (t + 8) (by omega))
  have b := C.det _ _ hJ (shield drive (loopWidth L) 8 (by decide) C x0 t0 hm t ht)
  simp only [bandOf] at a b
  show rhc (pdrive drive) x0 (t + 8) 1 = rhc (pdrive drive) x0 t 1
  rw [a, b, Nat.add_mod_right]

/-- A finite zero-tail start constructed from any number of loop blocks. -/
def stackedStart (L : Nat) (i : Nat) : Bool :=
  if h : 1 ≤ i ∧ i ≤ loopWidth L then loopBand 0 190 L ⟨i - 1, by omega⟩ else false

theorem stacked_start_finite (L : Nat) :
    ∀ i, loopWidth L < i → stackedStart L i = false := by
  intro i hi
  unfold stackedStart
  rw [dif_neg (by omega)]

theorem stacked_initial_band (L : Nat) :
    bandOf (rhc (pdrive drive) (stackedStart L)) (loopWidth L) 0 = loopBand 0 190 L := by
  funext i
  simp only [bandOf, rhc, stackedStart]
  rw [dif_pos (by constructor <;> omega)]
  rfl

theorem stacked_pattern_recognized (L : Nat) :
    recognizesLoop false L 0
      (bandOf (rhc (pdrive drive) (stackedStart L)) (loopWidth L) 0) = true := by
  rw [stacked_initial_band]
  apply List.any_eq_true.mpr
  refine ⟨190, by decide, ?_⟩
  simp [phase]

/-- An unconditional infinite family: every stacked start has period 8
from time zero in column 1, with a proved finite-support initial row. -/
theorem stacked_starts_periodic (L : Nat) :
    Rule30Bridge.PeriodicFrom (fun t => rhc (pdrive drive) (stackedStart L) t 1) 0 8 :=
  matched_band_periodic_from false L (stackedStart L) 0 (stacked_pattern_recognized L)

/-- A stronger, executable grammar-entry target; this is not asserted to be
equivalent to arbitrary certificate entry. Both witnesses are explicitly bounded. -/
def LoopEntryBound (f g : Nat → Nat) : Prop :=
  ∀ K (x0 : Nat → Bool), (∀ i, K < i → x0 i = false) →
    ∃ a : Bool, ∃ L t0, t0 ≤ f K ∧ loopWidth L ≤ g K ∧
      recognizesLoop a L (t0 % 8) (bandOf (rhc (pdrive drive) x0) (loopWidth L) t0) = true

theorem boundW_of_loopEntryBound (f g : Nat → Nat) (h : LoopEntryBound f g) :
    ClosureCheck.EntryBoundW drive f g (fun _ => 8) := by
  intro K x0 hK
  obtain ⟨a, L, t0, ht, hg, hm⟩ := h K x0 hK
  obtain ⟨C, hC⟩ := recognizesLoop_sound a L (t0 % 8) _ hm
  have hJ : 0 < loopWidth L := by rw [loopWidth_eq]; omega
  exact ⟨loopWidth L, 8, t0, hJ, hg, by decide, Nat.le_refl _, by decide, ht,
    ClosureCheck.reachDet_of_cert C hC⟩

theorem center_avoids_of_loopEntryBound (f g : Nat → Nat) (h : LoopEntryBound f g) :
    ¬ EventuallyRepeats Rule30Bridge.center30 drive :=
  ClosureCheck.center_avoids_of_boundW drive (by decide) f g (fun _ => 8)
    (boundW_of_loopEntryBound f g h)

end LoopMembership
