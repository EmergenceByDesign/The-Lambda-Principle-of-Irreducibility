import ShieldEntry

/-!
Loop translation, 23 October 2026. Claude, with Lu Semita.

Certificates grow by a fixed block. Putting one periodic column in front of a certificate gives a certificate,
when the new column obeys the rule with the outer drive and the old certificate's column-1 value (`certCons`).
For the drive (1110)* there is a block of seven columns whose last column is the drive itself; prefixing it to
any certificate for (1110)* whose column 1 is 0 at phases 3 and 7 gives a certificate for (1110)* seven columns
wider, again with column 1 zero at phases 3 and 7 (`loop_step`). Iterating gives certificates at every width
J + 7L from one base certificate (`loop_iterate`). The base certificates are finite data checked outside Lean.
-/

namespace LoopTranslation

open UniformWindow ShieldEntry

/-- Put one column in front of a band. -/
def consBand {J : Nat} (a : Bool) (S : Fin J → Bool) : Fin (J + 1) → Bool := fun i =>
  if h : i.val = 0 then a else S ⟨i.val - 1, by omega⟩

theorem bandStep_consBand (J : Nat) (hJ : 0 < J) (a : Bool) (S : Fin J → Bool) (d e : Bool) :
    bandStep (J + 1) (consBand a S) d e = consBand (Bool.xor d (a || S ⟨0, hJ⟩)) (bandStep J S a e) := by
  funext i
  obtain ⟨k, hk⟩ := i
  rcases k with _ | k
  · have h1 : (0 : Nat) + 1 < J + 1 := by omega
    simp only [bandStep, consBand, dite_true, h1]
    rfl
  · have hne' : ¬ (k + 1 = 0) := by omega
    have hne'' : ¬ (k + 1 + 1 = 0) := by omega
    by_cases h2 : k + 1 < J
    · have h3 : k + 1 + 1 < J + 1 := by omega
      simp only [bandStep, consBand, Nat.add_sub_cancel, hne', hne'', h2, h3, dite_false] <;> rfl
    · have h3 : ¬ (k + 1 + 1 < J + 1) := by omega
      simp only [bandStep, consBand, Nat.add_sub_cancel, hne', hne'', h2, h3, dite_false] <;> rfl

/-- One column in front of a certificate. -/
def certCons {w w' : List Bool} {J P : Nat} (hJ : 0 < J) (C : Certificate w' J P) (b : Nat → Bool)
    (hdrive : ∀ f, w'.getD (f % w'.length) false = b f)
    (hcons : ∀ f, b ((f + 1) % P) = Bool.xor (w.getD (f % w.length) false) (b f || C.value f)) :
    Certificate w (J + 1) P where
  R := fun f S' => ∃ S, C.R f S ∧ S' = consBand (b f) S
  closed := by
    rintro f S' ⟨S, hS, rfl⟩ e
    refine ⟨bandStep J S (b f) e, ?_, ?_⟩
    · have h := C.closed f S hS e
      rw [hdrive f] at h
      exact h
    · rw [bandStep_consBand J hJ, C.det f S hJ hS, ← hcons f]
  value := b
  det := by
    rintro f S' _ ⟨S, _, rfl⟩
    rfl

theorem certCons_mem {w w' : List Bool} {J P : Nat} (hJ : 0 < J) (C : Certificate w' J P) (b : Nat → Bool)
    (hdrive : ∀ f, w'.getD (f % w'.length) false = b f)
    (hcons : ∀ f, b ((f + 1) % P) = Bool.xor (w.getD (f % w.length) false) (b f || C.value f))
    (f : Nat) (S : Fin J → Bool) (hS : C.R f S) :
    (certCons (w := w) hJ C b hdrive hcons).R f (consBand (b f) S) := ⟨S, hS, rfl⟩

/-! The (1110)* loop block: absolute phase words, phases 0..7. -/

def drive : List Bool := [true, true, true, false]
def L1 : List Bool := [true, false, true, false, true, false, true, false]
def L2 : List Bool := [true, false, false, true, true, false, false, true]
def L3 : List Bool := [true, false, false, false, true, false, false, false]
def L6 : List Bool := [false, false, true, true, false, false, true, true]

def col (L : List Bool) (f : Nat) : Bool := L.getD (f % L.length) false

theorem col_mod8 (L : List Bool) (hL : L.length ∣ 8) (f : Nat) : col L f = col L (f % 8) := by
  unfold col
  rw [Nat.mod_mod_of_dvd f hL]

theorem succ_mod8 (f : Nat) : (f + 1) % 8 = (f % 8 + 1) % 8 := by
  omega

/-- The rule for a block column whose right neighbour is a known column. -/
theorem rule_known (Lo Lm Lr : List Bool) (ho : Lo.length ∣ 8) (hm : Lm.length ∣ 8) (hr : Lr.length ∣ 8)
    (h : ∀ g, g < 8 → col Lm ((g + 1) % 8) = Bool.xor (col Lo g) (col Lm g || col Lr g)) :
    ∀ f, col Lm ((f + 1) % 8) = Bool.xor (col Lo f) (col Lm f || col Lr f) := by
  intro f
  rw [succ_mod8, col_mod8 Lo ho f, col_mod8 Lm hm f, col_mod8 Lr hr f]
  exact h _ (Nat.mod_lt _ (by decide))

/-- The first prefix step: column 7 of the block is the drive itself, and the certificate's column-1 value is
read only where the drive is 0 (phases 3 and 7). -/
theorem rule_first {J : Nat} (C : Certificate drive J 8) (hper : ∀ f, C.value f = C.value (f % 8))
    (h3 : C.value 3 = false) (h7 : C.value 7 = false) :
    ∀ f, col drive ((f + 1) % 8) = Bool.xor (L6.getD (f % L6.length) false) (col drive f || C.value f) := by
  intro f
  have key : ∀ g, g < 8 → ∀ v : Bool, (g = 3 → v = false) → (g = 7 → v = false) →
      col drive ((g + 1) % 8) = Bool.xor (col L6 g) (col drive g || v) := by decide
  show col drive ((f + 1) % 8) = Bool.xor (col L6 f) (col drive f || C.value f)
  rw [succ_mod8, col_mod8 drive (by decide) f, col_mod8 L6 (by decide) f, hper f]
  exact key (f % 8) (Nat.mod_lt _ (by decide)) (C.value (f % 8))
    (fun h => by rw [h]; exact h3) (fun h => by rw [h]; exact h7)

/-- One loop: certificates for (1110)* gain seven columns. -/
theorem loop_step {J K : Nat} (hK : K = J + 7) (hJ : 0 < J) (C : Certificate drive J 8)
    (hper : ∀ f, C.value f = C.value (f % 8)) (h3 : C.value 3 = false) (h7 : C.value 7 = false) :
    ∃ C' : Certificate drive K 8, (∀ f, C'.value f = col L1 f) := by
  subst hK
  have hc7 := rule_first C hper h3 h7
  -- columns, from the right: b7 = drive, b6 = L6, b5 = L2, b4 = L3, b3 = L3, b2 = L2, b1 = L1
  let C7 := certCons (w := L6) hJ C (col drive) (fun f => rfl) hc7
  let C6 := certCons (w := L2) (by omega) C7 (col L6) (fun f => rfl)
    (rule_known L2 L6 drive (by decide) (by decide) (by decide) (by decide))
  let C5 := certCons (w := L3) (by omega) C6 (col L2) (fun f => rfl)
    (rule_known L3 L2 L6 (by decide) (by decide) (by decide) (by decide))
  let C4 := certCons (w := L3) (by omega) C5 (col L3) (fun f => rfl)
    (rule_known L3 L3 L2 (by decide) (by decide) (by decide) (by decide))
  let C3 := certCons (w := L2) (by omega) C4 (col L3) (fun f => rfl)
    (rule_known L2 L3 L3 (by decide) (by decide) (by decide) (by decide))
  let C2 := certCons (w := L1) (by omega) C3 (col L2) (fun f => rfl)
    (rule_known L1 L2 L3 (by decide) (by decide) (by decide) (by decide))
  let C1 := certCons (w := drive) (by omega) C2 (col L1) (fun f => rfl)
    (rule_known drive L1 L2 (by decide) (by decide) (by decide) (by decide))
  exact ⟨C1, fun f => rfl⟩

/-- Column 1 of the new certificate is again zero at phases 3 and 7, so loops can be stacked. -/
theorem L1_pins : (∀ f, col L1 f = col L1 (f % 8)) ∧ col L1 3 = false ∧ col L1 7 = false :=
  ⟨fun f => col_mod8 L1 (by decide) f, by decide, by decide⟩

/-- Certificates for (1110)* at every width J + 7L, from one base certificate whose column 1 is zero at
phases 3 and 7. -/
theorem loop_iterate {J : Nat} (hJ : 0 < J) (C : Certificate drive J 8)
    (hper : ∀ f, C.value f = C.value (f % 8)) (h3 : C.value 3 = false) (h7 : C.value 7 = false) :
    ∀ L K, K = J + 7 * L → ∃ C' : Certificate drive K 8,
      (∀ f, C'.value f = C'.value (f % 8)) ∧ C'.value 3 = false ∧ C'.value 7 = false := by
  intro L
  induction L with
  | zero =>
    intro K hK
    subst hK
    exact ⟨C, hper, h3, h7⟩
  | succ L ih =>
    intro K hK
    obtain ⟨C', hper', h3', h7'⟩ := ih (J + 7 * L) rfl
    obtain ⟨C'', hv⟩ := loop_step (J := J + 7 * L) (K := K) (by rw [hK]; omega) (by omega) C' hper' h3' h7'
    refine ⟨C'', fun f => ?_, ?_, ?_⟩
    · rw [hv f, hv (f % 8)]
      exact L1_pins.1 f
    · rw [hv 3]; exact L1_pins.2.1
    · rw [hv 7]; exact L1_pins.2.2

/-! The (1000)* drive is the loop word L3 with the same phases, so its bands are the loop's last columns in
front of (1110)* bands: three columns for column-1 word L2 (10011001), four for L3 (10001000). -/

def driveA : List Bool := [true, false, false, false]

theorem family_1000 {J : Nat} (hJ : 0 < J) (C : Certificate drive J 8)
    (hper : ∀ f, C.value f = C.value (f % 8)) (h3 : C.value 3 = false) (h7 : C.value 7 = false) (L : Nat) :
    (∃ C' : Certificate driveA (J + 7 * L + 3) 8, ∀ f, C'.value f = col L2 f) ∧
    (∃ C' : Certificate driveA (J + 7 * L + 4) 8, ∀ f, C'.value f = col L3 f) := by
  obtain ⟨C0, hper0, h30, h70⟩ := loop_iterate hJ C hper h3 h7 L (J + 7 * L) rfl
  have hJ0 : 0 < J + 7 * L := by omega
  let D7 := certCons (w := L6) hJ0 C0 (col drive) (fun f => rfl) (rule_first C0 hper0 h30 h70)
  let D6 := certCons (w := L2) (by omega) D7 (col L6) (fun f => rfl)
    (rule_known L2 L6 drive (by decide) (by decide) (by decide) (by decide))
  refine ⟨⟨certCons (w := driveA) (by omega) D6 (col L2) (fun f => rfl)
      (rule_known driveA L2 L6 (by decide) (by decide) (by decide) (by decide)), fun f => rfl⟩, ?_⟩
  let D5 := certCons (w := L3) (by omega) D6 (col L2) (fun f => rfl)
    (rule_known L3 L2 L6 (by decide) (by decide) (by decide) (by decide))
  exact ⟨certCons (w := driveA) (by omega) D5 (col L3) (fun f => rfl)
    (rule_known driveA L3 L2 (by decide) (by decide) (by decide) (by decide)), fun f => rfl⟩

end LoopTranslation
