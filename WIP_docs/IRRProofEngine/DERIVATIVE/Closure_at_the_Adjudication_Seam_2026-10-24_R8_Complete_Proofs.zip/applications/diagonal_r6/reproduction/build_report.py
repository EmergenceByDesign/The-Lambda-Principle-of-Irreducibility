#!/usr/bin/env python3
"""Build the R6 diagonal / recovery structural-bridge report."""
from pathlib import Path
from io import BytesIO
import hashlib, html, json, re
from PIL import Image as PILImage
import matplotlib
matplotlib.use('Agg')
from matplotlib.mathtext import math_to_image
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, PageBreak,
                               Table, TableStyle, Flowable, KeepTogether, Image)

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'reports'
OUT.mkdir(exist_ok=True)
receipt = json.loads((ROOT / 'receipts/certificate.json').read_text())
COUNT = receipt['new_theorem_count']
FONT = Path('/usr/share/fonts/truetype/dejavu')
for name, filename in [('Sans', 'DejaVuSans.ttf'), ('SansB', 'DejaVuSans-Bold.ttf'),
                       ('Serif', 'DejaVuSerif.ttf'), ('SerifB', 'DejaVuSerif-Bold.ttf'),
                       ('Mono', 'DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FONT / filename)))
pdfmetrics.registerFontFamily('Sans', normal='Sans', bold='SansB', italic='Sans', boldItalic='SansB')
pdfmetrics.registerFontFamily('Serif', normal='Serif', bold='SerifB', italic='Serif', boldItalic='SerifB')
INK = colors.HexColor('#182738')
BLUE = colors.HexColor('#165d83')
MUTED = colors.HexColor('#566575')
LIGHT = colors.HexColor('#edf4f8')
LINE = colors.HexColor('#cbd8e2')
AMBER = colors.HexColor('#a05c1b')
W, H = 595.28, 841.89
WIDTH = W - 88
STYLES = {
    'title': ParagraphStyle('title', fontName='SerifB', fontSize=23, leading=28,
                            textColor=INK, spaceAfter=13),
    'subtitle': ParagraphStyle('subtitle', fontName='Sans', fontSize=11, leading=15,
                               textColor=MUTED, spaceAfter=13),
    'h': ParagraphStyle('h', fontName='SansB', fontSize=14, leading=18,
                        textColor=BLUE, spaceBefore=8, spaceAfter=10),
    'sub': ParagraphStyle('sub', fontName='SansB', fontSize=10.5, leading=14,
                          textColor=INK, spaceBefore=7, spaceAfter=5),
    'p': ParagraphStyle('p', fontName='Serif', fontSize=9.65, leading=13.5,
                        textColor=INK, spaceAfter=8),
    'small': ParagraphStyle('small', fontName='Sans', fontSize=8.0, leading=11.0,
                            textColor=MUTED, spaceAfter=6),
    'cell': ParagraphStyle('cell', fontName='Sans', fontSize=8.05, leading=10.8,
                           textColor=INK),
    'head': ParagraphStyle('head', fontName='SansB', fontSize=8.0, leading=10.8,
                           textColor=colors.white),
    'code': ParagraphStyle('code', fontName='Mono', fontSize=7.1, leading=10,
                           textColor=MUTED, spaceAfter=8),
}
STORY = []
PLAIN = []

def para(text, style='p'):
    STORY.append(Paragraph(text, STYLES[style]))
    PLAIN.append(html.unescape(re.sub('<[^>]+>', '', text)))

def heading(text):
    para(text, 'h')

def sub(text):
    para(text, 'sub')

def page():
    STORY.append(PageBreak())
    PLAIN.append('\n' + '=' * 72 + '\n')

class Equation(Flowable):
    def __init__(self, tex, max_width=WIDTH, max_height=44):
        super().__init__()
        tex = tex.replace(r'\lor', r'\vee').replace(r'\land', r'\wedge')
        buffer = BytesIO()
        dpi = 360
        math_to_image('$' + tex + '$', buffer, dpi=dpi, format='png', color='#182738')
        buffer.seek(0)
        pixels = PILImage.open(buffer).size
        native_width, native_height = pixels[0] * 72 / dpi, pixels[1] * 72 / dpi
        scale = min(1.0, max_width / native_width, max_height / native_height)
        self.width = native_width * scale
        self.image_height = native_height * scale
        self.height = self.image_height + 10
        buffer.seek(0)
        self.image = Image(buffer, width=self.width, height=self.image_height)
    def draw(self):
        self.image.drawOn(self.canv, max(0, (WIDTH-self.width)/2), 5)

def eq(tex):
    STORY.append(Equation(tex))
    PLAIN.append('MATH: ' + tex)

def table(headers, rows, widths):
    contents = [[Paragraph(html.escape(v), STYLES['head']) for v in headers]]
    contents += [[Paragraph(v, STYLES['cell']) for v in row] for row in rows]
    t = Table(contents, colWidths=widths, hAlign='LEFT')
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), BLUE), ('VALIGN',(0,0),(-1,-1),'TOP'),
        ('LEFTPADDING',(0,0),(-1,-1),8), ('RIGHTPADDING',(0,0),(-1,-1),8),
        ('TOPPADDING',(0,0),(-1,-1),8), ('BOTTOMPADDING',(0,0),(-1,-1),8),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[LIGHT, colors.white]),
        ('LINEBELOW',(0,0),(-1,0),0.6,BLUE),
        ('LINEBELOW',(0,1),(-1,-1),0.4,LINE),
    ]))
    STORY.append(t)
    STORY.append(Spacer(1,9))
    PLAIN.append(' | '.join(headers))
    for row in rows:
        PLAIN.append(' | '.join(html.unescape(re.sub('<[^>]+>', '', v)) for v in row))

assert COUNT == 24
assert len(receipt['stages']) == 19

para('From recurring structure<br/>to a checked bridge', 'title')
para('Diagonalization, formal adjudication and the existing recovery seam.<br/>'
     'ChatGPT cooperative continuation | 23 October 2026 | R6', 'subtitle')
heading('The connection is now a construction')
para('The recurring structure can be identified by a theorem, rather than left as a request '
     'for another analogy. This continuation constructs a semantic Godel sentence from explicit '
     'quotation and substitution receipts, then turns it into the <b>same SeamCertificate type</b> '
     'already used for the Rule 30 recovery obstruction.')
para('The stronger version retains both proof and disproof status. A sentence G and its '
     'negation receive the same status from that readout while their interpreted truth values '
     'differ. The existing seam theorem therefore rules out every decoder of that status, '
     'and the existing ladder theorem forces any adequate added coordinate to distinguish them.')
eq(r'O_{\pm}(s)=(P(s),P(Ns)),\qquad O_{\pm}(G)=O_{\pm}(NG).')
eq(r'H(G)\ne H(NG)\quad\Longrightarrow\quad\neg\mathrm{Recovers}(O_{\pm},H).')
table(['Construction', 'What is checked'], [
    ('Diagonal core', 'The set/function form of Lawvere\'s fixed-point argument, plus a direct bridge to Recovers.'),
    ('Quotation to semantic self-reference', 'The sentence is explicitly constructed. Its self-referential meaning follows from the supplied coding and interpretation receipts.'),
    ('Semantic self-reference to a seam', 'Local soundness and the stated logical receipts yield ordinary and signed provability seams.'),
    ('Required ladder step', 'Every adequate refinement must split the same certified pair. The existing proof is reused unchanged.'),
], [WIDTH*.30, WIDTH*.70])
para('<b>24 new Lean theorems</b> and 34 named declarations are audited. All 19 modules compile '
     'with official Lean 4.22.0 at trust level 0, with zero errors or warnings. The new declarations '
     'use no custom axioms, sorryAx or Classical.choice.', 'small')
para('The interpretation H is declared throughout. The bridge does not obtain a position '
     'outside its own interpretive conditions by calling H truth. The positive claim is a checked '
     'structural connection between formal self-reference and recovery failure.', 'small')

page()
heading('1. One diagonal construction, two consequences')
para('Let E(c,x) be a family of readings indexed by code c. Let v transform output values '
     'without fixing any value. Define the diagonal target:')
eq(r'E:A\times A\to B,\qquad v:B\to B,\qquad \forall b,\ v(b)\ne b.')
eq(r'\Delta(x)=v(E(x,x)).')
para('No represented row E(c,-) equals this target everywhere: at its own code c, that '
     'equality would require E(c,c) = v(E(c,c)), contradicting the stated property of v. '
     'Equivalently, if the rows represent every function A to B, then every transformation '
     'of B must have a fixed point. This is the set/function specialization of Lawvere\'s '
     'argument [1].')
sub('A direct bridge to the recovery definition')
para('Suppose the rows include every decoder applied after a particular readout O. '
     'This is the explicit RepresentsAfter hypothesis:')
eq(r'\forall D:Y\to B,\quad\exists c,\quad\forall x,\ E(c,x)=D(O(x)).')
para('If a decoder recovered the diagonal target, its represented row would equal that '
     'target, which the preceding construction forbids. Lean checks the resulting implication:')
eq(r'\mathrm{RepresentsAfter}(O,E)\ \wedge\ (\forall b,\ v(b)\ne b)')
eq(r'\Longrightarrow\quad\neg\mathrm{Recovers}(O,\Delta).')
para('The representation premise is a genuine condition on E and O. It is not asserted '
     'for every arbitrary family of readings.', 'small')
sub('A fully instantiated finite example')
para('Take A = B = Bool, O(x) = unit, E(c,x) = c and v = Boolean negation. Every decoder '
     'of the unit readout is a constant row, so the representation premise is proved.')
table(['Input x', 'O(x)', 'E(0,x)', 'E(1,x)', 'Diagonal target'], [
    ('0', 'unit', '0', '1', '1'), ('1', 'unit', '0', '1', '0'),
], [WIDTH*.16, WIDTH*.18, WIDTH*.21, WIDTH*.21, WIDTH*.24])
para('Both inputs share the readout but require unequal target values. The finite '
     'diagonal argument thus instantiates an actual recovery obstruction.', 'small')
para('Receipts: point_surjection_forces_fixed_point; represented_decoders_cannot_recover_diagonal; '
     'constant_boolean_rows_represent_unit_decoders; finite_diagonal_instance.', 'code')

page()
heading('2. Constructing the Godel sentence from receipts')
para('The interface DiagonalInterpretation names sentences S, unary formulas U, and codes C. '
     'Let qS and qU quote sentences and unary formulas; I(u,c) instantiate a unary formula '
     'at a code; H interpret sentences; M interpret unary formulas; P mean provability; '
     'and Pc mean provability of a sentence named by its code. Each is an explicit input.')
sub('The four coding and interpretation receipts')
eq(r'H(I(u,c))\ \longleftrightarrow\ M(u,c).')
eq(r'd(q_U(u))=q_S(I(u,q_U(u))).')
eq(r'P_c(q_S(s))\ \longleftrightarrow\ P(s).')
eq(r'M(A,c)\ \longleftrightarrow\ \neg P_c(d(c)).')
para('Here d codes diagonal substitution, and A is a unary formula representing the '
     'negated provability of that substitution. The interface therefore records the exact '
     'representation work used by the construction. Coding syntax and substitution, and '
     'relating them to provability, are explicit stages in machine-checked Godel developments [2,3].')
sub('The sentence is then built, not postulated')
eq(r'G=I(A,q_U(A)).')
eq(r'H(G)\ \longleftrightarrow\ \neg P(G).')
para('The equivalence follows by applying the four receipts in order. The declaration '
     'constructed_sentence_has_diagonal_meaning checks those substitutions. This is a semantic '
     'bridge interface; it does not itself prove that a named arithmetic theory implements '
     'all four receipts.', 'small')
sub('From that equivalence to the ordinary recovery seam')
para('Add local soundness P(G) implies H(G). If P(G) held, soundness and the equivalence '
     'would yield its negation. Hence not P(G), and then H(G). For a falsum with neither '
     'P(falsum) nor H(falsum), G and falsum share the unprovable status but differ in H.')
eq(r'P(G)=P(\bot),\qquad H(G)\ne H(\bot).')
para('godelProvabilitySeam constructs the existing SeamCertificate from these witnesses. '
     'quotation_to_recovery_obstruction composes the coding construction with that seam '
     'and the earlier no-decoder theorem. No new obstruction definition is introduced.', 'small')

page()
heading('3. Retaining both proof and disproof')
para('A readout can register both whether a sentence has a proof and whether its negation '
     'has a proof. Use N for formal negation:')
eq(r'O_{\pm}(s)=(P(s),P(Ns)).')
para('In addition to the preceding diagonal meaning and local soundness at G, supply: '
     '(i) H(NG) if and only if not H(G); (ii) local soundness at NG; and '
     '(iii) proof-level double-negation elimination at G, P(NNG) implies P(G). '
     'These are explicit receipts, not a silent change of logic.')
para('The truth of G rules out a proof of NG by local soundness. A proof of NNG would '
     'yield the already excluded proof of G. Thus the two sentences have the following '
     'statuses, where the truth column uses the declared H:')
table(['Sentence', 'Provable', 'Negation provable', 'Holds under H'], [
    ('G', 'No', 'No', 'Yes'),
    ('NG', 'No', 'No', 'No'),
], [WIDTH*.18, WIDTH*.23, WIDTH*.30, WIDTH*.29])
eq(r'O_{\pm}(G)=O_{\pm}(NG),\qquad H(G)\ne H(NG).')
para('<b>godelSignedProofSeam</b> constructs a SeamCertificate with left = G and right = NG. '
     'The entire proof/refutation status readout collapses a distinction required by H. '
     'signed_proof_status_cannot_recover_truth applies the existing no-decoder theorem.')
sub('The existing ladder theorem applies without modification')
para('If an added coordinate C makes the joint readout adequate, it must distinguish '
     'these very witnesses:')
eq(r'\mathrm{Recovers}((O_{\pm},C),H)\quad\Longrightarrow\quad C(G)\ne C(NG).')
para('This is adequate_signed_refinement_must_split. It supplies a literal connection '
     'to the recovery ladder: the same object, the same obstruction theorem, and the '
     'same required splitting condition.')
para('The proof-status predicates describe actual derivability, not failure of a finite '
     'search to find a proof. No executable decision procedure for these predicates is '
     'asserted. Adding a target as a coordinate formally recovers that target but does not '
     'supply a method for computing it or a proof in the unchanged original theory.', 'small')

page()
heading('4. The exact connection to the Rule 30 work')
para('R5 already constructs actualPrefixSeam for every width J in the white-boundary '
     'Rule 30 half-line. R6 constructs a proof-status seam from quotation, interpretation '
     'and soundness receipts. Both inhabit the identical existing type:')
eq(r'\mathrm{SeamCertificate}(O,T).')
table(['Field', 'Signed Godel instance', 'Actual Rule 30 instance'], [
    ('Domain', 'Sentences in the declared interpretation', 'Finite initial half-lines'),
    ('Readout O', 'Proof and refutation status', 'First J initial cells'),
    ('Target T', 'Interpretation H of the sentence', 'Entire column-1 time trace'),
    ('Witnesses', 'G and NG', 'All white; one black cell at J+1'),
    ('Same reading', 'Both have neither proof nor refutation', 'The first J cells are all white'),
    ('Required distinction', 'H(G) differs from H(NG)', 'Column 1 differs at time J'),
], [WIDTH*.19, WIDTH*.405, WIDTH*.405])
para('The Rule 30 witnesses are proved for every J in the white-boundary driven model. '
     'The Godel witnesses follow from the explicitly named receipts above. These are '
     'different instantiations of the same recovery structure, with a checked route from '
     'formal self-reference into that structure.')
sub('What the structural identification now earns')
para('Within Lambda\'s terminology, the cut is the target-relevant distinction lost by '
     'the readout. The construction identifies that cut in each instance. It proves both '
     'the failure of every decoder of the coarse reading and the necessary distinction '
     'in any adequate refinement. Recognition of a shared structure is supported here '
     'by explicit witnesses and type-correct constructions.')
para('This does not transfer the unprovability of a Godel sentence to EntryBoundW. '
     'A Rule 30 independence claim still requires a specified theory and an argument '
     'about that particular predicate. R6 supplies the structural bridge to recovery; '
     'R5 retains the positive certificate-or-residue route for the dynamical problem.', 'small')
sub('Verification and provenance')
para('24 new theorems; 34 audited named declarations; 19 rebuilt source modules; Lean '
     '4.22.0, trust level 0; zero errors and warnings. New axiom reports use at most '
     'propext and Quot.sound. All 18 antecedent sources and the full R5 packet are '
     'preserved unchanged. No priority claim is made for the diagonal or Godel arguments.', 'small')
para('[1] <link href="https://tac.mta.ca/tac/reprints/articles/15/tr15.pdf" color="#165d83">'
     'Lawvere, Diagonal arguments and cartesian closed categories (1969; 2006 reprint).</link><br/>'
     '[2] <link href="https://www.cl.cam.ac.uk/~lp15/papers/Formath/Goedel-logic.pdf" color="#165d83">'
     'Paulson, A machine-assisted proof of Godel\'s incompleteness theorems (2014).</link><br/>'
     '[3] <link href="https://isa-afp.org/entries/Incompleteness.html" color="#165d83">'
     'Paulson et al., Godel\'s Incompleteness Theorems, Archive of Formal Proofs.</link>', 'small')
para('Conceptual programme: Lu Semita / EmergenceByDesign / MetaLabe. This cooperative '
     'structural analysis and formal continuation were developed with ChatGPT.', 'small')

def decorate(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(LINE)
    canvas.setLineWidth(.5)
    canvas.line(44,H-34,W-44,H-34)
    canvas.line(44,35,W-44,35)
    canvas.setFillColor(MUTED)
    canvas.setFont('Sans',7)
    canvas.drawString(44,H-25,'EMERGENCEBYDESIGN / METALABE')
    canvas.drawRightString(W-44,H-25,'DIAGONAL / RECOVERY BRIDGE | R6')
    canvas.drawString(44,23,'23 October 2026 | explicit construction and scoped receipts')
    canvas.drawRightString(W-44,23,str(doc.page))
    canvas.restoreState()

pdf = OUT / 'Rule30_ChatGPT_Diagonal_Seam_Bridge_2026-10-23_R6.pdf'
document = SimpleDocTemplate(str(pdf), pagesize=(W,H), leftMargin=44, rightMargin=44,
                             topMargin=48, bottomMargin=48,
                             title='From recurring structure to a checked bridge - R6',
                             author='EmergenceByDesign / MetaLabe with ChatGPT')
document.build(STORY,onFirstPage=decorate,onLaterPages=decorate)
(ROOT / 'MANUSCRIPT.txt').write_text('\n\n'.join(PLAIN)+'\n')
print(pdf)

