#!/usr/bin/env python3
"""Rebuild the 19-module chain and audit the R6 diagonal/recovery bridge."""
from pathlib import Path
import argparse, hashlib, json, os, re, subprocess
from datetime import datetime, timezone

p = argparse.ArgumentParser()
p.add_argument('--lean', required=True, type=Path)
p.add_argument('--compat-shim', type=Path)
a = p.parse_args()
root = Path(__file__).resolve().parents[1]
receipts = root / 'receipts'
build = receipts / 'build'
logs = receipts / 'logs'
build.mkdir(parents=True, exist_ok=True)
logs.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
env['LEAN_PATH'] = str(build)
if a.compat_shim:
    env['LD_PRELOAD'] = str(a.compat_shim.resolve())
exe = str(a.lean.resolve())
version = subprocess.run([exe, '--version'], env=env, capture_output=True,
                         text=True, check=True).stdout.strip()
modules = ['SeamClosure', 'Rule30Application', 'Rule30Bridge', 'BlackValueBridge',
           'DrivenLeft', 'RightHalf', 'UniformWindow', 'ShieldEntry',
           'LoopTranslation', 'EntryBridge', 'ClosureCheck', 'Base109',
           'LoopMembership', 'SeamIntegration', 'Rule30Seam', 'SeamClosureConditions', 'CertificateResidueBridge', 'Rule30WhiteBoundary', 'DiagonalSeamBridge']
stages = []
for module in modules:
    result = subprocess.run([exe, '--trust=0', '--json', '-o',
                             str(build / (module + '.olean')),
                             str(root / 'lean' / (module + '.lean'))],
                            env=env, capture_output=True, text=True)
    (logs / (module + '.stdout')).write_text(result.stdout)
    (logs / (module + '.stderr')).write_text(result.stderr)
    messages = [json.loads(line) for line in result.stdout.splitlines()
                if line.startswith('{')]
    record = {'module': module, 'exit_code': result.returncode,
              'errors': sum(m['severity'] == 'error' for m in messages),
              'warnings': sum(m['severity'] == 'warning' for m in messages)}
    stages.append(record)
    print(json.dumps(record), flush=True)
    if result.returncode or record['errors'] or record['warnings']:
        print(result.stdout, result.stderr, flush=True)
        raise SystemExit(1)
names = []
theorems = []
for module in ['DiagonalSeamBridge']:
    source = (root / 'lean' / (module + '.lean')).read_text()
    for kind, name in re.findall(r'^(theorem|def|structure)\s+([A-Za-z0-9_]+)', source, re.M):
        names.append(module + '.' + name)
        if kind == 'theorem':
            theorems.append(module + '.' + name)
audit = receipts / 'Audit.lean'
audit.write_text('import DiagonalSeamBridge\n' + ''.join(
    '#check ' + name + '\n#print axioms ' + name + '\n' for name in names))
result = subprocess.run([exe, '--trust=0', '--json', str(audit)],
                        env=env, capture_output=True, text=True)
(logs / 'audit.stdout').write_text(result.stdout)
(logs / 'audit.stderr').write_text(result.stderr)
messages = [json.loads(line) for line in result.stdout.splitlines()
            if line.startswith('{')]
assert result.returncode == 0 and len(messages) == 2 * len(names)
assert all(m['severity'] == 'information' for m in messages)
axioms = [m['data'] for m in messages if 'axiom' in m['data']]
assert len(axioms) == len(names)
assert all('Classical.choice' not in s and 'sorryAx' not in s for s in axioms)
for module in ['DiagonalSeamBridge']:
    source = (root / 'lean' / (module + '.lean')).read_text()
    assert not re.search(r'^\s*(?:axiom|constant|opaque)\s', source, re.M)
    assert not re.search(r'\b(?:sorry|admit|native_decide)\b', source)
receipt = {
    'verified_at_utc': datetime.now(timezone.utc).isoformat(),
    'lean_version': version, 'trust_level': 0, 'stages': stages,
    'new_theorem_count': len(theorems), 'new_theorems': theorems,
    'audited_declarations': names, 'axiom_reports': axioms,
    'new_results_use_Classical_choice': False,
    'source_hashes': {module + '.lean': hashlib.sha256(
        (root / 'lean' / (module + '.lean')).read_bytes()).hexdigest()
        for module in modules},
    'scope': 'Set/function diagonal core and a quotation-to-recovery bridge. '
             'Local soundness and logical receipts yield ordinary and signed '
             'provability SeamCertificates. A named arithmetic theory and '
             'the open Rule30 entry predicate are not instantiated here.'}
(receipts / 'certificate.json').write_text(json.dumps(receipt, indent=2) + '\n')
(receipts / 'statements_and_axioms.txt').write_text('\n\n'.join(
    m['data'] for m in messages) + '\n')
print('AUDIT PASSED:', len(theorems), 'new theorems;', len(names),
      'audited declarations', flush=True)
