FINITE WINDOW / FINITE-SUPPORT SEAM -- R7
ChatGPT cooperative review and continuation, 24 October 2026

This supplement reviews the uploaded Parallax at the center report and extends
its actual Rule 30 half-line definitions. The uploaded files are preserved
unchanged in antecedents/. All their Lean files are copied unchanged in lean/.
The new module is FiniteWindowSeam.lean.

NEW RESULTS

22 theorems and 33 named declarations, checked with Lean 4.22.0 at trust level 0:

* Every desired left-trace prefix of length K has an explicit finite start of
  support at most K, produced by K reconstruction steps.
* The maps between K-bit start prefixes and K-bit trace prefixes are inverses.
* At a black pin t < K, toggling initial cell t+1 is an involution preserving
  width and all earlier pin tests, and exactly one member of each pair breaks
  at t. This is the exact pairing behind halving before the support edge.
* For every word and every finite horizon T, a finite pair of starts satisfies
  the center rule throughout that horizon. The pair may depend on T.
* There is no width-independent time cap that makes every finite pair break.
  Every valid one-sided bound g must satisfy g(K) >= K.
* A finite truncation of the actual seven-cell ring and the infinite ring
  start form a SeamCertificate for finite-support status at every fixed
  finite initial prefix and every fixed finite left-trace window.
* Each fixed positive coordinate of the truncations eventually equals that
  coordinate of the infinite ring; each truncation is finite, the ring is not.

The displayed survivor-count formula in the report is an ordinary finite-
counting corollary of the checked inverse maps and pairing. It is not itself
a separate cardinality theorem in the Lean source.

EXACT SCOPE

The support-status seam is on a domain containing both finite and infinite
starts. Finite support is given in the original problem; the seam does not
remove that initial-condition information. It shows what a fixed finite
readout alone cannot establish on the enlarged domain.

The finite-window result has quantifiers: for every horizon there exists a
finite start pair surviving that horizon. It neither constructs a single
finite pair surviving forever nor refutes the all-finite-start eventual-break
conjecture. These are arbitrary starts in the auxiliary driven model, not
asserted restarts of the actual single-black-seed orbit.
No proof of AdmittedPattern or the full Rule 30 prize claim is
asserted. The width-dependent candidate bound remains unproved.

VERIFICATION

The complete 22-module source chain is rebuilt by reproduction/verify.py.
There are zero compiler errors or warnings. The new axiom reports use at
most propext and Quot.sound, and no custom axioms, sorryAx or Classical.choice.

The supplied 21-module build and 94-declaration audit were independently
reproduced with identical audit outputs. All shipped Python checks reproduced
their logs. The large historical C searches were not rerun.

receipts/certificate.json lists the new theorem names, exact source hashes,
input hashes and axiom reports. receipts/statements_and_axioms.txt includes
the exact checked signatures. receipts/parallax_reruns/ preserves the fresh
reproduced audit and Python-check logs.

REPRODUCTION

Install official Lean 4.22.0, then from the extracted packet run:

  python3 reproduction/verify.py --lean /absolute/path/to/lean-4.22.0-linux/bin/lean

This needs only Lean's bundled libraries, with no Mathlib download. Compiled
.olean files are excluded from the distribution so they are rebuilt.

The original restricted runtime needed the optional readlink compatibility
shim in reproduction/proc_self_locator.c, redirecting only its own
/proc/PID/exe lookup to /proc/self/exe. Lean and its kernel were unchanged.
If the same restriction occurs, build it as a shared library and pass
--compat-shim /absolute/path/to/the/library.so to verify.py.

Official archive SHA-256:
  85097a4d659fe388193a5efb0c413b880e101f1290cc41d00eb60847b18f064e
Lean executable SHA-256:
  cbf5fd536e142ef1beaccf33f788fd8a7f3f29fb214e75c11319a8d8677b4b2b
Release:
  https://github.com/leanprover/lean4/releases/tag/v4.22.0

The four-page PDF can be rebuilt with Python ReportLab, Matplotlib, Pillow,
and DejaVu fonts at /usr/share/fonts/truetype/dejavu:

  python3 reproduction/build_report.py

MANUSCRIPT.txt retains the editable prose and TeX equations.
MANIFEST_SHA256.json hashes every distributed payload except itself.

PROVENANCE

Parallax report and supplement: Claude with Lu Semita.
Conceptual programme: Lu Semita / EmergenceByDesign / MetaLabe.
New review, derivation and formal continuation: ChatGPT.
