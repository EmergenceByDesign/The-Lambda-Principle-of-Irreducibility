import LoopTranslation

/-!
The width-13 base certificate, 23 October 2026. Claude, with Lu Semita.

Every certificate found so far for the drive (1110)* consists of loop blocks in front of one small certificate:
109 states of width 13, in two phase versions. This file holds the 109 states as data and checks inside Lean, by
`decide`, that they form a certificate: the set is closed under the band step for both edge bits, and column 1 is
the word 00001010 of the phase. The check is a kernel computation on the data written below; nothing is imported
from outside the file. `certShift` moves any certificate along the phase; `base4` is the second phase version.
-/

namespace BaseCertificate

open UniformWindow ShieldEntry LoopTranslation

/-- Digits 0/1 to Booleans. -/
def b (l : List Nat) : List Bool := l.map (· == 1)

/-- The 109 states: (phase, columns 1..13, column 1 first). -/
def table : List (Nat × List Bool) := [
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 1]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 0]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 0, 1]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 1]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 1]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1, 1]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 0]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0]),
  (0, b [0, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 1]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 1]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 1]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1]),
  (1, b [0, 1, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 0]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 0, 1, 1]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 0, 0]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 0, 1]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 0]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 0, 1, 1, 1, 1]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 1, 1]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0]),
  (2, b [0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1]),
  (3, b [0, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0]),
  (3, b [0, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 1]),
  (3, b [0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 0]),
  (3, b [0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 0, 1]),
  (3, b [0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 0]),
  (3, b [0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 0, 1, 1]),
  (3, b [0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0]),
  (3, b [0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1]),
  (3, b [0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 0]),
  (3, b [0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1, 1, 1]),
  (4, b [1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0]),
  (4, b [1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1]),
  (4, b [1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1]),
  (4, b [1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 0]),
  (4, b [1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 0, 1]),
  (4, b [1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 0]),
  (4, b [1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0, 1, 1]),
  (4, b [1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0]),
  (4, b [1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1]),
  (4, b [1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1]),
  (5, b [0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0]),
  (5, b [0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 1]),
  (5, b [0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0]),
  (5, b [0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1]),
  (5, b [0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0]),
  (5, b [0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1]),
  (5, b [0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1]),
  (5, b [0, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0]),
  (5, b [0, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1]),
  (5, b [0, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1]),
  (5, b [0, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 0, 0, 1, 0, 1]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 1]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 1, 0]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 0]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1, 1]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 1]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 0]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 0, 1]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 0]),
  (6, b [1, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 0, 1]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 1]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 0, 1, 1]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 0]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 0, 1]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 0]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 0]),
  (7, b [0, 0, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1])
]

/-- One band step of width 13 on the list of columns 1..13; d enters at column 0, e at column 14. -/
def step13 : List Bool → Bool → Bool → List Bool
  | [a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12], d, e =>
    [Bool.xor d (a0 || a1), Bool.xor a0 (a1 || a2), Bool.xor a1 (a2 || a3), Bool.xor a2 (a3 || a4),
     Bool.xor a3 (a4 || a5), Bool.xor a4 (a5 || a6), Bool.xor a5 (a6 || a7), Bool.xor a6 (a7 || a8),
     Bool.xor a7 (a8 || a9), Bool.xor a8 (a9 || a10), Bool.xor a9 (a10 || a11), Bool.xor a10 (a11 || a12),
     Bool.xor a11 (a12 || e)]
  | l, _, _ => l

/-- Equality of Boolean lists, as a Boolean. -/
def eqL : List Bool → List Bool → Bool
  | [], [] => true
  | a :: l, c :: m => (a == c) && eqL l m
  | _, _ => false

/-- Is (f, l) in the list T? -/
def memT (f : Nat) (l : List Bool) : List (Nat × List Bool) → Bool
  | [] => false
  | x :: T => (x.1 == f && eqL x.2 l) || memT f l T

/-- The drive (1110)* at phase f. -/
def drv (f : Nat) : Bool := drive.getD (f % drive.length) false

/-- Column 1 of the certificate, by phase 0..7: 00001010. -/
def word : List Bool := [false, false, false, false, true, false, true, false]

/-- Closure: both successors of every state are in the table. -/
def closedB : Bool :=
  table.all fun x => memT ((x.1 + 1) % 8) (step13 x.2 (drv x.1) false) table &&
    memT ((x.1 + 1) % 8) (step13 x.2 (drv x.1) true) table

/-- Phases are below 8, and column 1 is the word of the phase. -/
def detB : Bool :=
  table.all fun x => decide (x.1 < 8) && (x.2.headD false == word.getD x.1 false)

theorem closedB_true : closedB = true := by decide

theorem detB_true : detB = true := by decide

theorem table_length : table.length = 109 := by decide

theorem eqL_sound : ∀ l m : List Bool, eqL l m = true → l = m
  | [], [], _ => rfl
  | a :: l, c :: m, h => by
    simp only [eqL, Bool.and_eq_true, beq_iff_eq] at h
    rw [h.1, eqL_sound l m h.2]
  | [], _ :: _, h => by simp [eqL] at h
  | _ :: _, [], h => by simp [eqL] at h

theorem memT_sound (f : Nat) (l : List Bool) :
    ∀ T, memT f l T = true → ∃ x ∈ T, x.1 = f ∧ x.2 = l
  | [], h => by simp [memT] at h
  | x :: T, h => by
    simp only [memT, Bool.or_eq_true, Bool.and_eq_true, beq_iff_eq] at h
    rcases h with ⟨h1, h2⟩ | h
    · exact ⟨x, List.mem_cons.2 (Or.inl rfl), h1, eqL_sound _ _ h2⟩
    · obtain ⟨y, hy, h3, h4⟩ := memT_sound f l T h
      exact ⟨y, List.mem_cons.2 (Or.inr hy), h3, h4⟩

/-- Column k + j (0-based) of a band, or false beyond its width. -/
def win {J : Nat} (S : Fin J → Bool) (k j : Nat) : Bool := if h : k + j < J then S ⟨k + j, h⟩ else false

/-- The 13 columns of a band starting at column k (0-based). -/
def window13 {J : Nat} (S : Fin J → Bool) (k : Nat) : List Bool :=
  [win S k 0, win S k 1, win S k 2, win S k 3, win S k 4, win S k 5, win S k 6,
   win S k 7, win S k 8, win S k 9, win S k 10, win S k 11, win S k 12]

/-- The list step is the band step. -/
theorem window13_step (T : Fin 13 → Bool) (d e : Bool) :
    window13 (bandStep 13 T d e) 0 = step13 (window13 T 0) d e := by
  rfl

/-- The 109 states as a certificate for (1110)* of width 13 and period 8. -/
def base : Certificate drive 13 8 where
  R := fun f T => memT f (window13 T 0) table = true
  closed := by
    intro f T h e
    obtain ⟨x, hx, h1, h2⟩ := memT_sound f _ table h
    have hc := (List.all_eq_true.1 closedB_true) x hx
    simp only [Bool.and_eq_true] at hc
    show memT ((f + 1) % 8) (window13 (bandStep 13 T (drive.getD (f % drive.length) false) e) 0) table = true
    rw [window13_step, ← h2, ← h1]
    cases e
    · exact hc.1
    · exact hc.2
  value := fun f => word.getD (f % 8) false
  det := by
    intro f T hJ h
    obtain ⟨x, hx, h1, h2⟩ := memT_sound f _ table h
    have hd := (List.all_eq_true.1 detB_true) x hx
    simp only [Bool.and_eq_true, decide_eq_true_eq, beq_iff_eq] at hd
    show (window13 T 0).headD false = word.getD (f % 8) false
    rw [← h2, hd.2, ← h1, Nat.mod_eq_of_lt hd.1]

theorem base_per : ∀ f, base.value f = base.value (f % 8) := by
  intro f
  show word.getD (f % 8) false = word.getD (f % 8 % 8) false
  rw [Nat.mod_mod]

theorem base_pin3 : base.value 3 = false := rfl

theorem base_pin7 : base.value 7 = false := rfl

/-- Moving a certificate along the phase by s: a certificate for any drive w' that reads w at phase f + s. -/
def certShift {w w' : List Bool} {J : Nat} (s : Nat) (C : Certificate w J 8)
    (hw : ∀ f, w'.getD (f % w'.length) false = w.getD (((f + s) % 8) % w.length) false) :
    Certificate w' J 8 where
  R := fun f S => C.R ((f + s) % 8) S
  closed := by
    intro f S h e
    have h' := C.closed _ S h e
    rw [← hw f] at h'
    have hph : ((f + s) % 8 + 1) % 8 = ((f + 1) % 8 + s) % 8 := by omega
    rw [hph] at h'
    exact h'
  value := fun f => C.value ((f + s) % 8)
  det := fun _ S hJ h => C.det _ S hJ h

theorem drive_shift4 : ∀ f, drive.getD (f % drive.length) false =
    drive.getD (((f + 4) % 8) % drive.length) false := by
  intro f
  show drive.getD (f % 4) false = drive.getD (((f + 4) % 8) % 4) false
  rw [show ((f + 4) % 8) % 4 = f % 4 by omega]

/-- The second phase version: column 1 is 10100000. -/
def base4 : Certificate drive 13 8 := certShift 4 base drive_shift4

theorem base4_per : ∀ f, base4.value f = base4.value (f % 8) := by
  intro f
  show base.value ((f + 4) % 8) = base.value ((f % 8 + 4) % 8)
  rw [show (f % 8 + 4) % 8 = (f + 4) % 8 by omega]

theorem base4_pin3 : base4.value 3 = false := rfl

theorem base4_pin7 : base4.value 7 = false := rfl

end BaseCertificate
