import LeftSeam
import RingComparator
import LeftCheck

/-!
Finite-window exhaustion and the finite-support seam, R7, 24 October 2026.
Extends the uploaded parallax supplement without changing its source modules.
The construction supplies finite starts for arbitrarily long compatible
windows, a finite-prefix bijection, and an actual ring/support seam.
No universal breaking premise is assumed in the unconditional constructions.
-/

namespace FiniteWindowSeam

open LeftBreak LeftSeam JointBreak RingComparator SeamClosure UniformWindow

def finiteShadow (b trace : Nat → Bool) (K : Nat) : Nat → Bool := rebuild b trace K

theorem shadow_is_finite (b trace : Nat → Bool) (K : Nat) :
    FiniteLeft K (finiteShadow b trace K) := rebuild_above b trace K

theorem shadow_matches_trace (b trace : Nat → Bool) (K t : Nat) (ht : t < K) :
    lhs b (finiteShadow b trace K) t 1 = trace t := by
  have cone : lhs b (finiteShadow b trace K) t 1 = lhs b (decodeStart b trace) t 1 := by
    apply lhs_cone
    intro i _ hi
    exact rebuild_stable b trace K i (by omega)
  rw [cone]
  exact congrFun (left_trace_onto b trace) t

def window (b : Nat → Bool) (K : Nat) (s : Nat → Bool) : Fin K → Bool :=
  fun t => lhs b s t.val 1

theorem prefix_pad (K : Nat) (p : Fin K → Bool) : startPrefix K (pad K p) = p := by
  funext i
  exact pad_get K p i

theorem same_prefix_same_window (b : Nat → Bool) (K : Nat) (s s' : Nat → Bool)
    (same : startPrefix K s = startPrefix K s') : window b K s = window b K s' := by
  funext t
  apply lhs_cone
  intro i hi hik
  have bound : i - 1 < K := by omega
  have eq := congrFun same ⟨i - 1, bound⟩
  change s (i - 1 + 1) = s' (i - 1 + 1) at eq
  rw [Nat.sub_add_cancel hi] at eq
  exact eq

def extendWindow (K : Nat) (trace : Fin K → Bool) : Nat → Bool :=
  fun t => if h : t < K then trace ⟨t, h⟩ else false

def forward (b : Nat → Bool) (K : Nat) (p : Fin K → Bool) : Fin K → Bool :=
  window b K (pad K p)

def backward (b : Nat → Bool) (K : Nat) (q : Fin K → Bool) : Fin K → Bool :=
  startPrefix K (finiteShadow b (extendWindow K q) K)

theorem forward_backward (b : Nat → Bool) (K : Nat) (q : Fin K → Bool) :
    forward b K (backward b K q) = q := by
  have same : startPrefix K (pad K (backward b K q)) =
      startPrefix K (finiteShadow b (extendWindow K q) K) := prefix_pad K _
  change window b K (pad K (backward b K q)) = q
  rw [same_prefix_same_window b K _ _ same]
  funext t
  show lhs b (finiteShadow b (extendWindow K q) K) t.val 1 = q t
  rw [shadow_matches_trace b (extendWindow K q) K t.val t.isLt]
  exact dif_pos t.isLt

theorem backward_forward (b : Nat → Bool) (K : Nat) (p : Fin K → Bool) :
    backward b K (forward b K p) = p := by
  have before : rebuild b (extendWindow K (forward b K p)) K =
      rebuild b (leftTrace b (pad K p)) K := by
    apply rebuild_before
    intro t ht
    show (if h : t < K then forward b K p ⟨t, h⟩ else false) = lhs b (pad K p) t 1
    rw [dif_pos ht]
    rfl
  change startPrefix K (rebuild b (extendWindow K (forward b K p)) K) = p
  rw [before]
  change startPrefix K (rebuild b (fun t => lhs b (pad K p) t 1) K) = p
  rw [rebuild_eq_trunc]
  funext i
  show trunc (pad K p) K (i.val + 1) = p i
  unfold trunc
  rw [if_pos (show 1 ≤ i.val + 1 ∧ i.val + 1 ≤ K from ⟨by omega, i.isLt⟩)]
  exact pad_get K p i

theorem forward_is_injective (b : Nat → Bool) (K : Nat) (p q : Fin K → Bool)
    (same : forward b K p = forward b K q) : p = q := by
  calc
    p = backward b K (forward b K p) := (backward_forward b K p).symm
    _ = backward b K (forward b K q) := congrArg (backward b K) same
    _ = q := backward_forward b K q

theorem every_trace_prefix_has_unique_start_prefix (b : Nat → Bool) (K : Nat)
    (q : Fin K → Bool) :
    ∃ p, forward b K p = q ∧ ∀ p', forward b K p' = q → p' = p := by
  refine ⟨backward b K q, forward_backward b K q, ?_⟩
  intro p' hp
  exact forward_is_injective b K p' (backward b K q)
    (hp.trans (forward_backward b K q).symm)

def finiteAnswer (w : List Bool) (K : Nat) : Nat → Bool :=
  finiteShadow (pdrive w) (fun t => !(pdrive w (t + 1))) K

theorem finite_answer_survives_window (w : List Bool) (K : Nat) :
    FiniteLeft K (finiteAnswer w K) ∧ ∀ t, t < K → ¬ BreaksAt w (finiteAnswer w K) t := by
  refine ⟨shadow_is_finite _ _ _, ?_⟩
  intro t ht broken
  have e := shadow_matches_trace (pdrive w) (fun t => !(pdrive w (t + 1))) K t ht
  change lhs (pdrive w) (finiteAnswer w K) t 1 = !(pdrive w (t + 1)) at e
  rw [broken.2] at e
  generalize pdrive w (t + 1) = x at e
  cases x <;> exact absurd e (by decide)

def finiteJointShadow (w : List Bool) (sR : Nat → Bool) (K : Nat) : Nat → Bool :=
  finiteShadow (pdrive w) (centerDemand w sR) K

theorem finite_joint_shadow_survives (w : List Bool) (sR : Nat → Bool) (K : Nat) :
    FiniteLeft K (finiteJointShadow w sR K) ∧
      ∀ t, t < K → ¬ JointBreaksAt w (finiteJointShadow w sR K) sR t := by
  refine ⟨shadow_is_finite _ _ _, ?_⟩
  intro t ht broken
  apply broken
  have e := shadow_matches_trace (pdrive w) (centerDemand w sR) K t ht
  change lhs (pdrive w) (finiteJointShadow w sR K) t 1 = centerDemand w sR t at e
  rw [e]
  unfold centerDemand
  generalize pdrive w (t + 1) = a
  generalize (pdrive w t || UniformWindow.rhc (pdrive w) sR t 1) = z
  cases a <;> cases z <;> rfl

theorem every_finite_window_has_a_finite_pair (w : List Bool) (T : Nat) :
    ∃ sL sR : Nat → Bool, FiniteLeft T sL ∧
      (∀ i, T < i → sR i = false) ∧ ∀ t, t < T → ¬ JointBreaksAt w sL sR t := by
  obtain ⟨finite, survives⟩ := finite_joint_shadow_survives w (fun _ => false) T
  exact ⟨finiteJointShadow w (fun _ => false) T, (fun _ => false), finite,
    (fun _ _ => rfl), survives⟩

theorem no_width_independent_joint_break_bound (w : List Bool) :
    ¬ (∃ T, ∀ K (sL sR : Nat → Bool), FiniteLeft K sL →
      (∀ i, K < i → sR i = false) → ∃ t, t ≤ T ∧ JointBreaksAt w sL sR t) := by
  intro bounded
  obtain ⟨T, bound⟩ := bounded
  obtain ⟨sL, sR, finL, finR, survives⟩ := every_finite_window_has_a_finite_pair w (T + 1)
  obtain ⟨t, ht, broken⟩ := bound (T + 1) sL sR finL finR
  exact survives t (by omega) broken

theorem every_left_bound_dominates_width (w : List Bool) (g : Nat → Nat)
    (bound : LeftBreakBound w g) (K : Nat) : K ≤ g K := by
  obtain ⟨finite, survives⟩ := finite_answer_survives_window w K
  obtain ⟨t, ht, broken⟩ := bound K (finiteAnswer w K) finite
  have later : K ≤ t := Nat.le_of_not_gt (fun early => survives t early broken)
  exact Nat.le_trans later ht

/-! The exact pairing behind halving at each black pin before the support edge. -/

def toggle (s : Nat → Bool) (j : Nat) : Nat → Bool :=
  fun i => if i = j then !(s i) else s i

theorem toggle_involution (s : Nat → Bool) (j : Nat) : toggle (toggle s j) j = s := by
  funext i
  by_cases eq : i = j
  · simp only [toggle, if_pos eq, Bool.not_not]
  · simp only [toggle, if_neg eq]

theorem toggle_preserves_support (s : Nat → Bool) (K j : Nat)
    (finite : FiniteLeft K s) (inside : j ≤ K) : FiniteLeft K (toggle s j) := by
  intro i hi
  show (if i = j then !(s i) else s i) = false
  rw [if_neg (show i ≠ j by omega)]
  exact finite i hi

theorem black_pin_pairs_prior_survivors (w : List Bool) (s : Nat → Bool) (t : Nat)
    (black : pdrive w t = true) :
    (∀ u, u < t → (BreaksAt w s u ↔ BreaksAt w (toggle s (t + 1)) u)) ∧
      (BreaksAt w s t ↔ ¬ BreaksAt w (toggle s (t + 1)) t) := by
  have agree : ∀ i, 1 ≤ i → i ≤ t → s i = toggle s (t + 1) i := by
    intro i _ hi
    show s i = (if i = t + 1 then !(s i) else s i)
    rw [if_neg (show i ≠ t + 1 by omega)]
  have different : s (t + 1) ≠ toggle s (t + 1) (t + 1) := by
    show s (t + 1) ≠ (if t + 1 = t + 1 then !(s (t + 1)) else s (t + 1))
    rw [if_pos rfl]
    cases s (t + 1) <;> decide
  obtain ⟨prior, changed⟩ := trace_first_difference (pdrive w) s (toggle s (t + 1)) t agree different
  constructor
  · intro u hu
    unfold BreaksAt
    rw [prior u hu]
  · unfold BreaksAt
    rw [black]
    generalize lhs (pdrive w) s t 1 = a at changed ⊢
    generalize lhs (pdrive w) (toggle s (t + 1)) t 1 = z at changed ⊢
    generalize pdrive w (t + 1) = c
    cases a <;> cases z <;> cases c <;> simp_all

/-! The finite-support target itself has a seam at every finite window. -/

def HasFiniteSupport (s : Nat → Bool) : Prop := ∃ K, FiniteLeft K s

theorem trunc_is_finite (s : Nat → Bool) (K : Nat) : FiniteLeft K (trunc s K) := by
  intro i hi
  unfold trunc
  exact if_neg (fun h => Nat.not_le_of_gt hi h.2)

theorem trunc_preserves_prefix (s : Nat → Bool) (K : Nat) :
    startPrefix K (trunc s K) = startPrefix K s := by
  funext i
  show (if 1 ≤ i.val + 1 ∧ i.val + 1 ≤ K then s (i.val + 1) else false) = s (i.val + 1)
  exact if_pos ⟨by omega, i.isLt⟩

theorem ring_start_is_not_finitely_supported : ¬ HasFiniteSupport (ringStart 0 0) := by
  intro finite
  obtain ⟨K, hK⟩ := finite
  exact ringStart_not_finite 0 0 (by decide) K hK

def ringSupportPrefixSeam (K : Nat) : SeamCertificate (startPrefix K) HasFiniteSupport where
  left := trunc (ringStart 0 0) K
  right := ringStart 0 0
  sameReading := trunc_preserves_prefix _ _
  distinctTargets := by
    intro same
    exact ring_start_is_not_finitely_supported (same.mp ⟨K, trunc_is_finite _ _⟩)

def ringSupportWindowSeam (b : Nat → Bool) (T : Nat) :
    SeamCertificate (window b T) HasFiniteSupport where
  left := trunc (ringStart 0 0) T
  right := ringStart 0 0
  sameReading := same_prefix_same_window b T _ _ (trunc_preserves_prefix _ _)
  distinctTargets := (ringSupportPrefixSeam T).distinctTargets

theorem no_finite_prefix_recovers_support (K : Nat) :
    ¬ Recovers (startPrefix K) HasFiniteSupport :=
  seam_certificate_closes_decoder_class _ _ (ringSupportPrefixSeam K)

theorem no_finite_trace_window_recovers_support (b : Nat → Bool) (T : Nat) :
    ¬ Recovers (window b T) HasFiniteSupport :=
  seam_certificate_closes_decoder_class _ _ (ringSupportWindowSeam b T)

theorem finite_truncations_converge_on_positive_cells (i : Nat) (hi : 1 ≤ i)
    (K : Nat) (hik : i ≤ K) : trunc (ringStart 0 0) K i = ringStart 0 0 i := by
  unfold trunc
  exact if_pos ⟨hi, hik⟩

end FiniteWindowSeam
