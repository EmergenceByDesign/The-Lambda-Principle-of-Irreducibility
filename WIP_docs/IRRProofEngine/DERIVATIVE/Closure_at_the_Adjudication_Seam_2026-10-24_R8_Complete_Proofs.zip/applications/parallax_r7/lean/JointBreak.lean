import LeftBreak
import ShieldEntry

/-!
The two-sided bridge, 23 October 2026. Claude, with Lu Semita.

Both half-lines are driven by the same center column, and the center obeys its own rule,
c(t+1) = L(t) xor (c(t) or R(t)), with L the left neighbour and R the right neighbour. This file states the bridge
with both sides at once:

* `JointBreaksAt w sL sR τ`: driven by the periodic word w, the left start sL and the right start sR violate the
  center's rule at time τ;
* `center_avoids_of_joint_breaks`: if every pair of finite starts eventually violates it, the center column never
  eventually repeats w;
* `joint_weaker`: the one-sided premise of `LeftBreak` implies this one, because a black-value break is a violation
  of the center's rule. The two-sided premise is therefore the weaker, and so the smaller, gap.
-/

namespace JointBreak

open Rule30Bridge Rule30Application RightHalf UniformWindow ShieldEntry LeftBreak

/-- Driven by w, the starts sL (left) and sR (right) violate the center's rule at time τ. -/
def JointBreaksAt (w : List Bool) (sL sR : Nat → Bool) (τ : Nat) : Prop :=
  pdrive w (τ + 1) ≠ Bool.xor (lhs (pdrive w) sL τ 1) (pdrive w τ || rhc (pdrive w) sR τ 1)

/-- Every pair of finite starts violates the center's rule at some time. -/
def EveryJointStartBreaks (w : List Bool) : Prop :=
  ∀ K (sL sR : Nat → Bool), FiniteLeft K sL → (∀ i, K < i → sR i = false) → ∃ τ, JointBreaksAt w sL sR τ

/-- A black-value break is a violation of the center's rule. -/
theorem joint_of_left (w : List Bool) (sL sR : Nat → Bool) (τ : Nat) (h : BreaksAt w sL τ) :
    JointBreaksAt w sL sR τ := by
  obtain ⟨black, value⟩ := h
  intro e
  rw [value, black, Bool.true_or] at e
  generalize pdrive w (τ + 1) = x at e
  cases x <;> exact absurd e (by decide)

/-- So the one-sided premise implies the two-sided one. -/
theorem joint_weaker (w : List Bool) (h : EveryLeftStartBreaks w) : EveryJointStartBreaks w := by
  intro K sL sR hL _
  obtain ⟨τ, hτ⟩ := h K sL hL
  exact ⟨τ, joint_of_left w sL sR τ hτ⟩

/-- The two-sided bridge: if every pair of finite starts eventually violates the center's rule under w, the
center column of Rule 30 never eventually repeats w. -/
theorem center_avoids_of_joint_breaks (w : List Bool) (h : EveryJointStartBreaks w) :
    ¬ EventuallyRepeats center30 w := by
  rintro ⟨N, hN⟩
  have hdrive : ∀ u, center30 (N + u) = pdrive w u := by
    intro u
    rw [hN (N + u) (Nat.le_add_right N u), Nat.add_sub_cancel_left]
    rfl
  have finL : FiniteLeft N (fun m => lh center30 N m) := fun i hi => DrivenLeft.lh_cone center30 N i hi
  have finR : ∀ i, N < i → (fun m => rh center30 N m) i = false := fun i hi => rh_outside center30 N i hi
  obtain ⟨τ, hτ⟩ := h N _ _ finL finR
  have e : (fun u => center30 (N + u)) = pdrive w := funext hdrive
  have rL : lh center30 (N + τ) 1 = lhs (pdrive w) (fun m => lh center30 N m) τ 1 := by
    rw [← e]
    exact lh_restart center30 N τ 1
  have rR : rh center30 (N + τ) 1 = rhc (pdrive w) (fun m => rh center30 N m) τ 1 := by
    rw [rh_eq_rhc center30 (N + τ) 1, rhc_restart center30 (fun _ => false) N τ 1, ← e]
    have hX : (fun m => rhc center30 (fun _ => false) N m) = (fun m => rh center30 N m) := by
      funext m
      exact (rh_eq_rhc center30 N m).symm
    rw [hX]
  unfold JointBreaksAt at hτ
  apply hτ
  rw [← rL, ← rR, ← hdrive τ, ← hdrive (τ + 1), lh_center30, rh_center30,
    show N + (τ + 1) = N + τ + 1 by omega, center30_succ]
  rfl

end JointBreak
