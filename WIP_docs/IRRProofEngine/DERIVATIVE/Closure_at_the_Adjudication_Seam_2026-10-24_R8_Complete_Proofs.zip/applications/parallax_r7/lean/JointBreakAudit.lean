import JointBreak
open JointBreak
#print axioms JointBreak.JointBreaksAt
#print axioms JointBreak.EveryJointStartBreaks
#print axioms JointBreak.joint_of_left
#print axioms JointBreak.joint_weaker
#print axioms JointBreak.center_avoids_of_joint_breaks
