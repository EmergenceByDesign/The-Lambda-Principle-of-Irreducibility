import UniformWindow

/-!
The black-value bridge for finite left starts, 23 October 2026. Claude, with Lu Semita.

Review R2 named the black-value obstruction (`BlackValueBridge.BlackValueObstruction`): at a black center cell,
Rule 30 forces the cell just left of the center to be the opposite of the next center cell
(`actual_black_value`), and a periodic drive should not be able to keep that up. This file states the
obstruction for one word at a time and for finite starts, in the form a finite computation can check start by
start, and proves the reduction to Problem 1 for that word.

* `lhs b s` is the left half-line driven at its right boundary by `b`, started from `s` instead of from white;
  with the white start it is `lh b`.
* `lh_restart`: from any time N on, `lh b` is the driven left half started from its own row at time N, driven
  by the rest of `b`.
* `BreaksAt w s τ`: under the periodic drive of `w`, the start `s` violates the black values at time τ.
* `center_avoids_of_left_breaks`: if every finite left start breaks the black values of `w`, the center column
  of Rule 30 never eventually repeats `w`. No hypothesis on `w` is needed: for a word with no black cell the
  premise is false.
* `LeftBreakBound w g`, the bounded premise, is a Π1 statement for each fixed `g`.

Nothing here assumes the premise.
-/

namespace LeftBreak

open Rule30Bridge Rule30Application BlackValueBridge DrivenLeft RightHalf UniformWindow

/-- The left half-line driven at its right boundary by `b`, from the start `s`: index m ≥ 1 stands for position
-m, whose value at time 0 is `s m`, and index 0 is the drive. -/
def lhs (b s : Nat → Bool) : Nat → Nat → Bool
  | t, 0 => b t
  | 0, m + 1 => s (m + 1)
  | t + 1, m + 1 => Bool.xor (lhs b s t (m + 2)) (lhs b s t (m + 1) || lhs b s t m)

theorem lhs_zero (b s : Nat → Bool) (t : Nat) : lhs b s t 0 = b t := by
  cases t <;> rfl

theorem lhs_step (b s : Nat → Bool) (t m : Nat) :
    lhs b s (t + 1) (m + 1) = Bool.xor (lhs b s t (m + 2)) (lhs b s t (m + 1) || lhs b s t m) := rfl

/-- The start matters only at positions -1, -2, .... -/
theorem lhs_congr (b s s' : Nat → Bool) (h : ∀ m, 1 ≤ m → s m = s' m) :
    ∀ t m, lhs b s t m = lhs b s' t m := by
  intro t
  induction t with
  | zero =>
    intro m
    cases m with
    | zero => rfl
    | succ m => exact h (m + 1) (by omega)
  | succ t ih =>
    intro m
    cases m with
    | zero => rfl
    | succ m => rw [lhs_step, lhs_step, ih (m + 2), ih (m + 1), ih m]

/-- With the white start, `lhs` is `lh`. -/
theorem lhs_white (b : Nat → Bool) : ∀ t m, lhs b (fun _ => false) t m = lh b t m := by
  intro t
  induction t with
  | zero =>
    intro m
    cases m with
    | zero => rfl
    | succ m => rfl
  | succ t ih =>
    intro m
    cases m with
    | zero => rfl
    | succ m => rw [lhs_step, lh_step, ih (m + 2), ih (m + 1), ih m]

/-- Restarting at time N: from then on the driven left half is the one started from its row at time N and
driven by the rest of the drive. -/
theorem lh_restart (b : Nat → Bool) (N : Nat) :
    ∀ t m, lh b (N + t) m = lhs (fun u => b (N + u)) (fun m => lh b N m) t m := by
  intro t
  induction t with
  | zero =>
    intro m
    cases m with
    | zero => rw [lhs_zero, DrivenLeft.lh_zero]
    | succ m => rfl
  | succ t ih =>
    intro m
    cases m with
    | zero => rw [lhs_zero, DrivenLeft.lh_zero]
    | succ m =>
      show lh b (N + t + 1) (m + 1) = lhs (fun u => b (N + u)) (fun m => lh b N m) (t + 1) (m + 1)
      rw [lh_step, lhs_step, ih (m + 2), ih (m + 1), ih m]

/-! ## Breaking the black values -/

/-- A start supported in positions -1..-K. -/
def FiniteLeft (K : Nat) (s : Nat → Bool) : Prop := ∀ i, K < i → s i = false

/-- Under the periodic drive of `w`, the start `s` breaks the black values at time τ: the drive is black at τ and
position -1 has the value of the next drive cell, where Rule 30 itself always has the opposite value. -/
def BreaksAt (w : List Bool) (s : Nat → Bool) (τ : Nat) : Prop :=
  pdrive w τ = true ∧ lhs (pdrive w) s τ 1 = pdrive w (τ + 1)

/-- Every finite left start breaks the black values of `w`. -/
def EveryLeftStartBreaks (w : List Bool) : Prop :=
  ∀ K s, FiniteLeft K s → ∃ τ, BreaksAt w s τ

/-- The bounded form. For a fixed bound `g` this is a Π1 statement: if it is false, one finite start of one width
shows it, by running for `g K + 1` steps. -/
def LeftBreakBound (w : List Bool) (g : Nat → Nat) : Prop :=
  ∀ K s, FiniteLeft K s → ∃ τ, τ ≤ g K ∧ BreaksAt w s τ

theorem every_of_bound (w : List Bool) (g : Nat → Nat) (h : LeftBreakBound w g) : EveryLeftStartBreaks w := by
  intro K s hs
  obtain ⟨τ, _, hb⟩ := h K s hs
  exact ⟨τ, hb⟩

theorem finiteLeft_mono {K K' : Nat} {s : Nat → Bool} (hs : FiniteLeft K s) (h : K ≤ K') : FiniteLeft K' s :=
  fun i hi => hs i (Nat.lt_of_le_of_lt h hi)

/-- Rule 30's own left half never breaks the black values of its center column, at any time. -/
theorem rule30_never_breaks (t : Nat) (black : center30 t = true) :
    lh center30 t 1 = !(center30 (t + 1)) := actual_black_value t black

/-- The bridge for one word: if every finite left start breaks the black values of `w`, the center column of
Rule 30 never eventually repeats `w`. -/
theorem center_avoids_of_left_breaks (w : List Bool) (h : EveryLeftStartBreaks w) :
    ¬ EventuallyRepeats center30 w := by
  rintro ⟨N, hN⟩
  have hdrive : ∀ u, center30 (N + u) = pdrive w u := by
    intro u
    rw [hN (N + u) (Nat.le_add_right N u), Nat.add_sub_cancel_left]
    rfl
  have fin : FiniteLeft N (fun m => lh center30 N m) := fun i hi => lh_cone center30 N i hi
  obtain ⟨τ, hblack, hval⟩ := h N _ fin
  have e : (fun u => center30 (N + u)) = pdrive w := funext hdrive
  have r : lh center30 (N + τ) 1 = lhs (pdrive w) (fun m => lh center30 N m) τ 1 := by
    rw [← e]
    exact lh_restart center30 N τ 1
  have black : center30 (N + τ) = true := by rw [hdrive τ]; exact hblack
  have av := rule30_never_breaks (N + τ) black
  rw [r, hval, show N + τ + 1 = N + (τ + 1) by omega, hdrive (τ + 1)] at av
  generalize pdrive w (τ + 1) = x at av
  cases x <;> exact absurd av (by decide)

/-- In the terms of Review R2: if every finite left start breaks the black values of `w`, no drive that eventually
repeats `w` keeps the black values at all its black cells from then on. This is `BlackValueObstruction` for the
drives that eventually repeat `w`, without its conditions at time 0 and against eventual whiteness. -/
theorem obstruction_of_left_breaks (w : List Bool) (h : EveryLeftStartBreaks w) (b : Nat → Bool) (N : Nat)
    (hN : ∀ t, N ≤ t → b t = w.getD ((t - N) % w.length) false) :
    ¬ (∀ t, N ≤ t → b t = true → lh b t 1 = !(b (t + 1))) := by
  intro values
  have hdrive : ∀ u, b (N + u) = pdrive w u := by
    intro u
    rw [hN (N + u) (Nat.le_add_right N u), Nat.add_sub_cancel_left]
    rfl
  have fin : FiniteLeft N (fun m => lh b N m) := fun i hi => lh_cone b N i hi
  obtain ⟨τ, hblack, hval⟩ := h N _ fin
  have e : (fun u => b (N + u)) = pdrive w := funext hdrive
  have r : lh b (N + τ) 1 = lhs (pdrive w) (fun m => lh b N m) τ 1 := by
    rw [← e]
    exact lh_restart b N τ 1
  have black : b (N + τ) = true := by rw [hdrive τ]; exact hblack
  have av := values (N + τ) (Nat.le_add_right N τ) black
  rw [r, hval, show N + τ + 1 = N + (τ + 1) by omega, hdrive (τ + 1)] at av
  generalize pdrive w (τ + 1) = x at av
  cases x <;> exact absurd av (by decide)

/-- The same through the bounded form. -/
theorem center_avoids_of_left_bound (w : List Bool) (g : Nat → Nat) (h : LeftBreakBound w g) :
    ¬ EventuallyRepeats center30 w :=
  center_avoids_of_left_breaks w (every_of_bound w g h)

/-- The words of period at most 4, other than the constant ones, up to rotation. -/
def w1110 : List Bool := [true, true, true, false]
def w1000 : List Bool := [true, false, false, false]
def w1100 : List Bool := [true, true, false, false]
def w10 : List Bool := [true, false]
def w100 : List Bool := [true, false, false]
def w110 : List Bool := [true, true, false]

end LeftBreak
