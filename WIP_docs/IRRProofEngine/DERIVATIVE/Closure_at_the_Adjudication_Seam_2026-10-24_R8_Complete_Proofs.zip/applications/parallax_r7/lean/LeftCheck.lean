import LeftReceipts

/-!
The admitted pattern, stated as a Π1 axiom, 23 October 2026. Claude, with Lu Semita.

`LeftBreak.center_avoids_of_left_bound` derives Problem 1 for a word w from `LeftBreakBound w g`. This file states
that premise as an axiom one can admit, and shows the two properties that make the admission checkable:

* it is exactly an infinite conjunction of finite Boolean checks, one per width (`leftBreakBound_iff_checks`):
  a Π1 statement;
* a single failed check refutes it (`failed_check_refutes`), so if it is false, one finite computation shows it.

`AdmittedPattern w` fixes the bound to the candidate of the step report, ⌈2pK/b⌉ + 4p. Its first widths are checked
here by the kernel with that bound (`admitted_*_checked`).
-/

set_option maxRecDepth 100000

namespace LeftCheck

open Rule30Bridge RightHalf UniformWindow LeftBreak LeftReceipts PatternReceipts

/-- The finite check at width K: every start number below 2^K breaks the black values of w by time T. -/
def leftCheck (w : List Bool) (T K : Nat) : Bool :=
  (List.range (2 ^ K)).all fun n => (List.range (T + 1)).any fun τ => breaksN w n τ

theorem seedL_finite (n K : Nat) (hn : n < 2 ^ K) : FiniteLeft K (seedL n) := by
  intro i hi
  show n.testBit (i - 1) = false
  apply Nat.testBit_lt_two_pow
  exact Nat.lt_of_lt_of_le hn (Nat.pow_le_pow_right (by decide) (by omega))

theorem breaksN_of_breaksAt (w : List Bool) (n τ : Nat) (h : BreaksAt w (seedL n) τ) : breaksN w n τ = true := by
  unfold breaksN
  rw [Bool.and_eq_true]
  refine ⟨h.1, decide_eq_true ?_⟩
  rw [rowL_spec]
  exact h.2

/-- The bounded premise is exactly the conjunction of the finite checks, one per width. -/
theorem leftBreakBound_iff_checks (w : List Bool) (g : Nat → Nat) :
    LeftBreakBound w g ↔ ∀ K, leftCheck w (g K) K = true := by
  constructor
  · intro h K
    unfold leftCheck
    rw [List.all_eq_true]
    intro n hn
    rw [List.mem_range] at hn
    rw [List.any_eq_true]
    obtain ⟨τ, hτ, hb⟩ := h K (seedL n) (seedL_finite n K hn)
    exact ⟨τ, List.mem_range.2 (by omega), breaksN_of_breaksAt w n τ hb⟩
  · intro h K s hs
    have hc := h K
    unfold leftCheck at hc
    rw [List.all_eq_true] at hc
    have hn := hc (startNum s K) (List.mem_range.2 (startNum_lt s K))
    rw [List.any_eq_true] at hn
    obtain ⟨τ, hτ, hb⟩ := hn
    rw [List.mem_range] at hτ
    exact ⟨τ, by omega, breaksN_sound w s K hs τ hb⟩

/-- One failed check refutes the premise. -/
theorem failed_check_refutes (w : List Bool) (g : Nat → Nat) (K : Nat) (h : leftCheck w (g K) K = false) :
    ¬ LeftBreakBound w g := by
  intro hb
  rw [(leftBreakBound_iff_checks w g).1 hb K] at h
  exact Bool.noConfusion h

/-- The candidate bound: ⌈2pK/b⌉ + 4p, with p the period and b the number of black cells of w. -/
def gw (w : List Bool) (K : Nat) : Nat := (2 * w.length * K + w.count true - 1) / w.count true + 4 * w.length

/-- The admitted pattern for the word w. -/
def AdmittedPattern (w : List Bool) : Prop := LeftBreakBound w (gw w)

/-- From the admitted pattern, Problem 1 for w follows. -/
theorem problem1_from_admitted_pattern (w : List Bool) (h : AdmittedPattern w) :
    ¬ EventuallyRepeats center30 w :=
  center_avoids_of_left_bound w (gw w) h

/-- The admitted pattern is Π1. -/
theorem admitted_pattern_is_pi1 (w : List Bool) :
    AdmittedPattern w ↔ ∀ K, leftCheck w (gw w K) K = true :=
  leftBreakBound_iff_checks w (gw w)

/-! The first widths of the admitted pattern, with the candidate bound itself, checked by the kernel. -/

theorem admitted_1110_checked : ∀ K, K < 13 → leftCheck w1110 (gw w1110 K) K = true := by decide +kernel
theorem admitted_1000_checked : ∀ K, K < 13 → leftCheck w1000 (gw w1000 K) K = true := by decide +kernel
theorem admitted_1100_checked : ∀ K, K < 13 → leftCheck w1100 (gw w1100 K) K = true := by decide +kernel
theorem admitted_10_checked : ∀ K, K < 13 → leftCheck w10 (gw w10 K) K = true := by decide +kernel
theorem admitted_100_checked : ∀ K, K < 13 → leftCheck w100 (gw w100 K) K = true := by decide +kernel
theorem admitted_110_checked : ∀ K, K < 13 → leftCheck w110 (gw w110 K) K = true := by decide +kernel

end LeftCheck
