import LeftCheck
open LeftCheck
#print axioms LeftCheck.leftCheck
#print axioms LeftCheck.seedL_finite
#print axioms LeftCheck.breaksN_of_breaksAt
#print axioms LeftCheck.leftBreakBound_iff_checks
#print axioms LeftCheck.failed_check_refutes
#print axioms LeftCheck.gw
#print axioms LeftCheck.AdmittedPattern
#print axioms LeftCheck.problem1_from_admitted_pattern
#print axioms LeftCheck.admitted_pattern_is_pi1
#print axioms LeftCheck.admitted_1110_checked
#print axioms LeftCheck.admitted_1000_checked
#print axioms LeftCheck.admitted_1100_checked
#print axioms LeftCheck.admitted_10_checked
#print axioms LeftCheck.admitted_100_checked
#print axioms LeftCheck.admitted_110_checked
