import LeftBreak
import PatternReceipts

/-!
Left-start receipts, 23 October 2026. Claude, with Lu Semita.

Rows of the driven left half as numbers (bit i is position -(i+1)); `rowL_spec` proves them equal to `lhs`. For a
width K, a list gives every start number n < 2^K a time τ, taken from the scan; `checkL` recomputes the row at τ in
the kernel and checks that the drive is black there and that position -1 has the value of the next drive cell.
`receiptL` turns a successful check into the statement about every start supported in positions -1..-K. The
witnesses come from the scan; Lean checks every one, so the scan is not part of the trust chain.
-/

namespace LeftReceipts

open Rule30Bridge RightHalf UniformWindow LeftBreak PatternReceipts

/-- One step of a left row as a number; the drive bit d enters at position 0. -/
def stepL (d : Bool) (r : Nat) : Nat := (r >>> 1) ^^^ (r ||| ((r <<< 1) ||| bitN d))

theorem stepL_testBit (d : Bool) (r i : Nat) :
    (stepL d r).testBit i =
      Bool.xor (r.testBit (i + 1)) (r.testBit i || (if i = 0 then d else r.testBit (i - 1))) := by
  unfold stepL
  rw [Nat.testBit_xor, Nat.testBit_shiftRight, Nat.testBit_or, Nat.testBit_or, Nat.testBit_shiftLeft,
    testBit_bitN, Nat.add_comm 1 i]
  cases i with
  | zero =>
    rw [decide_eq_false (by omega : ¬ (0 ≥ 1)), decide_eq_true (rfl : 0 = 0), if_pos rfl, Bool.false_and,
      Bool.false_or, Bool.true_and]
  | succ k =>
    rw [decide_eq_true (by omega : k + 1 ≥ 1), decide_eq_false (by omega : ¬ (k + 1 = 0)), Nat.add_sub_cancel,
      if_neg (by omega : ¬ (k + 1 = 0)), Bool.true_and, Bool.false_and, Bool.or_false]

/-- The left row at time t, from the start number n. -/
def rowL (b : Nat → Bool) (n : Nat) : Nat → Nat
  | 0 => n
  | t + 1 => stepL (b t) (rowL b n t)

/-- The start a number describes: position -m is bit m - 1. -/
def seedL (n : Nat) (m : Nat) : Bool := n.testBit (m - 1)

theorem rowL_spec (b : Nat → Bool) (n : Nat) : ∀ t i, (rowL b n t).testBit i = lhs b (seedL n) t (i + 1) := by
  intro t
  induction t with
  | zero =>
    intro i
    show n.testBit i = n.testBit (i + 1 - 1)
    rw [Nat.add_sub_cancel]
  | succ t ih =>
    intro i
    show (stepL (b t) (rowL b n t)).testBit i =
      Bool.xor (lhs b (seedL n) t (i + 1 + 1)) (lhs b (seedL n) t (i + 1) || lhs b (seedL n) t i)
    rw [stepL_testBit, ih (i + 1), ih i]
    cases i with
    | zero => rw [if_pos rfl, lhs_zero]
    | succ k => rw [if_neg (by omega), Nat.add_sub_cancel, ih k]

/-- The number of a start supported in positions -1..-K describes that start. -/
theorem seedL_start (s : Nat → Bool) (K : Nat) (hK : FiniteLeft K s) :
    ∀ m, 1 ≤ m → s m = seedL (startNum s K) m := by
  intro m hm
  unfold seedL startNum
  rw [ofBits_testBit, takeCols_getD]
  by_cases h : m - 1 < K
  · rw [if_pos h, show 1 + (m - 1) = m by omega]
  · rw [if_neg h, hK m (by omega)]

/-- Whether start number n breaks the black values of w at time τ. -/
def breaksN (w : List Bool) (n τ : Nat) : Bool :=
  pdrive w τ && decide ((rowL (pdrive w) n τ).testBit 0 = pdrive w (τ + 1))

theorem breaksN_sound (w : List Bool) (s : Nat → Bool) (K : Nat) (hK : FiniteLeft K s) (τ : Nat)
    (h : breaksN w (startNum s K) τ = true) : BreaksAt w s τ := by
  unfold breaksN at h
  rw [Bool.and_eq_true] at h
  obtain ⟨h1, h2⟩ := h
  have h3 := of_decide_eq_true h2
  rw [rowL_spec] at h3
  refine ⟨h1, ?_⟩
  rw [lhs_congr (pdrive w) s (seedL (startNum s K)) (seedL_start s K hK) τ 1]
  exact h3

/-- The entries are break times for the start numbers n0, n0 + 1, ..., in order. -/
def checkL (w : List Bool) (T : Nat) : Nat → List Nat → Bool
  | _, [] => true
  | n, τ :: τs => decide (τ ≤ T) && breaksN w n τ && checkL w T (n + 1) τs

theorem checkL_sound (w : List Bool) (T : Nat) :
    ∀ (τs : List Nat) (n0 : Nat), checkL w T n0 τs = true →
      ∀ n, n0 ≤ n → n < n0 + τs.length → ∃ τ, τ ≤ T ∧ breaksN w n τ = true := by
  intro τs
  induction τs with
  | nil => intro n0 _ n h1 h2; rw [List.length_nil] at h2; exfalso; omega
  | cons τ τs ih =>
    intro n0 h n h1 h2
    simp only [checkL, Bool.and_eq_true, decide_eq_true_eq] at h
    obtain ⟨⟨ht, hb⟩, hrest⟩ := h
    rcases Nat.eq_or_lt_of_le h1 with hs | hs
    · subst hs
      exact ⟨τ, ht, hb⟩
    · exact ih (n0 + 1) hrest n hs (by rw [List.length_cons] at h2; omega)

theorem checkL_append_true (w : List Bool) (T : Nat) :
    ∀ (τs1 τs2 : List Nat) (n0 : Nat), checkL w T n0 τs1 = true →
      checkL w T (n0 + τs1.length) τs2 = true → checkL w T n0 (τs1 ++ τs2) = true := by
  intro τs1
  induction τs1 with
  | nil => intro τs2 n0 _ h2; exact h2
  | cons τ τs ih =>
    intro τs2 n0 h1 h2
    simp only [List.cons_append, checkL, Bool.and_eq_true] at h1 ⊢
    refine ⟨h1.1, ih τs2 (n0 + 1) h1.2 ?_⟩
    rw [show n0 + 1 + τs.length = n0 + (τ :: τs).length by rw [List.length_cons]; omega]
    exact h2

/-- A successful check at width K, with 2^K entries, covers every start supported in positions -1..-K. -/
theorem receiptL (w : List Bool) (K T : Nat) (τs : List Nat) (hlen : τs.length = 2 ^ K)
    (h : checkL w T 0 τs = true) : ∀ s, FiniteLeft K s → ∃ τ, τ ≤ T ∧ BreaksAt w s τ := by
  intro s hK
  obtain ⟨τ, hτ, hb⟩ := checkL_sound w T τs 0 h (startNum s K) (Nat.zero_le _)
    (by rw [hlen]; have := startNum_lt s K; omega)
  exact ⟨τ, hτ, breaksN_sound w s K hK τ hb⟩

/-- So every width up to K is covered, with the same bound. -/
theorem receiptL_upto (w : List Bool) (K T : Nat)
    (h : ∀ s, FiniteLeft K s → ∃ τ, τ ≤ T ∧ BreaksAt w s τ) :
    ∀ K', K' ≤ K → ∀ s, FiniteLeft K' s → ∃ τ, τ ≤ T ∧ BreaksAt w s τ :=
  fun _ hK' s hs => h s (finiteLeft_mono hs hK')

end LeftReceipts
