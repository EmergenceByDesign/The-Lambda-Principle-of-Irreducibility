import LeftBreak
import SeamIntegration
import JointBreak

/-!
Parallax at the center, 23–24 October 2026. Claude, with Lu Semita; the seam vocabulary is R5's and R6's
(`SeamClosure`, `SeamIntegration`, unchanged).

The center column of Rule 30 drives two half-lines. This file describes both from the center, in R6's terms.

* The left half-line is transparent. For every drive, its column -1 trace recovers the whole start
  (`left_trace_recovers_start`, with an explicit decoder): the start cell at position J + 1 enters cell -1 at time
  J by exclusive or (`lhs_xor_entry`). So the prefix seam that R5 proved for the white-driven right half-line
  (`actualPrefixSeam`), and R6 built on, holds on the left for every drive (`leftPrefixSeam`), and the trace value
  at time J is exactly the coordinate R5's ladder adds at rung J (`trace_is_the_ladder_coordinate`).
* The left trace is also onto: every sequence is the trace of the start decoded from it (`left_trace_onto`). With
  the first J start cells fixed, the trace from time J on is still any sequence (`band_leaves_trace_free`), so no
  argument from the first J cells alone settles it.
* So, without finiteness, the left half absorbs any center column: for every word, a left start keeps its black
  values forever (`without_finiteness_every_word_fails`), and with the right start white, a left start keeps the
  center's own rule forever (`without_left_finiteness_every_word_fails_two_sided`). Both premises of the bridges
  need the left start finite.
* The right half-line is not transparent. Under the white drive, two different starts give the same column 1 trace
  (`rightTraceSeam`).
* At the center itself, the left view sees the right neighbour exactly at the center's white cells
  (`left_view_sees_right_at_white`, `white_cells_recover_right`) and not at its black cells
  (`black_hides_right`, `blackCellSeam`).
* The seam type is general: parity has a seam certificate too (`paritySeam`).
-/

namespace LeftSeam

open Rule30Bridge Rule30Application RightHalf UniformWindow LeftBreak SeamClosure SeamIntegration JointBreak

/-! ## 1. How the start enters the left half -/

/-- The value at (t, m) depends on the start only at positions 1..t+m. -/
theorem lhs_cone (b s s' : Nat → Bool) :
    ∀ t m, (∀ i, 1 ≤ i → i ≤ t + m → s i = s' i) → lhs b s t m = lhs b s' t m := by
  intro t
  induction t with
  | zero =>
    intro m h
    cases m with
    | zero => rfl
    | succ m => exact h (m + 1) (by omega) (by omega)
  | succ t ih =>
    intro m h
    cases m with
    | zero => rfl
    | succ m =>
      rw [lhs_step, lhs_step,
        ih (m + 2) (fun i h1 _ => h i h1 (by omega)),
        ih (m + 1) (fun i h1 _ => h i h1 (by omega)),
        ih m (fun i h1 _ => h i h1 (by omega))]

/-- The start cell at position t + m enters (t, m) by exclusive or. -/
theorem lhs_xor_entry (b s s' : Nat → Bool) :
    ∀ t m, 1 ≤ m → (∀ i, 1 ≤ i → i < t + m → s i = s' i) →
      Bool.xor (lhs b s t m) (lhs b s' t m) = Bool.xor (s (t + m)) (s' (t + m)) := by
  intro t
  induction t with
  | zero =>
    intro m hm _
    cases m with
    | zero => exact absurd hm (by decide)
    | succ m =>
      show Bool.xor (s (m + 1)) (s' (m + 1)) = Bool.xor (s (0 + (m + 1))) (s' (0 + (m + 1)))
      rw [Nat.zero_add]
  | succ t ih =>
    intro m hm h
    cases m with
    | zero => exact absurd hm (by decide)
    | succ m =>
      rw [lhs_step, lhs_step]
      have c1 : lhs b s t (m + 1) = lhs b s' t (m + 1) :=
        lhs_cone b s s' t (m + 1) (fun i h1 _ => h i h1 (by omega))
      have c0 : lhs b s t m = lhs b s' t m := lhs_cone b s s' t m (fun i h1 _ => h i h1 (by omega))
      have e := ih (m + 2) (by omega) (fun i h1 _ => h i h1 (by omega))
      rw [c1, c0, show t + 1 + (m + 1) = t + (m + 2) by omega, ← e]
      generalize lhs b s t (m + 2) = a
      generalize lhs b s' t (m + 2) = a'
      generalize (lhs b s' t (m + 1) || lhs b s' t m) = c
      cases a <;> cases a' <;> cases c <;> rfl

/-- Two starts that first differ at position J + 1 have column -1 traces that agree before time J and differ at
time J, under every drive. -/
theorem trace_first_difference (b s s' : Nat → Bool) (J : Nat)
    (agree : ∀ i, 1 ≤ i → i ≤ J → s i = s' i) (differ : s (J + 1) ≠ s' (J + 1)) :
    (∀ t, t < J → lhs b s t 1 = lhs b s' t 1) ∧ lhs b s J 1 ≠ lhs b s' J 1 := by
  refine ⟨fun t ht => lhs_cone b s s' t 1 (fun i h1 h2 => agree i h1 (by omega)), ?_⟩
  intro same
  have e := lhs_xor_entry b s s' J 1 (Nat.le_refl 1) (fun i h1 h2 => agree i h1 (by omega))
  rw [same] at e
  apply differ
  generalize s (J + 1) = x at e ⊢
  generalize s' (J + 1) = y at e ⊢
  generalize lhs b s' J 1 = z at e
  cases x <;> cases y <;> cases z <;> first | rfl | exact absurd e (by decide)

/-! ## 2. The left half is transparent: the trace recovers the start -/

/-- The start cut after position m: white at position 0 and beyond m. -/
def trunc (s : Nat → Bool) (m : Nat) : Nat → Bool := fun i => if 1 ≤ i ∧ i ≤ m then s i else false

/-- Rebuild the start from a trace, one cell per time step: cell m + 1 is the trace at time m, corrected by what
the rebuilt cells 1..m contribute. -/
def rebuild (b trace : Nat → Bool) : Nat → Nat → Bool
  | 0 => fun _ => false
  | m + 1 => fun i =>
      if i = m + 1 then Bool.xor (trace m) (lhs b (rebuild b trace m) m 1) else rebuild b trace m i

/-- The decoder: start cell i is read off after i rebuilding steps. -/
def decodeStart (b trace : Nat → Bool) (i : Nat) : Bool := rebuild b trace i i

theorem rebuild_eq_trunc (b s : Nat → Bool) :
    ∀ m, rebuild b (fun t => lhs b s t 1) m = trunc s m := by
  intro m
  induction m with
  | zero =>
    funext i
    show false = (if 1 ≤ i ∧ i ≤ 0 then s i else false)
    rw [if_neg (show ¬ (1 ≤ i ∧ i ≤ 0) by omega)]
  | succ m ih =>
    funext i
    show (if i = m + 1 then Bool.xor (lhs b s m 1) (lhs b (rebuild b (fun t => lhs b s t 1) m) m 1)
        else rebuild b (fun t => lhs b s t 1) m i) = trunc s (m + 1) i
    rw [ih]
    by_cases hi : i = m + 1
    · rw [if_pos hi, hi]
      have agree : ∀ j, 1 ≤ j → j < m + 1 → s j = trunc s m j := by
        intro j h1 h2
        show s j = (if 1 ≤ j ∧ j ≤ m then s j else false)
        rw [if_pos (show 1 ≤ j ∧ j ≤ m from ⟨h1, by omega⟩)]
      rw [lhs_xor_entry b s (trunc s m) m 1 (Nat.le_refl 1) agree]
      show Bool.xor (s (m + 1)) (if 1 ≤ m + 1 ∧ m + 1 ≤ m then s (m + 1) else false) =
        (if 1 ≤ m + 1 ∧ m + 1 ≤ m + 1 then s (m + 1) else false)
      rw [if_neg (show ¬ (1 ≤ m + 1 ∧ m + 1 ≤ m) by omega),
        if_pos (show 1 ≤ m + 1 ∧ m + 1 ≤ m + 1 from ⟨by omega, Nat.le_refl _⟩)]
      cases s (m + 1) <;> rfl
    · rw [if_neg hi]
      show (if 1 ≤ i ∧ i ≤ m then s i else false) = (if 1 ≤ i ∧ i ≤ m + 1 then s i else false)
      by_cases h1 : 1 ≤ i ∧ i ≤ m
      · rw [if_pos h1, if_pos (show 1 ≤ i ∧ i ≤ m + 1 from ⟨h1.1, by omega⟩)]
      · rw [if_neg h1, if_neg (show ¬ (1 ≤ i ∧ i ≤ m + 1) from
          fun h => h1 ⟨h.1, Nat.le_of_lt_succ (Nat.lt_of_le_of_ne h.2 hi)⟩)]

theorem decodeStart_trace (b s : Nat → Bool) (i : Nat) (hi : 1 ≤ i) :
    decodeStart b (fun t => lhs b s t 1) i = s i := by
  show rebuild b (fun t => lhs b s t 1) i i = s i
  rw [rebuild_eq_trunc]
  show (if 1 ≤ i ∧ i ≤ i then s i else false) = s i
  rw [if_pos (show 1 ≤ i ∧ i ≤ i from ⟨hi, Nat.le_refl i⟩)]

/-- The column -1 trace of the left half-line. -/
def leftTrace (b s : Nat → Bool) : Nat → Bool := fun t => lhs b s t 1

/-- The start cells at positions 1, 2, .... -/
def startCells (s : Nat → Bool) : Nat → Bool := fun m => s (m + 1)

/-- For every drive, the column -1 trace recovers the whole start. -/
theorem left_trace_recovers_start (b : Nat → Bool) : Recovers (leftTrace b) startCells :=
  ⟨fun trace m => decodeStart b trace (m + 1),
   fun s => funext fun m => decodeStart_trace b s (m + 1) (by omega)⟩

/-! ## 3. The prefix seam of R5 and R6 on the left, for every drive, and R5's ladder in time -/

/-- The first J start cells. -/
def startPrefix (J : Nat) (s : Nat → Bool) : Fin J → Bool := fun i => s (i.val + 1)

/-- One black cell, at position J + 1. -/
def spike (J : Nat) : Nat → Bool := fun i => decide (i = J + 1)

/-- For every drive and every J, the first J start cells cannot give the column -1 trace: the white start and the
single black cell at J + 1 read the same and their traces differ at time J. -/
def leftPrefixSeam (b : Nat → Bool) (J : Nat) : SeamCertificate (startPrefix J) (leftTrace b) where
  left := fun _ => false
  right := spike J
  sameReading := by
    funext i
    have hi := i.isLt
    show false = decide (i.val + 1 = J + 1)
    rw [decide_eq_false (show ¬ (i.val + 1 = J + 1) by omega)]
  distinctTargets := by
    intro same
    have d := (trace_first_difference b (fun _ => false) (spike J) J
      (fun i _ h2 => by
        show false = decide (i = J + 1)
        rw [decide_eq_false (show ¬ (i = J + 1) by omega)])
      (by
        show false ≠ decide (J + 1 = J + 1)
        rw [decide_eq_true rfl]
        decide)).2
    exact d (congrFun same J)

theorem no_prefix_recovers_left_trace (b : Nat → Bool) (J : Nat) :
    ¬ Recovers (startPrefix J) (leftTrace b) :=
  seam_certificate_closes_decoder_class _ _ (leftPrefixSeam b J)

/-- The same seam on finite starts, as R5's `actualPrefixSeam` is stated. -/
def FiniteLeftStart := {s : Nat → Bool // ∃ K, FiniteLeft K s}

def finiteWhite : FiniteLeftStart := ⟨fun _ => false, 0, fun _ _ => rfl⟩

def finiteSpike (J : Nat) : FiniteLeftStart :=
  ⟨spike J, J + 1, fun i hi => by
    show decide (i = J + 1) = false
    rw [decide_eq_false (show ¬ (i = J + 1) by omega)]⟩

def leftPrefixSeamFinite (b : Nat → Bool) (J : Nat) :
    SeamCertificate (fun s : FiniteLeftStart => startPrefix J s.val) (fun s => leftTrace b s.val) where
  left := finiteWhite
  right := finiteSpike J
  sameReading := (leftPrefixSeam b J).sameReading
  distinctTargets := (leftPrefixSeam b J).distinctTargets

/-- The first J start cells, padded with white. -/
def pad (J : Nat) (p : Fin J → Bool) : Nat → Bool :=
  fun i => if h : 1 ≤ i ∧ i ≤ J then p ⟨i - 1, by omega⟩ else false

/-- The trace value at time J, with the first J start cells, gives start cell J + 1. -/
theorem left_ladder_step (b : Nat → Bool) (J : Nat) :
    Recovers (fun s => (startPrefix J s, leftTrace b s J)) (fun s => s (J + 1)) := by
  refine ⟨fun pv => Bool.xor pv.2 (lhs b (pad J pv.1) J 1), fun s => ?_⟩
  show Bool.xor (lhs b s J 1) (lhs b (pad J (startPrefix J s)) J 1) = s (J + 1)
  have agree : ∀ i, 1 ≤ i → i < J + 1 → s i = pad J (startPrefix J s) i := by
    intro i h1 h2
    show s i = (if h : 1 ≤ i ∧ i ≤ J then startPrefix J s ⟨i - 1, by omega⟩ else false)
    rw [dif_pos (show 1 ≤ i ∧ i ≤ J from ⟨h1, by omega⟩)]
    show s i = s (i - 1 + 1)
    rw [Nat.sub_add_cancel h1]
  rw [lhs_xor_entry b s (pad J (startPrefix J s)) J 1 (Nat.le_refl 1) agree]
  show Bool.xor (s (J + 1))
      (if h : 1 ≤ J + 1 ∧ J + 1 ≤ J then startPrefix J s ⟨J + 1 - 1, by omega⟩ else false) = s (J + 1)
  rw [dif_neg (show ¬ (1 ≤ J + 1 ∧ J + 1 ≤ J) by omega)]
  cases s (J + 1) <;> rfl

/-- The start whose cells 1, 2, ... are the sequence x. -/
def startOf (x : Nat → Bool) : Nat → Bool := fun i => if i = 0 then false else x (i - 1)

theorem startPrefix_startOf (J : Nat) (x : Nat → Bool) : startPrefix J (startOf x) = Prefix J x := by
  funext i
  show (if i.val + 1 = 0 then false else x (i.val + 1 - 1)) = x i.val
  rw [if_neg (show ¬ (i.val + 1 = 0) by omega), Nat.add_sub_cancel]

/-- R5's abstract ladder, realized in time by the left half-line: on binary sequences, the J-prefix with the trace
value at time J recovers the next bit, and so, by R5's `added_coordinate_must_split` applied unchanged to R5's
`prefixSeam`, the trace at time J is a coordinate that splits R5's certified pair. -/
theorem trace_is_the_ladder_coordinate (b : Nat → Bool) (J : Nat) :
    Recovers (fun x => (Prefix J x, leftTrace b (startOf x) J)) (NextBit J) ∧
      leftTrace b (startOf (prefixSeam J).left) J ≠ leftTrace b (startOf (prefixSeam J).right) J := by
  have adequate : Recovers (fun x => (Prefix J x, leftTrace b (startOf x) J)) (NextBit J) := by
    obtain ⟨D, hD⟩ := left_ladder_step b J
    refine ⟨D, fun x => ?_⟩
    have h : D (startPrefix J (startOf x), leftTrace b (startOf x) J) = startOf x (J + 1) := hD (startOf x)
    rw [startPrefix_startOf] at h
    show D (Prefix J x, leftTrace b (startOf x) J) = x J
    rw [h]
    show (if J + 1 = 0 then false else x (J + 1 - 1)) = x J
    rw [if_neg (show ¬ (J + 1 = 0) by omega), Nat.add_sub_cancel]
  exact ⟨adequate, added_coordinate_must_split _ _ (prefixSeam J) (fun x => leftTrace b (startOf x) J) adequate⟩

/-! ## 4. The left trace is onto -/

/-- After m rebuilding steps, the cells beyond m are still white. -/
theorem rebuild_above (b trace : Nat → Bool) : ∀ m i, m < i → rebuild b trace m i = false := by
  intro m
  induction m with
  | zero => intro _ _; rfl
  | succ m ih =>
    intro i hi
    show (if i = m + 1 then Bool.xor (trace m) (lhs b (rebuild b trace m) m 1) else rebuild b trace m i) = false
    rw [if_neg (Nat.ne_of_gt hi)]
    exact ih i (Nat.lt_of_succ_lt hi)

/-- A rebuilt cell does not change in later steps. -/
theorem rebuild_stable (b trace : Nat → Bool) : ∀ m i, i ≤ m → rebuild b trace m i = rebuild b trace i i := by
  intro m
  induction m with
  | zero =>
    intro i hi
    rw [Nat.le_zero.1 hi]
  | succ m ih =>
    intro i hi
    by_cases h : i = m + 1
    · rw [h]
    · show (if i = m + 1 then Bool.xor (trace m) (lhs b (rebuild b trace m) m 1) else rebuild b trace m i) =
        rebuild b trace i i
      rw [if_neg h]
      exact ih i (Nat.le_of_lt_succ (Nat.lt_of_le_of_ne hi h))

/-- The first m rebuilding steps read the trace only before time m. -/
theorem rebuild_before (b trace trace' : Nat → Bool) :
    ∀ m, (∀ t, t < m → trace t = trace' t) → rebuild b trace m = rebuild b trace' m := by
  intro m
  induction m with
  | zero => intro _; rfl
  | succ m ih =>
    intro h
    have e := ih (fun t ht => h t (Nat.lt_succ_of_lt ht))
    funext i
    show (if i = m + 1 then Bool.xor (trace m) (lhs b (rebuild b trace m) m 1) else rebuild b trace m i) =
      (if i = m + 1 then Bool.xor (trace' m) (lhs b (rebuild b trace' m) m 1) else rebuild b trace' m i)
    rw [e, h m (Nat.lt_succ_self m)]

/-- Every sequence is the column -1 trace of the start decoded from it, under every drive. -/
theorem left_trace_onto (b trace : Nat → Bool) : leftTrace b (decodeStart b trace) = trace := by
  funext t
  show lhs b (decodeStart b trace) t 1 = trace t
  have cone : lhs b (decodeStart b trace) t 1 = lhs b (rebuild b trace (t + 1)) t 1 := by
    apply lhs_cone
    intro i _ h2
    show rebuild b trace i i = rebuild b trace (t + 1) i
    exact (rebuild_stable b trace (t + 1) i h2).symm
  rw [cone]
  have agree : ∀ i, 1 ≤ i → i < t + 1 → rebuild b trace (t + 1) i = rebuild b trace t i := by
    intro i _ h2
    show (if i = t + 1 then Bool.xor (trace t) (lhs b (rebuild b trace t) t 1) else rebuild b trace t i) =
      rebuild b trace t i
    rw [if_neg (Nat.ne_of_lt h2)]
  have e := lhs_xor_entry b (rebuild b trace (t + 1)) (rebuild b trace t) t 1 (Nat.le_refl 1) agree
  have top : rebuild b trace (t + 1) (t + 1) = Bool.xor (trace t) (lhs b (rebuild b trace t) t 1) := by
    show (if t + 1 = t + 1 then Bool.xor (trace t) (lhs b (rebuild b trace t) t 1)
      else rebuild b trace t (t + 1)) = Bool.xor (trace t) (lhs b (rebuild b trace t) t 1)
    rw [if_pos rfl]
  rw [top, rebuild_above b trace t (t + 1) (Nat.lt_succ_self t)] at e
  generalize lhs b (rebuild b trace (t + 1)) t 1 = x at e ⊢
  generalize lhs b (rebuild b trace t) t 1 = y at e
  generalize trace t = z at e ⊢
  cases x <;> cases y <;> cases z <;> first | rfl | exact absurd e (by decide)

/-- The padded prefix gives back its cells. -/
theorem pad_get (J : Nat) (p : Fin J → Bool) (i : Fin J) : pad J p (i.val + 1) = p i := by
  have h : 1 ≤ i.val + 1 ∧ i.val + 1 ≤ J := ⟨Nat.succ_le_succ (Nat.zero_le _), i.isLt⟩
  show (if h : 1 ≤ i.val + 1 ∧ i.val + 1 ≤ J then p ⟨i.val + 1 - 1, by omega⟩ else false) = p i
  rw [dif_pos h]
  exact congrArg p (Fin.ext (Nat.add_sub_cancel i.val 1))

/-- With the first J start cells fixed, the left half still produces any sequence at cell -1 from time J on. So an
argument that uses only the first J cells cannot settle the trace from time J on. -/
theorem band_leaves_trace_free (b : Nat → Bool) (J : Nat) (p : Fin J → Bool) (trace : Nat → Bool) :
    ∃ s, startPrefix J s = p ∧ ∀ t, J ≤ t → leftTrace b s t = trace t := by
  let trace' : Nat → Bool := fun t => if t < J then leftTrace b (pad J p) t else trace t
  refine ⟨decodeStart b trace', ?_, ?_⟩
  · funext i
    show rebuild b trace' (i.val + 1) (i.val + 1) = p i
    have e : rebuild b trace' (i.val + 1) = rebuild b (leftTrace b (pad J p)) (i.val + 1) := by
      apply rebuild_before
      intro t ht
      show (if t < J then leftTrace b (pad J p) t else trace t) = leftTrace b (pad J p) t
      rw [if_pos (Nat.lt_of_lt_of_le ht i.isLt)]
    rw [e]
    have d : rebuild b (leftTrace b (pad J p)) (i.val + 1) (i.val + 1) = pad J p (i.val + 1) :=
      decodeStart_trace b (pad J p) (i.val + 1) (Nat.succ_le_succ (Nat.zero_le _))
    rw [d, pad_get]
  · intro t ht
    rw [congrFun (left_trace_onto b trace') t]
    show (if t < J then leftTrace b (pad J p) t else trace t) = trace t
    rw [if_neg (Nat.not_lt.2 ht)]

/-! ## 5. So, without finiteness, the left half absorbs any center column -/

/-- The left start that answers every black value: its trace is not c(t+1), at every time. -/
def answerStart (w : List Bool) : Nat → Bool := decodeStart (pdrive w) (fun t => !(pdrive w (t + 1)))

theorem answerStart_never_breaks (w : List Bool) : ∀ τ, ¬ BreaksAt w (answerStart w) τ := by
  intro τ h
  have e : lhs (pdrive w) (answerStart w) τ 1 = !(pdrive w (τ + 1)) :=
    congrFun (left_trace_onto (pdrive w) (fun t => !(pdrive w (t + 1)))) τ
  rw [h.2] at e
  generalize pdrive w (τ + 1) = x at e
  cases x <;> exact absurd e (by decide)

/-- Without finiteness the one-sided premise fails for every word. -/
theorem without_finiteness_every_word_fails (w : List Bool) : ¬ ∀ s : Nat → Bool, ∃ τ, BreaksAt w s τ := by
  intro h
  obtain ⟨τ, hτ⟩ := h (answerStart w)
  exact answerStart_never_breaks w τ hτ

/-- What the center's rule asks of cell -1, given the right start: L(t) = c(t+1) xor (c(t) or R(t)). -/
def centerDemand (w : List Bool) (sR : Nat → Bool) : Nat → Bool :=
  fun t => Bool.xor (pdrive w (t + 1)) (pdrive w t || rhc (pdrive w) sR t 1)

/-- For every word and every right start, the left start decoded from the center's demand keeps the center's rule
at every time. -/
theorem open_left_keeps_center_rule (w : List Bool) (sR : Nat → Bool) :
    ∀ τ, ¬ JointBreaksAt w (decodeStart (pdrive w) (centerDemand w sR)) sR τ := by
  intro τ h
  apply h
  have e : lhs (pdrive w) (decodeStart (pdrive w) (centerDemand w sR)) τ 1 = centerDemand w sR τ :=
    congrFun (left_trace_onto (pdrive w) (centerDemand w sR)) τ
  rw [e]
  show pdrive w (τ + 1) = Bool.xor (Bool.xor (pdrive w (τ + 1)) (pdrive w τ || rhc (pdrive w) sR τ 1))
    (pdrive w τ || rhc (pdrive w) sR τ 1)
  generalize pdrive w (τ + 1) = x
  generalize (pdrive w τ || rhc (pdrive w) sR τ 1) = y
  cases x <;> cases y <;> rfl

/-- So the two-sided premise needs the left start finite: with the right start white, and so finite, it fails for
every word once the left start may be infinite. -/
theorem without_left_finiteness_every_word_fails_two_sided (w : List Bool) :
    ¬ ∀ sL : Nat → Bool, ∃ τ, JointBreaksAt w sL (fun _ => false) τ := by
  intro h
  obtain ⟨τ, hτ⟩ := h (decodeStart (pdrive w) (centerDemand w (fun _ => false)))
  exact open_left_keeps_center_rule w (fun _ => false) τ hτ

/-! ## 6. The right half is not transparent -/

/-- The white drive. -/
def whiteDrive : Nat → Bool := fun _ => false

/-- Under the white drive column 1 can only switch on. -/
theorem white_column_one_stays (x0 : Nat → Bool) (h : x0 1 = true) : ∀ t, rhc whiteDrive x0 t 1 = true := by
  intro t
  induction t with
  | zero => exact h
  | succ t ih =>
    show Bool.xor (rhc whiteDrive x0 t 0) (rhc whiteDrive x0 t 1 || rhc whiteDrive x0 t 2) = true
    have h0 : rhc whiteDrive x0 t 0 = false := by cases t <;> rfl
    rw [ih, h0]
    rfl

/-- The column 1 trace of the right half-line. -/
def rightTrace (b x0 : Nat → Bool) : Nat → Bool := fun t => rhc b x0 t 1

/-- Two different starts with the same column 1 trace under the white drive. -/
def rightTraceSeam : SeamCertificate (rightTrace whiteDrive) startCells where
  left := fun i => decide (i = 1)
  right := fun i => decide (i = 1) || decide (i = 2)
  sameReading := by
    funext t
    show rhc whiteDrive (fun i => decide (i = 1)) t 1 =
      rhc whiteDrive (fun i => decide (i = 1) || decide (i = 2)) t 1
    rw [white_column_one_stays (fun i => decide (i = 1)) (by decide) t,
      white_column_one_stays (fun i => decide (i = 1) || decide (i = 2)) (by decide) t]
  distinctTargets := fun same => absurd (congrFun same 1) (by decide)

theorem right_trace_cannot_recover_start : ¬ Recovers (rightTrace whiteDrive) startCells :=
  seam_certificate_closes_decoder_class _ _ rightTraceSeam

/-! ## 7. At the center: what the left view sees of the right -/

/-- At a white center cell the left view sees the right neighbour: R(t) = c(t+1) xor L(t). -/
theorem left_view_sees_right_at_white (t : Nat) (white : center30 t = false) :
    right30 t = Bool.xor (center30 (t + 1)) (left30 t) := by
  rw [center30_succ, white]
  generalize left30 t = L
  generalize right30 t = R
  cases L <;> cases R <;> rfl

/-- At a black center cell the next center value does not depend on the right neighbour. -/
theorem black_hides_right (t : Nat) (black : center30 t = true) : center30 (t + 1) = !(left30 t) := by
  rw [center30_succ, black]
  generalize left30 t = L
  generalize right30 t = R
  cases L <;> cases R <;> rfl

/-- The center's local view of a neighbourhood (L, c, R): left neighbour, own value, own next value. -/
def centerView (x : Bool × Bool × Bool) : Bool × Bool × Bool := (x.1, x.2.1, Bool.xor x.1 (x.2.1 || x.2.2))

/-- The right neighbour. -/
def rightOf (x : Bool × Bool × Bool) : Bool := x.2.2

/-- At its own black cells the center cannot see its right neighbour. -/
def blackCellSeam (L : Bool) : SeamCertificate centerView rightOf where
  left := (L, true, false)
  right := (L, true, true)
  sameReading := by cases L <;> rfl
  distinctTargets := fun h => Bool.noConfusion h

/-- At its white cells it sees the right neighbour exactly. -/
theorem white_cells_recover_right :
    Recovers (fun x : {x : Bool × Bool × Bool // x.2.1 = false} => centerView x.1) (fun x => rightOf x.1) := by
  refine ⟨fun v => Bool.xor v.2.2 v.1, fun x => ?_⟩
  obtain ⟨⟨L, c, R⟩, hc⟩ := x
  change c = false at hc
  subst hc
  cases L <;> cases R <;> rfl

/-! ## 8. The seam type is general -/

/-- Parity loses information about a number: 0 and 2 have the same parity. Any readout that loses information about
its target has a seam certificate, so two seams sharing the type do not, by that alone, share a cause. -/
def paritySeam : SeamCertificate (fun n : Nat => n % 2) (fun n : Nat => n) where
  left := 0
  right := 2
  sameReading := rfl
  distinctTargets := by decide

end LeftSeam
