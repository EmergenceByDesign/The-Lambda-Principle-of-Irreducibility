import BaseCertificate
import ClosureCheck

/-!
The loop family, 23 October 2026. Claude, with Lu Semita.

Every certificate seen so far for (1110)* is L loop blocks in front of a state of the 109-state certificate of
`BaseCertificate`, in one of its two phase versions, with any further columns free. This file makes that family a
Lean object. `loopPattern L f S` is a Boolean test on a band: its first 7L columns are the loop words at phase f,
and its next 13 columns are a state of the table at phase f or f + 4. `loop_family` proves that every band passing
the test lies in a certificate (`loopBlock` is the construction of `loop_step`, kept as a definition so that its
states can be named). `EntryBoundF` is the open core with this explicit test in place of "some certificate", and
`center_avoids_1110` carries it to Problem 1 for the pattern 1110.
-/

namespace LoopFamily

open Rule30Bridge Rule30Application RightHalf UniformWindow ShieldEntry EntryBridge ClosureCheck LoopTranslation
  BaseCertificate

/-! Bands: dropping the first column, and windows. -/

/-- The band without its first column. -/
def dropBand {J : Nat} (S : Fin (J + 1) → Bool) : Fin J → Bool := fun i => S ⟨i.val + 1, by omega⟩

theorem consBand_drop {J : Nat} (S : Fin (J + 1) → Bool) : consBand (S ⟨0, by omega⟩) (dropBand S) = S := by
  funext i
  obtain ⟨k, hk⟩ := i
  cases k with
  | zero => rfl
  | succ k =>
    show (if h : k + 1 = 0 then S ⟨0, by omega⟩ else S ⟨k + 1 - 1 + 1, by omega⟩) = S ⟨k + 1, hk⟩
    rw [dif_neg (by omega)]
    exact congrArg S (Fin.ext (by simp only []; omega))

theorem win_drop {J : Nat} (S : Fin (J + 1) → Bool) (k j : Nat) : win (dropBand S) k j = win S (k + 1) j := by
  unfold win
  by_cases h : k + j < J
  · rw [dif_pos h, dif_pos (by omega)]
    exact congrArg S (Fin.ext (by simp only []; omega))
  · rw [dif_neg h, dif_neg (by omega)]

theorem win_zero {J : Nat} (S : Fin J → Bool) (k j : Nat) : win S k j = win S 0 (k + j) := by
  unfold win
  by_cases h : k + j < J
  · rw [dif_pos h, dif_pos (by omega)]
    exact congrArg S (Fin.ext (by simp only []; omega))
  · rw [dif_neg h, dif_neg (by omega)]

theorem window13_congr {J J' : Nat} (S : Fin J → Bool) (S' : Fin J' → Bool) (k k' : Nat)
    (h : ∀ j, j < 13 → win S k j = win S' k' j) : window13 S k = window13 S' k' := by
  simp only [window13]
  rw [h 0 (by omega), h 1 (by omega), h 2 (by omega), h 3 (by omega), h 4 (by omega), h 5 (by omega),
    h 6 (by omega), h 7 (by omega), h 8 (by omega), h 9 (by omega), h 10 (by omega), h 11 (by omega),
    h 12 (by omega)]

/-! The loop-block columns. -/

/-- Column k of a loop block (k taken mod 7), at phase f: 10101010, 10011001, 10001000, 10001000, 10011001,
00110011, 11101110. -/
def blockWord (k f : Nat) : Bool :=
  match k % 7 with
  | 0 => col L1 f
  | 1 => col L2 f
  | 2 => col L3 f
  | 3 => col L3 f
  | 4 => col L2 f
  | 5 => col L6 f
  | _ => col drive f

theorem blockWord_add7 (k f : Nat) : blockWord (k + 7) f = blockWord k f := by
  unfold blockWord
  rw [Nat.add_mod_right]

/-- Columns k, ..., k + n - 1 of S are block columns 0, ..., n - 1 at phase f. -/
def blockOK (f k : Nat) {J : Nat} (S : Fin J → Bool) : Nat → Bool
  | 0 => true
  | n + 1 => blockOK f k S n && (win S k n == blockWord n f)

theorem blockOK_spec (f k : Nat) {J : Nat} (S : Fin J → Bool) :
    ∀ n, blockOK f k S n = true ↔ ∀ i, i < n → win S k i = blockWord i f := by
  intro n
  induction n with
  | zero => exact ⟨fun _ i hi => absurd hi (Nat.not_lt_zero i), fun _ => rfl⟩
  | succ n ih =>
    simp only [blockOK, Bool.and_eq_true, beq_iff_eq, ih]
    constructor
    · rintro ⟨h1, h2⟩ i hi
      by_cases h : i < n
      · exact h1 i h
      · rw [show i = n by omega]; exact h2
    · intro h
      exact ⟨fun i hi => h i (by omega), h n (by omega)⟩

/-! The test. -/

/-- From column k on: L loop blocks at phase f, then a state of the table at phase f or f + 4. -/
def loopPatternAt (k L f : Nat) {J : Nat} (S : Fin J → Bool) : Bool :=
  decide (k + 7 * L + 13 ≤ J) && blockOK f k S (7 * L) &&
    (memT f (window13 S (k + 7 * L)) table || memT ((f + 4) % 8) (window13 S (k + 7 * L)) table)

/-- The test for (1110)*: L loop blocks from column 1 on, then a state of the table. -/
def loopPattern (L f : Nat) {J : Nat} (S : Fin J → Bool) : Bool := loopPatternAt 0 L f S

theorem blockOK_drop (f k : Nat) {J : Nat} (S : Fin (J + 1) → Bool) :
    ∀ n, blockOK f (k + 1) S n = blockOK f k (dropBand S) n := by
  intro n
  induction n with
  | zero => rfl
  | succ n ih => simp only [blockOK, ih, win_drop]

theorem loopPatternAt_drop (k L f : Nat) {J : Nat} (S : Fin (J + 1) → Bool) :
    loopPatternAt (k + 1) L f S = loopPatternAt k L f (dropBand S) := by
  have hw : window13 S (k + 1 + 7 * L) = window13 (dropBand S) (k + 7 * L) := by
    apply window13_congr
    intro j _
    rw [win_drop, show k + 7 * L + 1 = k + 1 + 7 * L by omega]
  have hd : decide (k + 1 + 7 * L + 13 ≤ J + 1) = decide (k + 7 * L + 13 ≤ J) := by
    by_cases h : k + 7 * L + 13 ≤ J
    · rw [decide_eq_true h, decide_eq_true (by omega)]
    · rw [decide_eq_false h, decide_eq_false (by omega)]
  unfold loopPatternAt
  rw [hw, blockOK_drop, hd]

/-! Widening a certificate by free columns. -/

theorem widen_mem {w : List Bool} {J0 : Nat} (hJ0 : 0 < J0) (C : Certificate w J0 8) (f : Nat) :
    ∀ n (S : Fin (J0 + n) → Bool), C.R f (fun i : Fin J0 => S ⟨i.val, by omega⟩) →
      ∃ C' : Certificate w (J0 + n) 8, (∀ g, C'.value g = C.value g) ∧ C'.R f S := by
  intro n
  induction n with
  | zero => intro S h; exact ⟨C, fun _ => rfl, h⟩
  | succ n ih =>
    intro S h
    obtain ⟨C', hv, hC'⟩ := ih (restrictBand S) h
    exact ⟨certWiden (Nat.lt_of_lt_of_le hJ0 (Nat.le_add_right J0 n)) C', hv, hC'⟩

/-! The loop block as a definition. -/

/-- Seven loop columns in front of a band, at phase f. -/
def blockCons {J : Nat} (f : Nat) (S : Fin J → Bool) : Fin (J + 7) → Bool :=
  consBand (col L1 f) (consBand (col L2 f) (consBand (col L3 f) (consBand (col L3 f)
    (consBand (col L2 f) (consBand (col L6 f) (consBand (col drive f) S))))))

/-- The loop block in front of a certificate whose column 1 is 0 at phases 3 and 7 (the construction of
`loop_step`). -/
def loopBlock {J : Nat} (hJ : 0 < J) (C : Certificate drive J 8) (hper : ∀ f, C.value f = C.value (f % 8))
    (h3 : C.value 3 = false) (h7 : C.value 7 = false) : Certificate drive (J + 7) 8 :=
  let C7 := certCons (w := L6) hJ C (col drive) (fun _ => rfl) (rule_first C hper h3 h7)
  let C6 := certCons (w := L2) (by omega) C7 (col L6) (fun _ => rfl)
    (rule_known L2 L6 drive (by decide) (by decide) (by decide) (by decide))
  let C5 := certCons (w := L3) (by omega) C6 (col L2) (fun _ => rfl)
    (rule_known L3 L2 L6 (by decide) (by decide) (by decide) (by decide))
  let C4 := certCons (w := L3) (by omega) C5 (col L3) (fun _ => rfl)
    (rule_known L3 L3 L2 (by decide) (by decide) (by decide) (by decide))
  let C3 := certCons (w := L2) (by omega) C4 (col L3) (fun _ => rfl)
    (rule_known L2 L3 L3 (by decide) (by decide) (by decide) (by decide))
  let C2 := certCons (w := L1) (by omega) C3 (col L2) (fun _ => rfl)
    (rule_known L1 L2 L3 (by decide) (by decide) (by decide) (by decide))
  certCons (w := drive) (by omega) C2 (col L1) (fun _ => rfl)
    (rule_known drive L1 L2 (by decide) (by decide) (by decide) (by decide))

theorem loopBlock_value {J : Nat} (hJ : 0 < J) (C : Certificate drive J 8) (hper) (h3) (h7) (f : Nat) :
    (loopBlock hJ C hper h3 h7).value f = col L1 f := rfl

theorem loopBlock_mem {J : Nat} (hJ : 0 < J) (C : Certificate drive J 8) (hper) (h3) (h7) (f : Nat)
    (S : Fin J → Bool) (hS : C.R f S) : (loopBlock hJ C hper h3 h7).R f (blockCons f S) :=
  ⟨_, ⟨_, ⟨_, ⟨_, ⟨_, ⟨_, ⟨S, hS, rfl⟩, rfl⟩, rfl⟩, rfl⟩, rfl⟩, rfl⟩, rfl⟩

/-- Seven columns dropped. -/
def drop7 {J : Nat} (S : Fin (J + 7) → Bool) : Fin J → Bool :=
  dropBand (dropBand (dropBand (dropBand (dropBand (dropBand (dropBand S))))))

theorem consBand_zero {J : Nat} (a : Bool) (X : Fin J → Bool) (h : 0 < J + 1) : consBand a X ⟨0, h⟩ = a := rfl

theorem consBand_succ {J : Nat} (a : Bool) (X : Fin J → Bool) (i : Nat) (h : i + 1 < J + 1) :
    consBand a X ⟨i + 1, h⟩ = X ⟨i, by omega⟩ := by
  simp only [consBand]
  rw [dif_neg (by omega)]
  exact congrArg X (Fin.ext (by simp only []; omega))

theorem win_eq {J : Nat} (S : Fin J → Bool) (i : Nat) (hi : i < J) : win S 0 i = S ⟨i, hi⟩ := by
  unfold win
  rw [dif_pos (by omega)]
  exact congrArg S (Fin.ext (by simp only []; omega))

theorem blockCons_drop7 {J : Nat} (f : Nat) (S : Fin (J + 7) → Bool)
    (h : ∀ i, i < 7 → win S 0 i = blockWord i f) : blockCons f (drop7 S) = S := by
  funext ⟨i, hi⟩
  rcases i with _ | _ | _ | _ | _ | _ | _ | k
  · simp only [blockCons, consBand_zero]
    rw [← win_eq S _ hi, h _ (by omega)]; rfl
  · simp only [blockCons, consBand_succ, consBand_zero]
    rw [← win_eq S _ hi, h _ (by omega)]; rfl
  · simp only [blockCons, consBand_succ, consBand_zero]
    rw [← win_eq S _ hi, h _ (by omega)]; rfl
  · simp only [blockCons, consBand_succ, consBand_zero]
    rw [← win_eq S _ hi, h _ (by omega)]; rfl
  · simp only [blockCons, consBand_succ, consBand_zero]
    rw [← win_eq S _ hi, h _ (by omega)]; rfl
  · simp only [blockCons, consBand_succ, consBand_zero]
    rw [← win_eq S _ hi, h _ (by omega)]; rfl
  · simp only [blockCons, consBand_succ, consBand_zero]
    rw [← win_eq S _ hi, h _ (by omega)]; rfl
  · simp only [blockCons, consBand_succ]
    rfl

theorem loopPatternAt_drop7 (L f : Nat) {J : Nat} (S : Fin (J + 7) → Bool) :
    loopPatternAt 7 L f S = loopPatternAt 0 L f (drop7 S) :=
  (loopPatternAt_drop 6 L f S).trans <| (loopPatternAt_drop 5 L f _).trans <|
    (loopPatternAt_drop 4 L f _).trans <| (loopPatternAt_drop 3 L f _).trans <|
    (loopPatternAt_drop 2 L f _).trans <| (loopPatternAt_drop 1 L f _).trans <| loopPatternAt_drop 0 L f _

theorem first13_window {n : Nat} (S : Fin (13 + n) → Bool) :
    window13 (fun i : Fin 13 => S ⟨i.val, by omega⟩) 0 = window13 S 0 := by
  apply window13_congr
  intro j hj
  unfold win
  rw [dif_pos (by omega), dif_pos (by omega)]

/-- Every band that passes the test lies in a certificate for (1110)* of its width, whose column 1 is again 0 at
phases 3 and 7. -/
theorem loop_family (L : Nat) : ∀ (J f : Nat) (S : Fin J → Bool), loopPattern L f S = true →
    ∃ C : Certificate drive J 8, (∀ g, C.value g = C.value (g % 8)) ∧ C.value 3 = false ∧
      C.value 7 = false ∧ C.R f S := by
  induction L with
  | zero =>
    intro J f S hp
    simp only [loopPattern, loopPatternAt, Bool.and_eq_true, Bool.or_eq_true, decide_eq_true_eq] at hp
    obtain ⟨⟨hJ, _⟩, hm⟩ := hp
    obtain ⟨n, rfl⟩ : ∃ n, J = 13 + n := ⟨J - 13, by omega⟩
    have hw := first13_window S
    rcases hm with hm | hm
    · obtain ⟨C, hv, hC⟩ := widen_mem (by decide) base f n S
        (by show memT f (window13 _ 0) table = true; rw [hw]; exact hm)
      exact ⟨C, fun g => by rw [hv, hv]; exact base_per g, by rw [hv]; rfl, by rw [hv]; rfl, hC⟩
    · obtain ⟨C, hv, hC⟩ := widen_mem (by decide) base4 f n S
        (by show memT ((f + 4) % 8) (window13 _ 0) table = true; rw [hw]; exact hm)
      exact ⟨C, fun g => by rw [hv, hv]; exact base4_per g, by rw [hv]; rfl, by rw [hv]; rfl, hC⟩
  | succ L ih =>
    intro J f S hp
    have hp' := hp
    simp only [loopPattern, loopPatternAt, Bool.and_eq_true, Bool.or_eq_true, decide_eq_true_eq] at hp'
    obtain ⟨⟨hJ, hb⟩, hm⟩ := hp'
    obtain ⟨J', rfl⟩ : ∃ J', J = J' + 7 := ⟨J - 7, by omega⟩
    have hpre := (blockOK_spec f 0 S _).1 hb
    -- the first seven columns are a loop block
    have hcons : blockCons f (drop7 S) = S := blockCons_drop7 f S (fun i hi => hpre i (by omega))
    -- the rest passes the test with one block fewer
    have h7 : loopPatternAt 7 L f S = true := by
      simp only [loopPatternAt, Bool.and_eq_true, Bool.or_eq_true, decide_eq_true_eq]
      refine ⟨⟨by omega, ?_⟩, ?_⟩
      · apply (blockOK_spec f 7 S _).2
        intro i hi
        rw [win_zero, hpre (7 + i) (by omega), Nat.add_comm, blockWord_add7]
      · rw [show 7 + 7 * L = 0 + 7 * (L + 1) by omega]
        exact hm
    rw [loopPatternAt_drop7] at h7
    obtain ⟨C', hper', h3', h7', hC'⟩ := ih J' f (drop7 S) h7
    refine ⟨loopBlock (by omega) C' hper' h3' h7', fun g => L1_pins.1 g, L1_pins.2.1, L1_pins.2.2, ?_⟩
    rw [← hcons]
    exact loopBlock_mem _ C' hper' h3' h7' f _ hC'

/-! The open core with the explicit test. -/

/-- Every start supported in columns 1..K passes the test, with at most ℓ K loop blocks, by time f K. -/
def EntryBoundF (f ℓ : Nat → Nat) : Prop :=
  ∀ K (x0 : Nat → Bool), (∀ i, K < i → x0 i = false) →
    ∃ t0 L, t0 ≤ f K ∧ L ≤ ℓ K ∧
      loopPattern L (t0 % 8) (bandOf (rhc (pdrive drive) x0) (7 * L + 13) t0) = true

theorem bound_of_boundF (f ℓ : Nat → Nat) (h : EntryBoundF f ℓ) : EntryBound drive f := by
  intro K x0 hK
  obtain ⟨t0, L, ht, _, hp⟩ := h K x0 hK
  obtain ⟨C, _, _, _, hC⟩ := loop_family L (7 * L + 13) (t0 % 8) _ hp
  exact ⟨7 * L + 13, 8, t0, C, by omega, by decide, by decide, ht, hC⟩

theorem boundW_of_boundF (f ℓ : Nat → Nat) (h : EntryBoundF f ℓ) :
    EntryBoundW drive f (fun K => 7 * ℓ K + 13) (fun _ => 8) := by
  apply (boundW_iff_cert drive f _ _).2
  intro K x0 hK
  obtain ⟨t0, L, ht, hL, hp⟩ := h K x0 hK
  obtain ⟨C, _, _, _, hC⟩ := loop_family L (7 * L + 13) (t0 % 8) _ hp
  exact ⟨7 * L + 13, 8, t0, C, by omega, by omega, by decide, Nat.le_refl 8, by decide, ht, hC⟩

/-- The bridge for the pattern 1110: the explicit test, passed in bounded time by every finite start, gives
Problem 1 restricted to 1110. -/
theorem center_avoids_1110 (f ℓ : Nat → Nat) (h : EntryBoundF f ℓ) : ¬ EventuallyRepeats center30 drive :=
  center_avoids_of_bound drive (by decide) f (bound_of_boundF f ℓ h)

/-! The other words of period dividing 4. Each is the word of some column of the loop block, up to a phase
shift: 1000 is column 3 and column 4 (L3), 1100 is column 2 and column 5 (L2, shifted by 3) and column 6 (L6,
shifted by 2), and 10 is column 1 (L1). A band whose first columns are the block columns after that one, followed
by loop blocks and the base, lies in a certificate for that word. -/

/-- The drive (1100)*. -/
def driveC : List Bool := [true, true, false, false]

/-- The drive (10)*. -/
def driveB : List Bool := [true, false]

/-- Head columns: the block columns after column 4, after column 3, after column 6, after column 5, after
column 2 and after column 1. -/
def hdA3 : List (Nat → Bool) := [col L2, col L6, col drive]
def hdA4 : List (Nat → Bool) := [col L3, col L2, col L6, col drive]
def hdC1 : List (Nat → Bool) := [col drive]
def hdC2 : List (Nat → Bool) := [col L6, col drive]
def hdC5 : List (Nat → Bool) := [col L3, col L3, col L2, col L6, col drive]
def hdB6 : List (Nat → Bool) := [col L2, col L3, col L3, col L2, col L6, col drive]

/-- Head columns in front of a band, at phase g. -/
def headCons {J : Nat} (g : Nat) : (hd : List (Nat → Bool)) → (Fin J → Bool) → Fin (J + hd.length) → Bool
  | [], S => S
  | c :: cs, S => consBand (c g) (headCons g cs S)

/-- n columns dropped. -/
def dropN {J : Nat} : (n : Nat) → (Fin (J + n) → Bool) → Fin J → Bool
  | 0, S => S
  | n + 1, S => dropN n (dropBand S)

/-- Columns i, i + 1, ... of S are the head words at phase g. -/
def headOK (g : Nat) {J : Nat} (S : Fin J → Bool) : List (Nat → Bool) → Nat → Bool
  | [], _ => true
  | c :: cs, i => (win S 0 i == c g) && headOK g S cs (i + 1)

/-- The test for a word other than 1110: head columns, then L loop blocks, then a state of the table. -/
def headPattern (hd : List (Nat → Bool)) (L g : Nat) {J : Nat} (S : Fin J → Bool) : Bool :=
  headOK g S hd 0 && loopPatternAt hd.length L g S

theorem headOK_drop (g : Nat) {J : Nat} (S : Fin (J + 1) → Bool) :
    ∀ (cs : List (Nat → Bool)) (i : Nat), headOK g S cs (i + 1) = headOK g (dropBand S) cs i := by
  intro cs
  induction cs with
  | nil => intro i; rfl
  | cons c cs ih =>
    intro i
    simp only [headOK]
    rw [ih (i + 1), win_drop, win_zero S 1 i, Nat.add_comm 1 i]

theorem headCons_drop (g : Nat) {J : Nat} :
    ∀ (hd : List (Nat → Bool)) (S : Fin (J + hd.length) → Bool), headOK g S hd 0 = true →
      headCons g hd (dropN hd.length S) = S := by
  intro hd
  induction hd with
  | nil => intro S _; rfl
  | cons c cs ih =>
    intro S h
    simp only [headOK, Bool.and_eq_true, beq_iff_eq] at h
    obtain ⟨h0, h1⟩ := h
    rw [headOK_drop] at h1
    have e := ih (dropBand S) h1
    show consBand (c g) (headCons g cs (dropN cs.length (dropBand S))) = S
    rw [e, ← h0, win_eq S 0 (by show 0 < J + (cs.length + 1); omega)]
    exact consBand_drop S

theorem loopPatternAt_dropN (L g : Nat) {J : Nat} :
    ∀ (n : Nat) (S : Fin (J + n) → Bool) (k : Nat), loopPatternAt (k + n) L g S = loopPatternAt k L g (dropN n S) := by
  intro n
  induction n with
  | zero => intro S k; rfl
  | succ n ih =>
    intro S k
    show loopPatternAt ((k + n) + 1) L g S = loopPatternAt k L g (dropN n (dropBand S))
    rw [loopPatternAt_drop, ih]

/-- A band passing the head test, with the head dropped, passes the (1110)* test at the same phase. -/
theorem head_split (hd : List (Nat → Bool)) (L g : Nat) {J : Nat} (S : Fin (J + hd.length) → Bool)
    (hp : headPattern hd L g S = true) :
    headCons g hd (dropN hd.length S) = S ∧ loopPattern L g (dropN hd.length S) = true := by
  simp only [headPattern, Bool.and_eq_true] at hp
  refine ⟨headCons_drop g hd S hp.1, ?_⟩
  have := loopPatternAt_dropN L g hd.length S 0
  rw [Nat.zero_add] at this
  show loopPatternAt 0 L g (dropN hd.length S) = true
  rw [← this]
  exact hp.2

/-! The partial chains of the loop block, from the column next to the certificate. -/
section chains

variable {J : Nat} (hJ : 0 < J) (C : Certificate drive J 8) (hper : ∀ f, C.value f = C.value (f % 8))
  (h3 : C.value 3 = false) (h7 : C.value 7 = false)

def ch7 : Certificate L6 (J + 1) 8 :=
  certCons (w := L6) hJ C (col drive) (fun _ => rfl) (rule_first C hper h3 h7)

def ch6 : Certificate L2 (J + 2) 8 :=
  certCons (w := L2) (Nat.succ_pos J) (ch7 hJ C hper h3 h7) (col L6) (fun _ => rfl)
    (rule_known L2 L6 drive (by decide) (by decide) (by decide) (by decide))

def ch5 : Certificate L3 (J + 3) 8 :=
  certCons (w := L3) (Nat.succ_pos (J + 1)) (ch6 hJ C hper h3 h7) (col L2) (fun _ => rfl)
    (rule_known L3 L2 L6 (by decide) (by decide) (by decide) (by decide))

def ch4 : Certificate L3 (J + 4) 8 :=
  certCons (w := L3) (Nat.succ_pos (J + 2)) (ch5 hJ C hper h3 h7) (col L3) (fun _ => rfl)
    (rule_known L3 L3 L2 (by decide) (by decide) (by decide) (by decide))

def ch3 : Certificate L2 (J + 5) 8 :=
  certCons (w := L2) (Nat.succ_pos (J + 3)) (ch4 hJ C hper h3 h7) (col L3) (fun _ => rfl)
    (rule_known L2 L3 L3 (by decide) (by decide) (by decide) (by decide))

def ch2 : Certificate L1 (J + 6) 8 :=
  certCons (w := L1) (Nat.succ_pos (J + 4)) (ch3 hJ C hper h3 h7) (col L2) (fun _ => rfl)
    (rule_known L1 L2 L3 (by decide) (by decide) (by decide) (by decide))

/-- (1000)*, three head columns. -/
def chA3 : Certificate LoopTranslation.driveA (J + 3) 8 :=
  certCons (w := LoopTranslation.driveA) (Nat.succ_pos (J + 1)) (ch6 hJ C hper h3 h7) (col L2) (fun _ => rfl)
    (rule_known LoopTranslation.driveA L2 L6 (by decide) (by decide) (by decide) (by decide))

/-- (1000)*, four head columns. -/
def chA4 : Certificate LoopTranslation.driveA (J + 4) 8 :=
  certCons (w := LoopTranslation.driveA) (Nat.succ_pos (J + 2)) (ch5 hJ C hper h3 h7) (col L3) (fun _ => rfl)
    (rule_known LoopTranslation.driveA L3 L2 (by decide) (by decide) (by decide) (by decide))

end chains

theorem driveC_L6 : ∀ f, driveC.getD (f % driveC.length) false = L6.getD (((f + 2) % 8) % L6.length) false := by
  intro f
  show driveC.getD (f % 4) false = L6.getD (((f + 2) % 8) % 8) false
  rw [show f % 4 = (f % 8) % 4 by omega, show ((f + 2) % 8) % 8 = (f % 8 + 2) % 8 by omega]
  have key : ∀ g, g < 8 → driveC.getD (g % 4) false = L6.getD ((g + 2) % 8) false := by decide
  exact key _ (Nat.mod_lt _ (by decide))

theorem driveC_L2 : ∀ f, driveC.getD (f % driveC.length) false = L2.getD (((f + 3) % 8) % L2.length) false := by
  intro f
  show driveC.getD (f % 4) false = L2.getD (((f + 3) % 8) % 8) false
  rw [show f % 4 = (f % 8) % 4 by omega, show ((f + 3) % 8) % 8 = (f % 8 + 3) % 8 by omega]
  have key : ∀ g, g < 8 → driveC.getD (g % 4) false = L2.getD ((g + 3) % 8) false := by decide
  exact key _ (Nat.mod_lt _ (by decide))

theorem driveB_L1 : ∀ f, driveB.getD (f % driveB.length) false = L1.getD (((f + 0) % 8) % L1.length) false := by
  intro f
  show driveB.getD (f % 2) false = L1.getD (((f + 0) % 8) % 8) false
  rw [show f % 2 = (f % 8) % 2 by omega, show ((f + 0) % 8) % 8 = f % 8 by omega]
  have key : ∀ g, g < 8 → driveB.getD (g % 2) false = L1.getD g false := by decide
  exact key _ (Nat.mod_lt _ (by decide))

/-- From the (1110)* family to a certificate for a head family, at the unshifted phase g. -/
theorem family_head (L g : Nat) {J : Nat} (hd : List (Nat → Bool)) (S : Fin (J + hd.length) → Bool)
    (hp : headPattern hd L g S = true) :
    ∃ C : Certificate drive J 8, 0 < J ∧ (∀ f, C.value f = C.value (f % 8)) ∧ C.value 3 = false ∧
      C.value 7 = false ∧ C.R g (dropN hd.length S) ∧ headCons g hd (dropN hd.length S) = S := by
  obtain ⟨hc, hl⟩ := head_split hd L g S hp
  have hJ : 0 < J := by
    simp only [loopPattern, loopPatternAt, Bool.and_eq_true, decide_eq_true_eq] at hl
    omega
  obtain ⟨C, hper, h3, h7, hC⟩ := loop_family L J g _ hl
  exact ⟨C, hJ, hper, h3, h7, hC, hc⟩

theorem family_A3 (L f : Nat) {J : Nat} (S : Fin (J + 3) → Bool) (hp : headPattern hdA3 L f S = true) :
    ∃ C : Certificate LoopTranslation.driveA (J + 3) 8, C.R f S := by
  obtain ⟨C, hJ, hper, h3, h7, hC, hc⟩ := family_head L f hdA3 S hp
  refine ⟨chA3 hJ C hper h3 h7, ?_⟩
  rw [← hc]
  exact ⟨_, ⟨_, ⟨_, hC, rfl⟩, rfl⟩, rfl⟩

theorem family_A4 (L f : Nat) {J : Nat} (S : Fin (J + 4) → Bool) (hp : headPattern hdA4 L f S = true) :
    ∃ C : Certificate LoopTranslation.driveA (J + 4) 8, C.R f S := by
  obtain ⟨C, hJ, hper, h3, h7, hC, hc⟩ := family_head L f hdA4 S hp
  refine ⟨chA4 hJ C hper h3 h7, ?_⟩
  rw [← hc]
  exact ⟨_, ⟨_, ⟨_, ⟨_, hC, rfl⟩, rfl⟩, rfl⟩, rfl⟩

theorem family_C1 (L f : Nat) {J : Nat} (S : Fin (J + 1) → Bool)
    (hp : headPattern hdC1 L ((f + 2) % 8) S = true) : ∃ C : Certificate driveC (J + 1) 8, C.R f S := by
  obtain ⟨C, hJ, hper, h3, h7, hC, hc⟩ := family_head L ((f + 2) % 8) hdC1 S hp
  refine ⟨certShift 2 (ch7 hJ C hper h3 h7) driveC_L6, ?_⟩
  show (ch7 hJ C hper h3 h7).R ((f + 2) % 8) S
  rw [← hc]
  exact ⟨_, hC, rfl⟩

theorem family_C2 (L f : Nat) {J : Nat} (S : Fin (J + 2) → Bool)
    (hp : headPattern hdC2 L ((f + 3) % 8) S = true) : ∃ C : Certificate driveC (J + 2) 8, C.R f S := by
  obtain ⟨C, hJ, hper, h3, h7, hC, hc⟩ := family_head L ((f + 3) % 8) hdC2 S hp
  refine ⟨certShift 3 (ch6 hJ C hper h3 h7) driveC_L2, ?_⟩
  show (ch6 hJ C hper h3 h7).R ((f + 3) % 8) S
  rw [← hc]
  exact ⟨_, ⟨_, hC, rfl⟩, rfl⟩

theorem family_C5 (L f : Nat) {J : Nat} (S : Fin (J + 5) → Bool)
    (hp : headPattern hdC5 L ((f + 3) % 8) S = true) : ∃ C : Certificate driveC (J + 5) 8, C.R f S := by
  obtain ⟨C, hJ, hper, h3, h7, hC, hc⟩ := family_head L ((f + 3) % 8) hdC5 S hp
  refine ⟨certShift 3 (ch3 hJ C hper h3 h7) driveC_L2, ?_⟩
  show (ch3 hJ C hper h3 h7).R ((f + 3) % 8) S
  rw [← hc]
  exact ⟨_, ⟨_, ⟨_, ⟨_, ⟨_, hC, rfl⟩, rfl⟩, rfl⟩, rfl⟩, rfl⟩

theorem family_B6 (L f : Nat) {J : Nat} (S : Fin (J + 6) → Bool)
    (hp : headPattern hdB6 L ((f + 0) % 8) S = true) : ∃ C : Certificate driveB (J + 6) 8, C.R f S := by
  obtain ⟨C, hJ, hper, h3, h7, hC, hc⟩ := family_head L ((f + 0) % 8) hdB6 S hp
  refine ⟨certShift 0 (ch2 hJ C hper h3 h7) driveB_L1, ?_⟩
  show (ch2 hJ C hper h3 h7).R ((f + 0) % 8) S
  rw [← hc]
  exact ⟨_, ⟨_, ⟨_, ⟨_, ⟨_, ⟨_, hC, rfl⟩, rfl⟩, rfl⟩, rfl⟩, rfl⟩, rfl⟩

/-! The bridges for the other words. -/

/-- (1000)*: every finite start passes one of the two head tests by time f K. -/
def EntryBoundA (f ℓ : Nat → Nat) : Prop :=
  ∀ K (x0 : Nat → Bool), (∀ i, K < i → x0 i = false) → ∃ t0 L, t0 ≤ f K ∧ L ≤ ℓ K ∧
    (headPattern hdA3 L (t0 % 8) (bandOf (rhc (pdrive LoopTranslation.driveA) x0) (7 * L + 13 + 3) t0) = true ∨
     headPattern hdA4 L (t0 % 8) (bandOf (rhc (pdrive LoopTranslation.driveA) x0) (7 * L + 13 + 4) t0) = true)

/-- (1100)*: every finite start passes one of the three head tests by time f K. -/
def EntryBoundC (f ℓ : Nat → Nat) : Prop :=
  ∀ K (x0 : Nat → Bool), (∀ i, K < i → x0 i = false) → ∃ t0 L, t0 ≤ f K ∧ L ≤ ℓ K ∧
    (headPattern hdC1 L ((t0 % 8 + 2) % 8) (bandOf (rhc (pdrive driveC) x0) (7 * L + 13 + 1) t0) = true ∨
     headPattern hdC2 L ((t0 % 8 + 3) % 8) (bandOf (rhc (pdrive driveC) x0) (7 * L + 13 + 2) t0) = true ∨
     headPattern hdC5 L ((t0 % 8 + 3) % 8) (bandOf (rhc (pdrive driveC) x0) (7 * L + 13 + 5) t0) = true)

/-- (10)*: every finite start passes the head test by time f K. -/
def EntryBoundB (f ℓ : Nat → Nat) : Prop :=
  ∀ K (x0 : Nat → Bool), (∀ i, K < i → x0 i = false) → ∃ t0 L, t0 ≤ f K ∧ L ≤ ℓ K ∧
    headPattern hdB6 L ((t0 % 8 + 0) % 8) (bandOf (rhc (pdrive driveB) x0) (7 * L + 13 + 6) t0) = true

theorem bound_of_boundA (f ℓ : Nat → Nat) (h : EntryBoundA f ℓ) : EntryBound LoopTranslation.driveA f := by
  intro K x0 hK
  obtain ⟨t0, L, ht, _, hp | hp⟩ := h K x0 hK
  · obtain ⟨C, hC⟩ := family_A3 L (t0 % 8) _ hp
    exact ⟨_, 8, t0, C, by omega, by decide, by decide, ht, hC⟩
  · obtain ⟨C, hC⟩ := family_A4 L (t0 % 8) _ hp
    exact ⟨_, 8, t0, C, by omega, by decide, by decide, ht, hC⟩

theorem bound_of_boundC (f ℓ : Nat → Nat) (h : EntryBoundC f ℓ) : EntryBound driveC f := by
  intro K x0 hK
  obtain ⟨t0, L, ht, _, hp | hp | hp⟩ := h K x0 hK
  · obtain ⟨C, hC⟩ := family_C1 L (t0 % 8) _ hp
    exact ⟨_, 8, t0, C, by omega, by decide, by decide, ht, hC⟩
  · obtain ⟨C, hC⟩ := family_C2 L (t0 % 8) _ hp
    exact ⟨_, 8, t0, C, by omega, by decide, by decide, ht, hC⟩
  · obtain ⟨C, hC⟩ := family_C5 L (t0 % 8) _ hp
    exact ⟨_, 8, t0, C, by omega, by decide, by decide, ht, hC⟩

theorem bound_of_boundB (f ℓ : Nat → Nat) (h : EntryBoundB f ℓ) : EntryBound driveB f := by
  intro K x0 hK
  obtain ⟨t0, L, ht, _, hp⟩ := h K x0 hK
  obtain ⟨C, hC⟩ := family_B6 L (t0 % 8) _ hp
  exact ⟨_, 8, t0, C, by omega, by decide, by decide, ht, hC⟩

theorem center_avoids_1000 (f ℓ : Nat → Nat) (h : EntryBoundA f ℓ) :
    ¬ EventuallyRepeats center30 LoopTranslation.driveA :=
  center_avoids_of_bound _ (by decide) f (bound_of_boundA f ℓ h)

theorem center_avoids_1100 (f ℓ : Nat → Nat) (h : EntryBoundC f ℓ) : ¬ EventuallyRepeats center30 driveC :=
  center_avoids_of_bound _ (by decide) f (bound_of_boundC f ℓ h)

theorem center_avoids_10 (f ℓ : Nat → Nat) (h : EntryBoundB f ℓ) : ¬ EventuallyRepeats center30 driveB :=
  center_avoids_of_bound _ (by decide) f (bound_of_boundB f ℓ h)

end LoopFamily
