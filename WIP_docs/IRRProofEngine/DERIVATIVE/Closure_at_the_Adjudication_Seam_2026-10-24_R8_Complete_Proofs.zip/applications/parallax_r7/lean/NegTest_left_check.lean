import LeftCheck
open LeftBreak LeftCheck
/-! Negative test: the finite check can fail. With bound 0 (resp. 1) most starts have not broken yet, so the check
is false; the kernel confirms it. -/
theorem neg_check_1110 : leftCheck w1110 0 8 = false := by decide +kernel
theorem neg_check_10 : leftCheck w10 1 5 = false := by decide +kernel
#print axioms neg_check_1110
#print axioms neg_check_10
