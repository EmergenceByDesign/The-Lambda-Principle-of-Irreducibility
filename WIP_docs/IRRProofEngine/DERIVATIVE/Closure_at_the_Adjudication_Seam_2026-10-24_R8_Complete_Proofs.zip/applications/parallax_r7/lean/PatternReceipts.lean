import LoopFamily

/-!
Receipts inside Lean, 23 October 2026. Claude, with Lu Semita.

`EntryBoundF` asks every finite start to pass the explicit test of `LoopFamily` by a bounded time. Each width is a
finite check, and this file lets Lean's kernel carry out that check. Rows of the right half are numbers (bit i is
column i + 1), and `rowN_spec` proves them equal to `rhc`. For a width K, a list of witnesses gives, for every start
number s < 2^K, a time t0 and a number L of loop blocks; `checkW` verifies each one by computing the row at t0 and
evaluating the test, and `receiptW` turns a successful check into the statement about every start supported in
columns 1..K. The witnesses come from the scan; Lean checks them, so the scan is not part of the trust chain.
-/

namespace PatternReceipts

open Rule30Bridge RightHalf UniformWindow ShieldEntry EntryBridge ClosureCheck LoopTranslation BaseCertificate
  LoopFamily

/-! Rows as numbers. -/

/-- A bit as a number. -/
def bitN (d : Bool) : Nat := if d then 1 else 0

theorem testBit_bitN (d : Bool) (m : Nat) : (bitN d).testBit m = (decide (m = 0) && d) := by
  cases d with
  | false =>
    show (0 : Nat).testBit m = (decide (m = 0) && false)
    rw [Nat.zero_testBit, Bool.and_false]
  | true =>
    cases m with
    | zero => rfl
    | succ n =>
      show (1 : Nat).testBit (n + 1) = (decide (n + 1 = 0) && true)
      rw [Nat.testBit_add_one, show (1 : Nat) / 2 = 0 from rfl, Nat.zero_testBit,
        decide_eq_false (Nat.succ_ne_zero n), Bool.false_and]

/-- One step of a row; d enters at column 0. -/
def stepN (d : Bool) (r : Nat) : Nat := ((r <<< 1) ||| bitN d) ^^^ (r ||| (r >>> 1))

theorem stepN_testBit (d : Bool) (r m : Nat) :
    (stepN d r).testBit m = Bool.xor (if m = 0 then d else r.testBit (m - 1)) (r.testBit m || r.testBit (m + 1)) := by
  unfold stepN
  rw [Nat.testBit_xor, Nat.testBit_or, Nat.testBit_or, Nat.testBit_shiftLeft, Nat.testBit_shiftRight, testBit_bitN]
  cases m with
  | zero =>
    rw [decide_eq_false (by omega : ¬ (0 ≥ 1)), decide_eq_true (rfl : 0 = 0), if_pos rfl, Bool.false_and,
      Bool.false_or, Bool.true_and, Nat.add_comm 1 0]
  | succ k =>
    rw [decide_eq_true (by omega : k + 1 ≥ 1), decide_eq_false (by omega : ¬ (k + 1 = 0)), Nat.add_sub_cancel,
      if_neg (by omega), Nat.add_comm 1 (k + 1), Bool.true_and, Bool.false_and, Bool.or_false]

/-- The row at time t, from the start number s. -/
def rowN (b : Nat → Bool) (s : Nat) : Nat → Nat
  | 0 => s
  | t + 1 => stepN (b t) (rowN b s t)

/-- The start a number describes: column i is bit i - 1. -/
def seedOfN (s : Nat) (i : Nat) : Bool := if i = 0 then false else s.testBit (i - 1)

theorem rowN_spec (b : Nat → Bool) (s : Nat) : ∀ t m, (rowN b s t).testBit m = rhc b (seedOfN s) t (m + 1) := by
  intro t
  induction t with
  | zero =>
    intro m
    show s.testBit m = seedOfN s (m + 1)
    simp only [seedOfN, Nat.add_sub_cancel]
    rfl
  | succ t ih =>
    intro m
    show (stepN (b t) (rowN b s t)).testBit m =
      Bool.xor (rhc b (seedOfN s) t m) (rhc b (seedOfN s) t (m + 1) || rhc b (seedOfN s) t (m + 2))
    rw [stepN_testBit, ih m, ih (m + 1)]
    cases m with
    | zero =>
      rw [if_pos rfl]
      cases t <;> rfl
    | succ m =>
      rw [if_neg (by omega), Nat.add_sub_cancel, ih m]

/-! Starts as numbers. -/

/-- A list of bits as a number, first bit lowest. -/
def ofBits : List Bool → Nat
  | [] => 0
  | a :: l => bitN a + 2 * ofBits l

theorem ofBits_testBit : ∀ (l : List Bool) (i : Nat), (ofBits l).testBit i = l.getD i false
  | [], i => by
    show (0 : Nat).testBit i = ([] : List Bool).getD i false
    rw [Nat.zero_testBit]
    cases i <;> rfl
  | a :: l, i => by
    cases i with
    | zero =>
      rw [Nat.testBit_zero]
      cases a
      · show decide ((0 + 2 * ofBits l) % 2 = 1) = false
        exact decide_eq_false (by omega)
      · show decide ((1 + 2 * ofBits l) % 2 = 1) = true
        exact decide_eq_true (by omega)
    | succ i =>
      rw [Nat.testBit_add_one]
      have : (bitN a + 2 * ofBits l) / 2 = ofBits l := by
        cases a
        · show (0 + 2 * ofBits l) / 2 = ofBits l; omega
        · show (1 + 2 * ofBits l) / 2 = ofBits l; omega
      show ((bitN a + 2 * ofBits l) / 2).testBit i = l.getD i false
      rw [this, ofBits_testBit l i]

theorem ofBits_lt : ∀ l : List Bool, ofBits l < 2 ^ l.length
  | [] => by decide
  | a :: l => by
    have h := ofBits_lt l
    show bitN a + 2 * ofBits l < 2 ^ (l.length + 1)
    rw [Nat.pow_succ]
    cases a
    · show 0 + 2 * ofBits l < 2 ^ l.length * 2; omega
    · show 1 + 2 * ofBits l < 2 ^ l.length * 2; omega

/-- Columns s, s + 1, ..., s + n - 1 of a start, as a list. -/
def takeCols (x0 : Nat → Bool) : Nat → Nat → List Bool
  | _, 0 => []
  | s, n + 1 => x0 s :: takeCols x0 (s + 1) n

theorem getD_nil (m : Nat) : ([] : List Bool).getD m false = false := by
  cases m <;> rfl

theorem takeCols_getD (x0 : Nat → Bool) :
    ∀ n s j, (takeCols x0 s n).getD j false = if j < n then x0 (s + j) else false := by
  intro n
  induction n with
  | zero =>
    intro s j
    show ([] : List Bool).getD j false = _
    rw [getD_nil, if_neg (Nat.not_lt_zero j)]
  | succ n ih =>
    intro s j
    cases j with
    | zero => show x0 s = _; rw [if_pos (by omega), Nat.add_zero]
    | succ j =>
      show (takeCols x0 (s + 1) n).getD j false = _
      rw [ih (s + 1) j]
      by_cases h : j < n
      · rw [if_pos h, if_pos (by omega), show s + 1 + j = s + (j + 1) by omega]
      · rw [if_neg h, if_neg (by omega)]

theorem takeCols_length (x0 : Nat → Bool) : ∀ n s, (takeCols x0 s n).length = n := by
  intro n
  induction n with
  | zero => intro s; rfl
  | succ n ih => intro s; show (takeCols x0 (s + 1) n).length + 1 = n + 1; rw [ih]

/-- The start number of a start supported in columns 1..K. -/
def startNum (x0 : Nat → Bool) (K : Nat) : Nat := ofBits (takeCols x0 1 K)

theorem startNum_lt (x0 : Nat → Bool) (K : Nat) : startNum x0 K < 2 ^ K := by
  have h := ofBits_lt (takeCols x0 1 K)
  rw [takeCols_length] at h
  exact h

theorem bandOf_start (b : Nat → Bool) (x0 : Nat → Bool) (K : Nat) (hK : ∀ i, K < i → x0 i = false) (J t : Nat) :
    bandOf (rhc b x0) J t = fun i => (rowN b (startNum x0 K) t).testBit i.val := by
  funext i
  rw [rowN_spec]
  simp only [bandOf]
  refine rhc_cone _ _ _ _ t (i.val + 1) (by omega) (fun _ _ => rfl) (fun j hj _ => ?_)
  unfold seedOfN startNum
  rw [if_neg (by omega), ofBits_testBit, takeCols_getD]
  by_cases h : j - 1 < K
  · rw [if_pos h, show 1 + (j - 1) = j by omega]
  · rw [if_neg h, hK j (by omega)]

/-! The check, with witnesses. -/

/-- The entries (t0, L) are witnesses for the start numbers s, s + 1, ... in order. -/
def checkW (b : Nat → Bool) (pass : Nat → Nat → Nat → Bool) (T Lmax : Nat) : Nat → List (Nat × Nat) → Bool
  | _, [] => true
  | s, w :: ws => decide (w.1 ≤ T) && decide (w.2 ≤ Lmax) && pass (rowN b s w.1) w.1 w.2 &&
      checkW b pass T Lmax (s + 1) ws

theorem checkW_sound (b : Nat → Bool) (pass : Nat → Nat → Nat → Bool) (T Lmax : Nat) :
    ∀ (ws : List (Nat × Nat)) (s0 : Nat), checkW b pass T Lmax s0 ws = true →
      ∀ s, s0 ≤ s → s < s0 + ws.length → ∃ t0 L, t0 ≤ T ∧ L ≤ Lmax ∧ pass (rowN b s t0) t0 L = true := by
  intro ws
  induction ws with
  | nil => intro s0 _ s h1 h2; rw [List.length_nil] at h2; exfalso; omega
  | cons w ws ih =>
    intro s0 h s h1 h2
    simp only [checkW, Bool.and_eq_true, decide_eq_true_eq] at h
    obtain ⟨⟨⟨ht, hL⟩, hp⟩, hrest⟩ := h
    rcases Nat.eq_or_lt_of_le h1 with hs | hs
    · subst hs
      exact ⟨w.1, w.2, ht, hL, hp⟩
    · exact ih (s0 + 1) hrest s hs (by rw [List.length_cons] at h2; omega)

theorem checkW_append_true (b : Nat → Bool) (pass : Nat → Nat → Nat → Bool) (T Lmax : Nat) :
    ∀ (ws1 ws2 : List (Nat × Nat)) (s0 : Nat), checkW b pass T Lmax s0 ws1 = true →
      checkW b pass T Lmax (s0 + ws1.length) ws2 = true → checkW b pass T Lmax s0 (ws1 ++ ws2) = true := by
  intro ws1
  induction ws1 with
  | nil => intro ws2 s0 _ h2; exact h2
  | cons w ws ih =>
    intro ws2 s0 h1 h2
    simp only [List.cons_append, checkW, Bool.and_eq_true] at h1 ⊢
    refine ⟨h1.1, ih ws2 (s0 + 1) h1.2 ?_⟩
    rw [show s0 + 1 + ws.length = s0 + (w :: ws).length by rw [List.length_cons]; omega]
    exact h2

/-- A successful check at width K, with 2^K witnesses, covers every start supported in columns 1..K. -/
theorem receiptW (b : Nat → Bool) (pass : Nat → Nat → Nat → Bool) (K T Lmax : Nat) (ws : List (Nat × Nat))
    (hlen : ws.length = 2 ^ K) (h : checkW b pass T Lmax 0 ws = true) :
    ∀ x0 : Nat → Bool, ∃ t0 L, t0 ≤ T ∧ L ≤ Lmax ∧ pass (rowN b (startNum x0 K) t0) t0 L = true := by
  intro x0
  exact checkW_sound b pass T Lmax ws 0 h (startNum x0 K) (Nat.zero_le _) (by rw [hlen]; have := startNum_lt x0 K; omega)

/-! The tests of `LoopFamily` on numbers. -/

/-- The first J columns of a row, as a band. -/
def rowBandN (r J : Nat) : Fin J → Bool := fun i => r.testBit i.val

def pass1110 (r t L : Nat) : Bool := loopPattern L (t % 8) (rowBandN r (7 * L + 13))

def pass1000 (r t L : Nat) : Bool :=
  headPattern hdA3 L (t % 8) (rowBandN r (7 * L + 13 + 3)) ||
    headPattern hdA4 L (t % 8) (rowBandN r (7 * L + 13 + 4))

def pass1100 (r t L : Nat) : Bool :=
  headPattern hdC1 L ((t % 8 + 2) % 8) (rowBandN r (7 * L + 13 + 1)) ||
    (headPattern hdC2 L ((t % 8 + 3) % 8) (rowBandN r (7 * L + 13 + 2)) ||
      headPattern hdC5 L ((t % 8 + 3) % 8) (rowBandN r (7 * L + 13 + 5)))

/-- The width-K instance of `EntryBoundF`, from a successful check. -/
theorem receipt_1110 (K T Lmax : Nat) (ws : List (Nat × Nat)) (hlen : ws.length = 2 ^ K)
    (h : checkW (pdrive drive) pass1110 T Lmax 0 ws = true) :
    ∀ x0 : Nat → Bool, (∀ i, K < i → x0 i = false) → ∃ t0 L, t0 ≤ T ∧ L ≤ Lmax ∧
      loopPattern L (t0 % 8) (bandOf (rhc (pdrive drive) x0) (7 * L + 13) t0) = true := by
  intro x0 hK
  obtain ⟨t0, L, ht, hL, hp⟩ := receiptW _ _ K T Lmax ws hlen h x0
  refine ⟨t0, L, ht, hL, ?_⟩
  rw [bandOf_start _ x0 K hK]
  exact hp

/-- The width-K instance of `EntryBoundA`, from a successful check. -/
theorem receipt_1000 (K T Lmax : Nat) (ws : List (Nat × Nat)) (hlen : ws.length = 2 ^ K)
    (h : checkW (pdrive LoopTranslation.driveA) pass1000 T Lmax 0 ws = true) :
    ∀ x0 : Nat → Bool, (∀ i, K < i → x0 i = false) → ∃ t0 L, t0 ≤ T ∧ L ≤ Lmax ∧
      (headPattern hdA3 L (t0 % 8) (bandOf (rhc (pdrive LoopTranslation.driveA) x0) (7 * L + 13 + 3) t0) = true ∨
       headPattern hdA4 L (t0 % 8) (bandOf (rhc (pdrive LoopTranslation.driveA) x0) (7 * L + 13 + 4) t0) = true) := by
  intro x0 hK
  obtain ⟨t0, L, ht, hL, hp⟩ := receiptW _ _ K T Lmax ws hlen h x0
  refine ⟨t0, L, ht, hL, ?_⟩
  rw [bandOf_start _ x0 K hK, bandOf_start _ x0 K hK]
  simpa only [pass1000, Bool.or_eq_true] using hp

/-- The width-K instance of `EntryBoundC`, from a successful check. -/
theorem receipt_1100 (K T Lmax : Nat) (ws : List (Nat × Nat)) (hlen : ws.length = 2 ^ K)
    (h : checkW (pdrive driveC) pass1100 T Lmax 0 ws = true) :
    ∀ x0 : Nat → Bool, (∀ i, K < i → x0 i = false) → ∃ t0 L, t0 ≤ T ∧ L ≤ Lmax ∧
      (headPattern hdC1 L ((t0 % 8 + 2) % 8) (bandOf (rhc (pdrive driveC) x0) (7 * L + 13 + 1) t0) = true ∨
       headPattern hdC2 L ((t0 % 8 + 3) % 8) (bandOf (rhc (pdrive driveC) x0) (7 * L + 13 + 2) t0) = true ∨
       headPattern hdC5 L ((t0 % 8 + 3) % 8) (bandOf (rhc (pdrive driveC) x0) (7 * L + 13 + 5) t0) = true) := by
  intro x0 hK
  obtain ⟨t0, L, ht, hL, hp⟩ := receiptW _ _ K T Lmax ws hlen h x0
  refine ⟨t0, L, ht, hL, ?_⟩
  rw [bandOf_start _ x0 K hK, bandOf_start _ x0 K hK, bandOf_start _ x0 K hK]
  simpa only [pass1100, Bool.or_eq_true] using hp

end PatternReceipts
