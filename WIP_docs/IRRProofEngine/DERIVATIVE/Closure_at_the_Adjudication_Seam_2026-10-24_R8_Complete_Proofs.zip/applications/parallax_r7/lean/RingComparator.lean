import LeftBreak
import LoopTranslation
import JointBreak

/-!
The closed-world comparator, 23–24 October 2026. Claude, with Lu Semita.

Rule 30 on a ring of 7 cells has an orbit of period 4. Its seven columns are, read rightward from cell 0, exactly
the seven columns of the loop block of `LoopTranslation` and `LoopFamily`: L1, L2, L3, L3, L2, L6, and then the
drive word 1110 again (`loop_block_is_the_ring_orbit`). The right side's certificates are copies of this closed
world unrolled into the half-line.

Read leftward from a cell, the same orbit is a left start that keeps the black values of that cell's word forever
(`ring_start_never_breaks`): every local law at the center holds, because it is Rule 30 itself. That start is not
finite (`ringStart_not_finite`). So the finiteness hypothesis of `LeftBreak.EveryLeftStartBreaks` cannot be
dropped: without it the statement is false for 1110, 1000, 1100 and 10
(`without_finiteness_the_pattern_fails_*`). Read both ways from the drive cell, the orbit keeps the center's own rule
(`ring_pair_never_violates`), so the two-sided premise of `JointBreak` fails without finiteness too
(`without_finiteness_the_two_sided_premise_fails_*`). Whatever proves these premises has to use the open edge of the
light cone, which the closed world lacks.
-/

namespace RingComparator

open LeftBreak UniformWindow JointBreak

/-- The four states of the orbit, bit j for cell j. -/
def st : Nat → Nat
  | 0 => 63
  | 1 => 1
  | 2 => 67
  | _ => 100

/-- Cell j of the 7-cell ring at time a, both read cyclically. -/
def ring (a j : Nat) : Bool := (st (a % 4)).testBit (j % 7)

theorem ring_rule_small : ∀ a, a < 4 → ∀ j, j < 7 →
    (st ((a + 1) % 4)).testBit j =
      Bool.xor ((st a).testBit ((j + 6) % 7)) ((st a).testBit j || (st a).testBit ((j + 1) % 7)) := by
  decide

/-- Rule 30 on the ring: new cell j = old cell j - 1 xor (old cell j or old cell j + 1). -/
theorem ring_rule (a j : Nat) :
    ring (a + 1) j = Bool.xor (ring a (j + 6)) (ring a j || ring a (j + 1)) := by
  unfold ring
  rw [show (a + 1) % 4 = (a % 4 + 1) % 4 by omega, show (j + 6) % 7 = (j % 7 + 6) % 7 by omega,
    show (j + 1) % 7 = (j % 7 + 1) % 7 by omega]
  exact ring_rule_small (a % 4) (Nat.mod_lt _ (by decide)) (j % 7) (Nat.mod_lt _ (by decide))

/-! ## The loop block is this orbit -/

theorem loop_block_small : ∀ r, r < 8 →
    LoopTranslation.L1.getD r false = (st (r % 4)).testBit 1 ∧
    LoopTranslation.L2.getD r false = (st (r % 4)).testBit 2 ∧
    LoopTranslation.L3.getD r false = (st (r % 4)).testBit 3 ∧
    LoopTranslation.L3.getD r false = (st (r % 4)).testBit 4 ∧
    LoopTranslation.L2.getD r false = (st (r % 4)).testBit 5 ∧
    LoopTranslation.L6.getD r false = (st (r % 4)).testBit 6 ∧
    LoopTranslation.drive.getD (r % 4) false = (st (r % 4)).testBit 0 := by
  decide

/-- The loop block's seven columns are the ring's cells 1..7, and cell 7 is cell 0: the seventh column returns to
the drive word. -/
theorem loop_block_is_the_ring_orbit (f : Nat) :
    LoopTranslation.col LoopTranslation.L1 f = ring f 1 ∧
    LoopTranslation.col LoopTranslation.L2 f = ring f 2 ∧
    LoopTranslation.col LoopTranslation.L3 f = ring f 3 ∧
    LoopTranslation.col LoopTranslation.L3 f = ring f 4 ∧
    LoopTranslation.col LoopTranslation.L2 f = ring f 5 ∧
    LoopTranslation.col LoopTranslation.L6 f = ring f 6 ∧
    LoopTranslation.col LoopTranslation.drive f = ring f 7 := by
  have h := loop_block_small (f % 8) (Nat.mod_lt _ (by decide))
  show LoopTranslation.L1.getD (f % 8) false = (st (f % 4)).testBit (1 % 7) ∧
    LoopTranslation.L2.getD (f % 8) false = (st (f % 4)).testBit (2 % 7) ∧
    LoopTranslation.L3.getD (f % 8) false = (st (f % 4)).testBit (3 % 7) ∧
    LoopTranslation.L3.getD (f % 8) false = (st (f % 4)).testBit (4 % 7) ∧
    LoopTranslation.L2.getD (f % 8) false = (st (f % 4)).testBit (5 % 7) ∧
    LoopTranslation.L6.getD (f % 8) false = (st (f % 4)).testBit (6 % 7) ∧
    LoopTranslation.drive.getD (f % 4) false = (st (f % 4)).testBit (7 % 7)
  rw [show f % 4 = f % 8 % 4 by omega]
  exact h

/-! ## Read leftward, the orbit is a left start that never breaks -/

/-- The left start read off the ring: position -m is cell c0 - m, that is cell c0 + 6m, at time a0. -/
def ringStart (c0 a0 : Nat) (m : Nat) : Bool := ring a0 (c0 + 6 * m)

theorem lhs_eq_ring (b : Nat → Bool) (c0 a0 : Nat) (hb : ∀ t, b t = ring (t + a0) c0) :
    ∀ t m, lhs b (ringStart c0 a0) t m = ring (t + a0) (c0 + 6 * m) := by
  intro t
  induction t with
  | zero =>
    intro m
    cases m with
    | zero => rw [lhs_zero, hb, Nat.mul_zero, Nat.add_zero c0]
    | succ k =>
      show ring a0 (c0 + 6 * (k + 1)) = ring (0 + a0) (c0 + 6 * (k + 1))
      rw [Nat.zero_add]
  | succ t ih =>
    intro m
    cases m with
    | zero => rw [lhs_zero, hb, Nat.mul_zero, Nat.add_zero c0]
    | succ k =>
      rw [lhs_step, ih (k + 2), ih (k + 1), ih k, show t + 1 + a0 = t + a0 + 1 by omega, ring_rule]
      have e1 : c0 + 6 * (k + 1) + 6 = c0 + 6 * (k + 2) := by omega
      have e2 : ring (t + a0) (c0 + 6 * (k + 1) + 1) = ring (t + a0) (c0 + 6 * k) := by
        unfold ring
        rw [show (c0 + 6 * (k + 1) + 1) % 7 = (c0 + 6 * k) % 7 by omega]
      rw [e1, e2]

/-- If the drive is the ring's cell c0, the ring's left start keeps the black values forever. -/
theorem ring_start_never_breaks (w : List Bool) (c0 a0 : Nat) (hb : ∀ t, pdrive w t = ring (t + a0) c0) :
    ∀ τ, ¬ BreaksAt w (ringStart c0 a0) τ := by
  intro τ h
  obtain ⟨black, value⟩ := h
  rw [hb τ] at black
  rw [lhs_eq_ring (pdrive w) c0 a0 hb τ 1, hb (τ + 1), show τ + 1 + a0 = τ + a0 + 1 by omega,
    ring_rule, black, Nat.mul_one, Bool.true_or] at value
  generalize ring (τ + a0) (c0 + 6) = x at value
  cases x <;> exact absurd value (by decide)

/-- The ring's left start has black cells arbitrarily far out, so it is not finite. -/
theorem ringStart_not_finite (c0 a0 : Nat) (center_black : ring a0 c0 = true) :
    ∀ K, ¬ FiniteLeft K (ringStart c0 a0) := by
  intro K fin
  have h : ring a0 (c0 + 6 * (7 * (K + 1))) = false := fin (7 * (K + 1)) (by omega)
  have e : ring a0 (c0 + 6 * (7 * (K + 1))) = ring a0 c0 := by
    unfold ring
    rw [show (c0 + 6 * (7 * (K + 1))) % 7 = c0 % 7 by omega]
  rw [e, center_black] at h
  exact Bool.noConfusion h

/-! ## Four words -/

theorem drive_1110 : ∀ t, pdrive w1110 t = ring (t + 0) 0 := by
  intro t
  show w1110.getD (t % 4) false = (st ((t + 0) % 4)).testBit (0 % 7)
  rw [Nat.add_zero]
  have h : t % 4 < 4 := Nat.mod_lt _ (by decide)
  generalize t % 4 = r at h ⊢
  revert r
  decide

theorem drive_1000 : ∀ t, pdrive w1000 t = ring (t + 0) 3 := by
  intro t
  show w1000.getD (t % 4) false = (st ((t + 0) % 4)).testBit (3 % 7)
  rw [Nat.add_zero]
  have h : t % 4 < 4 := Nat.mod_lt _ (by decide)
  generalize t % 4 = r at h ⊢
  revert r
  decide

theorem drive_1100 : ∀ t, pdrive w1100 t = ring (t + 2) 6 := by
  intro t
  show w1100.getD (t % 4) false = (st ((t + 2) % 4)).testBit (6 % 7)
  rw [show (t + 2) % 4 = (t % 4 + 2) % 4 by omega]
  have h : t % 4 < 4 := Nat.mod_lt _ (by decide)
  generalize t % 4 = r at h ⊢
  revert r
  decide

theorem drive_10 : ∀ t, pdrive w10 t = ring (t + 0) 1 := by
  intro t
  show w10.getD (t % 2) false = (st ((t + 0) % 4)).testBit (1 % 7)
  rw [Nat.add_zero, show t % 2 = t % 4 % 2 by omega]
  have h : t % 4 < 4 := Nat.mod_lt _ (by decide)
  generalize t % 4 = r at h ⊢
  revert r
  decide

theorem without_finiteness_the_pattern_fails_1110 : ¬ ∀ s : Nat → Bool, ∃ τ, BreaksAt w1110 s τ := by
  intro h
  obtain ⟨τ, hτ⟩ := h (ringStart 0 0)
  exact ring_start_never_breaks w1110 0 0 drive_1110 τ hτ

theorem without_finiteness_the_pattern_fails_1000 : ¬ ∀ s : Nat → Bool, ∃ τ, BreaksAt w1000 s τ := by
  intro h
  obtain ⟨τ, hτ⟩ := h (ringStart 3 0)
  exact ring_start_never_breaks w1000 3 0 drive_1000 τ hτ

theorem without_finiteness_the_pattern_fails_1100 : ¬ ∀ s : Nat → Bool, ∃ τ, BreaksAt w1100 s τ := by
  intro h
  obtain ⟨τ, hτ⟩ := h (ringStart 6 2)
  exact ring_start_never_breaks w1100 6 2 drive_1100 τ hτ

theorem without_finiteness_the_pattern_fails_10 : ¬ ∀ s : Nat → Bool, ∃ τ, BreaksAt w10 s τ := by
  intro h
  obtain ⟨τ, hτ⟩ := h (ringStart 1 0)
  exact ring_start_never_breaks w10 1 0 drive_10 τ hτ

/-- The comparator for 1110, in one statement: a start that is not finite and never breaks. -/
theorem closed_world_comparator_1110 :
    (∀ K, ¬ FiniteLeft K (ringStart 0 0)) ∧ ∀ τ, ¬ BreaksAt w1110 (ringStart 0 0) τ :=
  ⟨ringStart_not_finite 0 0 (by decide), ring_start_never_breaks w1110 0 0 drive_1110⟩

/-! ## Both sides: the closed world keeps the center's own rule -/

/-- The right start read off the ring: position m is cell c0 + m, at time a0. -/
def ringStartR (c0 a0 : Nat) (m : Nat) : Bool := ring a0 (c0 + m)

theorem rhc_eq_ring (b : Nat → Bool) (c0 a0 : Nat) (hb : ∀ t, b t = ring (t + a0) c0) :
    ∀ t m, rhc b (ringStartR c0 a0) t m = ring (t + a0) (c0 + m) := by
  intro t
  induction t with
  | zero =>
    intro m
    cases m with
    | zero => rw [show rhc b (ringStartR c0 a0) 0 0 = b 0 from rfl, hb, Nat.add_zero c0]
    | succ k =>
      show ring a0 (c0 + (k + 1)) = ring (0 + a0) (c0 + (k + 1))
      rw [Nat.zero_add]
  | succ t ih =>
    intro m
    cases m with
    | zero => rw [show rhc b (ringStartR c0 a0) (t + 1) 0 = b (t + 1) from rfl, hb, Nat.add_zero c0]
    | succ k =>
      show Bool.xor (rhc b (ringStartR c0 a0) t k)
          (rhc b (ringStartR c0 a0) t (k + 1) || rhc b (ringStartR c0 a0) t (k + 2)) =
        ring (t + 1 + a0) (c0 + (k + 1))
      rw [ih k, ih (k + 1), ih (k + 2), show t + 1 + a0 = t + a0 + 1 by omega, ring_rule]
      have e1 : ring (t + a0) (c0 + (k + 1) + 6) = ring (t + a0) (c0 + k) := by
        unfold ring
        rw [show (c0 + (k + 1) + 6) % 7 = (c0 + k) % 7 by omega]
      have e2 : c0 + (k + 1) + 1 = c0 + (k + 2) := by omega
      rw [e1, e2]

/-- Read both ways from the drive cell, the ring keeps the center's rule at every time. -/
theorem ring_pair_never_violates (w : List Bool) (c0 a0 : Nat) (hb : ∀ t, pdrive w t = ring (t + a0) c0) :
    ∀ τ, ¬ JointBreaksAt w (ringStart c0 a0) (ringStartR c0 a0) τ := by
  intro τ h
  apply h
  rw [lhs_eq_ring (pdrive w) c0 a0 hb τ 1, rhc_eq_ring (pdrive w) c0 a0 hb τ 1, hb (τ + 1), hb τ,
    show τ + 1 + a0 = τ + a0 + 1 by omega, ring_rule, Nat.mul_one]

theorem without_finiteness_the_two_sided_premise_fails_1110 :
    ¬ ∀ sL sR : Nat → Bool, ∃ τ, JointBreaksAt w1110 sL sR τ := by
  intro h
  obtain ⟨τ, hτ⟩ := h (ringStart 0 0) (ringStartR 0 0)
  exact ring_pair_never_violates w1110 0 0 drive_1110 τ hτ

theorem without_finiteness_the_two_sided_premise_fails_1000 :
    ¬ ∀ sL sR : Nat → Bool, ∃ τ, JointBreaksAt w1000 sL sR τ := by
  intro h
  obtain ⟨τ, hτ⟩ := h (ringStart 3 0) (ringStartR 3 0)
  exact ring_pair_never_violates w1000 3 0 drive_1000 τ hτ

theorem without_finiteness_the_two_sided_premise_fails_1100 :
    ¬ ∀ sL sR : Nat → Bool, ∃ τ, JointBreaksAt w1100 sL sR τ := by
  intro h
  obtain ⟨τ, hτ⟩ := h (ringStart 6 2) (ringStartR 6 2)
  exact ring_pair_never_violates w1100 6 2 drive_1100 τ hτ

theorem without_finiteness_the_two_sided_premise_fails_10 :
    ¬ ∀ sL sR : Nat → Bool, ∃ τ, JointBreaksAt w10 sL sR τ := by
  intro h
  obtain ⟨τ, hτ⟩ := h (ringStart 1 0) (ringStartR 1 0)
  exact ring_pair_never_violates w10 1 0 drive_10 τ hτ

end RingComparator
