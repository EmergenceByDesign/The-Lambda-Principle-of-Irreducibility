#!/usr/bin/env python3
"""Create the R7 finite-window/support-seam review and proof report."""
from pathlib import Path
from io import BytesIO
import html, json, re
import matplotlib
matplotlib.use('Agg')
from matplotlib.mathtext import math_to_image
from PIL import Image as PILImage
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, Flowable, Image

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'reports'
OUT.mkdir(exist_ok=True)
receipt = json.loads((ROOT / 'receipts/certificate.json').read_text())
assert receipt['new_theorem_count'] == 22 and len(receipt['stages']) == 22
fontroot = Path('/usr/share/fonts/truetype/dejavu')
for n,f in [('Sans','DejaVuSans.ttf'),('SansB','DejaVuSans-Bold.ttf'),
            ('Serif','DejaVuSerif.ttf'),('SerifB','DejaVuSerif-Bold.ttf'),('Mono','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(n,str(fontroot/f)))
for n in ['Sans','Serif']:
    pdfmetrics.registerFontFamily(n,normal=n,bold=n+'B',italic=n,boldItalic=n+'B')
INK=colors.HexColor('#182738'); BLUE=colors.HexColor('#165d83')
MUTED=colors.HexColor('#566575'); LIGHT=colors.HexColor('#edf4f8'); LINE=colors.HexColor('#cbd8e2')
W,H=595.28,841.89
WIDTH=W-88
STYLES={
 'title':ParagraphStyle('title',fontName='SerifB',fontSize=23,leading=28,textColor=INK,spaceAfter=13),
 'subtitle':ParagraphStyle('subtitle',fontName='Sans',fontSize=10.5,leading=14.5,textColor=MUTED,spaceAfter=12),
 'h':ParagraphStyle('h',fontName='SansB',fontSize=13.5,leading=17,textColor=BLUE,spaceBefore=7,spaceAfter=9),
 'sub':ParagraphStyle('sub',fontName='SansB',fontSize=10.5,leading=14,textColor=INK,spaceBefore=7,spaceAfter=5),
 'p':ParagraphStyle('p',fontName='Serif',fontSize=9.6,leading=13.3,textColor=INK,spaceAfter=8),
 'small':ParagraphStyle('small',fontName='Sans',fontSize=8,leading=10.8,textColor=MUTED,spaceAfter=6),
 'cell':ParagraphStyle('cell',fontName='Sans',fontSize=8,leading=10.6,textColor=INK),
 'head':ParagraphStyle('head',fontName='SansB',fontSize=8,leading=10.6,textColor=colors.white),
 'code':ParagraphStyle('code',fontName='Mono',fontSize=6.9,leading=9.6,textColor=MUTED,spaceAfter=7),
}
STORY=[]; PLAIN=[]
def para(s,style='p'):
    STORY.append(Paragraph(s,STYLES[style]))
    PLAIN.append(html.unescape(re.sub('<[^>]+>','',s)))
def heading(s):para(s,'h')
def sub(s):para(s,'sub')
def page():STORY.append(PageBreak());PLAIN.append('\n'+'='*70+'\n')
class Equation(Flowable):
    def __init__(self,tex):
        super().__init__()
        b=BytesIO(); dpi=360
        math_to_image('$'+tex+'$',b,dpi=dpi,format='png',color='#182738')
        b.seek(0); px=PILImage.open(b).size
        nw,nh=px[0]*72/dpi,px[1]*72/dpi
        scale=min(1,WIDTH/nw,45/nh)
        self.width=nw*scale;self.ih=nh*scale;self.height=self.ih+10
        b.seek(0);self.im=Image(b,width=self.width,height=self.ih)
    def draw(self):self.im.drawOn(self.canv,(WIDTH-self.width)/2,5)
def eq(tex):STORY.append(Equation(tex));PLAIN.append('MATH: '+tex)
def table(headers,rows,widths):
    data=[[Paragraph(html.escape(h),STYLES['head']) for h in headers]]
    data += [[Paragraph(s,STYLES['cell']) for s in row] for row in rows]
    t=Table(data,colWidths=widths,hAlign='LEFT')
    t.setStyle(TableStyle([
        ('BACKGROUND',(0,0),(-1,0),BLUE),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),
        ('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[LIGHT,colors.white]),
        ('LINEBELOW',(0,0),(-1,-1),.4,LINE)]))
    STORY.extend([t,Spacer(1,8)])
    PLAIN.append(' | '.join(headers))
    PLAIN.extend(' | '.join(re.sub('<[^>]+>','',s) for s in row) for row in rows)

para('Finite evidence<br/>and the support seam','title')
para('Review and continuation of the parallax supplement.<br/>24 October 2026 | ChatGPT cooperative continuation | R7','subtitle')
heading('The seam can be recognized at its declared readout')
para('Each verified finite case contributes an exact result. The parallax report [1] adds '
     'more than larger scans: an explicit inverse for the left trace, a weaker two-sided '
     'sufficient condition, and an identity between the loop block and a seven-cell ring orbit. '
     'These structural results identify where the remaining argument must act.')
para('R7 proves a further boundary: <b>no fixed finite left-trace window can determine '
     'whether an arbitrary admitted half-line has finite support.</b> A finite truncation '
     'of the actual ring start and the infinite ring start have the same finite reading '
     'but opposite support status. This is an explicit SeamCertificate, for every window length.')
eq(r'\forall b,T,\quad\neg\mathrm{Recovers}(\mathrm{Window}_{b,T},\mathrm{FiniteSupport}).')
para('R7 also proves that every chosen finite horizon can be matched by a finite pair '
     'of starts keeping the center rule throughout that horizon. The pair may depend '
     'on the horizon. Therefore arbitrarily long finite compatibility and the eventual '
     'failure of every fixed finite start are logically compatible.')
table(['Question', 'Result'],[
 ('Does each verified width add evidence?', 'Yes: it proves a finite instance and rules out counterexamples in that tested range.'),
 ('Is there a support seam?', 'Yes: the same ring/truncation witness works at every fixed finite observation window.'),
 ('Do the scans prove exhaustion of all widths?', 'No uniform exhaustion argument follows from the finite checks alone. The all-width breaking premise remains to be proved.'),
 ('Can the beginning of the gap be located?', 'The first K trace bits biject with the K start bits. Fresh-bit halving is exact before the support edge; continuation after it is the unresolved part.'),
], [WIDTH*.35,WIDTH*.65])
para('<b>22 new Lean theorems</b>; 33 audited named declarations; the complete 22-module '
     'chain rebuilt at trust level 0. No compiler errors or warnings, no custom axioms, '
     'sorryAx or Classical.choice in the new results. The supplied 94-declaration audit '
     'and shipped Python checks were independently reproduced.','small')

page()
heading('1. Finite prefixes, inversion and exact pairing')
para('Let b be any boundary drive and let q be any desired left-neighbor trace. The '
     'parallax rebuild procedure yields a finite start after K reconstruction steps:')
eq(r's_K=\mathrm{rebuild}(b,q,K).')
eq(r'\mathrm{FiniteLeft}(K,s_K),\qquad\forall t<K,\ \mathrm{lhs}(b,s_K,t,1)=q(t).')
para('The proof compares the K-step reconstruction with the full decoded start inside '
     'the backward light cone. It uses rebuild_stable, lhs_cone and left_trace_onto. '
     'The finite reconstruction is explicit and needs no choice principle.')
sub('The first K start bits and first K trace bits are in bijection')
para('forward evolves a padded K-bit start and reads K trace bits. backward reconstructs '
     'a start from a K-bit trace and reads its first K cells. Both inverse identities '
     'are checked:')
eq(r'\mathrm{forward}(\mathrm{backward}(q))=q,\qquad'
   r'\mathrm{backward}(\mathrm{forward}(p))=p.')
para('Consequently every K-bit trace has exactly one K-bit start prefix. This completes '
     'the structural inverse needed for counting the initial black-value constraints.')
sub('The exact involution behind halving')
para('At a black drive time t less than K, pair each start with the start obtained by '
     'flipping its initial cell t+1. The flip is an involution, preserves support at '
     'width K, preserves every earlier black-value test, and reverses whether the '
     'test at time t breaks. Exactly one member of each pair survives that pin.')
para('Count starts by their K positive initial bits; cell 0 is the boundary drive. '
     'For T at most K, let B(T) count black drive cells at times 0 through T-1. '
     'Ordinary finite counting gives the survivor count:')
eq(r'\#\mathrm{Survivors}(K,T)=2^{K-B(T)},\qquad 0\leq T\leq K.')
para('Lean checks the inverse maps and the exact pairing, rather than a separate '
     'cardinality declaration for this displayed corollary. After time K the next '
     'initial cell is fixed white by the support condition; the same fresh-bit '
     'halving argument can no longer be applied.','small')
para('Receipts: shadow_matches_trace; forward_backward; backward_forward; '
     'every_trace_prefix_has_unique_start_prefix; toggle_involution; '
     'toggle_preserves_support; black_pin_pairs_prior_survivors.','code')

page()
heading('2. Arbitrarily long finite agreement and a real seam')
para('For a proposed periodic drive w and a right start sR, the center rule requires '
     'the left trace to be:')
eq(r'q(t)=c(t+1)\oplus(c(t)\vee R(t)),\qquad c=\mathrm{pdrive}(w).')
para('Apply the finite reconstruction to this demand and choose the right start all '
     'white. For every T, Lean constructs a left start supported within T and a '
     'finite right start such that the center rule holds for every t less than T:')
eq(r'\forall T,\quad\exists s_L,s_R\ \mathrm{finite},\quad'
   r'\forall t<T,\ \neg\mathrm{JointBreaksAt}(w,s_L,s_R,t).')
para('This proves that no width-independent time cap can force a violation for every '
     'finite pair. The analogous one-sided construction also proves that any valid '
     'LeftBreakBound w g must satisfy g(K) at least K. It does not refute the '
     'width-dependent bound proposed in the parallax report.')
para('These are arbitrary finite starts admitted by the auxiliary driven model. '
     'They are not asserted to occur as restarts of the actual single-black-seed orbit.','small')
sub('The ring gives an explicit support-status seam')
para('Use the seven-cell ring start s-infinity from [1]. It has black cells arbitrarily '
     'far out and is therefore not finitely supported. Let sT be its white truncation '
     'after cell T. This start is finite. Their first T cells agree, so their left '
     'traces agree through time T-1 under every common drive b.')
eq(r'O_{b,T}(s_T)=O_{b,T}(s_\infty),\quad'
   r'\mathrm{FS}(s_T),\quad\neg\mathrm{FS}(s_\infty).')
para('ringSupportWindowSeam constructs precisely those witnesses. The existing '
     'seam theorem then excludes every decoder of that finite window for support '
     'status. This is a proved class-wide obstruction, not an inference from '
     'failure to find a counterexample.')
para('Each fixed positive coordinate of the truncations eventually equals the '
     'corresponding ring coordinate. Thus finite starts approximate this infinite '
     'start at every fixed finite resolution, while the limiting start is not '
     'finite. No topology or compactness theorem is assumed for this construction.','small')
para('<b>Domain matters:</b> this support seam is on the enlarged domain containing '
     'both finite and infinite starts. In the original Rule 30 problem finite '
     'support is given as an initial-condition fact. The seam does not erase that '
     'fact; it shows why a proof must use it beyond what a fixed finite window reveals.','small')
para('Receipts: every_finite_window_has_a_finite_pair; no_width_independent_joint_break_bound; '
     'every_left_bound_dominates_width; ringSupportWindowSeam; '
     'no_finite_trace_window_recovers_support.','code')

page()
heading('3. What the remaining residue now means')
para('The unconditional finite-window theorem has one order of quantifiers:')
eq(r'\forall T\ \exists\mathrm{\ finite\ starts}\ \forall t<T:\ '
   r'\mathrm{center\ rule\ holds}.')
para('The proposed all-start breaking theorem has another:')
eq(r'\forall\mathrm{\ finite\ starts}\ \exists t:\ '
   r'\mathrm{center\ rule\ fails}.')
para('These can both hold: the starts matching a longer window may require larger '
     'support. A compatible start is not required to remain the same as T grows. '
     'The scans and finite-window approximations therefore do not by themselves '
     'settle permanent survival of any one finite start.')
sub('The evidentiary value is exact, with its range retained')
para('Checking another width strengthens the proved finite range. It cannot be '
     'dismissed as no evidence. But this is not a numerical error estimate tending '
     'to zero over all widths. A proposed bound fitted to the scans is constrained '
     'by those scans; the same data are not independent confirmation of the fit.')
para('The two-sided bridge is a useful weakening of the one-sided premise. That '
     'logical implication does not measure how much of the unbounded domain is '
     'exhausted. Refuting one candidate bound would refute that bound, while '
     'leaving other bounds and the weaker two-sided route available.')
sub('The next proof target is located after the support edge')
para('Before the edge, the finite-prefix bijection and pin pairing explain the '
     'available freedom exactly. After the edge, the reconstructed continuation '
     'must obey an eventually white initial tail. The positive target is an '
     'invariant, induction or ranking argument showing that this tail condition '
     'forces a later black-value or joint violation. R7 does not assume that result.')
para('The report is right to distinguish a shared SeamCertificate type from a '
     'shared cause. R6 supplied a conditional diagonal-to-recovery construction; '
     'its interface alone did not establish the arithmetic hypotheses of Godel\'s '
     'theorem. Here the new support seam uses explicit states of this Rule 30 model.','small')
sub('Verification and handoff')
para('22 new theorems; 33 audited named declarations; 22 source modules rebuilt '
     'with official Lean 4.22.0, trust level 0; no compiler errors or warnings. '
     'Axiom reports for new declarations use at most propext and Quot.sound. '
     'The full uploaded report and supplement are preserved unchanged. The '
     'large historical C scans were not rerun; the supplied Lean audit and '
     'all shipped Python checks were reproduced.','small')
para('[1] Claude with Lu Semita, Parallax at the center, step report, 23-24 October '
     '2026, and accompanying supplement. [2] This packet: FiniteWindowSeam.lean '
     'and receipts/statements_and_axioms.txt.','small')
para('Conceptual programme: Lu Semita / EmergenceByDesign / MetaLabe. '
     'Review, new derivation and formal continuation developed with ChatGPT.','small')

def decorate(c,doc):
    c.saveState();c.setStrokeColor(LINE);c.setLineWidth(.5)
    c.line(44,H-34,W-44,H-34);c.line(44,35,W-44,35)
    c.setFillColor(MUTED);c.setFont('Sans',7)
    c.drawString(44,H-25,'EMERGENCEBYDESIGN / METALABE')
    c.drawRightString(W-44,H-25,'FINITE WINDOW / SUPPORT SEAM | R7')
    c.drawString(44,23,'24 October 2026 | explicit witnesses and retained scope')
    c.drawRightString(W-44,23,str(doc.page));c.restoreState()
pdf=OUT/'Rule30_ChatGPT_Finite_Window_Seam_2026-10-24_R7.pdf'
doc=SimpleDocTemplate(str(pdf),pagesize=(W,H),leftMargin=44,rightMargin=44,
                      topMargin=48,bottomMargin=48,title='Finite evidence and the support seam - R7',
                      author='EmergenceByDesign / MetaLabe with ChatGPT')
doc.build(STORY,onFirstPage=decorate,onLaterPages=decorate)
(ROOT/'MANUSCRIPT.txt').write_text('\n\n'.join(PLAIN)+'\n')
print(pdf)
