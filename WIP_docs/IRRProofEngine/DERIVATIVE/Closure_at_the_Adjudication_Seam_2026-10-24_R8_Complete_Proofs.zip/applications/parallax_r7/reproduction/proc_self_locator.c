#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
ssize_t readlink(const char *path, char *buf, size_t n) {
    static ssize_t (*original)(const char *, char *, size_t);
    if (!original) original = dlsym(RTLD_NEXT, "readlink");
    char mine[80];
    snprintf(mine, sizeof(mine), "/proc/%ld/exe", (long)getpid());
    return original(strcmp(path, mine) == 0 ? "/proc/self/exe" : path, buf, n);
}
ssize_t readlinkat(int fd, const char *path, char *buf, size_t n) {
    static ssize_t (*original)(int, const char *, char *, size_t);
    if (!original) original = dlsym(RTLD_NEXT, "readlinkat");
    char mine[80];
    snprintf(mine, sizeof(mine), "/proc/%ld/exe", (long)getpid());
    return original(fd, strcmp(path, mine) == 0 ? "/proc/self/exe" : path, buf, n);
}
