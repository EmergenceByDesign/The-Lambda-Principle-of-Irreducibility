#!/usr/bin/env python3
"""Rebuild the 22-module chain and audit the finite-window/support seam results."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, os, re, subprocess, zipfile

p = argparse.ArgumentParser()
p.add_argument('--lean', required=True, type=Path)
p.add_argument('--compat-shim', type=Path)
a = p.parse_args()
root = Path(__file__).resolve().parents[1]
receipts = root / 'receipts'
build = receipts / 'build'
logs = receipts / 'logs'
build.mkdir(parents=True, exist_ok=True)
logs.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
env['LEAN_PATH'] = str(build)
if a.compat_shim:
    env['LD_PRELOAD'] = str(a.compat_shim.resolve())
exe = str(a.lean.resolve())
version = subprocess.run([exe, '--version'], env=env, capture_output=True,
                         text=True, check=True).stdout.strip()
modules = ['SeamClosure', 'Rule30Application', 'Rule30Bridge', 'BlackValueBridge',
           'DrivenLeft', 'RightHalf', 'UniformWindow', 'LeftBreak', 'SeamIntegration',
           'ShieldEntry', 'JointBreak', 'LeftSeam', 'LoopTranslation', 'RingComparator',
           'BaseCertificate', 'EntryBridge', 'ClosureCheck', 'LoopFamily',
           'PatternReceipts', 'LeftReceipts', 'LeftCheck', 'FiniteWindowSeam']
stages = []
for module in modules:
    result = subprocess.run([exe, '--trust=0', '--json', '-o',
                             str(build / (module + '.olean')),
                             str(root / 'lean' / (module + '.lean'))],
                            env=env, capture_output=True, text=True)
    (logs / (module + '.stdout')).write_text(result.stdout)
    (logs / (module + '.stderr')).write_text(result.stderr)
    messages = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
    record = {'module': module, 'exit_code': result.returncode,
              'errors': sum(m['severity'] == 'error' for m in messages),
              'warnings': sum(m['severity'] == 'warning' for m in messages)}
    stages.append(record)
    print(json.dumps(record), flush=True)
    assert result.returncode == record['errors'] == record['warnings'] == 0, (result.stdout, result.stderr)
source = (root / 'lean/FiniteWindowSeam.lean').read_text()
declarations = re.findall(r'^(theorem|def)\s+([A-Za-z0-9_]+)', source, re.M)
names = ['FiniteWindowSeam.' + n for _, n in declarations]
theorems = ['FiniteWindowSeam.' + n for k, n in declarations if k == 'theorem']
audit = receipts / 'Audit.lean'
audit.write_text('import FiniteWindowSeam\n' + ''.join(
    '#check ' + n + '\n#print axioms ' + n + '\n' for n in names))
result = subprocess.run([exe, '--trust=0', '--json', str(audit)], env=env,
                        capture_output=True, text=True)
(logs / 'audit.stdout').write_text(result.stdout)
(logs / 'audit.stderr').write_text(result.stderr)
messages = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
assert result.returncode == 0 and len(messages) == 2 * len(names)
assert all(m['severity'] == 'information' for m in messages)
axioms = [m['data'] for m in messages if 'axiom' in m['data']]
assert len(axioms) == len(names)
for report in axioms:
    assert 'Classical.choice' not in report and 'sorryAx' not in report, report
    if 'depends on axioms: [' in report:
        used = report.split('depends on axioms: [')[1].split(']')[0].split(', ')
        assert set(used) <= {'propext', 'Quot.sound'}, report
assert not re.search(r'^\s*(?:axiom|constant|opaque)\s', source, re.M)
assert not re.search(r'\b(?:sorry|admit|native_decide)\b', source)
original = root / 'antecedents/Rule30_Parallax_Seam_2026-10-24_Supplement.zip'
with zipfile.ZipFile(original) as z:
    original_lean = [n for n in z.namelist() if '/lean/' in n and n.endswith('.lean')]
    for n in original_lean:
        assert z.read(n) == (root / 'lean' / Path(n).name).read_bytes(), n
receipt = {
    'verified_at_utc': datetime.now(timezone.utc).isoformat(),
    'lean_version': version, 'trust_level': 0, 'stages': stages,
    'new_theorem_count': len(theorems), 'new_theorems': theorems,
    'audited_declarations': names, 'axiom_reports': axioms,
    'antecedent_lean_files_preserved': len(original_lean),
    'source_hashes': {m + '.lean': hashlib.sha256((root / 'lean' / (m + '.lean')).read_bytes()).hexdigest()
                      for m in modules},
    'input_hashes': {f.name: hashlib.sha256(f.read_bytes()).hexdigest()
                     for f in (root / 'antecedents').iterdir() if f.is_file()},
    'scope': 'Finite-prefix bijection and black-pin pairing; finite compatible starts '
             'for every finite horizon; explicit finite-support seams using the '
             '7-cell ring; no proof of AdmittedPattern or permanent finite survival.'}
(receipts / 'certificate.json').write_text(json.dumps(receipt, indent=2) + '\n')
(receipts / 'statements_and_axioms.txt').write_text('\n\n'.join(m['data'] for m in messages) + '\n')
print('AUDIT PASSED:', len(theorems), 'new theorems;', len(names), 'named declarations', flush=True)
