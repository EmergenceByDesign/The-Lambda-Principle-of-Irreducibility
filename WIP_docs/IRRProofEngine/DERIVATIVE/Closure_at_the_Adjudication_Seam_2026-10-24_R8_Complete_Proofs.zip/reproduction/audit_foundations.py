#!/usr/bin/env python3
"""Audit selected foundational statements after verify_all.py has built R6."""
from pathlib import Path
import argparse,json,os,subprocess
p=argparse.ArgumentParser()
p.add_argument('--lean',required=True,type=Path)
p.add_argument('--compat-shim',type=Path)
a=p.parse_args()
root=Path(__file__).resolve().parents[1]
out=root/'receipts/foundations'
out.mkdir(parents=True,exist_ok=True)
names=[
 'SeamClosure.recovery_requires_fibre_constancy',
 'SeamClosure.collision_excludes_every_decoder',
 'SeamClosure.postprocessing_preserves_collision',
 'SeamClosure.exact_image_recovery_iff',
 'SeamClosure.total_recovery_iff_with_default',
 'SeamClosure.equal_declared_criteria_require_equal_verdicts',
 'SeamIntegration.added_coordinate_must_split',
 'SeamIntegration.old_readout_cannot_supply_essential_coordinate',
 'SeamIntegration.erasing_cut_parameter_obstructs',
 'SeamIntegration.retained_cut_parameter_recovers_with_calibration',
 'SeamClosureConditions.independent_coordinate_and_one_split_are_insufficient',
 'SeamClosureConditions.complete_recovery_does_not_force_universal_entry',
 'SeamClosureConditions.nullself_cannot_supply_registered_certification',
]
source=out/'FoundationAudit.lean'
source.write_text('import SeamClosureConditions\n'+''.join('#check '+n+'\n#print axioms '+n+'\n' for n in names))
env=os.environ.copy()
env['LEAN_PATH']=str(root/'receipts/diagonal_r6/build')
if a.compat_shim:env['LD_PRELOAD']=str(a.compat_shim.resolve())
r=subprocess.run([str(a.lean.resolve()),'--trust=0','--json',str(source)],env=env,capture_output=True,text=True)
(out/'audit.stdout').write_text(r.stdout);(out/'audit.stderr').write_text(r.stderr)
messages=[json.loads(l) for l in r.stdout.splitlines() if l.startswith('{')]
assert r.returncode==0 and len(messages)==2*len(names),(r.stdout,r.stderr)
assert all(m['severity']=='information' for m in messages)
ax=[m['data'] for m in messages if 'axiom' in m['data']]
assert len(ax)==len(names)
(out/'axiom_ledger.json').write_text(json.dumps({'audited':names,'axiom_reports':ax},indent=2)+'\n')
(out/'statements_and_axioms.txt').write_text('\n\n'.join(m['data'] for m in messages)+'\n')
for x in ax:print(x)
