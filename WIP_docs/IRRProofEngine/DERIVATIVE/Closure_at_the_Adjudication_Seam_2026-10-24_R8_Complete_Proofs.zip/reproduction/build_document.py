#!/usr/bin/env python3
"""Typeset the complete treatment and check cross-references and overflows."""
from pathlib import Path
import json, re, shutil, subprocess
from pypdf import PdfReader

root=Path(__file__).resolve().parents[1]
source=root/'manuscript'
out=root/'receipts/latex'
out.mkdir(parents=True,exist_ok=True)
core=json.loads((root/'receipts/core/certificate.json').read_text())
assert len(core['audited_theorems'])==18 and len(core['audited_declarations'])==25
assert all('does not depend on any axioms' in x for x in core['axiom_reports'])
(source/'core_axiom_reports.txt').write_text('\n'.join(core['axiom_reports'])+'\n')
for n in range(1,4):
 result=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',
                        '-output-directory='+str(out),'closure_at_the_seam.tex'],
                       cwd=source,capture_output=True,text=True)
 (out/f'pass_{n}.txt').write_text(result.stdout+'\n'+result.stderr)
 if result.returncode:
  print('\n'.join(result.stdout.splitlines()[-60:]))
  raise SystemExit(result.returncode)
log=(out/'closure_at_the_seam.log').read_text()
assert not re.search(r'Overfull \\[hv]box',log), 'Typesetting overflow; inspect final log.'
assert 'There were undefined references' not in log
assert not re.search(r'LaTeX Warning: (?:Reference|Citation).*undefined',log)
assert 'destination with the same identifier' not in log
pdf=out/'closure_at_the_seam.pdf'
reader=PdfReader(pdf)
assert all(p.extract_text().strip() for p in reader.pages)
reports=root/'reports'
reports.mkdir(exist_ok=True)
final=reports/'Closure_at_the_Adjudication_Seam_2026-10-24_R8.pdf'
shutil.copyfile(pdf,final)
print(json.dumps({'pdf':str(final),'pages':len(reader.pages),'bytes':final.stat().st_size,
                  'overfull_boxes':0,'undefined_references':0}))
