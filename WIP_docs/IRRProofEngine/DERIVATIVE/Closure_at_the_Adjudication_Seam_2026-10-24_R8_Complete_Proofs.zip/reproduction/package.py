#!/usr/bin/env python3
"""Package the complete verified corpus; check every distributed payload hash."""
from pathlib import Path
import hashlib,json,zipfile
from pypdf import PdfReader

root=Path(__file__).resolve().parents[1]
summary=json.loads((root/'receipts/verification_summary.json').read_text())
assert sum(t['modules'] for t in summary['targets'])==43
assert sum(t['audited_theorems'] for t in summary['targets'])==64
assert sum(t['audited_declarations'] for t in summary['targets'])==92
for label in ['core','diagonal_r6','parallax_r7']:
 c=json.loads((root/'receipts'/label/'certificate.json').read_text())
 assert all(s['exit_code']==s['errors']==s['warnings']==0 for s in c['stages'])
 source=root/'core' if label=='core' else root/'applications'/label/'lean'
 for n,h in c['source_hashes'].items():
  assert hashlib.sha256((source/n).read_bytes()).hexdigest()==h,n
 if label=='core':assert all('does not depend on any axioms' in a for a in c['axiom_reports'])
foundations=json.loads((root/'receipts/foundations/axiom_ledger.json').read_text())
assert len(foundations['audited'])==13
for app in ['diagonal_r6','parallax_r7']:
 base=root/'applications'/app
 m=json.loads((base/'MANIFEST_SHA256.json').read_text())
 for n,info in m['files'].items():
  assert hashlib.sha256((base/n).read_bytes()).hexdigest()==info['sha256'],(app,n)
pdf=root/'reports/Closure_at_the_Adjudication_Seam_2026-10-24_R8.pdf'
reader=PdfReader(pdf)
assert len(reader.pages)==25
assert all(p.extract_text().strip() for p in reader.pages)
assert hashlib.sha256((root/'source_packets/Rule30_ChatGPT_Diagonal_Seam_Bridge_2026-10-23_R6_Packet.zip').read_bytes()).hexdigest()=='98029ab6b32d33bfc84cf7068a41384476151c4f693d506a31430569a6a726a8'
assert hashlib.sha256((root/'source_packets/Rule30_ChatGPT_Finite_Window_Seam_2026-10-24_R7_Packet.zip').read_bytes()).hexdigest()=='737ae1a395c8b1a4e3de76d4c674c36b267c69716d41cd2cf93403c3126bb67a'
files=[]
for f in sorted(root.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(root)
 if rel.parts[0]=='qa' or '__pycache__' in rel.parts or f.suffix in {'.olean','.ilean'}:continue
 if rel.parts[:2]==('receipts','core_build'):continue
 if rel.parts[:2]==('receipts','latex') and f.suffix in {'.pdf','.aux','.toc','.out'}:continue
 if f.name=='MANIFEST_SHA256.json' and len(rel.parts)==1:continue
 files.append(f)
manifest={'edition':root.name,'hash_algorithm':'SHA-256','files':{
 str(f.relative_to(root)):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size}
 for f in files}}
mp=root/'MANIFEST_SHA256.json'
mp.write_text(json.dumps(manifest,indent=2)+'\n')
archive=root.parent/(root.name+'_Complete_Proofs.zip')
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files+[mp]:z.write(f,str(f.relative_to(root)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 m=json.loads(z.read('MANIFEST_SHA256.json'))
 assert set(z.namelist())==set(m['files'])|{'MANIFEST_SHA256.json'}
 for n,info in m['files'].items():
  data=z.read(n)
  assert len(data)==info['bytes'] and hashlib.sha256(data).hexdigest()==info['sha256'],n
print('VERIFIED',len(files),'payload hashes; ZIP integrity passed.')
for f in [pdf,archive]:
 print(json.dumps({'path':str(f),'bytes':f.stat().st_size,
                   'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}))
