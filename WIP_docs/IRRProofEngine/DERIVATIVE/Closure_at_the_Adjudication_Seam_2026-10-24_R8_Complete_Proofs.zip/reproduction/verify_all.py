#!/usr/bin/env python3
"""Build the core and both complete application chains in isolated Lean paths."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, os, re, subprocess

p=argparse.ArgumentParser()
p.add_argument('--lean', required=True, type=Path)
p.add_argument('--compat-shim', type=Path)
p.add_argument('--core-only', action='store_true')
a=p.parse_args()
root=Path(__file__).resolve().parents[1]
receipts=root/'receipts'
env0=os.environ.copy()
if a.compat_shim: env0['LD_PRELOAD']=str(a.compat_shim.resolve())
exe=str(a.lean.resolve())
version=subprocess.run([exe,'--version'],env=env0,capture_output=True,text=True,check=True).stdout.strip()
targets=[('core',root/'core',['UniversalRecoveryClosure','ClosureConsequences'],
          ['UniversalRecoveryClosure','ClosureConsequences'])]
if not a.core_only:
 for label,rel in [('diagonal_r6','applications/diagonal_r6'),('parallax_r7','applications/parallax_r7')]:
  base=root/rel
  c=json.loads((base/'receipts/certificate.json').read_text())
  modules=[s['module'] for s in c['stages']]
  audit_modules=sorted(set(n.split('.')[0] for n in c['audited_declarations']))
  targets.append((label,base/'lean',modules,audit_modules))
all_receipts=[]
for label,source_root,modules,audit_modules in targets:
 out=receipts/label
 build=out/'build';logs=out/'logs'
 build.mkdir(parents=True,exist_ok=True);logs.mkdir(parents=True,exist_ok=True)
 env=env0.copy();env['LEAN_PATH']=str(build)
 stages=[]
 for module in modules:
  result=subprocess.run([exe,'--trust=0','--json','-o',str(build/(module+'.olean')),
                        str(source_root/(module+'.lean'))],env=env,capture_output=True,text=True)
  (logs/(module+'.stdout')).write_text(result.stdout)
  (logs/(module+'.stderr')).write_text(result.stderr)
  messages=[json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
  stage={'module':module,'exit_code':result.returncode,
         'errors':sum(m['severity']=='error' for m in messages),
         'warnings':sum(m['severity']=='warning' for m in messages)}
  stages.append(stage)
  print(label,json.dumps(stage),flush=True)
  assert stage['exit_code']==stage['errors']==stage['warnings']==0,(result.stdout,result.stderr)
 names=[];theorems=[]
 for module in audit_modules:
  source=(source_root/(module+'.lean')).read_text()
  for kind,name in re.findall(r'^(theorem|def|structure)\s+([A-Za-z0-9_]+)',source,re.M):
   names.append(module+'.'+name)
   if kind=='theorem':theorems.append(module+'.'+name)
  assert not re.search(r'^\s*(?:axiom|constant|opaque)\s',source,re.M)
  assert not re.search(r'\b(?:sorry|admit|native_decide)\b',source)
 audit=out/'Audit.lean'
 audit.write_text(''.join('import '+m+'\n' for m in audit_modules)+
                  ''.join('#check '+n+'\n#print axioms '+n+'\n' for n in names))
 result=subprocess.run([exe,'--trust=0','--json',str(audit)],env=env,capture_output=True,text=True)
 (logs/'audit.stdout').write_text(result.stdout);(logs/'audit.stderr').write_text(result.stderr)
 messages=[json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
 assert result.returncode==0 and len(messages)==2*len(names),(result.stdout,result.stderr)
 assert all(m['severity']=='information' for m in messages)
 axioms=[m['data'] for m in messages if 'axiom' in m['data']]
 assert len(axioms)==len(names)
 for ax in axioms:
  assert 'Classical.choice' not in ax and 'sorryAx' not in ax,ax
  if label=='core':assert 'does not depend on any axioms' in ax,ax
  elif 'depends on axioms: [' in ax:
   used=set(ax.split('depends on axioms: [')[1].split(']')[0].split(', '))
   assert used<={'propext','Quot.sound'},ax
 record={'target':label,'verified_at_utc':datetime.now(timezone.utc).isoformat(),
         'lean_version':version,'trust_level':0,'stages':stages,
         'audited_declarations':names,'audited_theorems':theorems,'axiom_reports':axioms,
         'source_hashes':{m+'.lean':hashlib.sha256((source_root/(m+'.lean')).read_bytes()).hexdigest()
                          for m in modules}}
 (out/'certificate.json').write_text(json.dumps(record,indent=2)+'\n')
 (out/'statements_and_axioms.txt').write_text('\n\n'.join(m['data'] for m in messages)+'\n')
 all_receipts.append(record)
 print(label,'AUDIT PASSED',len(theorems),'theorems;',len(names),'named declarations',flush=True)
summary={'verified_at_utc':datetime.now(timezone.utc).isoformat(),'lean_version':version,
         'trust_level':0,'targets':[{'target':r['target'],'modules':len(r['stages']),
           'audited_theorems':len(r['audited_theorems']),
           'audited_declarations':len(r['audited_declarations'])} for r in all_receipts],
         'lean_executable_sha256':hashlib.sha256(a.lean.resolve().read_bytes()).hexdigest()}
(receipts/('core_summary.json' if a.core_only else 'verification_summary.json')).write_text(json.dumps(summary,indent=2)+'\n')
print('ALL REQUESTED TARGETS PASSED',flush=True)
