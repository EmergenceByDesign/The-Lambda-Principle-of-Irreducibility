/-
Axiom as Pharmakon
Scoped Deductive Closure, Symmetric Adjudication, and Class-Level Uncertainty
Lean supplement.

Lu Semita (EmergenceByDesign), in co-authorship with Nexus and Orion, in continuous working
collaboration with the ChatGPT family, Claude family, and Grok within MetaLabe.

The Lean formalization was developed with Claude (Anthropic).

This work does not claim ownership, priority, or discovery over established mathematics, logic,
proof theory, model theory, computability theory, Lean, Mathlib, Gödel’s theorems, Lindemann’s
theorem, transcendence theory, cellular automata, or any other established mathematical object or
result used or cited here. Established results remain attributed to their original sources. The
contribution lies in the stated construction, formal organization, application, and relationships
developed here.

Status conventions (as in the paper):
* proved here: declarations below with no hypothesis standing for an external theorem;
* Mathlib: `irrational_pi`, `Real.sin_lt`, `Real.sin_gt_sub_cube`,
  `tendsto_const_div_atTop_nhds_zero_nat` are used as proved in Mathlib, not reproved;
* explicit premises: Gödel completeness (`hcomp : Complete Sat`), soundness (`hsound : Sound Sat`),
  Gödel–Rosser (`rosser : Indep T G`) and Lindemann for π (`LindemannPi : Transcendental ℤ π`)
  appear only as named hypotheses; no `axiom` is declared in this file;
* reused (imported, not reproved): `Rule30Bridge` (Rule 30 Bridge R1, 23 October 2026; Claude, with
  Lu Semita, building on the R2 packet) and its dependencies `Rule30Application` and `SeamClosure`
  (R2 packet, developed with ChatGPT), as included in the R8 packet "Closure at the Adjudication
  Seam" (24 October 2026); the Rule 30 object `Rule30Bridge.center30` and the theorems
  `center30_not_eventually_white`, `center30_not_eventually_black` and
  `rule30_problem1_iff_marginal_step` are used from there;
* finite receipt: `Rule30Center.receiptCheck_eq_true`, evaluated by the kernel;
* open: which of `A` or `B` holds for the Rule 30 center sequence is not decided here.

Checked with Lean 4.35.0 and Mathlib v4.35.0; see RECEIPT.txt for the build of the reused modules.
The kernel report (`#print axioms`) is at the end.
-/
import Mathlib.Data.Set.Basic
import Mathlib.Data.Nat.Sqrt
import Mathlib.NumberTheory.Real.Irrational
import Mathlib.RingTheory.Algebraic.Basic
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Bounds
import Mathlib.Analysis.Real.Pi.Irrational
import Mathlib.Analysis.SpecificLimits.Basic
import Rule30Bridge

universe u v

/-! # Part I. Consequence relations, closure, refutation, adjudication, registries, models (§§1–8, 12–13, 19, 21) -/

/-- An abstract consequence relation. Only the assumption rule and cut are assumed;
monotonicity is derived (`Consequence.monotonicity`). -/
class Consequence (Sentence : Type u) where
  Prov : Set Sentence → Sentence → Prop
  assumption : ∀ {Γ : Set Sentence} {φ : Sentence}, φ ∈ Γ → Prov Γ φ
  cut : ∀ {Γ Δ : Set Sentence} {φ : Sentence}, (∀ ψ ∈ Δ, Prov Γ ψ) → Prov Δ φ → Prov Γ φ
  neg : Sentence → Sentence

namespace Consequence

variable {Sentence : Type u} [Consequence Sentence]

/-! ## Deductive closure -/

/-- Lemma 1: monotonicity follows from assumption and cut. -/
theorem monotonicity {Γ Δ : Set Sentence} {φ : Sentence} (hsub : Γ ⊆ Δ) (h : Prov Γ φ) :
    Prov Δ φ :=
  cut (fun _ hψ => assumption (hsub hψ)) h

/-- The deductive closure `Cn Γ = {φ | Γ ⊢ φ}`. -/
def Cn (Γ : Set Sentence) : Set Sentence := {φ | Prov Γ φ}

/-- Theorem 1(a). -/
theorem subset_Cn (Γ : Set Sentence) : Γ ⊆ Cn Γ := fun _ h => assumption h

/-- Theorem 1(b), membership form. -/
theorem mem_Cn_Cn_iff (Γ : Set Sentence) (φ : Sentence) : φ ∈ Cn (Cn Γ) ↔ φ ∈ Cn Γ :=
  ⟨fun h => cut (fun _ hψ => hψ) h, fun h => assumption h⟩

/-- Theorem 1(b), equality form. -/
theorem closure_idempotent (Γ : Set Sentence) : Cn (Cn Γ) = Cn Γ :=
  Set.ext (mem_Cn_Cn_iff Γ)

/-- Every member of `Γ ∪ {φ}` is derivable from `Γ` once `Γ ⊢ φ`. -/
theorem union_singleton_derivable {Γ : Set Sentence} {φ : Sentence} (h : Prov Γ φ) :
    ∀ θ ∈ Γ ∪ {φ}, Prov Γ θ := fun θ hθ =>
  Or.elim hθ (fun hΓ => assumption hΓ) (fun e => (show θ = φ from e) ▸ h)

/-- Theorem 1(c), membership form. -/
theorem mem_Cn_union_singleton_iff {Γ : Set Sentence} {φ : Sentence} (h : Prov Γ φ)
    (ψ : Sentence) : ψ ∈ Cn (Γ ∪ {φ}) ↔ ψ ∈ Cn Γ :=
  ⟨fun hψ => cut (union_singleton_derivable h) hψ,
   fun hψ => monotonicity (fun _ hx => Or.inl hx) hψ⟩

/-- Theorem 1(c), equality form: reusing a derived sentence as a premise is conservative. -/
theorem proved_as_premise_is_conservative {Γ : Set Sentence} {φ : Sentence} (h : Prov Γ φ) :
    Cn (Γ ∪ {φ}) = Cn Γ :=
  Set.ext (mem_Cn_union_singleton_iff h)

/-- Theorem 1(c), with `insert` (the form used in the original Lean sketch). -/
theorem proved_as_premise_is_conservative_insert {Γ : Set Sentence} {φ : Sentence}
    (h : Prov Γ φ) : Cn (insert φ Γ) = Cn Γ :=
  Set.ext fun _ =>
    ⟨fun hψ => cut (fun θ hθ => Or.elim hθ (fun e => (show θ = φ from e) ▸ h)
      (fun hΓ => assumption hΓ)) hψ,
     fun hψ => monotonicity (fun _ hx => Or.inr hx) hψ⟩

/-! ## Consistency and refutation -/

/-- Consistency: no sentence is derived together with its negation. -/
def Consistent (Γ : Set Sentence) : Prop := ∀ φ, ¬ (Prov Γ φ ∧ Prov Γ (neg φ))

/-- `α` and `β` are contradictory: one is the negation of the other. -/
def Contradictory (α β : Sentence) : Prop := β = neg α ∨ α = neg β

theorem Contradictory.symm {α β : Sentence} (h : Contradictory α β) : Contradictory β α :=
  Or.elim h Or.inr Or.inl

theorem contradictory_neg (φ : Sentence) : Contradictory φ (neg φ) := Or.inl rfl

/-- A consistent set derives no contradictory pair. -/
theorem Consistent.not_both {Γ : Set Sentence} (hc : Consistent Γ) {α β : Sentence}
    (h : Contradictory α β) : ¬ (Prov Γ α ∧ Prov Γ β) := fun ⟨hα, hβ⟩ =>
  Or.elim h (fun e => hc α ⟨hα, e ▸ hβ⟩) (fun e => hc β ⟨hβ, e ▸ hα⟩)

/-- A consistent set that derives `φ` does not derive `¬φ`. -/
theorem Consistent.not_prov_neg {Γ : Set Sentence} (hc : Consistent Γ) {φ : Sentence}
    (h : Prov Γ φ) : ¬ Prov Γ (neg φ) := fun hn => hc φ ⟨h, hn⟩

/-- Theorem 2, general constructive core: if `Γ ⊢ α`, `Γ` is consistent and `Γ ∪ Δ ⊢ β` for a
sentence `β` contradicting `α`, then not every member of `Δ` is derivable from `Γ`. -/
theorem not_all_premises_derivable {Γ Δ : Set Sentence} {α β : Sentence}
    (hα : Prov Γ α) (hcons : Consistent Γ) (hc : Contradictory α β)
    (hβ : Prov (Γ ∪ Δ) β) : ¬ ∀ δ ∈ Δ, Prov Γ δ := fun hall =>
  hcons.not_both hc
    ⟨hα, cut (fun θ hθ => Or.elim hθ (fun h => assumption h) (fun h => hall θ h)) hβ⟩

/-- Theorem 2, constructive core. -/
theorem refutation_requires_new_premise {Γ Δ : Set Sentence} {φ : Sentence}
    (hpos : Prov Γ φ) (hcons : Consistent Γ) (hneg : Prov (Γ ∪ Δ) (neg φ)) :
    ¬ ∀ δ ∈ Δ, Prov Γ δ :=
  not_all_premises_derivable hpos hcons (contradictory_neg φ) hneg

/-- Theorem 2, existential form (classical). -/
theorem negative_derivation_requires_new_premise {Γ Δ : Set Sentence} {φ : Sentence}
    (hpos : Prov Γ φ) (hcons : Consistent Γ) (hneg : Prov (Γ ∪ Δ) (neg φ)) :
    ∃ δ ∈ Δ, ¬ Prov Γ δ := by
  by_contra h
  exact refutation_requires_new_premise hpos hcons hneg
    (fun δ hδ => by_contra fun hn => h ⟨δ, hδ, hn⟩)

/-- Theorem 2(b): a premise set that keeps `Γ` and derives `¬φ` is itself inconsistent
whenever `Γ ⊢ φ`. No consistency hypothesis is needed. -/
theorem refuting_extension_inconsistent {Γ Δ : Set Sentence} {φ : Sentence}
    (hpos : Prov Γ φ) (hneg : Prov (Γ ∪ Δ) (neg φ)) : ¬ Consistent (Γ ∪ Δ) := fun hc =>
  hc φ ⟨monotonicity (fun _ h => Or.inl h) hpos, hneg⟩

/-! ## Symmetric adjudication -/

/-- Theorem 6, constructive core. A claimed derivation of `φ` from premises `Γ₀` and an objection
deriving `χ` from premises `Δ` under a relation `Prov'` cannot satisfy all six conditions at once:
(1) the premises of the claimed derivation are admitted, `Γ₀ ⊆ Γ`;
(2) the claimed inference is valid, `Γ₀ ⊢ φ`;
(3) the admitted premises are consistent;
(4) every premise of the objection is derivable from `Γ`;
(5) under the fixed reading, the objection's conclusion contradicts `φ`;
(6) every inference available to the objection is available to `⊢`. -/
theorem symmetric_adjudication_core {Γ Γ₀ Δ : Set Sentence} {φ χ : Sentence}
    {Prov' : Set Sentence → Sentence → Prop}
    (hadm : Γ₀ ⊆ Γ) (hinf : Prov Γ₀ φ) (hcons : Consistent Γ)
    (hold : ∀ δ ∈ Δ, Prov Γ δ) (hint : Contradictory φ χ)
    (hrel : ∀ Θ ψ, Prov' Θ ψ → Prov Θ ψ) (hobj : Prov' Δ χ) : False :=
  hcons.not_both hint ⟨monotonicity hadm hinf, cut hold (hrel Δ χ hobj)⟩

/-- Theorem 6, disjunctive form (classical): a successful objection falsifies at least one of the
six conditions. -/
theorem symmetric_adjudication {Γ Γ₀ Δ : Set Sentence} {φ χ : Sentence}
    {Prov' : Set Sentence → Sentence → Prop} (hobj : Prov' Δ χ) :
    ¬ Γ₀ ⊆ Γ ∨ ¬ Prov Γ₀ φ ∨ ¬ Consistent Γ ∨ (∃ δ ∈ Δ, ¬ Prov Γ δ) ∨
      ¬ Contradictory φ χ ∨ (∃ Θ ψ, Prov' Θ ψ ∧ ¬ Prov Θ ψ) := by
  by_cases h1 : Γ₀ ⊆ Γ
  · by_cases h2 : Prov Γ₀ φ
    · by_cases h3 : Consistent Γ
      · by_cases h4 : ∀ δ ∈ Δ, Prov Γ δ
        · by_cases h5 : Contradictory φ χ
          · by_cases h6 : ∀ Θ ψ, Prov' Θ ψ → Prov Θ ψ
            · exact (symmetric_adjudication_core h1 h2 h3 h4 h5 h6 hobj).elim
            · push Not at h6
              exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inr h6))))
          · exact Or.inr (Or.inr (Or.inr (Or.inr (Or.inl h5))))
        · push Not at h4
          exact Or.inr (Or.inr (Or.inr (Or.inl h4)))
      · exact Or.inr (Or.inr (Or.inl h3))
    · exact Or.inr (Or.inl h2)
  · exact Or.inl h1

/-- Self-application: the same theorem governs a challenge to an established objection. -/
theorem symmetric_adjudication_core_swap {Γ Γ₀ Δ : Set Sentence} {φ χ : Sentence}
    {Prov' : Set Sentence → Sentence → Prop}
    (hadm : Γ₀ ⊆ Γ) (hinf : Prov Γ₀ χ) (hcons : Consistent Γ)
    (hold : ∀ δ ∈ Δ, Prov Γ δ) (hint : Contradictory φ χ)
    (hrel : ∀ Θ ψ, Prov' Θ ψ → Prov Θ ψ) (hobj : Prov' Δ φ) : False :=
  symmetric_adjudication_core hadm hinf hcons hold hint.symm hrel hobj

/-! ## Attitudes are not derivations -/

/-- Non-acceptance is not refutation: in a consistent setting with `Γ ⊢ φ`, no rule of the form
"if `φ` is not accepted then `Γ ⊢ ¬φ`" can hold for every acceptance predicate. -/
theorem nonacceptance_not_refutation {Γ : Set Sentence} {φ : Sentence}
    (hpos : Prov Γ φ) (hcons : Consistent Γ) :
    ¬ ∀ Accept : Sentence → Prop, ¬ Accept φ → Prov Γ (neg φ) :=
  fun h => hcons φ ⟨hpos, h (fun _ => False) id⟩

/-- A hedge is not a derivation: no rule "if perhaps `¬φ` then `Γ ⊢ ¬φ`" holds for every
hedging predicate, in a consistent setting with `Γ ⊢ φ`. -/
theorem hedge_not_refutation {Γ : Set Sentence} {φ : Sentence}
    (hpos : Prov Γ φ) (hcons : Consistent Γ) :
    ¬ ∀ Perhaps : Sentence → Prop, Perhaps (neg φ) → Prov Γ (neg φ) :=
  fun h => hcons φ ⟨hpos, h (fun _ => True) trivial⟩

/-- If non-acceptance were adjoined as an inference rule, consistency would force acceptance
of every derived sentence. -/
theorem bridge_rule_forces_acceptance {Γ : Set Sentence} {φ : Sentence}
    (Accept : Sentence → Prop) (bridge : ∀ ψ, ¬ Accept ψ → Prov Γ (neg ψ))
    (hpos : Prov Γ φ) (hcons : Consistent Γ) : ¬ ¬ Accept φ :=
  fun hna => hcons φ ⟨hpos, bridge φ hna⟩

/-! ## Operational openness and formal independence -/

/-- A registry records which sentences currently have an accepted receipt. -/
structure Registry (Sentence : Type u) where
  receipt : Sentence → Prop

/-- Operational openness: neither `φ` nor `¬φ` has an accepted receipt. -/
def Registry.Open (R : Registry Sentence) (φ : Sentence) : Prop :=
  ¬ R.receipt φ ∧ ¬ R.receipt (neg φ)

/-- A registry is sound for `Γ` when every receipt is backed by a derivation from `Γ`. -/
def Registry.SoundFor (R : Registry Sentence) (Γ : Set Sentence) : Prop :=
  ∀ ψ, R.receipt ψ → Prov Γ ψ

/-- Formal independence: `Γ` derives neither `φ` nor `¬φ`. -/
def Indep (Γ : Set Sentence) (φ : Sentence) : Prop := ¬ Prov Γ φ ∧ ¬ Prov Γ (neg φ)

/-- Independence implies openness in every registry sound for `Γ`. -/
theorem Registry.open_of_indep {R : Registry Sentence} {Γ : Set Sentence} (hR : R.SoundFor Γ)
    {φ : Sentence} (h : Indep Γ φ) : R.Open φ :=
  ⟨fun r => h.1 (hR φ r), fun r => h.2 (hR _ r)⟩

/-- Independence is relative to `Γ`: the extension `Γ ∪ {φ}` decides `φ`. -/
theorem not_indep_union_self (Γ : Set Sentence) (φ : Sentence) : ¬ Indep (Γ ∪ {φ}) φ :=
  fun h => h.1 (assumption (Or.inr rfl))

/-- Explosion: an inconsistent premise set derives every sentence. -/
def Explosive (Sentence : Type u) [Consequence Sentence] : Prop :=
  ∀ (Γ : Set Sentence) (φ ψ : Sentence), Prov Γ φ → Prov Γ (neg φ) → Prov Γ ψ

/-- Under explosion, an independent sentence certifies consistency. -/
theorem consistent_of_indep (hexp : Explosive Sentence) {Γ : Set Sentence} {φ : Sentence}
    (h : Indep Γ φ) : Consistent Γ :=
  fun ψ ⟨h1, h2⟩ => h.1 (hexp Γ ψ φ h1 h2)

/-! ## Models: the split of an independent sentence -/

section Models

variable {Model : Type v} (Sat : Model → Sentence → Prop)

/-- `M` satisfies every member of `Γ`. -/
def ModelsAll (M : Model) (Γ : Set Sentence) : Prop := ∀ ψ ∈ Γ, Sat M ψ

/-- Semantic consequence. -/
def Entails (Γ : Set Sentence) (φ : Sentence) : Prop := ∀ M, ModelsAll Sat M Γ → Sat M φ

/-- Completeness of `⊢` for the semantics (Gödel 1930 for classical first-order logic). -/
def Complete : Prop := ∀ (Γ : Set Sentence) (φ : Sentence), Entails Sat Γ φ → Prov Γ φ

/-- Soundness of `⊢` for the semantics. -/
def Sound : Prop := ∀ (Γ : Set Sentence) (φ : Sentence), Prov Γ φ → Entails Sat Γ φ

/-- The classical (Tarski) clause for negation. -/
def NegClause : Prop := ∀ (M : Model) (φ : Sentence), Sat M (neg φ) ↔ ¬ Sat M φ

variable {Sat}

/-- Theorem 3, constructive core (first half): not every model of `Γ` satisfies `¬φ`. -/
theorem model_split_core_pos (hcomp : Complete Sat) {Γ : Set Sentence} {φ : Sentence}
    (hn : ¬ Prov Γ (neg φ)) : ¬ ∀ M, ModelsAll Sat M Γ → Sat M (neg φ) :=
  fun h => hn (hcomp Γ (neg φ) h)

/-- Theorem 3, constructive core (second half): not every model of `Γ` satisfies `φ`. -/
theorem model_split_core_neg (hcomp : Complete Sat) {Γ : Set Sentence} {φ : Sentence}
    (hp : ¬ Prov Γ φ) : ¬ ∀ M, ModelsAll Sat M Γ → Sat M φ :=
  fun h => hp (hcomp Γ φ h)

/-- Theorem 3 (classical): an independent sentence holds in some model of `Γ` and fails in
another. Consistency of `Γ` is not assumed. -/
theorem model_split (hcomp : Complete Sat) (hneg : NegClause Sat) {Γ : Set Sentence}
    {φ : Sentence} (hind : Indep Γ φ) :
    (∃ M, ModelsAll Sat M Γ ∧ Sat M φ) ∧ (∃ N, ModelsAll Sat N Γ ∧ Sat N (neg φ)) := by
  constructor
  · by_contra h
    exact model_split_core_pos hcomp hind.2 fun M hM => (hneg M φ).2 fun hφ => h ⟨M, hM, hφ⟩
  · by_contra h
    exact model_split_core_neg hcomp hind.1 fun M hM =>
      by_contra fun hφ => h ⟨M, hM, (hneg M φ).2 hφ⟩

/-- A countermodel establishes underivability, given soundness. -/
theorem not_prov_of_countermodel (hsound : Sound Sat) {Γ : Set Sentence} {φ : Sentence}
    {M : Model} (hM : ModelsAll Sat M Γ) (hφ : ¬ Sat M φ) : ¬ Prov Γ φ :=
  fun h => hφ (hsound Γ φ h M hM)

/-- Corollary 3.1(a), constructive: `Γ ∪ {φ}` is consistent. -/
theorem indep_union_pos_consistent (hsound : Sound Sat) (hcomp : Complete Sat)
    (hneg : NegClause Sat) {Γ : Set Sentence} {φ : Sentence} (hind : Indep Γ φ) :
    Consistent (Γ ∪ {φ}) := by
  intro ψ ⟨h1, h2⟩
  refine model_split_core_pos hcomp hind.2 fun M hM => (hneg M φ).2 fun hφ => ?_
  have hM' : ModelsAll Sat M (Γ ∪ {φ}) := fun θ hθ =>
    Or.elim hθ (fun h => hM θ h) (fun e => (show θ = φ from e) ▸ hφ)
  exact (hneg M ψ).1 (hsound _ _ h2 M hM') (hsound _ _ h1 M hM')

/-- Corollary 3.1(b), classical: `Γ ∪ {¬φ}` is consistent. -/
theorem indep_union_neg_consistent (hsound : Sound Sat) (hcomp : Complete Sat)
    (hneg : NegClause Sat) {Γ : Set Sentence} {φ : Sentence} (hind : Indep Γ φ) :
    Consistent (Γ ∪ {neg φ}) := by
  intro ψ ⟨h1, h2⟩
  obtain ⟨N, hN, hNφ⟩ := (model_split hcomp hneg hind).2
  have hN' : ModelsAll Sat N (Γ ∪ {neg φ}) := fun θ hθ =>
    Or.elim hθ (fun h => hN θ h) (fun e => (show θ = neg φ from e) ▸ hNφ)
  exact (hneg N ψ).1 (hsound _ _ h2 N hN') (hsound _ _ h1 N hN')

/-- Corollary 3.1: an independent sentence is decided, consistently, in either extension. -/
theorem indep_decided_in_extensions (hsound : Sound Sat) (hcomp : Complete Sat)
    (hneg : NegClause Sat) {Γ : Set Sentence} {φ : Sentence} (hind : Indep Γ φ) :
    (Consistent (Γ ∪ {φ}) ∧ Prov (Γ ∪ {φ}) φ) ∧
      (Consistent (Γ ∪ {neg φ}) ∧ Prov (Γ ∪ {neg φ}) (neg φ)) :=
  ⟨⟨indep_union_pos_consistent hsound hcomp hneg hind, assumption (Or.inr rfl)⟩,
   ⟨indep_union_neg_consistent hsound hcomp hneg hind, assumption (Or.inr rfl)⟩⟩

/-- §19: a Gödel–Rosser sentence for `T`, supplied as an explicit hypothesis, splits the models
of `T` and is decided in either extension. -/
theorem rosser_instance (hsound : Sound Sat) (hcomp : Complete Sat) (hneg : NegClause Sat)
    {T : Set Sentence} {G : Sentence} (rosser : Indep T G) :
    ((∃ M, ModelsAll Sat M T ∧ Sat M G) ∧ (∃ N, ModelsAll Sat N T ∧ Sat N (neg G))) ∧
      (Consistent (T ∪ {G}) ∧ Prov (T ∪ {G}) G) ∧
      (Consistent (T ∪ {neg G}) ∧ Prov (T ∪ {neg G}) (neg G)) :=
  ⟨model_split hcomp hneg rosser, indep_decided_in_extensions hsound hcomp hneg rosser⟩

end Models

end Consequence

/-! ## Countermodels -/

namespace Countermodels

open Consequence

/-- Two sentences, `p` and its negation `np`. -/
inductive Two where
  | p
  | np

/-- On `Two`, `Γ ⊢ φ` holds exactly when `φ ∈ Γ`. -/
instance twoConsequence : Consequence Two where
  Prov Γ φ := φ ∈ Γ
  assumption h := h
  cut hΔ hφ := hΔ _ hφ
  neg
    | .p => .np
    | .np => .p

/-- A one-sentence language in which everything is derivable from everything. -/
inductive One where
  | s

instance oneConsequence : Consequence One where
  Prov _ _ := True
  assumption _ := trivial
  cut _ _ := trivial
  neg _ := .s

/-- Theorem 2 needs consistency. -/
theorem refutation_needs_consistency :
    ∃ (Γ Δ : Set One) (φ : One), Prov Γ φ ∧ Prov (Γ ∪ Δ) (neg φ) ∧ (∀ δ ∈ Δ, Prov Γ δ) ∧
      ¬ Consistent Γ :=
  ⟨∅, ∅, .s, trivial, trivial, fun _ _ => trivial, fun h => h .s ⟨trivial, trivial⟩⟩

/-- Theorem 2 needs `Γ ⊢ φ`. -/
theorem refutation_needs_derivation :
    ∃ (Γ Δ : Set Two) (φ : Two), Consistent Γ ∧ ¬ Prov Γ φ ∧ Prov (Γ ∪ Δ) (neg φ) ∧
      (∀ δ ∈ Δ, Prov Γ δ) := by
  refine ⟨{Two.np}, ∅, Two.p, ?_, ?_, ?_, ?_⟩
  · intro ψ ⟨h1, h2⟩
    cases ψ with
    | p => exact Two.noConfusion (show Two.p = Two.np from h1)
    | np => exact Two.noConfusion (show Two.p = Two.np from h2)
  · intro h
    exact Two.noConfusion (show Two.p = Two.np from h)
  · exact Or.inl (show Two.np = Two.np from rfl)
  · intro δ hδ
    exact absurd hδ (Set.notMem_empty δ)

/-- Not deriving `φ` is not deriving `¬φ`. -/
theorem underivable_not_refuted : ¬ ∀ (Γ : Set Two) (φ : Two), ¬ Prov Γ φ → Prov Γ (neg φ) :=
  fun h => Set.notMem_empty _ (h ∅ Two.p (Set.notMem_empty _))

/-- Operational openness does not imply independence. -/
theorem open_not_indep :
    ∃ (R : Registry Two) (Γ : Set Two) (φ : Two), R.SoundFor Γ ∧ R.Open φ ∧ ¬ Indep Γ φ :=
  ⟨⟨fun _ => False⟩, {Two.p}, Two.p, fun _ h => h.elim, ⟨id, id⟩,
    fun h => h.1 (show Two.p = Two.p from rfl)⟩

end Countermodels

/-! # Part II. First-order syntax and semantics: stability under expansion, isomorphism (§§9–11, 14) -/

namespace FO

/-- A first-order language: function and relation symbols graded by arity. -/
structure Language where
  Func : Nat → Type
  Rel : Nat → Type

/-- Tuples of length `n`, as an inductive family. -/
inductive Tup (α : Type) : Nat → Type where
  | nil : Tup α 0
  | cons {n : Nat} : α → Tup α n → Tup α (n + 1)

def Tup.map {α β : Type} (f : α → β) : {n : Nat} → Tup α n → Tup β n
  | _, .nil => .nil
  | _, .cons a as => .cons (f a) (Tup.map f as)

variable {L L' : Language}

mutual
/-- Terms; variables are de Bruijn indices. -/
inductive Term (L : Language) : Type where
  | var : Nat → Term L
  | func {n : Nat} : L.Func n → Terms L n → Term L
/-- Argument lists of length `n`. -/
inductive Terms (L : Language) : Nat → Type where
  | nil : Terms L 0
  | cons {n : Nat} : Term L → Terms L n → Terms L (n + 1)
end

/-- Formulas; `all` and `ex` bind de Bruijn index 0. -/
inductive Formula (L : Language) : Type where
  | falsum : Formula L
  | equal : Term L → Term L → Formula L
  | rel {n : Nat} : L.Rel n → Terms L n → Formula L
  | not : Formula L → Formula L
  | and : Formula L → Formula L → Formula L
  | or : Formula L → Formula L → Formula L
  | imp : Formula L → Formula L → Formula L
  | all : Formula L → Formula L
  | ex : Formula L → Formula L

/-- An `L`-structure on the domain `α`. -/
structure Structure (L : Language) (α : Type) where
  funMap : {n : Nat} → L.Func n → Tup α n → α
  relMap : {n : Nat} → L.Rel n → Tup α n → Prop

/-- Extend an assignment by a value for de Bruijn index 0. -/
def consAssign {α : Type} (a : α) (v : Nat → α) : Nat → α
  | 0 => a
  | n + 1 => v n

variable {α β : Type}

mutual
def Term.eval (M : Structure L α) (v : Nat → α) : Term L → α
  | .var n => v n
  | .func f ts => M.funMap f (Terms.eval M v ts)
def Terms.eval (M : Structure L α) (v : Nat → α) : {n : Nat} → Terms L n → Tup α n
  | _, .nil => .nil
  | _, .cons t ts => .cons (Term.eval M v t) (Terms.eval M v ts)
end

/-- Satisfaction of a formula under an assignment. -/
def Formula.Realize (M : Structure L α) : Formula L → (Nat → α) → Prop
  | .falsum, _ => False
  | .equal t₁ t₂, v => Term.eval M v t₁ = Term.eval M v t₂
  | .rel R ts, v => M.relMap R (Terms.eval M v ts)
  | .not φ, v => ¬ Formula.Realize M φ v
  | .and φ ψ, v => Formula.Realize M φ v ∧ Formula.Realize M ψ v
  | .or φ ψ, v => Formula.Realize M φ v ∨ Formula.Realize M ψ v
  | .imp φ ψ, v => Formula.Realize M φ v → Formula.Realize M ψ v
  | .all φ, v => ∀ a : α, Formula.Realize M φ (consAssign a v)
  | .ex φ, v => ∃ a : α, Formula.Realize M φ (consAssign a v)

/-- A language morphism, sending each symbol to a symbol of the same arity. An inclusion
`L ⊆ L'` is the case where both maps are injective; injectivity is not used below. -/
structure LHom (L L' : Language) where
  onFunc : {n : Nat} → L.Func n → L'.Func n
  onRel : {n : Nat} → L.Rel n → L'.Rel n

mutual
def LHom.onTerm (ι : LHom L L') : Term L → Term L'
  | .var n => .var n
  | .func f ts => .func (ι.onFunc f) (LHom.onTerms ι ts)
def LHom.onTerms (ι : LHom L L') : {n : Nat} → Terms L n → Terms L' n
  | _, .nil => .nil
  | _, .cons t ts => .cons (LHom.onTerm ι t) (LHom.onTerms ι ts)
end

def LHom.onFormula (ι : LHom L L') : Formula L → Formula L'
  | .falsum => .falsum
  | .equal t₁ t₂ => .equal (ι.onTerm t₁) (ι.onTerm t₂)
  | .rel R ts => .rel (ι.onRel R) (ι.onTerms ts)
  | .not φ => .not (LHom.onFormula ι φ)
  | .and φ ψ => .and (LHom.onFormula ι φ) (LHom.onFormula ι ψ)
  | .or φ ψ => .or (LHom.onFormula ι φ) (LHom.onFormula ι ψ)
  | .imp φ ψ => .imp (LHom.onFormula ι φ) (LHom.onFormula ι ψ)
  | .all φ => .all (LHom.onFormula ι φ)
  | .ex φ => .ex (LHom.onFormula ι φ)

/-- `M'` is an expansion of `M` along `ι` on the same domain: every old symbol keeps exactly
its old interpretation. (The reduct of `M'` to `L` is `M`.) -/
structure IsExpansion (ι : LHom L L') (M : Structure L α) (M' : Structure L' α) : Prop where
  funMap_eq : ∀ {n : Nat} (f : L.Func n) (xs : Tup α n), M'.funMap (ι.onFunc f) xs = M.funMap f xs
  relMap_iff : ∀ {n : Nat} (R : L.Rel n) (xs : Tup α n), M'.relMap (ι.onRel R) xs ↔ M.relMap R xs

section Expansion
variable {ι : LHom L L'} {M : Structure L α} {M' : Structure L' α}

mutual
theorem eval_onTerm (h : IsExpansion ι M M') (v : Nat → α) :
    (t : Term L) → Term.eval M' v (ι.onTerm t) = Term.eval M v t
  | .var _ => rfl
  | .func f ts => by
      show M'.funMap (ι.onFunc f) (Terms.eval M' v (ι.onTerms ts)) = M.funMap f (Terms.eval M v ts)
      rw [eval_onTerms h v ts]
      exact h.funMap_eq f _
theorem eval_onTerms (h : IsExpansion ι M M') (v : Nat → α) :
    {n : Nat} → (ts : Terms L n) → Terms.eval M' v (ι.onTerms ts) = Terms.eval M v ts
  | _, .nil => rfl
  | _, .cons t ts => by
      show Tup.cons (Term.eval M' v (ι.onTerm t)) (Terms.eval M' v (ι.onTerms ts)) =
        Tup.cons (Term.eval M v t) (Terms.eval M v ts)
      rw [eval_onTerm h v t, eval_onTerms h v ts]
end

/-- Theorem 4 (semantic stability). -/
theorem realize_onFormula (h : IsExpansion ι M M') :
    (φ : Formula L) → (v : Nat → α) → (Formula.Realize M' (ι.onFormula φ) v ↔ Formula.Realize M φ v)
  | .falsum, _ => Iff.rfl
  | .equal t₁ t₂, v => by
      show Term.eval M' v (ι.onTerm t₁) = Term.eval M' v (ι.onTerm t₂) ↔
        Term.eval M v t₁ = Term.eval M v t₂
      rw [eval_onTerm h v t₁, eval_onTerm h v t₂]
  | .rel R ts, v => by
      show M'.relMap (ι.onRel R) (Terms.eval M' v (ι.onTerms ts)) ↔ M.relMap R (Terms.eval M v ts)
      rw [eval_onTerms h v ts]
      exact h.relMap_iff R _
  | .not φ, v => not_congr (realize_onFormula h φ v)
  | .and φ ψ, v => and_congr (realize_onFormula h φ v) (realize_onFormula h ψ v)
  | .or φ ψ, v => or_congr (realize_onFormula h φ v) (realize_onFormula h ψ v)
  | .imp φ ψ, v => imp_congr (realize_onFormula h φ v) (realize_onFormula h ψ v)
  | .all φ, v => forall_congr' fun a => realize_onFormula h φ (consAssign a v)
  | .ex φ, v => exists_congr fun a => realize_onFormula h φ (consAssign a v)

end Expansion


/-- Theorem 4, consequence: a formula true in `M` stays true, read in any expansion `M'`. -/
theorem realize_onFormula_of_realize {ι : LHom L L'} {M : Structure L α} {M' : Structure L' α}
    (h : IsExpansion ι M M') {φ : Formula L} {v : Nat → α} (hφ : Formula.Realize M φ v) :
    Formula.Realize M' (ι.onFormula φ) v :=
  (realize_onFormula h φ v).2 hφ

/-! ### Reinterpreting an old symbol can change truth -/

/-- A language with no function symbols and one relation symbol of each arity. -/
def LP : Language where
  Func _ := Empty
  Rel _ := Unit

/-- `∃x P(x)` with `P` the unary relation symbol of `LP`. -/
def exP : Formula LP := .ex (.rel (n := 1) () (.cons (.var 0) .nil))

/-- `P` interpreted as true everywhere on a one-point domain. -/
def M₁ : Structure LP Unit where
  funMap f _ := nomatch f
  relMap _ _ := True

/-- The same symbol `P`, reinterpreted as false everywhere. -/
def M₂ : Structure LP Unit where
  funMap f _ := nomatch f
  relMap _ _ := False

theorem reinterpretation_changes_truth (v : Nat → Unit) :
    Formula.Realize M₁ exP v ∧ ¬ Formula.Realize M₂ exP v :=
  ⟨⟨(), trivial⟩, fun ⟨_, h⟩ => h⟩

/-- The identity language morphism. -/
def LHom.id (L : Language) : LHom L L where
  onFunc f := f
  onRel R := R

/-- So `M₂` is not an expansion of `M₁` along the identity: Theorem 4 would otherwise
transport the truth of `exP`. The preservation hypothesis cannot be dropped. -/
theorem reinterpretation_not_expansion : ¬ IsExpansion (LHom.id LP) M₁ M₂ := fun h =>
  (reinterpretation_changes_truth (fun _ => ())).2
    ((realize_onFormula h exP (fun _ => ())).2 (reinterpretation_changes_truth (fun _ => ())).1)

/-! ### Isomorphism and transport -/

/-- An isomorphism of `L`-structures: a bijection (given with its inverse) commuting with every
function symbol and preserving every relation symbol in both directions. -/
structure Iso (M : Structure L α) (N : Structure L β) where
  toFun : α → β
  invFun : β → α
  left_inv : ∀ a, invFun (toFun a) = a
  right_inv : ∀ b, toFun (invFun b) = b
  map_fun : ∀ {n : Nat} (f : L.Func n) (xs : Tup α n), toFun (M.funMap f xs) = N.funMap f (xs.map toFun)
  map_rel : ∀ {n : Nat} (R : L.Rel n) (xs : Tup α n), N.relMap R (xs.map toFun) ↔ M.relMap R xs

section Iso
variable {M : Structure L α} {N : Structure L β}

mutual
theorem Iso.eval_term (h : Iso M N) {v : Nat → α} {w : Nat → β}
    (hvw : ∀ n, w n = h.toFun (v n)) : (t : Term L) → Term.eval N w t = h.toFun (Term.eval M v t)
  | .var n => hvw n
  | .func f ts => by
      show N.funMap f (Terms.eval N w ts) = h.toFun (M.funMap f (Terms.eval M v ts))
      rw [Iso.eval_terms h hvw ts, h.map_fun]
theorem Iso.eval_terms (h : Iso M N) {v : Nat → α} {w : Nat → β}
    (hvw : ∀ n, w n = h.toFun (v n)) :
    {n : Nat} → (ts : Terms L n) → Terms.eval N w ts = (Terms.eval M v ts).map h.toFun
  | _, .nil => rfl
  | _, .cons t ts => by
      show Tup.cons (Term.eval N w t) (Terms.eval N w ts) =
        Tup.cons (h.toFun (Term.eval M v t)) ((Terms.eval M v ts).map h.toFun)
      rw [Iso.eval_term h hvw t, Iso.eval_terms h hvw ts]
end

theorem Iso.cons_pointwise (h : Iso M N) {v : Nat → α} {w : Nat → β}
    (hvw : ∀ n, w n = h.toFun (v n)) {a : α} {b : β} (hab : b = h.toFun a) :
    ∀ n, consAssign b w n = h.toFun (consAssign a v n)
  | 0 => hab
  | n + 1 => hvw n

theorem Iso.toFun_inj (h : Iso M N) {a a' : α} (e : h.toFun a = h.toFun a') : a = a' :=
  (h.left_inv a).symm.trans ((congrArg h.invFun e).trans (h.left_inv a'))

/-- Theorem 5, assignment-pointwise form. -/
theorem Iso.realize (h : Iso M N) : (φ : Formula L) → {v : Nat → α} → {w : Nat → β} →
    (∀ n, w n = h.toFun (v n)) → (Formula.Realize N φ w ↔ Formula.Realize M φ v)
  | .falsum, _, _, _ => Iff.rfl
  | .equal t₁ t₂, v, w, hvw => by
      show Term.eval N w t₁ = Term.eval N w t₂ ↔ Term.eval M v t₁ = Term.eval M v t₂
      rw [h.eval_term hvw t₁, h.eval_term hvw t₂]
      exact ⟨h.toFun_inj, congrArg h.toFun⟩
  | .rel R ts, v, w, hvw => by
      show N.relMap R (Terms.eval N w ts) ↔ M.relMap R (Terms.eval M v ts)
      rw [h.eval_terms hvw ts]
      exact h.map_rel R _
  | .not φ, _, _, hvw => not_congr (h.realize φ hvw)
  | .and φ ψ, _, _, hvw => and_congr (h.realize φ hvw) (h.realize ψ hvw)
  | .or φ ψ, _, _, hvw => or_congr (h.realize φ hvw) (h.realize ψ hvw)
  | .imp φ ψ, _, _, hvw => imp_congr (h.realize φ hvw) (h.realize ψ hvw)
  | .all φ, _, _, hvw =>
      ⟨fun hN a => (h.realize φ (h.cons_pointwise hvw rfl)).1 (hN (h.toFun a)),
       fun hM b => (h.realize φ (h.cons_pointwise hvw (h.right_inv b).symm)).2 (hM (h.invFun b))⟩
  | .ex φ, _, _, hvw =>
      ⟨fun ⟨b, hb⟩ => ⟨h.invFun b, (h.realize φ (h.cons_pointwise hvw (h.right_inv b).symm)).1 hb⟩,
       fun ⟨a, ha⟩ => ⟨h.toFun a, (h.realize φ (h.cons_pointwise hvw rfl)).2 ha⟩⟩

/-- Theorem 5: `M` satisfies `φ` under `s` iff `N` satisfies `φ` under `h ∘ s`. -/
theorem Iso.realize_comp (h : Iso M N) (φ : Formula L) (s : Nat → α) :
    Formula.Realize M φ s ↔ Formula.Realize N φ (fun n => h.toFun (s n)) :=
  (h.realize φ (fun _ => rfl)).symm

end Iso

/-! ### Both halves of bijectivity are needed -/

/-- A map of structures commuting with function symbols and preserving relation symbols in both
directions, with no bijectivity assumed. -/
structure Hom (M : Structure L α) (N : Structure L β) where
  toFun : α → β
  map_fun : ∀ {n : Nat} (f : L.Func n) (xs : Tup α n), toFun (M.funMap f xs) = N.funMap f (xs.map toFun)
  map_rel : ∀ {n : Nat} (R : L.Rel n) (xs : Tup α n), N.relMap R (xs.map toFun) ↔ M.relMap R xs

/-- The empty language. -/
def L0 : Language where
  Func _ := Empty
  Rel _ := Empty

/-- The structure of the empty language on a domain. -/
def bare (α : Type) : Structure L0 α where
  funMap f _ := nomatch f
  relMap R _ := nomatch R

/-- `∃x ∃y ¬(x = y)`: there are two distinct elements. -/
def twoDistinct : Formula L0 := .ex (.ex (.not (.equal (.var 0) (.var 1))))

theorem twoDistinct_bool (v : Nat → Bool) : Formula.Realize (bare Bool) twoDistinct v :=
  ⟨true, false, fun h => Bool.noConfusion h⟩

theorem twoDistinct_unit (v : Nat → Unit) : ¬ Formula.Realize (bare Unit) twoDistinct v :=
  fun ⟨_, _, h⟩ => h rfl

/-- A surjective, non-injective map preserving all symbols: truth is not preserved. -/
def collapse : Hom (bare Bool) (bare Unit) where
  toFun _ := ()
  map_fun f _ := nomatch f
  map_rel R _ := nomatch R

theorem injectivity_needed :
    (∀ b : Unit, ∃ a : Bool, collapse.toFun a = b) ∧
      Formula.Realize (bare Bool) twoDistinct (fun _ => true) ∧
      ¬ Formula.Realize (bare Unit) twoDistinct (fun _ => collapse.toFun true) :=
  ⟨fun _ => ⟨true, rfl⟩, twoDistinct_bool _, twoDistinct_unit _⟩

/-- An injective, non-surjective map preserving all symbols: truth is not preserved. -/
def embedPoint : Hom (bare Unit) (bare Bool) where
  toFun _ := true
  map_fun f _ := nomatch f
  map_rel R _ := nomatch R

theorem surjectivity_needed :
    (∀ a a' : Unit, embedPoint.toFun a = embedPoint.toFun a' → a = a') ∧
      ¬ Formula.Realize (bare Unit) twoDistinct (fun _ => ()) ∧
      Formula.Realize (bare Bool) twoDistinct (fun _ => embedPoint.toFun ()) :=
  ⟨fun _ _ _ => rfl, twoDistinct_unit _, twoDistinct_bool _⟩

end FO

/-! # Part III. Class-level closure: null sets, polygons, integer and polynomial relations for π (§§15–18) -/

namespace ClassClosure

open Real Polynomial Filter

/-! ## Class-level null closure -/

/-- Null closure, membership form. -/
theorem null_closure_mem {α : Type*} (C : Set α) (R : α → Prop) :
    (∀ x ∈ C, ¬ R x) ↔ ∀ x, x ∉ {x ∈ C | R x} :=
  ⟨fun h x hx => h x hx.1 hx.2, fun h x hC hR => h x ⟨hC, hR⟩⟩

/-- Null closure, set-equality form. -/
theorem null_closure {α : Type*} (C : Set α) (R : α → Prop) :
    (∀ x ∈ C, ¬ R x) ↔ {x ∈ C | R x} = ∅ :=
  (null_closure_mem C R).trans Set.eq_empty_iff_forall_notMem.symm

/-! ## Exact proportion as an integer relation -/

/-- `x` is rational iff `a * x - b = 0` for integers `a ≠ 0` and `b`. -/
theorem rational_iff_int_relation (x : ℝ) :
    x ∈ Set.range ((↑) : ℚ → ℝ) ↔ ∃ a b : ℤ, a ≠ 0 ∧ (a : ℝ) * x - b = 0 := by
  constructor
  · rintro ⟨q, rfl⟩
    refine ⟨q.den, q.num, by exact_mod_cast q.den_nz, ?_⟩
    have hden : (q.den : ℝ) ≠ 0 := by exact_mod_cast q.den_nz
    rw [Rat.cast_def]
    push_cast
    field_simp
    ring
  · rintro ⟨a, b, ha, h⟩
    refine ⟨(b : ℚ) / a, ?_⟩
    have ha' : (a : ℝ) ≠ 0 := by exact_mod_cast ha
    push_cast
    field_simp
    linarith

/-- No nontrivial integer relation closes on `π` (from Mathlib's `irrational_pi`). -/
theorem pi_int_relation_null : ∀ a b : ℤ, a ≠ 0 → (a : ℝ) * π - b ≠ 0 :=
  fun a b ha h => irrational_pi ((rational_iff_int_relation π).2 ⟨a, b, ha, h⟩)

/-- The integer-relation solution set for `π` is empty. -/
theorem pi_int_relation_set_empty :
    {ab : ℤ × ℤ | ab.1 ≠ 0 ∧ (ab.1 : ℝ) * π = ab.2} = ∅ :=
  Set.eq_empty_of_forall_notMem fun ab h =>
    pi_int_relation_null ab.1 ab.2 h.1 (sub_eq_zero.2 h.2)

/-! ## Transcendence as a closure of the polynomial relation class -/

/-- Algebraicity over `ℤ` is the integer polynomial relation (Mathlib's definition, unfolded). -/
theorem isAlgebraic_int_iff (x : ℝ) :
    IsAlgebraic ℤ x ↔ ∃ p : ℤ[X], p ≠ 0 ∧ aeval x p = 0 := Iff.rfl

section Lindemann

/-! Lindemann's theorem for `π` enters as an explicit hypothesis. -/

variable (LindemannPi : Transcendental ℤ π)
include LindemannPi

/-- No nonzero integer polynomial vanishes at `π`. -/
theorem pi_poly_relation_null : ∀ p : ℤ[X], p ≠ 0 → aeval π p ≠ 0 :=
  fun p hp h => LindemannPi ⟨p, hp, h⟩

/-- The polynomial-relation solution set for `π` is empty. -/
theorem pi_poly_relation_set_empty : {p : ℤ[X] | p ≠ 0 ∧ aeval π p = 0} = ∅ :=
  Set.eq_empty_of_forall_notMem fun p h => pi_poly_relation_null LindemannPi p h.1 h.2

end Lindemann

/-- The linear relation `a X - b`. -/
noncomputable def linPoly (a b : ℤ) : ℤ[X] := C a * X - C b

theorem linPoly_coeff_one (a b : ℤ) : (linPoly a b).coeff 1 = a := by
  rw [linPoly, coeff_sub, coeff_C_mul_X, coeff_C]
  simp

theorem linPoly_coeff_zero (a b : ℤ) : (linPoly a b).coeff 0 = -b := by
  rw [linPoly, coeff_sub, coeff_C_mul_X, coeff_C]
  simp

theorem linPoly_ne_zero {a b : ℤ} (ha : a ≠ 0) : linPoly a b ≠ 0 := fun h =>
  ha (by rw [← linPoly_coeff_one a b, h, coeff_zero])

theorem aeval_linPoly (x : ℝ) (a b : ℤ) : aeval x (linPoly a b) = (a : ℝ) * x - b := by
  simp [linPoly]

/-- The linear relation class embeds in the polynomial relation class. -/
theorem linPoly_injective : Function.Injective (fun ab : ℤ × ℤ => linPoly ab.1 ab.2) := by
  rintro ⟨a, b⟩ ⟨a', b'⟩ h
  have h1 := congrArg (fun p : ℤ[X] => p.coeff 1) h
  have h0 := congrArg (fun p : ℤ[X] => p.coeff 0) h
  simp only [linPoly_coeff_one, linPoly_coeff_zero, neg_inj] at h1 h0
  rw [h1, h0]

theorem linear_class_into_poly_class {x : ℝ} {a b : ℤ} (h : a ≠ 0 ∧ (a : ℝ) * x - b = 0) :
    linPoly a b ≠ 0 ∧ aeval x (linPoly a b) = 0 :=
  ⟨linPoly_ne_zero h.1, (aeval_linPoly x a b).trans h.2⟩

/-- Closing the polynomial class closes the linear class. -/
theorem int_relation_null_of_transcendental {x : ℝ} (hx : Transcendental ℤ x) :
    ∀ a b : ℤ, a ≠ 0 → (a : ℝ) * x - b ≠ 0 :=
  fun a b ha h => hx ⟨linPoly a b, linear_class_into_poly_class ⟨ha, h⟩⟩

/-! ## Inscribed regular polygons -/

/-- Perimeter of the regular `n`-gon inscribed in the unit circle. -/
noncomputable def P (n : ℕ) : ℝ := 2 * n * Real.sin (π / n)

/-- `P n < 2π` for every `n ≥ 1`. -/
theorem P_lt_two_pi {n : ℕ} (hn : 1 ≤ n) : P n < 2 * π := by
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  have hx : 0 < π / n := div_pos pi_pos hn'
  calc P n = 2 * n * Real.sin (π / n) := rfl
    _ < 2 * n * (π / n) := mul_lt_mul_of_pos_left (Real.sin_lt hx) (by positivity)
    _ = 2 * π := by field_simp

/-- The polygon class `n ≥ 3`. -/
theorem polygon_perimeter_lt {n : ℕ} (hn : 3 ≤ n) : P n < 2 * π := P_lt_two_pi (by omega)

/-- No finite polygon in the class closes the equality. -/
theorem polygon_equality_set_empty : {n : ℕ | 3 ≤ n ∧ P n = 2 * π} = ∅ :=
  Set.eq_empty_of_forall_notMem fun _ h => (polygon_perimeter_lt h.1).ne h.2

/-- Lower bound: `2π − π³/(3n²) < P n` for every `n ≥ 1`. -/
theorem two_pi_sub_lt_P {n : ℕ} (hn : 1 ≤ n) : 2 * π - π ^ 3 / (3 * n ^ 2) < P n := by
  have hn' : (0 : ℝ) < n := by exact_mod_cast hn
  have hx : 0 < π / n := div_pos pi_pos hn'
  have key : 2 * (n : ℝ) * (π / n - (π / n) ^ 3 / 6) = 2 * π - π ^ 3 / (3 * n ^ 2) := by
    field_simp
    ring
  calc 2 * π - π ^ 3 / (3 * n ^ 2) = 2 * (n : ℝ) * (π / n - (π / n) ^ 3 / 6) := key.symm
    _ < 2 * n * Real.sin (π / n) :=
        mul_lt_mul_of_pos_left (Real.sin_gt_sub_cube hx) (by positivity)

/-- Explicit rate: `|2π − P n| < π³/(3n²)` for every `n ≥ 1`. -/
theorem abs_two_pi_sub_P_lt {n : ℕ} (hn : 1 ≤ n) : |2 * π - P n| < π ^ 3 / (3 * n ^ 2) := by
  rw [abs_of_pos (by linarith [P_lt_two_pi hn])]
  linarith [two_pi_sub_lt_P hn]

/-- `P n → 2π`. -/
theorem P_tendsto : Tendsto P atTop (nhds (2 * π)) := by
  have hlow : Tendsto (fun n : ℕ => 2 * π - (π ^ 3 / 3) / (n : ℝ)) atTop (nhds (2 * π)) := by
    have hc : Tendsto (fun _ : ℕ => 2 * π) atTop (nhds (2 * π)) := tendsto_const_nhds
    simpa using hc.sub (tendsto_const_div_atTop_nhds_zero_nat (π ^ 3 / 3))
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le' hlow tendsto_const_nhds ?_ ?_
  · filter_upwards [eventually_ge_atTop 1] with n hn
    have hn' : (1 : ℝ) ≤ n := by exact_mod_cast hn
    have h := two_pi_sub_lt_P hn
    have hle : π ^ 3 / (3 * (n : ℝ) ^ 2) ≤ (π ^ 3 / 3) / n := by
      rw [div_div]
      exact div_le_div_of_nonneg_left (by positivity) (by linarith) (by nlinarith)
    linarith
  · filter_upwards [eventually_ge_atTop 1] with n hn
    exact (P_lt_two_pi hn).le

/-- Approach without attainment. -/
theorem P_approaches_not_attained :
    Tendsto P atTop (nhds (2 * π)) ∧ ∀ n : ℕ, 1 ≤ n → P n ≠ 2 * π :=
  ⟨P_tendsto, fun _ hn => (P_lt_two_pi hn).ne⟩

end ClassClosure

/-! # Part IV. Rule 30 (§20)

The Rule 30 object `Rule30Bridge.center30` and the reused theorems come from the imported module
`Rule30Bridge` (see the header). -/

namespace EventualPeriod

/-! ## The eventual-period certificate class of a Boolean sequence -/

/-- `E Q = {(P, T) | P > 0 ∧ ∀ t ≥ T, Q (t + P) = Q t}`. -/
def E (Q : ℕ → Bool) : Set (ℕ × ℕ) := {PT | 0 < PT.1 ∧ ∀ t, PT.2 ≤ t → Q (t + PT.1) = Q t}

/-- A: eventual periodicity, `E Q ≠ ∅` in the form `E Q` is nonempty. -/
def A (Q : ℕ → Bool) : Prop := (E Q).Nonempty

/-- B: non-eventual-periodicity, `E Q = ∅`. -/
def B (Q : ℕ → Bool) : Prop := E Q = ∅

/-- A in the form `E Q ≠ ∅` (classical). -/
theorem A_iff_ne_empty (Q : ℕ → Bool) : A Q ↔ E Q ≠ ∅ := Set.nonempty_iff_ne_empty

/-- Expanded form of A. -/
theorem A_iff (Q : ℕ → Bool) :
    A Q ↔ ∃ P, 0 < P ∧ ∃ T, ∀ t, T ≤ t → Q (t + P) = Q t :=
  ⟨fun ⟨⟨P, T⟩, hP, h⟩ => ⟨P, hP, T, h⟩, fun ⟨P, hP, T, h⟩ => ⟨(P, T), hP, h⟩⟩

/-- Expanded form of B, membership version (constructive). -/
theorem B_mem_iff (Q : ℕ → Bool) :
    (∀ PT, PT ∉ E Q) ↔ ∀ P, 0 < P → ∀ T, ¬ ∀ t, T ≤ t → Q (t + P) = Q t :=
  ⟨fun h P hP T hT => h (P, T) ⟨hP, hT⟩, fun h ⟨P, T⟩ ⟨hP, hT⟩ => h P hP T hT⟩

/-- Expanded form of B (classical). -/
theorem B_iff (Q : ℕ → Bool) :
    B Q ↔ ∀ P, 0 < P → ∀ T, ∃ t, T ≤ t ∧ Q (t + P) ≠ Q t := by
  rw [B, Set.eq_empty_iff_forall_notMem, B_mem_iff]
  refine forall_congr' fun P => forall_congr' fun _ => forall_congr' fun T => ?_
  push Not
  rfl

/-- A and B exclude each other (constructive). -/
theorem not_A_and_B (Q : ℕ → Bool) : ¬ (A Q ∧ B Q) := fun ⟨⟨x, hx⟩, hB⟩ =>
  (show x ∈ (∅ : Set (ℕ × ℕ)) from hB ▸ hx)

/-- A or B (classical): the unresolved status is not a third truth value. -/
theorem A_or_B (Q : ℕ → Bool) : A Q ∨ B Q :=
  (Set.eq_empty_or_nonempty (E Q)).elim Or.inr Or.inl

/-- A finite witness excludes one candidate. -/
theorem not_mem_E_of_witness {Q : ℕ → Bool} {P T t : ℕ} (ht : T ≤ t)
    (hne : Q (t + P) ≠ Q t) : (P, T) ∉ E Q := fun h => hne (h.2 t ht)

/-! ### The same classes in the existing tail predicates (`Rule30Application`, R2 packet) -/

/-- A is the existing predicate `EventuallyPeriodic` (constructive). -/
theorem A_iff_eventuallyPeriodic (Q : ℕ → Bool) : A Q ↔ Rule30Application.EventuallyPeriodic Q :=
  ⟨fun ⟨⟨P, T⟩, hP, h⟩ => ⟨T, P, hP, h⟩, fun ⟨T, P, hP, h⟩ => ⟨(P, T), hP, h⟩⟩

/-- The membership form of B is the existing predicate `NegativeTranslation` (constructive). -/
theorem B_mem_iff_negativeTranslation (Q : ℕ → Bool) :
    (∀ PT, PT ∉ E Q) ↔ Rule30Application.NegativeTranslation Q :=
  ⟨fun h N p hp hn => h (p, N) ⟨hp, fun t ht =>
      Decidable.byContradiction fun hne => hn ⟨t, ht, hne⟩⟩,
   fun h ⟨P, T⟩ ⟨hP, hper⟩ => h T P hP fun ⟨t, ht, hne⟩ => hne (hper t ht)⟩

/-- B is the existing predicate `NonPeriodic` (classical). -/
theorem B_iff_nonPeriodic (Q : ℕ → Bool) : B Q ↔ Rule30Application.NonPeriodic Q :=
  (B_iff Q).trans ⟨fun h N p hp => h p hp N, fun h P hP T => h T P hP⟩

/-- B is the negation of A. -/
theorem B_iff_not_A (Q : ℕ → Bool) : B Q ↔ ¬ A Q := Set.not_nonempty_iff_eq_empty.symm

/-- Excluding an infinite subfamily does not close the class: a sequence with no certificate of
period 1 can still be eventually periodic. -/
theorem period_one_closure_not_full :
    ∃ q : ℕ → Bool, (∀ T, (1, T) ∉ E q) ∧ A q := by
  refine ⟨fun t => t % 2 == 1, fun T h => ?_, (2, 0), Nat.two_pos, fun t _ => ?_⟩
  · have h1 := h.2 T (Nat.le_refl T)
    simp only at h1
    rcases Nat.mod_two_eq_zero_or_one T with h0 | h0
    · rw [Nat.add_mod, h0] at h1; simp at h1
    · rw [Nat.add_mod, h0] at h1; simp at h1
  · simp only
    rw [Nat.add_mod_right]

/-! ### Finite prefixes do not decide A or B -/

/-- The indicator of perfect squares. -/
def isSq (t : ℕ) : Bool := Nat.sqrt t * Nat.sqrt t == t

theorem isSq_mul_self (m : ℕ) : isSq (m * m) = true := by
  simp [isSq, Nat.sqrt_eq]

theorem isSq_mul_self_add {m a : ℕ} (h0 : 0 < a) (h : a ≤ m + m) : isSq (m * m + a) = false := by
  simp only [isSq, Nat.sqrt_add_eq m h, beq_eq_false_iff_ne, ne_eq]
  omega

/-- Every finite prefix of every Boolean sequence extends both to a sequence satisfying A and to a
sequence satisfying B. -/
theorem prefix_does_not_decide (Q : ℕ → Bool) (N : ℕ) :
    (∃ Q₁ : ℕ → Bool, (∀ t < N, Q₁ t = Q t) ∧ A Q₁) ∧
      (∃ Q₂ : ℕ → Bool, (∀ t < N, Q₂ t = Q t) ∧ B Q₂) := by
  refine ⟨⟨fun t => if t < N then Q t else false, fun t ht => ite_eq_left ht, (1, N), Nat.one_pos,
    fun t ht => ?_⟩, ⟨fun t => if t < N then Q t else isSq t, fun t ht => ite_eq_left ht, ?_⟩⟩
  · simp only
    rw [ite_eq_right (by omega), ite_eq_right (by omega)]
  · refine Set.eq_empty_of_forall_notMem ?_
    rintro ⟨P, T⟩ ⟨hP, hper⟩
    have hm : T + N + P ≤ (T + N + P) * (T + N + P) := Nat.le_mul_self _
    have h1 := hper ((T + N + P) * (T + N + P)) (by simp only; omega)
    simp only at h1
    rw [ite_eq_right (by omega), ite_eq_right (by omega), isSq_mul_self_add hP (by omega),
      isSq_mul_self] at h1
    exact Bool.false_ne_true h1

end EventualPeriod

namespace Rule30Center

open Rule30Bridge EventualPeriod

/-- The center sequence `Q(t)` of the stipulated Rule 30 construction. -/
abbrev Q : ℕ → Bool := center30

/-- Every candidate of period 1 is excluded: an infinite subfamily of the candidate class, closed
by the reused theorems `center30_not_eventually_white` and `center30_not_eventually_black`. -/
theorem period_one_excluded : ∀ T, (1, T) ∉ E Q := by
  intro T ⟨_, h⟩
  have hconst : ∀ n, Q (T + n) = Q T := by
    intro n
    induction n with
    | zero => rfl
    | succ n ih => exact (h (T + n) (Nat.le_add_right T n)).trans ih
  have hall : ∀ t, T ≤ t → Q t = Q T := fun t ht => by
    have := hconst (t - T)
    rwa [Nat.add_sub_cancel' ht] at this
  cases hQ : Q T with
  | false => exact center30_not_eventually_white ⟨T, fun t ht => (hall t ht).trans hQ⟩
  | true => exact center30_not_eventually_black ⟨T, fun t ht => (hall t ht).trans hQ⟩

/-- B for the Rule 30 center sequence is one implication between adjacent columns; this uses the
reused theorem `rule30_problem1_iff_marginal_step`. -/
theorem B_Q_iff_marginal_step :
    B Q ↔ (Rule30Application.EventuallyPeriodic center30 →
      Rule30Application.EventuallyPeriodic right30) :=
  (B_iff_not_A Q).trans ((not_congr (A_iff_eventuallyPeriodic Q)).trans
    rule30_problem1_iff_marginal_step)

/-- Finite computational receipt, Boolean form: for every `P ∈ {1, 2, 3}` and `T ∈ {0, 1, 2, 3}`
some `t` with `T ≤ t ≤ 9` has `Q (t + P) ≠ Q t`. -/
def receiptCheck : Bool :=
  (List.range 3).all fun i => (List.range 4).all fun T =>
    (List.range 10).any fun t => decide (T ≤ t) && (Q (t + (i + 1)) != Q t)

/-- The receipt, evaluated by the kernel. -/
theorem receiptCheck_eq_true : receiptCheck = true := by decide

/-- The receipt read as a statement about `Q`. -/
theorem finite_exclusion_receipt :
    ∀ P T : ℕ, 0 < P → P < 4 → T < 4 → ∃ t, T ≤ t ∧ t < 10 ∧ Q (t + P) ≠ Q t := by
  intro P T hP hP4 hT4
  have h := receiptCheck_eq_true
  simp only [receiptCheck, List.all_eq_true, List.any_eq_true, List.mem_range,
    Bool.and_eq_true, decide_eq_true_eq, bne_iff_ne, ne_eq] at h
  obtain ⟨t, ht10, hTt, hne⟩ := h (P - 1) (by omega) T hT4
  refine ⟨t, hTt, ht10, ?_⟩
  rwa [show P - 1 + 1 = P by omega] at hne

/-- Hence those twelve candidates are not in `E Q`. -/
theorem finite_family_excluded : ∀ P T : ℕ, 0 < P → P < 4 → T < 4 → (P, T) ∉ E Q := by
  intro P T hP hP4 hT4
  obtain ⟨t, ht, _, hne⟩ := finite_exclusion_receipt P T hP hP4 hT4
  exact not_mem_E_of_witness ht hne

/-- The finite receipt does not close B: an eventually periodic sequence satisfies it too. -/
theorem receipt_compatible_with_A : ∃ Q₁ : ℕ → Bool, A Q₁ ∧
    ∀ P T : ℕ, 0 < P → P < 4 → T < 4 → ∃ t, T ≤ t ∧ t < 10 ∧ Q₁ (t + P) ≠ Q₁ t := by
  obtain ⟨⟨Q₁, hpre, hA⟩, _⟩ := prefix_does_not_decide Q 13
  refine ⟨Q₁, hA, fun P T hP hP4 hT4 => ?_⟩
  obtain ⟨t, ht, ht10, hne⟩ := finite_exclusion_receipt P T hP hP4 hT4
  refine ⟨t, ht, ht10, ?_⟩
  rw [hpre _ (by omega), hpre _ (by omega)]
  exact hne

/-- A and B for the Rule 30 center sequence, expanded. -/
theorem A_Q_iff : A Q ↔ ∃ P, 0 < P ∧ ∃ T, ∀ t, T ≤ t → Q (t + P) = Q t := A_iff Q

theorem B_Q_iff : B Q ↔ ∀ P, 0 < P → ∀ T, ∃ t, T ≤ t ∧ Q (t + P) ≠ Q t := B_iff Q

end Rule30Center

/-! # Kernel report: axioms of every theorem in this file -/

#print axioms Consequence.monotonicity
#print axioms Consequence.subset_Cn
#print axioms Consequence.mem_Cn_Cn_iff
#print axioms Consequence.closure_idempotent
#print axioms Consequence.union_singleton_derivable
#print axioms Consequence.mem_Cn_union_singleton_iff
#print axioms Consequence.proved_as_premise_is_conservative
#print axioms Consequence.proved_as_premise_is_conservative_insert
#print axioms Consequence.Contradictory.symm
#print axioms Consequence.contradictory_neg
#print axioms Consequence.Consistent.not_both
#print axioms Consequence.Consistent.not_prov_neg
#print axioms Consequence.not_all_premises_derivable
#print axioms Consequence.refutation_requires_new_premise
#print axioms Consequence.negative_derivation_requires_new_premise
#print axioms Consequence.refuting_extension_inconsistent
#print axioms Consequence.symmetric_adjudication_core
#print axioms Consequence.symmetric_adjudication
#print axioms Consequence.symmetric_adjudication_core_swap
#print axioms Consequence.nonacceptance_not_refutation
#print axioms Consequence.hedge_not_refutation
#print axioms Consequence.bridge_rule_forces_acceptance
#print axioms Consequence.Registry.open_of_indep
#print axioms Consequence.not_indep_union_self
#print axioms Consequence.consistent_of_indep
#print axioms Consequence.model_split_core_pos
#print axioms Consequence.model_split_core_neg
#print axioms Consequence.model_split
#print axioms Consequence.not_prov_of_countermodel
#print axioms Consequence.indep_union_pos_consistent
#print axioms Consequence.indep_union_neg_consistent
#print axioms Consequence.indep_decided_in_extensions
#print axioms Consequence.rosser_instance
#print axioms Countermodels.refutation_needs_consistency
#print axioms Countermodels.refutation_needs_derivation
#print axioms Countermodels.underivable_not_refuted
#print axioms Countermodels.open_not_indep
#print axioms FO.eval_onTerm
#print axioms FO.eval_onTerms
#print axioms FO.realize_onFormula
#print axioms FO.realize_onFormula_of_realize
#print axioms FO.reinterpretation_changes_truth
#print axioms FO.reinterpretation_not_expansion
#print axioms FO.Iso.eval_term
#print axioms FO.Iso.eval_terms
#print axioms FO.Iso.cons_pointwise
#print axioms FO.Iso.toFun_inj
#print axioms FO.Iso.realize
#print axioms FO.Iso.realize_comp
#print axioms FO.twoDistinct_bool
#print axioms FO.twoDistinct_unit
#print axioms FO.injectivity_needed
#print axioms FO.surjectivity_needed
#print axioms ClassClosure.null_closure_mem
#print axioms ClassClosure.null_closure
#print axioms ClassClosure.rational_iff_int_relation
#print axioms ClassClosure.pi_int_relation_null
#print axioms ClassClosure.pi_int_relation_set_empty
#print axioms ClassClosure.isAlgebraic_int_iff
#print axioms ClassClosure.pi_poly_relation_null
#print axioms ClassClosure.pi_poly_relation_set_empty
#print axioms ClassClosure.linPoly_coeff_one
#print axioms ClassClosure.linPoly_coeff_zero
#print axioms ClassClosure.linPoly_ne_zero
#print axioms ClassClosure.aeval_linPoly
#print axioms ClassClosure.linPoly_injective
#print axioms ClassClosure.linear_class_into_poly_class
#print axioms ClassClosure.int_relation_null_of_transcendental
#print axioms ClassClosure.P_lt_two_pi
#print axioms ClassClosure.polygon_perimeter_lt
#print axioms ClassClosure.polygon_equality_set_empty
#print axioms ClassClosure.two_pi_sub_lt_P
#print axioms ClassClosure.abs_two_pi_sub_P_lt
#print axioms ClassClosure.P_tendsto
#print axioms ClassClosure.P_approaches_not_attained
#print axioms EventualPeriod.A_iff_ne_empty
#print axioms EventualPeriod.A_iff
#print axioms EventualPeriod.B_mem_iff
#print axioms EventualPeriod.B_iff
#print axioms EventualPeriod.not_A_and_B
#print axioms EventualPeriod.A_or_B
#print axioms EventualPeriod.not_mem_E_of_witness
#print axioms EventualPeriod.A_iff_eventuallyPeriodic
#print axioms EventualPeriod.B_mem_iff_negativeTranslation
#print axioms EventualPeriod.B_iff_nonPeriodic
#print axioms EventualPeriod.B_iff_not_A
#print axioms EventualPeriod.period_one_closure_not_full
#print axioms EventualPeriod.isSq_mul_self
#print axioms EventualPeriod.isSq_mul_self_add
#print axioms EventualPeriod.prefix_does_not_decide
#print axioms Rule30Center.period_one_excluded
#print axioms Rule30Center.B_Q_iff_marginal_step
#print axioms Rule30Center.receiptCheck_eq_true
#print axioms Rule30Center.finite_exclusion_receipt
#print axioms Rule30Center.finite_family_excluded
#print axioms Rule30Center.receipt_compatible_with_A
#print axioms Rule30Center.A_Q_iff
#print axioms Rule30Center.B_Q_iff
#print axioms Rule30Bridge.center30_not_eventually_white
#print axioms Rule30Bridge.center30_not_eventually_black
#print axioms Rule30Bridge.rule30_problem1_iff_marginal_step
