ON DIY QUANTUM COMPUTING (working title) -- LEAN KERNEL K1
Spin isomers, the exchange lock and its key
31 October 2026

Lu Semita (EmergenceByDesign), in co-authorship with Nexus and Orion, in continuous working
collaboration with the ChatGPT family, Claude family, and Grok within METALABE.

READ FIRST

This folder holds the first formal layer of the paper: one new Lean file, three corpus modules
reused byte for byte, the build receipts, the claim register and the computations that sit beside
the proofs. Lean certifies the model: the propositions in the files, under their stated
hypotheses. Whether a physical sample meets those hypotheses is a bridge, listed with its own
receipt in THEOREM_REGISTER.json and notes/CLAIM_LEDGER_K1.md. No fundamentality, first position or
hierarchy is asserted; the declared origin is the first cut (source and target roles), carried by
the reused frame kernel.

CONTENTS

lean/DIYQCKernel.lean        the new kernel (sections 0-14)
lean/reused/                  UniversalRecoveryClosure, ClosureConsequences (R8 core),
                              LambdaSpatiotemporalFrame (frame kernel), unchanged
receipts/                     per-target certificate.json, Audit.lean, statements_and_axioms.txt,
                              compiler logs, verification_summary.json
RECEIPT.txt                   human-readable receipt (toolchain, hashes, provenance, axiom profiles)
THEOREM_REGISTER.json         every claim with status: proved / bridge / computed / imported / open
notes/CLAIM_LEDGER_K1.md      the same ledger in prose, with the pedagogical symbols and their scope
computations/                 Python scripts and their JSON results (finite computations)
bundle/                       one-paste single-file version for a web Lean editor
reproduction/                 verify_diyqc.py, make_bundle.py, make_register.py, make_receipt.py

WHAT THE KERNEL PROVES (plain words)

1. The lock. For two identical nuclei, swapping everything multiplies the state by a fixed sign
   (minus for protons, plus for deuterons). So the spin family fixes the rotation family:
   para hydrogen rotates evenly, ortho hydrogen oddly; for deuterium it is the other way round.
2. The key. A coupling that treats the two nuclei alike converts nothing. A coupling that tells
   the nuclei apart but not their positions leaves the physical sector. Only a coupling that is
   odd under both exchanges converts: the field must differ across the bond. Conversion also
   needs a sink for at least 2B of rotational energy and for the change of spin.
3. Recognition is not conversion. A uniform readout cannot recognize para; a total-spin reading
   can, without converting anything.
4. The witness. Product states and their mixtures have singlet weight at most one half, so para
   order above one half is entanglement.
5. Symbols with formal anchors: the two-turn return, the edge-on swing, calendar closure and the
   Pythagorean comma, and the fire-like error threshold.

SEAL (this edition)

Lean 4.35.0 (commit eb6cafb7290e8bd5f2937522d8d804f58f02bafc), trust level 0, no Mathlib.
Kernel: 175 named declarations (114 theorems), 0 errors, 0 warnings. Every declaration of the lock
and key (sections 0-5, 59 declarations) reports no axioms at all. The models, arithmetic and
witness use at most propext and Quot.sound. Nothing uses Classical.choice, sorry or native_decide.
Reused modules: byte-identical. The R8 core again gives 18 theorems / 25 declarations, all
axiom-free, as its original receipt records; the frame kernel's 23 theorems are again axiom-free.
Details: RECEIPT.txt and receipts/.

REBUILD

With Lean 4.35.0 on this machine:
  python3 reproduction/verify_diyqc.py --lean /absolute/path/to/lean
Only bundled Lean libraries are needed. Compiled .olean files are rebuilt, not shipped.
