#!/usr/bin/env python3
"""
deuterium_spin_order.py

Question: how does D2 (boson nuclei, spin 1) compare with H2 (fermion nuclei, spin 1/2)
as a source of nuclear spin order for entanglement when the order comes from cold
enrichment of the spin isomers? Plus: how long must a six-pole (hexapole) lens be to
focus atoms (electron moment) versus molecules (nuclear moments only)?

Imported (stated as imported):
  - Rotational constants, ground vibrational level: H2 B0 = 59.322 cm^-1, D2 B0 = 29.904 cm^-1.
  - Symmetrization rule: total wavefunction antisymmetric under exchange of identical
    fermions, symmetric for identical bosons.
  - Werner (1989): a Werner state is separable iff its weight on the antisymmetric
    subspace is <= 1/2.
  - Hildebrand (2007) absolutely-PPT conditions for 3x3: two 3x3 matrices built from the
    sorted spectrum must be positive semidefinite (form quoted from QETLAB AbsPPTConstraints).
  - Two-qubit maximal negativity for spectrum {p,(1-p)/3 x3} is max(0, p - 1/2)
    (Verstraete, Audenaert, De Moor 2001).
  - Magnetic moments: Bohr magneton, nuclear magneton, deuteron 0.857 muN, ortho-H2 J=1
    best-aligned state ~6.47 muN (2 x 2.793 nuclear + 0.883 rotational).
  - Hexapole pole-tip field 1.5 T (ANKE atomic beam source); bore radius 10 mm is assumed.

Derived here:
  - D2: symmetric spin states (I=0 and I=2; 6 states) pair with even J (ortho-D2, ground);
    antisymmetric (I=1; 3 states) pair with odd J (para-D2).
  - Spin state at ortho fraction q: rho = q P_S/6 + (1-q) P_A/3 (two-qutrit Werner state).
  - Largest entanglement any gate sequence (global unitary) can reach, by numerical search
    over U(9); checked against Hildebrand's boundary.
  - Hexapole: |B| = B0 (r/r0)^2 -> harmonic well; parallel-to-point focusing length
    L = (pi/2) v / omega with omega = sqrt(2 mu B0 / (m r0^2)).

Error record (kept, not erased): the first pass maximised negativity directly from random
starts. Negativity is exactly zero over a wide region, so the optimiser had no slope and
reported zero entanglement for ortho fractions 0.86-0.92 that Hildebrand's conditions say
are entangleable. Fixed by a two-stage search: first minimise the smallest eigenvalue of
the partial transpose (slope everywhere), then maximise negativity from that point. The
corrected search agrees with the Hildebrand boundary q = 6/7.
"""
import json

import numpy as np
from scipy.optimize import brentq, minimize

C2 = 1.4387769                      # cm^-1 -> K
TH_H2, TH_D2 = C2 * 59.322, C2 * 29.904


def frac_even(T, theta, w_even, w_odd):
    J = np.arange(0, 40)
    w = (2 * J + 1) * np.exp(-J * (J + 1) * theta / T)
    e, o = w_even * w[J % 2 == 0].sum(), w_odd * w[J % 2 == 1].sum()
    return e / (e + o)


def p_para_H2(T):    # para-H2: even J, nuclear weight 1; ortho-H2: odd J, weight 3
    return frac_even(T, TH_H2, 1, 3)


def q_ortho_D2(T):   # ortho-D2: even J, nuclear weight 6; para-D2: odd J, weight 3
    return frac_even(T, TH_D2, 6, 3)


def ptrans(rho, d=3):
    return rho.reshape(d, d, d, d).transpose(0, 3, 2, 1).reshape(d * d, d * d)


def hildebrand_appt(lam):
    l = np.sort(np.asarray(lam, float))[::-1]
    L = lambda i: l[i - 1]
    m1 = np.array([[2 * L(9), L(8) - L(1), L(7) - L(2)],
                   [L(8) - L(1), 2 * L(6), L(5) - L(3)],
                   [L(7) - L(2), L(5) - L(3), 2 * L(4)]])
    m2 = np.array([[2 * L(9), L(8) - L(1), L(6) - L(2)],
                   [L(8) - L(1), 2 * L(7), L(5) - L(3)],
                   [L(6) - L(2), L(5) - L(3), 2 * L(4)]])
    return bool(min(np.linalg.eigvalsh(m1).min(), np.linalg.eigvalsh(m2).min()) >= -1e-12)


IU = np.triu_indices(9, 1)


def unitary(x):
    H = np.zeros((9, 9), complex)
    H[IU] = x[:36] + 1j * x[36:72]
    H = H + H.conj().T
    H[np.diag_indices(9)] = x[72:81]
    w, V = np.linalg.eigh(H)
    return (V * np.exp(1j * w)) @ V.conj().T


def pt_eigs(x, D):
    U = unitary(x)
    return np.linalg.eigvalsh(ptrans(U @ D @ U.conj().T))


def orbit_search(lam, restarts=8, seed=1):
    """Two-stage search over U(9): (1) minimise smallest partial-transpose eigenvalue,
    (2) maximise negativity from there. Returns (min eigenvalue found, max negativity)."""
    rng = np.random.default_rng(seed)
    D = np.diag(np.asarray(lam, float))
    best_min, best_neg = 1.0, 0.0
    for _ in range(restarts):
        r1 = minimize(lambda x: pt_eigs(x, D)[0], rng.normal(scale=1.5, size=81),
                      method="BFGS", options=dict(maxiter=600))
        best_min = min(best_min, float(r1.fun))
        if r1.fun < 0:
            def negsum(x):
                ev = pt_eigs(x, D)
                return float(ev[ev < 0].sum())
            r2 = minimize(negsum, r1.x, method="BFGS", options=dict(maxiter=600))
            best_neg = max(best_neg, -float(r2.fun))
    return best_min, best_neg


def EN(N):
    """Log-negativity in bits; 1.0 = one Bell pair; two qutrits max = log2(3)."""
    return float(np.log2(1 + 2 * N))


lam_q = lambda q: [q / 6] * 6 + [(1 - q) / 3] * 3
out = {"theta_rot_K": {"H2": round(TH_H2, 3), "D2": round(TH_D2, 3)}}

# 1. Equilibrium isomer fractions
out["equilibrium"] = [dict(T_K=T, para_H2=round(p_para_H2(T), 4), ortho_D2=round(q_ortho_D2(T), 4))
                      for T in (300, 77, 64, 50, 40, 39, 35, 30, 25, 20.4)]
out["para_D2_high_T_limit"] = "1/3 (statistical weights 6:3)"

# 2. Boundaries
out["D2_as_is_entangled_iff_para_D2_gt"] = 0.5
out["D2_hildebrand_APPT"] = {f"q={q}": hildebrand_appt(lam_q(q)) for q in (0.85, 0.857, 0.858, 0.9, 1.0)}
out["D2_gate_entangleable_iff_ortho_D2_gt"] = "6/7 = 0.857143"
out["D2_T_threshold_K"] = round(brentq(lambda T: q_ortho_D2(T) - 6 / 7, 25, 80), 2)
out["H2_T_threshold_K_order_kept"] = round(brentq(lambda T: p_para_H2(T) - 0.5, 50, 120), 2)

# 3. Numerical boundary scan and closed-form check N = (7q - 6)/12
scan = []
for q in (0.84, 0.85, 0.857, 0.86, 0.87, 0.88, 0.9, 1.0):
    m, n = orbit_search(lam_q(q))
    scan.append(dict(q=q, min_PT_eig=round(m, 6), max_negativity=round(n, 6),
                     closed_form=round(max(0.0, (7 * q - 6) / 12), 6)))
    print(scan[-1], flush=True)
out["D2_boundary_scan"] = scan

# 4. Best log-negativity reachable by gates vs enrichment temperature
rows = []
for T in (77, 40, 39, 35, 30, 25, 20.4):
    q, p = q_ortho_D2(T), p_para_H2(T)
    _, n = orbit_search(lam_q(q))
    rows.append(dict(T_K=T, ortho_D2=round(q, 4), EN_D2_best=round(EN(n), 3),
                     para_H2=round(p, 4), EN_H2_best=round(EN(max(0.0, p - 0.5)), 3)))
    print(rows[-1], flush=True)
out["best_log_negativity_by_gates"] = rows
_, n_para = orbit_search([1 / 3] * 3 + [0] * 6, restarts=10)
out["pure_para_D2"] = dict(as_is_negativity=round(1 / 3, 6), as_is_EN=round(EN(1 / 3), 3),
                           best_by_gates_EN=round(EN(n_para), 3))
out["reference_EN"] = dict(bell_pair=1.0, max_two_qutrits=round(float(np.log2(3)), 3))

# 5. Hexapole focusing: atoms (electron moment) vs molecules (nuclear moments)
muB, muN, u, kB = 9.2740e-24, 5.0508e-27, 1.66054e-27, 1.380649e-23
B0, r0 = 1.5, 0.010


def focus(mu, m_u, v):
    w = np.sqrt(2 * mu * B0 / r0 ** 2 / (m_u * u))
    return (np.pi / 2) * v / w, mu * B0 / kB


def v_super(T, m_u, gamma):
    return np.sqrt(2 * gamma / (gamma - 1) * kB * T / (m_u * u))


hx = []
for name, mu, m, T, g in [("D atom, electron moment", muB, 2.014, 65, 5 / 3),
                          ("H atom, electron moment", muB, 1.008, 70, 5 / 3),
                          ("ortho-H2 J=1, best state ~6.47 muN", 6.47 * muN, 2.016, 65, 7 / 5),
                          ("ortho-D2 I=2 m=2, 2 x 0.857 muN", 1.714 * muN, 4.028, 65, 7 / 5),
                          ("ortho-D2, room-temperature source", 1.714 * muN, 4.028, 300, 7 / 5)]:
    v = v_super(T, m, g)
    Lf, depth = focus(mu, m, v)
    hx.append(dict(case=name, source_T_K=T, speed_m_s=round(v), focus_length_m=round(Lf, 3),
                   well_depth_mK=round(depth * 1e3, 3)))
out["hexapole_focusing_B0_1.5T_bore_10mm"] = hx

with open("deuterium_spin_order_results.json", "w") as fh:
    json.dump(out, fh, indent=1)
print(json.dumps(out, indent=1))
