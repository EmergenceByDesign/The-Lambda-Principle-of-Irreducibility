#!/usr/bin/env python3
"""
nv_cnot_selectivity.py

Question: in an NV-ensemble two-qubit register (electron spin + its own 14N nucleus),
how narrow must the diamond's line be for a frequency-selective microwave pulse to act
as a CNOT good enough to make an entangled (Bell) state that passes the standard
entanglement witness (Bell-state fidelity F > 0.5)?

Forks run both ways: rectangular vs Gaussian microwave pulse; Gaussian vs Lorentzian
line shape. Also: ideal vs realistic initialisation.

Scope / assumptions (stated, not hidden):
  - electron qubit = ms 0 / -1; nuclear qubit = mI 0 / +1 (ESLAC-polarised into +1)
  - 14N hyperfine line spacing A = 2.16 MHz; drive resonant with the mI=+1 line
  - inhomogeneous broadening = static detuning spread (the T2* line width)
  - no homogeneous decay during the pulse (echo T2 assumed >> pulse length)
  - ideal RF pi/2 on the nucleus before the CNOT
  - out-of-qubit populations (ms=+1 electron, mI=-1 nucleus) count as zero fidelity
  - F maximised over one global frame phase (an experimenter's calibration)
"""
import json
import time

import numpy as np

A = 2.16            # MHz
TWO_PI = 2 * np.pi


def grid(gamma, shape):
    if shape == "gaussian":
        s = gamma / 2.3548
        d = np.linspace(-5 * s, 5 * s, 601)
        w = np.exp(-d**2 / (2 * s**2))
    else:  # lorentzian, truncated at +/-30 HWHM
        h = gamma / 2
        d = np.linspace(-30 * h, 30 * h, 2401)
        w = 1 / (1 + (d / h) ** 2)
    return d, w / w.sum()


def step(omega, delta, dt):
    """Propagator for H = [[0, om/2],[om/2, -delta]] (MHz), time dt (us). Vectorised over delta."""
    op = np.sqrt(delta**2 + omega**2)
    ph = np.exp(1j * np.pi * delta * dt)
    c = np.cos(np.pi * op * dt)
    s = np.where(op > 0, np.sin(np.pi * op * dt) / np.where(op > 0, op, 1), np.pi * dt)
    U = np.empty(delta.shape + (2, 2), complex)
    U[..., 0, 0] = ph * (c - 1j * s * delta)
    U[..., 1, 1] = ph * (c + 1j * s * delta)
    U[..., 0, 1] = ph * (-1j * s * omega)
    U[..., 1, 0] = ph * (-1j * s * omega)
    return U


def propagate(delta, pulse, par):
    if pulse == "rect":
        om = par
        return step(om, delta, 1 / (2 * om)), 1 / (2 * om)
    sig = par                                   # gaussian, truncated at +/-3 sigma
    nst = 300
    t = np.linspace(-3 * sig, 3 * sig, nst + 1)
    tc = 0.5 * (t[1:] + t[:-1])
    dt = t[1] - t[0]
    env = np.exp(-tc**2 / (2 * sig**2))
    env *= 0.5 / (env.sum() * dt)               # area: integral(om dt) = 1/2  -> pi pulse
    U = np.broadcast_to(np.eye(2, dtype=complex), delta.shape + (2, 2)).copy()
    for om in env:
        U = step(om, delta, dt) @ U
    return U, 6 * sig


def fidelity(gamma, shape, pulse, par, p_e, p_n):
    d, w = grid(gamma, shape)
    U1, T = propagate(d, pulse, par)            # nuclear |1> = mI=+1 : resonant line
    U0, _ = propagate(d + A, pulse, par)        # nuclear |0> = mI=0  : line offset by A
    rho = np.zeros((4, 4), complex)             # basis |e,N>, index 2e+N
    plus = np.array([1, 1]) / np.sqrt(2)
    minus = np.array([1, -1]) / np.sqrt(2)
    comps = [(0, plus, p_e * p_n), (0, minus, p_e * (1 - p_n) / 2),
             (1, plus, (1 - p_e) / 2 * p_n), (1, minus, (1 - p_e) / 2 * (1 - p_n) / 2)]
    for e0, nuc, wt in comps:
        ev = np.zeros(2)
        ev[e0] = 1
        a0 = U0 @ ev                            # electron state for nuclear branch 0, shape (n,2)
        a1 = U1 @ ev
        psi = np.zeros((d.size, 4), complex)
        psi[:, 0] = nuc[0] * a0[:, 0]           # |e=0,N=0>
        psi[:, 2] = nuc[0] * a0[:, 1]           # |e=1,N=0>
        psi[:, 1] = nuc[1] * a1[:, 0]           # |e=0,N=1>
        psi[:, 3] = nuc[1] * a1[:, 1]           # |e=1,N=1>
        rho += wt * np.einsum("k,ki,kj->ij", w, psi, psi.conj())
    F = 0.5 * (rho[0, 0].real + rho[3, 3].real) + abs(rho[0, 3])
    # truth table (ideal init): flip probability per nuclear branch
    flip1 = float(np.sum(w * np.abs(U1[:, 1, 0]) ** 2))
    flip0 = float(np.sum(w * np.abs(U0[:, 1, 0]) ** 2))
    return float(F), T, flip1, flip0


t0 = time.time()
gammas = [0.1, 0.2, 0.3, 0.5, 0.7, 1.0, 1.5, 2.0, 3.0]
scan = {"rect": np.geomspace(0.05, 3.0, 60), "gauss": np.geomspace(0.05, 5.0, 60)}
inits = {"ideal": (1.0, 1.0), "realistic_0.9_0.95": (0.9, 0.95), "pessimistic_0.8_0.9": (0.8, 0.9)}
out = dict(scope=__doc__.strip().split("Scope / assumptions (stated, not hidden):")[1].strip(),
           A_MHz=A, results={})
for shape in ("gaussian", "lorentzian"):
    for pulse in ("rect", "gauss"):
        for g in gammas:
            key = f"{shape}_line|{pulse}_pulse|FWHM_{g}MHz"
            best = {}
            for iname, (pe, pn) in inits.items():
                rows = [(par,) + fidelity(g, shape, pulse, par, pe, pn) for par in scan[pulse]]
                par, F, T, f1, f0 = max(rows, key=lambda r: r[1])
                best[iname] = dict(F=round(F, 3), pulse_param=round(float(par), 4),
                                   pulse_length_us=round(float(T), 3),
                                   flip_if_N1=round(f1, 3), flip_if_N0=round(f0, 3))
            out["results"][key] = best
            print(key, {k: v["F"] for k, v in best.items()},
                  "len_us", best["ideal"]["pulse_length_us"], flush=True)
out["runtime_s"] = round(time.time() - t0, 1)
with open("nv_cnot_selectivity_results.json", "w") as fh:
    json.dump(out, fh, indent=1)
