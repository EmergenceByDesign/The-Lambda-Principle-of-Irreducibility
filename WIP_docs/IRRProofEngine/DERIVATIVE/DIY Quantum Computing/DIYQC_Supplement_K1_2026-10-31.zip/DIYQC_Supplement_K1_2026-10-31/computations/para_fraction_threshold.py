#!/usr/bin/env python3
"""
para_fraction_threshold.py

Question: at what enrichment temperature does the equilibrium para fraction p of H2 pass one half,
the point above which the nuclear singlet weight certifies entanglement (Lean K1:
Witness.above_half_is_entangled)? How much margin do the cheap cooling routes give?

Imported (stated as imported):
  - J=0 to J=1 interval of H2: 118.48677 cm^-1 (Beyer et al., PRL 123, 163002, 2019).
  - Higher levels from the standard Raman S-branch of H2: S(0) 354.37, S(1) 587.03, S(2) 814.42,
    S(3) 1034.67 cm^-1; rigid-rotor constant B0 = 59.322 cm^-1 and distortion D0 = 0.0471 cm^-1.
  - Nuclear spin weights 1 (even J, para) and 3 (odd J, ortho).
  - Liquid nitrogen: normal boiling point 77.36 K; triple point 63.15 K (pumped bath).
  - Measured output of a 77 K generator: about 48 % para (Chapman et al., Anal. Chem. 2021).
Derived here: p(T) for three level models, the threshold temperature, and the margins.
"""
import json

import numpy as np
from scipy.optimize import brentq

C2 = 1.4387769                       # cm^-1 -> K
B0, D0 = 59.322, 0.0471
LEV = {0: 0.0, 1: 118.48677, 2: 354.37}
LEV[3] = LEV[1] + 587.03
LEV[4] = LEV[2] + 814.42
LEV[5] = LEV[3] + 1034.67

MODELS = {
    'rigid rotor': lambda J: B0 * J * (J + 1),
    'rotor with distortion': lambda J: B0 * J * (J + 1) - D0 * (J * (J + 1)) ** 2,
    'measured levels (J<=5), distortion above': lambda J: LEV[J] if J in LEV else
        B0 * J * (J + 1) - D0 * (J * (J + 1)) ** 2,
}


def para_fraction(T, energy, jmax=12):
    even = odd = 0.0
    for J in range(jmax + 1):
        w = (2 * J + 1) * np.exp(-energy(J) * C2 / T)
        if J % 2 == 0:
            even += w
        else:
            odd += w
    return even / (even + 3 * odd)


out = {}
for name, energy in MODELS.items():
    th = brentq(lambda T: para_fraction(T, energy) - 0.5, 60, 100)
    out[name] = {
        'threshold_T_K': round(th, 2),
        'gap_J0_J1_K': round((energy(1) - energy(0)) * C2, 2),
        'p_at': {str(T): round(para_fraction(T, energy), 4)
                 for T in (300, 90, 80, 77.36, 77, 70, 65, 63.15, 50, 40, 30, 20.3)},
    }
m = out['measured levels (J<=5), distortion above']
out['margins_above_one_half_points'] = {
    'LN2 at 77.36 K, full equilibrium': round(100 * (m['p_at']['77.36'] - 0.5), 2),
    'LN2 generator as measured (48 %)': round(48.0 - 50.0, 2),
    'pumped LN2 at 65 K': round(100 * (m['p_at']['65'] - 0.5), 2),
    'pumped LN2 at the triple point 63.15 K': round(100 * (m['p_at']['63.15'] - 0.5), 2),
}
with open('para_fraction_threshold_results.json', 'w') as fh:
    json.dump(out, fh, indent=1)
print(json.dumps(out, indent=1))
