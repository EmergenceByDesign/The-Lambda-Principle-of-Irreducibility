#!/usr/bin/env python3
"""
parahydrogen_entanglement_boundary.py

Question: where is the boundary between "too mixed to hold entanglement" and
"can be made entangled" for a two-proton NMR register whose spin order comes from
para-hydrogen, and what enrichment temperature does each preparation route need?

Imported (stated as imported):
  - Two-qubit spectral criterion (Ishizaka & Hiroshima 2000; Verstraete, Audenaert &
    De Moor 2001): with eigenvalues l1>=l2>=l3>=l4, the largest concurrence any global
    unitary (any gate sequence) can reach is max(0, l1 - l3 - 2*sqrt(l2*l4)).
    Checked numerically below against Wootters' concurrence of the explicit optimal state.
  - H2 rotational temperature theta = hcB0/k with B0 = 59.322 cm^-1 (ground vibrational state).

Derived here:
  - Para fraction p -> two-proton state p|S><S| + (1-p)/3 (I - |S><S|)
    = (1-eps) I/4 + eps |S><S|,  eps = (4p-1)/3.
  - Singlet order kept (synchronised reaction, or reaction at low field then slow transfer
    into the magnet): spectrum {p, (1-p)/3 x3}  ->  C_max = 2p - 1.
  - Singlet order dephased (continuous reaction inside the magnet, weak coupling):
    spectrum {(1+eps)/4 x2, (1-eps)/4 x2}  ->  C_max = (eps - sqrt(1-eps^2)) / 2.
"""
import json

import numpy as np

THETA = 1.4387769 * 59.322          # K


def para_fraction(T):
    J = np.arange(0, 40)
    w = (2 * J + 1) * np.exp(-J * (J + 1) * THETA / T)
    even, odd = w[J % 2 == 0].sum(), w[J % 2 == 1].sum()
    return even / (even + 3 * odd)


def cmax_from_spectrum(lams):
    l = np.sort(np.asarray(lams, float))[::-1]
    return l[0] - l[2] - 2 * np.sqrt(l[1] * l[3])


def wootters(rho):
    sy = np.array([[0, -1j], [1j, 0]])
    yy = np.kron(sy, sy)
    R = rho @ yy @ rho.conj() @ yy
    ev = np.sqrt(np.abs(np.sort(np.linalg.eigvals(R).real)[::-1]))
    return max(0.0, ev[0] - ev[1] - ev[2] - ev[3])


def optimal_state(lams):
    """Verstraete et al. form: l1|Phi+><Phi+| + l2|01><01| + l3|Phi-><Phi-| + l4|10><10|."""
    l = np.sort(np.asarray(lams, float))[::-1]
    phip = np.array([1, 0, 0, 1]) / np.sqrt(2)
    phim = np.array([1, 0, 0, -1]) / np.sqrt(2)
    e01 = np.array([0, 1, 0, 0])
    e10 = np.array([0, 0, 1, 0])
    return sum(li * np.outer(v, v) for li, v in zip(l, (phip, e01, phim, e10)))


def spectra(p):
    eps = (4 * p - 1) / 3
    kept = [p, (1 - p) / 3, (1 - p) / 3, (1 - p) / 3]
    deph = [(1 + eps) / 4, (1 + eps) / 4, (1 - eps) / 4, (1 - eps) / 4]
    return eps, kept, deph


rows = []
cases = [("normal H2, room temperature", 298.0), ("LN2 bath", 77.0),
         ("LN2 pumped to near its triple point", 64.0), ("cryocooler", 50.0),
         ("cryocooler", 40.0), ("cryocooler", 30.0), ("liquid-H2 temperature", 20.4)]
for label, T in cases:
    p = para_fraction(T)
    eps, kept, deph = spectra(p)
    ck, cd = cmax_from_spectrum(kept), cmax_from_spectrum(deph)
    rows.append(dict(source=label, T_K=T, para_fraction=round(p, 4), eps=round(eps, 4),
                     Cmax_singlet_order_kept=round(max(0, ck), 4),
                     Cmax_singlet_order_dephased=round(max(0, cd), 4),
                     check_wootters_kept=round(wootters(optimal_state(kept)), 4),
                     check_wootters_dephased=round(wootters(optimal_state(deph)), 4)))

# thresholds
p_kept = 0.5
eps_d = 1 / np.sqrt(2)
p_deph = (3 * eps_d + 1) / 4

# thermal comparison: two protons at 1 T, 298 K (high-temperature limit)
h, k = 6.62607015e-34, 1.380649e-23
pol = h * 42.577e6 / (2 * k * 298.0)
ab = 0.25 * np.array([(1 + pol) ** 2, (1 + pol) * (1 - pol), (1 - pol) * (1 + pol), (1 - pol) ** 2])
thermal = dict(proton_polarization_1T_298K=float(pol),
               Cmax=float(cmax_from_spectrum(ab)))

out = dict(theta_rot_K=THETA, rows=rows,
           threshold_para_fraction_singlet_kept=p_kept,
           threshold_para_fraction_dephased=round(float(p_deph), 4),
           thermal_room_temperature=thermal)
with open("parahydrogen_entanglement_boundary_results.json", "w") as fh:
    json.dump(out, fh, indent=1)
print(json.dumps(out, indent=1))
