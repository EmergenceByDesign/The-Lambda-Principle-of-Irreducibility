import DIYQCKernel
#check DIYQC.FirstCut.factorsThrough_iff_recovers
#print axioms DIYQC.FirstCut.factorsThrough_iff_recovers
#check DIYQC.FirstCut.swap
#print axioms DIYQC.FirstCut.swap
#check DIYQC.FirstCut.swap_swap
#print axioms DIYQC.FirstCut.swap_swap
#check DIYQC.FirstCut.RoleBlind
#print axioms DIYQC.FirstCut.RoleBlind
#check DIYQC.FirstCut.role_blind_reading_cannot_order
#print axioms DIYQC.FirstCut.role_blind_reading_cannot_order
#check DIYQC.FirstCut.cut_is_held_not_read
#print axioms DIYQC.FirstCut.cut_is_held_not_read
#check DIYQC.FirstCut.labelled_reading_recovers_order
#print axioms DIYQC.FirstCut.labelled_reading_recovers_order
#check DIYQC.Sign
#print axioms DIYQC.Sign
#check DIYQC.Sign.mul
#print axioms DIYQC.Sign.mul
#check DIYQC.Sign.flip
#print axioms DIYQC.Sign.flip
#check DIYQC.Sign.mul_self
#print axioms DIYQC.Sign.mul_self
#check DIYQC.Sign.mul_comm
#print axioms DIYQC.Sign.mul_comm
#check DIYQC.Sign.flip_flip
#print axioms DIYQC.Sign.flip_flip
#check DIYQC.Sign.flip_ne
#print axioms DIYQC.Sign.flip_ne
#check DIYQC.Sign.mul_minus
#print axioms DIYQC.Sign.mul_minus
#check DIYQC.Sign.mul_eq_plus_iff
#print axioms DIYQC.Sign.mul_eq_plus_iff
#check DIYQC.SignedCarrier
#print axioms DIYQC.SignedCarrier
#check DIYQC.SignedCarrier.act
#print axioms DIYQC.SignedCarrier.act
#check DIYQC.SignedCarrier.act_self
#print axioms DIYQC.SignedCarrier.act_self
#check DIYQC.SignedCarrier.act_act
#print axioms DIYQC.SignedCarrier.act_act
#check DIYQC.SignedCarrier.neg_act
#print axioms DIYQC.SignedCarrier.neg_act
#check DIYQC.SignedCarrier.sign_actions_agree_only_at_zero
#print axioms DIYQC.SignedCarrier.sign_actions_agree_only_at_zero
#check DIYQC.ExchangePair
#print axioms DIYQC.ExchangePair
#check DIYQC.ExchangePair.Statistics
#print axioms DIYQC.ExchangePair.Statistics
#check DIYQC.ExchangePair.SpinClass
#print axioms DIYQC.ExchangePair.SpinClass
#check DIYQC.ExchangePair.RotationParity
#print axioms DIYQC.ExchangePair.RotationParity
#check DIYQC.ExchangePair.spinSwap_act
#print axioms DIYQC.ExchangePair.spinSwap_act
#check DIYQC.ExchangePair.isomer_lock
#print axioms DIYQC.ExchangePair.isomer_lock
#check DIYQC.ExchangePair.fermion_antisymmetric_even
#print axioms DIYQC.ExchangePair.fermion_antisymmetric_even
#check DIYQC.ExchangePair.fermion_symmetric_odd
#print axioms DIYQC.ExchangePair.fermion_symmetric_odd
#check DIYQC.ExchangePair.boson_symmetric_even
#print axioms DIYQC.ExchangePair.boson_symmetric_even
#check DIYQC.ExchangePair.boson_antisymmetric_odd
#print axioms DIYQC.ExchangePair.boson_antisymmetric_odd
#check DIYQC.ExchangePair.RespectsSign
#print axioms DIYQC.ExchangePair.RespectsSign
#check DIYQC.ExchangePair.SpinParity
#print axioms DIYQC.ExchangePair.SpinParity
#check DIYQC.ExchangePair.PosParity
#print axioms DIYQC.ExchangePair.PosParity
#check DIYQC.ExchangePair.act_respect
#print axioms DIYQC.ExchangePair.act_respect
#check DIYQC.ExchangePair.spinSwap_of_parity
#print axioms DIYQC.ExchangePair.spinSwap_of_parity
#check DIYQC.ExchangePair.posSwap_of_parity
#print axioms DIYQC.ExchangePair.posSwap_of_parity
#check DIYQC.ExchangePair.spinClass_of_parity
#print axioms DIYQC.ExchangePair.spinClass_of_parity
#check DIYQC.ExchangePair.statistics_of_parity
#print axioms DIYQC.ExchangePair.statistics_of_parity
#check DIYQC.ExchangePair.spinClass_disjoint
#print axioms DIYQC.ExchangePair.spinClass_disjoint
#check DIYQC.ExchangePair.statistics_disjoint
#print axioms DIYQC.ExchangePair.statistics_disjoint
#check DIYQC.ExchangePair.even_preserves_spin_class
#print axioms DIYQC.ExchangePair.even_preserves_spin_class
#check DIYQC.ExchangePair.odd_flips_spin_class
#print axioms DIYQC.ExchangePair.odd_flips_spin_class
#check DIYQC.ExchangePair.even_cannot_convert
#print axioms DIYQC.ExchangePair.even_cannot_convert
#check DIYQC.ExchangePair.doubly_odd_preserves_statistics
#print axioms DIYQC.ExchangePair.doubly_odd_preserves_statistics
#check DIYQC.ExchangePair.spin_odd_pos_even_leaves_sector
#print axioms DIYQC.ExchangePair.spin_odd_pos_even_leaves_sector
#check DIYQC.ExchangePair.spin_odd_pos_even_vanishes_in_sector
#print axioms DIYQC.ExchangePair.spin_odd_pos_even_vanishes_in_sector
#check DIYQC.ExchangePair.key_converts
#print axioms DIYQC.ExchangePair.key_converts
#check DIYQC.ExchangePair.converting_coupling_is_doubly_odd
#print axioms DIYQC.ExchangePair.converting_coupling_is_doubly_odd
#check DIYQC.Additive
#print axioms DIYQC.Additive
#check DIYQC.SitePair
#print axioms DIYQC.SitePair
#check DIYQC.SitePair.sum
#print axioms DIYQC.SitePair.sum
#check DIYQC.SitePair.difference
#print axioms DIYQC.SitePair.difference
#check DIYQC.SitePair.sum_respects
#print axioms DIYQC.SitePair.sum_respects
#check DIYQC.SitePair.difference_respects
#print axioms DIYQC.SitePair.difference_respects
#check DIYQC.SitePair.sum_even
#print axioms DIYQC.SitePair.sum_even
#check DIYQC.SitePair.difference_odd
#print axioms DIYQC.SitePair.difference_odd
#check DIYQC.SitePair.sum_cannot_convert
#print axioms DIYQC.SitePair.sum_cannot_convert
#check DIYQC.SitePair.difference_flips
#print axioms DIYQC.SitePair.difference_flips
#check DIYQC.Model.decForallFin
#print axioms DIYQC.Model.decForallFin
#check DIYQC.Model.Spins
#print axioms DIYQC.Model.Spins
#check DIYQC.Model.State
#print axioms DIYQC.Model.State
#check DIYQC.Model.state_ext
#print axioms DIYQC.Model.state_ext
#check DIYQC.Model.negV
#print axioms DIYQC.Model.negV
#check DIYQC.Model.zeroV
#print axioms DIYQC.Model.zeroV
#check DIYQC.Model.addV
#print axioms DIYQC.Model.addV
#check DIYQC.Model.posSwapV
#print axioms DIYQC.Model.posSwapV
#check DIYQC.Model.Spins.spinSwapV
#print axioms DIYQC.Model.Spins.spinSwapV
#check DIYQC.Model.Spins.carrier
#print axioms DIYQC.Model.Spins.carrier
#check DIYQC.Model.Spins.uniform
#print axioms DIYQC.Model.Spins.uniform
#check DIYQC.Model.Spins.gradient
#print axioms DIYQC.Model.Spins.gradient
#check DIYQC.Model.Spins.uniform_sum_pos_even
#print axioms DIYQC.Model.Spins.uniform_sum_pos_even
#check DIYQC.Model.Spins.uniform_difference_pos_even
#print axioms DIYQC.Model.Spins.uniform_difference_pos_even
#check DIYQC.Model.Spins.gradient_difference_pos_odd
#print axioms DIYQC.Model.Spins.gradient_difference_pos_odd
#check DIYQC.Model.protons
#print axioms DIYQC.Model.protons
#check DIYQC.Model.deuterons
#print axioms DIYQC.Model.deuterons
#check DIYQC.Model.Hydrogen.para
#print axioms DIYQC.Model.Hydrogen.para
#check DIYQC.Model.Hydrogen.orthoOdd
#print axioms DIYQC.Model.Hydrogen.orthoOdd
#check DIYQC.Model.Hydrogen.symmetricEven
#print axioms DIYQC.Model.Hydrogen.symmetricEven
#check DIYQC.Model.Hydrogen.para4
#print axioms DIYQC.Model.Hydrogen.para4
#check DIYQC.Model.Hydrogen.para_is_fermion_pair
#print axioms DIYQC.Model.Hydrogen.para_is_fermion_pair
#check DIYQC.Model.Hydrogen.para_is_antisymmetric
#print axioms DIYQC.Model.Hydrogen.para_is_antisymmetric
#check DIYQC.Model.Hydrogen.para_rotates_evenly
#print axioms DIYQC.Model.Hydrogen.para_rotates_evenly
#check DIYQC.Model.Hydrogen.uniform_annihilates_para
#print axioms DIYQC.Model.Hydrogen.uniform_annihilates_para
#check DIYQC.Model.Hydrogen.spin_difference_without_gradient
#print axioms DIYQC.Model.Hydrogen.spin_difference_without_gradient
#check DIYQC.Model.Hydrogen.symmetricEven_wrong_statistics
#print axioms DIYQC.Model.Hydrogen.symmetricEven_wrong_statistics
#check DIYQC.Model.Hydrogen.gradient_converts_para
#print axioms DIYQC.Model.Hydrogen.gradient_converts_para
#check DIYQC.Model.Hydrogen.orthoOdd_is_fermion_pair
#print axioms DIYQC.Model.Hydrogen.orthoOdd_is_fermion_pair
#check DIYQC.Model.Hydrogen.orthoOdd_is_symmetric
#print axioms DIYQC.Model.Hydrogen.orthoOdd_is_symmetric
#check DIYQC.Model.Hydrogen.orthoOdd_rotates_oddly
#print axioms DIYQC.Model.Hydrogen.orthoOdd_rotates_oddly
#check DIYQC.Model.Hydrogen.gradient_returns_to_para
#print axioms DIYQC.Model.Hydrogen.gradient_returns_to_para
#check DIYQC.Model.Hydrogen.orthoOdd_nonzero
#print axioms DIYQC.Model.Hydrogen.orthoOdd_nonzero
#check DIYQC.Model.Hydrogen.symmetricEven_nonzero
#print axioms DIYQC.Model.Hydrogen.symmetricEven_nonzero
#check DIYQC.Model.Deuterium.ortho
#print axioms DIYQC.Model.Deuterium.ortho
#check DIYQC.Model.Deuterium.paraOdd
#print axioms DIYQC.Model.Deuterium.paraOdd
#check DIYQC.Model.Deuterium.antisymmetricEven
#print axioms DIYQC.Model.Deuterium.antisymmetricEven
#check DIYQC.Model.Deuterium.orthoBack
#print axioms DIYQC.Model.Deuterium.orthoBack
#check DIYQC.Model.Deuterium.ortho_is_boson_pair
#print axioms DIYQC.Model.Deuterium.ortho_is_boson_pair
#check DIYQC.Model.Deuterium.ortho_is_symmetric
#print axioms DIYQC.Model.Deuterium.ortho_is_symmetric
#check DIYQC.Model.Deuterium.ortho_rotates_evenly
#print axioms DIYQC.Model.Deuterium.ortho_rotates_evenly
#check DIYQC.Model.Deuterium.uniform_annihilates_ortho
#print axioms DIYQC.Model.Deuterium.uniform_annihilates_ortho
#check DIYQC.Model.Deuterium.spin_difference_without_gradient
#print axioms DIYQC.Model.Deuterium.spin_difference_without_gradient
#check DIYQC.Model.Deuterium.antisymmetricEven_wrong_statistics
#print axioms DIYQC.Model.Deuterium.antisymmetricEven_wrong_statistics
#check DIYQC.Model.Deuterium.gradient_converts_ortho
#print axioms DIYQC.Model.Deuterium.gradient_converts_ortho
#check DIYQC.Model.Deuterium.paraOdd_is_boson_pair
#print axioms DIYQC.Model.Deuterium.paraOdd_is_boson_pair
#check DIYQC.Model.Deuterium.paraOdd_is_antisymmetric
#print axioms DIYQC.Model.Deuterium.paraOdd_is_antisymmetric
#check DIYQC.Model.Deuterium.paraOdd_rotates_oddly
#print axioms DIYQC.Model.Deuterium.paraOdd_rotates_oddly
#check DIYQC.Model.Deuterium.gradient_returns_to_ortho
#print axioms DIYQC.Model.Deuterium.gradient_returns_to_ortho
#check DIYQC.Model.Deuterium.paraOdd_nonzero
#print axioms DIYQC.Model.Deuterium.paraOdd_nonzero
#check DIYQC.Recognition.PairState
#print axioms DIYQC.Recognition.PairState
#check DIYQC.Recognition.uniformReading
#print axioms DIYQC.Recognition.uniformReading
#check DIYQC.Recognition.isomer
#print axioms DIYQC.Recognition.isomer
#check DIYQC.Recognition.totalSpinReading
#print axioms DIYQC.Recognition.totalSpinReading
#check DIYQC.Recognition.uniform_reading_cannot_recognize
#print axioms DIYQC.Recognition.uniform_reading_cannot_recognize
#check DIYQC.Recognition.adequate_coordinate_separates
#print axioms DIYQC.Recognition.adequate_coordinate_separates
#check DIYQC.Recognition.total_spin_recognizes
#print axioms DIYQC.Recognition.total_spin_recognizes
#check DIYQC.Recognition.conversion_changes_total_spin
#print axioms DIYQC.Recognition.conversion_changes_total_spin
#check DIYQC.Sink.rotLevel
#print axioms DIYQC.Sink.rotLevel
#check DIYQC.Sink.lowest_gap
#print axioms DIYQC.Sink.lowest_gap
#check DIYQC.Sink.rotLevel_gap
#print axioms DIYQC.Sink.rotLevel_gap
#check DIYQC.Sink.parity_change_needs_energy
#print axioms DIYQC.Sink.parity_change_needs_energy
#check DIYQC.Counting.sym
#print axioms DIYQC.Counting.sym
#check DIYQC.Counting.anti
#print axioms DIYQC.Counting.anti
#check DIYQC.Counting.sym_add_anti
#print axioms DIYQC.Counting.sym_add_anti
#check DIYQC.Counting.sym_eq_anti_add
#print axioms DIYQC.Counting.sym_eq_anti_add
#check DIYQC.Counting.hydrogen_families
#print axioms DIYQC.Counting.hydrogen_families
#check DIYQC.Counting.deuterium_families
#print axioms DIYQC.Counting.deuterium_families
#check DIYQC.Counting.coldFamily
#print axioms DIYQC.Counting.coldFamily
#check DIYQC.Counting.anti_ge_three
#print axioms DIYQC.Counting.anti_ge_three
#check DIYQC.Counting.sym_ge_three
#print axioms DIYQC.Counting.sym_ge_three
#check DIYQC.Counting.cold_family_single_iff
#print axioms DIYQC.Counting.cold_family_single_iff
#check DIYQC.Witness.Amp2
#print axioms DIYQC.Witness.Amp2
#check DIYQC.Witness.norm2
#print axioms DIYQC.Witness.norm2
#check DIYQC.Witness.detRe
#print axioms DIYQC.Witness.detRe
#check DIYQC.Witness.detIm
#print axioms DIYQC.Witness.detIm
#check DIYQC.Witness.ipRe
#print axioms DIYQC.Witness.ipRe
#check DIYQC.Witness.ipIm
#print axioms DIYQC.Witness.ipIm
#check DIYQC.Witness.lagrange
#print axioms DIYQC.Witness.lagrange
#check DIYQC.Witness.square_nonneg
#print axioms DIYQC.Witness.square_nonneg
#check DIYQC.Witness.product_singlet_bound
#print axioms DIYQC.Witness.product_singlet_bound
#check DIYQC.Witness.mixtureSinglet
#print axioms DIYQC.Witness.mixtureSinglet
#check DIYQC.Witness.mixtureNorm
#print axioms DIYQC.Witness.mixtureNorm
#check DIYQC.Witness.separable_singlet_bound
#print axioms DIYQC.Witness.separable_singlet_bound
#check DIYQC.Witness.above_half_is_entangled
#print axioms DIYQC.Witness.above_half_is_entangled
#check DIYQC.TwoTurn.spinorSign
#print axioms DIYQC.TwoTurn.spinorSign
#check DIYQC.TwoTurn.directionReading
#print axioms DIYQC.TwoTurn.directionReading
#check DIYQC.TwoTurn.one_turn_flips
#print axioms DIYQC.TwoTurn.one_turn_flips
#check DIYQC.TwoTurn.returns_after_two_turns
#print axioms DIYQC.TwoTurn.returns_after_two_turns
#check DIYQC.TwoTurn.direction_cannot_recover_sign
#print axioms DIYQC.TwoTurn.direction_cannot_recover_sign
#check DIYQC.TwoTurn.reference_must_separate
#print axioms DIYQC.TwoTurn.reference_must_separate
#check DIYQC.TwoTurn.SpinStatisticsBridge
#print axioms DIYQC.TwoTurn.SpinStatisticsBridge
#check DIYQC.TwoTurn.proton_pair_is_fermion
#print axioms DIYQC.TwoTurn.proton_pair_is_fermion
#check DIYQC.TwoTurn.deuteron_pair_is_boson
#print axioms DIYQC.TwoTurn.deuteron_pair_is_boson
#check DIYQC.EdgeOn.fold
#print axioms DIYQC.EdgeOn.fold
#check DIYQC.EdgeOn.fold_symm
#print axioms DIYQC.EdgeOn.fold_symm
#check DIYQC.EdgeOn.edge_on_cannot_recover_phase
#print axioms DIYQC.EdgeOn.edge_on_cannot_recover_phase
#check DIYQC.EdgeOn.quarter_turns_collide
#print axioms DIYQC.EdgeOn.quarter_turns_collide
#check DIYQC.EdgeOn.swing_positions_12
#print axioms DIYQC.EdgeOn.swing_positions_12
#check DIYQC.Closure.tzolkin_round
#print axioms DIYQC.Closure.tzolkin_round
#check DIYQC.Closure.calendar_round
#print axioms DIYQC.Closure.calendar_round
#check DIYQC.Closure.calendar_round_gcd
#print axioms DIYQC.Closure.calendar_round_gcd
#check DIYQC.Closure.calendar_round_counts
#print axioms DIYQC.Closure.calendar_round_counts
#check DIYQC.Closure.selective_closure
#print axioms DIYQC.Closure.selective_closure
#check DIYQC.Closure.three_pow_odd
#print axioms DIYQC.Closure.three_pow_odd
#check DIYQC.Closure.two_pow_even
#print axioms DIYQC.Closure.two_pow_even
#check DIYQC.Closure.pythagorean_nonclosure
#print axioms DIYQC.Closure.pythagorean_nonclosure
#check DIYQC.Closure.pythagorean_comma
#print axioms DIYQC.Closure.pythagorean_comma
#check DIYQC.Threshold.step
#print axioms DIYQC.Threshold.step
#check DIYQC.Threshold.iter
#print axioms DIYQC.Threshold.iter
#check DIYQC.Threshold.step_zero
#print axioms DIYQC.Threshold.step_zero
#check DIYQC.Threshold.step_lt
#print axioms DIYQC.Threshold.step_lt
#check DIYQC.Threshold.iter_bound
#print axioms DIYQC.Threshold.iter_bound
#check DIYQC.Threshold.below_threshold_dies_out
#print axioms DIYQC.Threshold.below_threshold_dies_out
#check DIYQC.Threshold.above_threshold_no_decrease
#print axioms DIYQC.Threshold.above_threshold_no_decrease
