#!/usr/bin/env python3
"""Compose RECEIPT.txt (the layout of the Axiom as Pharmakon R3 receipt) from the certificates."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

root = Path(__file__).resolve().parents[1]
summary = json.loads((root / 'receipts/verification_summary.json').read_text())
certs = {t: json.loads((root / f'receipts/{t}/certificate.json').read_text())
         for t in ('reused_core', 'reused_frame', 'kernel')}
k = certs['kernel']


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def stage_text(cert, module):
    s = next(x for x in cert['stages'] if x['module'] == module)
    extra = f"; {s['information']} information message(s) (its own #check/#print lines)" if s['information'] else ''
    return f"exit {s['exit_code']}, {s['errors']} errors, {s['warnings']} warnings{extra}"


def profile_text(p):
    keys = sorted(p, key=lambda k: (k != 'none', len(k), k))
    return '; '.join(f"[{k}]: {p[k]}" if k != 'none' else f"none: {p[k]}" for k in keys)


REUSED = [
    ('UniversalRecoveryClosure', 'reused_core',
     'core/UniversalRecoveryClosure.lean of WIP_docs/IRRProofEngine/DERIVATIVE/'
     'Closure_at_the_Adjudication_Seam_2026-10-24_R8_Complete_Proofs.zip',
     'Closure at the Adjudication Seam, core (R8 packet, 24 October 2026; unchanged in R8.1)',
     'Lean 4.22.0, trust level 0: 0 errors, 0 warnings; core axiom reports empty'),
    ('ClosureConsequences', 'reused_core',
     'core/ClosureConsequences.lean of WIP_docs/IRRProofEngine/DERIVATIVE/'
     'Closure_at_the_Adjudication_Seam_2026-10-24_R8_Complete_Proofs.zip',
     'Closure at the Adjudication Seam, core (R8 packet, 24 October 2026; unchanged in R8.1)',
     'Lean 4.22.0, trust level 0: 0 errors, 0 warnings; core axiom reports empty'),
    ('LambdaSpatiotemporalFrame', 'reused_frame',
     'embedded file LambdaSpatiotemporalFrame.lean of WIP_docs/IRRProofEngine/DERIVATIVE/'
     'Lambda_Reference_and_Spatiotemporal_Descriptive_Frame_V1.pdf',
     'Lambda, Reference, and the Spatiotemporal Descriptive Frame, receipt edition '
     '(Lu Semita, EmergenceByDesign, 10 September 2026)',
     'Lean Web, Lean 4.33.0: PASS, 23 theorems, 0 errors, 0 warnings, 23 axiom-free reports; '
     'accepted source 13340 bytes, 352 lines'),
]

lines = [
    'ON DIY QUANTUM COMPUTING (working title) - Lean kernel K1 - receipt '
    f"({datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')} UTC)",
    '',
    f"Toolchain: {summary['lean_version']}",
    '           compiled here from the official source tree at tag v4.35.0 (the release archive could',
    '           not be downloaded from this environment); same commit as the toolchain of the',
    '           Axiom as Pharmakon R3 receipt. Executable SHA-256 '
    f"{summary['lean_executable_sha256']}",
    '           (a thin launcher linked to the compiler library libleanshared.so, SHA-256',
    f"           {summary.get('lean_shared_library_sha256', 'not recorded')}).",
    '           The official release names its target x86_64-unknown-linux-gnu; this source build',
    '           names x86_64-pc-linux-gnu. The commit is identical.',
    'Library:   bundled Lean libraries only (no Mathlib). Trust level 0 for every compilation.',
    '',
    f"Main file: DIYQCKernel.lean   SHA-256 {sha(root / 'lean/DIYQCKernel.lean')}",
    f"           {len(k['audited_declarations'])} declarations ({len(k['audited_theorems'])} theorems); "
    'sorry/admit/native_decide/axiom declarations: 0.',
    f"           Result: {stage_text(k, 'DIYQCKernel')}.",
    f"           Axiom profiles: {profile_text(k['axiom_profile'])}",
    f"           Every axiom report is in receipts/kernel/statements_and_axioms.txt, verbatim.",
    '',
    'Reused modules (folder lean/reused/), byte-identical to their sources, compiled here in this order:',
]
NAMESPACE = {'UniversalRecoveryClosure': 'UniversalRecoveryClosure.',
             'ClosureConsequences': 'ClosureConsequences.',
             'LambdaSpatiotemporalFrame': 'LambdaSpatiotemporal.'}


def module_profile(cert, prefix):
    prof, n = {}, 0
    for d, rep in zip(cert['audited_declarations'], cert['axiom_reports']):
        if not d.startswith(prefix):
            continue
        n += 1
        used = 'none'
        if 'depends on axioms: [' in rep:
            used = rep.split('depends on axioms: [')[1].split(']')[0]
        prof[used] = prof.get(used, 0) + 1
    return n, prof


for name, target, src, work, orig in REUSED:
    c = certs[target]
    n, prof = module_profile(c, NAMESPACE[name])
    lines += [
        f'  {name}.lean',
        f"      SHA-256 {sha(root / 'lean/reused' / (name + '.lean'))}  unchanged; this build: "
        f'{stage_text(c, name)}',
        f'      audited here: {n} declarations; axiom profile {profile_text(prof)}',
        f'      from: {src}',
        f'      work: {work}',
        f'      original check: {orig}',
    ]
core = certs['reused_core']; frame = certs['reused_frame']
lines += [
    '',
    'Agreement with the original receipts:',
    f"  R8 core: {len(core['audited_theorems'])} theorems and {len(core['audited_declarations'])} named "
    'declarations, every axiom report empty (R8 recorded 18 and 25, all empty).',
    f"  Frame kernel: {len(frame['audited_theorems'])} theorems, every axiom report empty "
    f"({len(frame['audited_declarations'])} named declarations audited; the V1 receipt recorded 23 "
    'theorems, all axiom-free).',
]
lines += [
    '',
    'Sources: corpus repository EmergenceByDesign/The-Lambda-Principle-of-Irreducibility, commit',
    '  55436de8367c06d81fc5d9a35a5ada503c1ce09a (30 October 2026):',
    '  WIP_docs/IRRProofEngine/DERIVATIVE/Closure_at_the_Adjudication_Seam_2026-10-24_R8_Complete_Proofs.zip',
    '      SHA-256 dec8a3bb86780380bedb3c6b6aef214dba9c4766852a970115a267d7f7eab89c',
    '  WIP_docs/IRRProofEngine/DERIVATIVE/Lambda_Reference_and_Spatiotemporal_Descriptive_Frame_V1.pdf',
    '      SHA-256 f73ad48bdd06a528bced44d4babccf24c00a78939cead983343b1d74d01d868a',
    '  Both archive hashes equal those recorded in the Axiom as Pharmakon R3 receipt.',
    '',
    'Explicit premises (structure fields and hypotheses, never axioms): SignedCarrier, ExchangePair,',
    '  Additive and SitePair fields; SpinStatisticsBridge.agrees (spin-statistics, held as a bridge).',
    '  No physical statement is certified by this file; see THEOREM_REGISTER.json for every bridge.',
    '',
    'Rebuild (from this folder, with Lean 4.35.0):',
    '  python3 reproduction/verify_diyqc.py --lean /absolute/path/to/lean',
    'One-paste check: bundle/DIYQC_Kernel_K1_bundle.lean (the four files verbatim, import lines removed,',
    '  followed by #print axioms for every kernel declaration).',
]
(root / 'RECEIPT.txt').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
