#!/usr/bin/env python3
"""Write THEOREM_REGISTER.json (R8 layout) from the claim list below and the kernel certificate.

Each claim carries a status label (provenance and scope, never rank). For PROVED claims the
axiom dependencies are copied from receipts/kernel/certificate.json, the compiler's own report.
"""
from pathlib import Path
import json

root = Path(__file__).resolve().parents[1]
cert = json.loads((root / 'receipts/kernel/certificate.json').read_text())
axioms = {}
for name, rep in zip(cert['audited_declarations'], cert['axiom_reports']):
    used = []
    if 'depends on axioms: [' in rep:
        used = rep.split('depends on axioms: [')[1].split(']')[0].split(', ')
    axioms[name] = used

K = 'DIYQC.'


def proved(cid, receipts, premises, conclusion, coverage):
    rs = [K + r for r in receipts]
    for r in rs:
        assert r in axioms, r
    used = {a for r in rs for a in axioms[r]}
    deps = [a for a in ('propext', 'Classical.choice', 'Quot.sound') if a in used] + \
        sorted(used - {'propext', 'Classical.choice', 'Quot.sound'})
    return {'id': cid, 'status': 'proved', 'premises': premises, 'conclusion': conclusion,
            'coverage': coverage, 'receipt': rs, 'axiom_dependencies': deps}


def other(cid, status, statement, receipt, scope):
    return {'id': cid, 'status': status, 'statement': statement, 'receipt': receipt, 'scope': scope}


claims = [
    proved('isomer_lock', ['ExchangePair.isomer_lock', 'ExchangePair.fermion_antisymmetric_even',
                           'ExchangePair.fermion_symmetric_odd', 'ExchangePair.boson_symmetric_even',
                           'ExchangePair.boson_antisymmetric_odd'],
           ['E is an ExchangePair (sign action, involutive spin exchange commuting with the sign)',
            'Statistics sigma v', 'SpinClass epsilon v'],
           'RotationParity (sigma*epsilon) v: for protons the antisymmetric family rotates evenly and '
           'the symmetric family oddly; for deuterons the reverse.',
           'Every carrier, state and pair of signs satisfying the premises.'),
    proved('first_cut_exchange', ['FirstCut.role_blind_reading_cannot_order', 'FirstCut.cut_is_held_not_read',
                                  'FirstCut.labelled_reading_recovers_order',
                                  'FirstCut.factorsThrough_iff_recovers'],
           ['reading is role-blind: reading (b,a) = reading (a,b)', 'a != b'],
           'The roles stay distinct, yet no role-blind reading recovers which carrier is first; a labelled '
           'reading does. The frame kernel FactorsThrough and the seam kernel Recovers are the same proposition.',
           'Every type of carriers and readings.'),
    proved('lock_is_exact', ['ExchangePair.even_cannot_convert', 'SitePair.sum_cannot_convert'],
           ['A respects the sign', 'A commutes with spin exchange', 'SpinClass epsilon v'],
           'Whatever A sends into the other spin class is zero; in particular the part of a two-site '
           'coupling that is the same at both nuclei converts nothing.',
           'Every such coupling and state.'),
    proved('spin_difference_alone_leaves_sector', ['ExchangePair.spin_odd_pos_even_leaves_sector',
                                                   'ExchangePair.spin_odd_pos_even_vanishes_in_sector'],
           ['A respects the sign', 'A anticommutes with spin exchange', 'A commutes with position exchange',
            'Statistics sigma v'],
           'A v has statistics flip sigma; if it also has statistics sigma it is zero.',
           'Every such coupling and state.'),
    proved('key_converts', ['ExchangePair.key_converts', 'SitePair.difference_flips', 'SitePair.difference_odd'],
           ['A respects the sign', 'A anticommutes with spin exchange and with position exchange',
            'Statistics sigma v', 'SpinClass epsilon v'],
           'A v keeps statistics sigma, lies in spin class flip epsilon, and has rotation parity '
           'sigma*flip epsilon.',
           'Every such coupling and state.'),
    proved('only_the_key_converts', ['ExchangePair.converting_coupling_is_doubly_odd'],
           ['A respects the sign and has definite parities s (spin exchange) and t (position exchange)',
            'v and A v share statistics sigma', 'v in class epsilon, A v in class flip epsilon', 'A v != 0'],
           's = minus and t = minus: the coupling differs between the nuclei and between the positions.',
           'Every coupling of definite parities.'),
    proved('nonvacuity_hydrogen', ['Model.Spins.uniform_difference_pos_even', 'Model.Spins.gradient_difference_pos_odd',
                                   'Model.Hydrogen.para_is_fermion_pair', 'Model.Hydrogen.para_rotates_evenly',
                                   'Model.Hydrogen.uniform_annihilates_para',
                                   'Model.Hydrogen.spin_difference_without_gradient',
                                   'Model.Hydrogen.symmetricEven_wrong_statistics',
                                   'Model.Hydrogen.gradient_converts_para', 'Model.Hydrogen.orthoOdd_is_symmetric',
                                   'Model.Hydrogen.orthoOdd_rotates_oddly', 'Model.Hydrogen.orthoOdd_is_fermion_pair',
                                   'Model.Hydrogen.gradient_returns_to_para', 'Model.Hydrogen.orthoOdd_nonzero'],
           ['Two spin-1/2 nuclei with two rotational manifolds (even J, odd J)'],
           'A uniform field annihilates para; a spin difference without a position difference makes a '
           'state of the wrong statistics; a field difference across the molecule makes ortho with odd '
           'rotation and leads back to para.',
           'The stated finite model only (a witness that the general theorems are not vacuous).'),
    proved('nonvacuity_deuterium', ['Model.Deuterium.ortho_is_boson_pair', 'Model.Deuterium.ortho_rotates_evenly',
                                    'Model.Deuterium.uniform_annihilates_ortho',
                                    'Model.Deuterium.spin_difference_without_gradient',
                                    'Model.Deuterium.antisymmetricEven_wrong_statistics',
                                    'Model.Deuterium.gradient_converts_ortho',
                                    'Model.Deuterium.paraOdd_is_antisymmetric',
                                    'Model.Deuterium.paraOdd_rotates_oddly', 'Model.Deuterium.paraOdd_is_boson_pair',
                                    'Model.Deuterium.gradient_returns_to_ortho', 'Model.Deuterium.paraOdd_nonzero'],
           ['Two spin-1 nuclei with two rotational manifolds (even J, odd J)'],
           'The same three cases for a boson pair: the total-spin-zero ortho state rotates evenly; a field '
           'difference makes antisymmetric (para) spin with odd rotation and leads back.',
           'The stated finite model only.'),
    proved('recognition_is_not_conversion', ['Recognition.uniform_reading_cannot_recognize',
                                             'Recognition.adequate_coordinate_separates',
                                             'Recognition.total_spin_recognizes',
                                             'Recognition.conversion_changes_total_spin'],
           ['Four-state two-spin model in the total-spin basis'],
           'A uniform-field readout cannot recognize the isomer; any adequate added coordinate separates '
           'the middle ortho state from para; a total-spin reading recognizes it; conversion changes the '
           'total spin.',
           'The stated readings; the collision part covers every decoder of the readout type.'),
    proved('sink', ['Sink.rotLevel_gap', 'Sink.parity_change_needs_energy', 'Sink.lowest_gap'],
           ['Levels E_J = B J(J+1)', 'J and K of different parity'],
           'The rotational energy changes by at least 2B.', 'All J, K.'),
    proved('counting', ['Counting.sym_add_anti', 'Counting.hydrogen_families', 'Counting.deuterium_families',
                        'Counting.cold_family_single_iff'],
           ['d levels per nucleus'],
           'sym d + anti d = d^2; 3:1 for H2, 6:3 for D2; the cold family is a single state exactly for '
           'a spin-1/2 fermion pair, and has three or more states for a boson pair with spin.',
           'All d (the last statement for d >= 2).'),
    proved('witness', ['Witness.lagrange', 'Witness.product_singlet_bound', 'Witness.separable_singlet_bound',
                       'Witness.above_half_is_entangled'],
           ['Gaussian-integer amplitudes', 'finite mixtures with natural-number weights'],
           'Product states and their mixtures have singlet weight <= 1/2; weight above 1/2 excludes them.',
           'All integer-scaled amplitudes and finite lists; extension to complex amplitudes is bridge B6.'),
    proved('two_turn', ['TwoTurn.returns_after_two_turns', 'TwoTurn.direction_cannot_recover_sign',
                        'TwoTurn.reference_must_separate', 'TwoTurn.proton_pair_is_fermion',
                        'TwoTurn.deuteron_pair_is_boson'],
           ['spinorSign n = parity of n; the last two hold under SpinStatisticsBridge'],
           'The sign returns after two turns; a direction reading cannot recover it; an adequate reference '
           'must separate zero turns from one; under the bridge, proton pairs are fermions and deuteron '
           'pairs bosons.',
           'All n; the bridge is a premise, not proved.'),
    proved('edge_on', ['EdgeOn.fold_symm', 'EdgeOn.edge_on_cannot_recover_phase'],
           ['0 < k < n', 'k != n - k'],
           'Seen in its own plane, the two senses of a rotation give the same swing; the phase is not '
           'recovered by any decoder of the swing.', 'All such n, k.'),
    proved('closure', ['Closure.calendar_round', 'Closure.tzolkin_round', 'Closure.pythagorean_nonclosure',
                       'Closure.pythagorean_comma', 'Closure.selective_closure'],
           ['natural numbers'],
           '260 and 365 close at 18980; no positive number of exact fifths closes on octaves; the 2:1 '
           'closure behind the selective gate.', 'As stated.'),
    proved('threshold', ['Threshold.step_lt', 'Threshold.below_threshold_dies_out',
                         'Threshold.above_threshold_no_decrease'],
           ['x -> c x x / N', '0 < N'],
           'Below threshold (c x < N) the count dies out within x rounds; at or above it, no round lowers it.',
           'All c, N, x.'),
    other('B1', 'bridge', 'Two identical nuclei with spin and rotation form an ExchangePair; total exchange '
          '= spin exchange composed with position exchange; the statistics sign comes from spin-statistics.',
          'argued in the paper; SpinStatisticsBridge held as a structure premise', 'H2, D2 and similar homonuclear pairs'),
    other('B2', 'bridge', 'Couplings act linearly and decompose into the four parity classes under the two '
          'commuting exchanges.', 'standard linear algebra, stated in the paper', 'all couplings'),
    other('B3', 'bridge', 'A catalyst field at the two nuclei is a SitePair; "differs across the bond" means '
          'odd position parity of the difference part.', 'argued in the paper', 'magnetic and other agents alike'),
    other('B4', 'bridge', 'Rotational levels B J(J+1); measured levels change the threshold by about 0.1 K.',
          'computations/para_fraction_threshold.py', 'H2 ground vibrational state'),
    other('B5', 'bridge', 'Equilibrium para fraction from Boltzmann weights with nuclear degeneracies 1:3 (H2), '
          '6:3 (D2).', 'computations/*.py', 'thermal equilibrium only'),
    other('B6', 'bridge', 'Gaussian-integer amplitudes stand for complex amplitudes (homogeneity and density).',
          'argued in the paper', 'the witness inequality'),
    other('B7', 'bridge', 'A separable state in finite dimension is a finite mixture of product states.',
          'imported (Caratheodory)', 'finite dimension'),
    other('M1', 'bridge', 'EdgeOn.fold_symm and edge_on_cannot_recover_phase are the index form of Part II '
          'inversion_preserves_spectral_read, spectral_collision_has_two_branches and '
          'spectral_read_cannot_recover_phase; the step between forms is that cos(2 pi k/n) is injective '
          'for 0 <= k <= n/2.', 'Part II receipts (LambdaPartII.lean, Mathlib); not recompiled here',
          'n evenly spaced phases'),
    other('H1', 'empirical_hypothesis', 'The low-field rate decrease over rare-earth catalysts sits where Zeeman '
          'and rotational levels become shared (crossings), where Part II section 8 predicts first-order '
          'rather than second-order behaviour.', 'none yet; test: rate against field through the crossing fields',
          'rare-earth catalysts, fields below about 40 Oe'),
    other('C1', 'computed', 'Para fraction exceeds 1/2 below 77.84 K (measured levels; 77.94 K rigid rotor). '
          'At 77.36 K the equilibrium margin is +0.33 points; pumped LN2 at 63.15-65 K gives +10.5 to +12.3.',
          'computations/para_fraction_threshold.py and results', 'model B4-B5'),
    other('C2', 'computed', 'D2 gate-entangleable boundary ortho fraction 6/7 (39.29 K); best negativity (7q-6)/12.',
          'computations/deuterium_spin_order.py and results', 'uses imported Hildebrand conditions'),
    other('C3', 'computed', 'Two-proton register thresholds: kept order p > 0.5; dephased p > 0.78.',
          'computations/parahydrogen_entanglement_boundary.py and results', 'imported spectral criterion'),
    other('C4', 'computed', 'NV selective CNOT: Omega = A/sqrt(3); rectangular beat Gaussian in 54/54 cases.',
          'computations/nv_cnot_selectivity.py and results', 'as scripted'),
    other('I1', 'imported', 'Para-H2 (20 K, charcoal) derived two-proton state: purity 0.916, entanglement of '
          'formation 0.822; Deutsch and Grover run on such states.',
          'Anwar et al. PRL 93, 040501 (2004); PRA 70, 032324 (2004); arXiv quant-ph/0407091', 'room-temperature liquid sample'),
    other('I2', 'imported', 'LN2 77 K generator with hydrated iron(III) oxide reaches about 48 % para.',
          'Chapman et al., Anal. Chem. 2021', 'one design'),
    other('I3', 'imported', 'Conversion needs an inhomogeneous field; a homogeneous field should not affect it; '
          'rate scales as mu^2 d^-6.', 'Wigner 1933 via Ilisca, PCCP 2025', 'paramagnetic dipolar mechanism'),
    other('I4', 'imported', 'H2 J=0 to J=1 interval 118.48677 cm^-1.', 'Beyer et al., PRL 123, 163002 (2019)', 'measured'),
    other('O1', 'open', 'Conversion rate magnitudes.', 'none', 'K1 proves selection rules only'),
    other('O2', 'open', 'Low-field rate decrease over rare-earth catalysts.', 'Ilisca 2025 reports no explanation', ''),
    other('O3', 'open', 'Mechanisms on ferromagnetic and non-magnetic surfaces.', 'Ilisca 2025', 'K1 gives the required symmetry, not the agent'),
    other('O4', 'open', 'Lean witness for the D2 6/7 boundary; Werner converse direction.', 'none', ''),
    other('O5', 'open', 'Cheapest readout and transfer chemistry for a garage build.', 'none', 'engineering record'),
]
register = {
    'edition': 'On DIY Quantum Computing (working title), kernel K1, 2026-10-31',
    'central_status': 'proved_isomer_lock_and_key',
    'return_rule': ('Carry each proved result forward in its unchanged hypotheses. A further instance already '
                    'quantified by a theorem does not reopen it. An objection names a failed hypothesis, an '
                    'invalid bridge, or an inference not preserved; doubt alone leaves a claim OPEN, not FALSE.'),
    'lean_version': cert['lean_version'],
    'claims': claims,
}
(root / 'THEOREM_REGISTER.json').write_text(json.dumps(register, indent=2, ensure_ascii=False) + '\n')
print('claims:', len(claims), '| proved:', sum(c['status'] == 'proved' for c in claims))
