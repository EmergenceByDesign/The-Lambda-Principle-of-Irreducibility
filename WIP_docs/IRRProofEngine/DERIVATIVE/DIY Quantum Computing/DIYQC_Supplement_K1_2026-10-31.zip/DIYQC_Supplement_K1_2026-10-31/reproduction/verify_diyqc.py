#!/usr/bin/env python3
"""Build and audit the DIY quantum computing kernel and its reused corpus modules.

Adapted from reproduction/verify_all.py of Closure at the Adjudication Seam (R8, 24 October 2026):
the same isolated-path compilation at trust level 0, the same zero-error / zero-warning rule, the
same #check + #print axioms audit of every named declaration. Two changes: declarations are named
with their full namespace path (the kernel nests namespaces), and the axiom rule is recorded per
target instead of one label for all.

Usage:  python3 reproduction/verify_diyqc.py --lean /absolute/path/to/lean
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, os, re, subprocess

p = argparse.ArgumentParser()
p.add_argument('--lean', required=True, type=Path)
a = p.parse_args()
root = Path(__file__).resolve().parents[1]
receipts = root / 'receipts'
exe = str(a.lean.resolve())
version = subprocess.run([exe, '--version'], capture_output=True, text=True, check=True).stdout.strip()

# (label, source dir, modules compiled in order, modules audited, axioms allowed per declaration)
TARGETS = [
    ('reused_core', root / 'lean' / 'reused', ['UniversalRecoveryClosure', 'ClosureConsequences'],
     ['UniversalRecoveryClosure', 'ClosureConsequences'], set()),
    ('reused_frame', root / 'lean' / 'reused', ['LambdaSpatiotemporalFrame'],
     ['LambdaSpatiotemporalFrame'], set()),
    ('kernel', root / 'lean',
     ['reused/UniversalRecoveryClosure', 'reused/ClosureConsequences',
      'reused/LambdaSpatiotemporalFrame', 'DIYQCKernel'],
     ['DIYQCKernel'], {'propext', 'Quot.sound'}),
]

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from verify_diyqc_names import declarations  # noqa: E402


def messages_of(stdout):
    return [json.loads(line) for line in stdout.splitlines() if line.startswith('{')]


all_receipts = []
for label, source_root, modules, audit_modules, allowed in TARGETS:
    out = receipts / label
    build = out / 'build'
    logs = out / 'logs'
    build.mkdir(parents=True, exist_ok=True)
    logs.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env['LEAN_PATH'] = str(build.resolve())
    stages = []
    for module in modules:
        name = Path(module).name
        src = (source_root / (module + '.lean')).resolve()
        # Run from the file's own folder so that the module name is the file stem.
        r = subprocess.run([exe, '--trust=0', '--json', '-o', str(build.resolve() / (name + '.olean')),
                            src.name], cwd=src.parent, env=env, capture_output=True, text=True)
        (logs / (name + '.stdout')).write_text(r.stdout)
        (logs / (name + '.stderr')).write_text(r.stderr)
        ms = messages_of(r.stdout)
        stage = {'module': name, 'exit_code': r.returncode,
                 'errors': sum(m['severity'] == 'error' for m in ms),
                 'warnings': sum(m['severity'] == 'warning' for m in ms),
                 'information': sum(m['severity'] == 'information' for m in ms)}
        stages.append(stage)
        print(label, json.dumps(stage), flush=True)
        assert stage['exit_code'] == stage['errors'] == stage['warnings'] == 0, (r.stdout, r.stderr)
    names, theorems = [], []
    for module in audit_modules:
        source = (source_root / (module + '.lean')).read_text()
        assert not re.search(r'^\s*(?:axiom|constant|opaque)\s', source, re.M)
        assert not re.search(r'\b(?:sorry|admit|native_decide)\b', source)
        n, t = declarations(source)
        names += n
        theorems += t
    audit = out / 'Audit.lean'
    audit.write_text(''.join('import ' + Path(m).name + '\n' for m in audit_modules) +
                     ''.join('#check ' + n + '\n#print axioms ' + n + '\n' for n in names))
    r = subprocess.run([exe, '--trust=0', '--json', audit.name], cwd=out, env=env,
                       capture_output=True, text=True)
    (logs / 'audit.stdout').write_text(r.stdout)
    (logs / 'audit.stderr').write_text(r.stderr)
    ms = messages_of(r.stdout)
    assert r.returncode == 0 and len(ms) == 2 * len(names), (r.stdout[-3000:], r.stderr)
    assert all(m['severity'] == 'information' for m in ms)
    axiom_reports = [m['data'] for m in ms if 'axiom' in m['data']]
    assert len(axiom_reports) == len(names)
    profile = {}
    for name, rep in zip(names, axiom_reports):
        assert 'sorryAx' not in rep, rep
        used = set()
        if 'depends on axioms: [' in rep:
            used = set(rep.split('depends on axioms: [')[1].split(']')[0].split(', '))
        assert used <= allowed, (name, rep)
        key = rep.split('depends on axioms: [')[1].split(']')[0] if used else 'none'
        profile[key] = profile.get(key, 0) + 1
    record = {'target': label, 'verified_at_utc': datetime.now(timezone.utc).isoformat(),
              'lean_version': version, 'trust_level': 0, 'stages': stages,
              'audited_declarations': names, 'audited_theorems': theorems,
              'axiom_profile': profile, 'axiom_reports': axiom_reports,
              'source_hashes': {Path(m).name + '.lean':
                                hashlib.sha256((source_root / (m + '.lean')).read_bytes()).hexdigest()
                                for m in modules}}
    (out / 'certificate.json').write_text(json.dumps(record, indent=2, ensure_ascii=False) + '\n')
    (out / 'statements_and_axioms.txt').write_text('\n\n'.join(m['data'] for m in ms) + '\n')
    all_receipts.append(record)
    print(label, 'AUDIT PASSED', len(theorems), 'theorems;', len(names), 'named declarations;',
          'axiom profile', profile, flush=True)

summary = {'verified_at_utc': datetime.now(timezone.utc).isoformat(), 'lean_version': version,
           'trust_level': 0,
           'targets': [{'target': r['target'], 'modules': len(r['stages']),
                        'audited_theorems': len(r['audited_theorems']),
                        'audited_declarations': len(r['audited_declarations']),
                        'axiom_profile': r['axiom_profile']} for r in all_receipts],
           'lean_executable_sha256': hashlib.sha256(a.lean.resolve().read_bytes()).hexdigest()}
shared = a.lean.resolve().parent.parent / 'lib' / 'lean' / 'libleanshared.so'
if shared.exists():  # a source build links the compiler as a shared library next to the binary
    summary['lean_shared_library_sha256'] = hashlib.sha256(shared.read_bytes()).hexdigest()
(receipts / 'verification_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('ALL TARGETS PASSED', flush=True)
