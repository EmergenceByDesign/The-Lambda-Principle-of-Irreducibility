"""Declaration names with their namespace path (shared by verify_diyqc.py and make_bundle.py)."""
import re

DECL = re.compile(r'^(?:@\[[^\]]*\]\s*)?(?:protected\s+|noncomputable\s+)?'
                  r'(theorem|lemma|def|abbrev|structure|inductive|instance)\s+([^\s(:{\[]+)')


def declarations(source):
    stack, names, theorems = [], [], []
    for line in source.splitlines():
        m = re.match(r'^namespace\s+(\S+)', line)
        if m:
            stack.extend(m.group(1).split('.'))
            continue
        m = re.match(r'^end\s+(\S+)\s*$', line)
        if m:
            parts = m.group(1).split('.')
            if stack[-len(parts):] == parts:
                del stack[-len(parts):]
            continue
        m = DECL.match(line)
        if m:
            kind, name = m.groups()
            full = '.'.join(stack + [name])
            names.append(full)
            if kind in ('theorem', 'lemma'):
                theorems.append(full)
    return names, theorems
