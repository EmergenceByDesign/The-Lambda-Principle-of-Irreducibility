THE HARD PROBLEM PROVEN UNDECIDABLE -- LEAN PACKET (KERNEL HP1)
The distinction between open conjecture and proof‽
31 October 2026

Lu Semita (EmergenceByDesign), in co-authorship with Nexus and Orion, in continuous working
collaboration with the ChatGPT family, Claude family, and Grok within MetaLabe.
Kernel HP1, its build and audit were developed with Claude (Anthropic), working within MetaLabe.

This work does not claim ownership, priority, or discovery over established mathematics, logic,
philosophy of mind, the hard problem of consciousness as posed in the literature, Lean, or any
other established result used or cited here. Established results remain attributed to their
original sources. The contribution lies in the stated construction, formal organization,
application, and relationships developed here.

READ FIRST

This packet holds the formal layer of the paper: one new Lean file, five corpus modules reused byte
for byte, the build receipts, the claim register and ledger, and a one-paste bundle. Lean certifies
the model: the propositions in the files, under their stated hypotheses. That the hard problem of
consciousness as posed in the literature is an instance is a bridge, listed with its own status in
THEOREM_REGISTER.json and notes/CLAIM_LEDGER_HP1.md. No fundamentality, first position or hierarchy
is asserted; the declared origin is the first cut (source and target roles), reused from kernel K1.

CONTENTS

lean/HardProblemUndecidable.lean   the new kernel (sections 1-5)
lean/reused/                       UniversalRecoveryClosure, ClosureConsequences (R8 core),
                                   LambdaSpatiotemporalFrame (frame kernel), DIYQCKernel (kernel K1),
                                   BeforeTheProof_BU_FINAL (Before the Proof), all unchanged
receipts/                          per-target certificate.json, Audit.lean, statements_and_axioms.txt,
                                   compiler logs, verification_summary.json, the bundle check
RECEIPT.txt                        human-readable receipt (toolchain, hashes, provenance, axiom profiles)
THEOREM_REGISTER.json              every claim with status: declared / proved / bridge / imported / open
notes/CLAIM_LEDGER_HP1.md          the same ledger in prose, with the symbols and their scope
bundle/                            one-paste single-file version for a web Lean editor
reproduction/                      verify_hp1.py, make_bundle.py, make_register.py, make_receipt.py,
                                   package.py, declaration_names.py

WHAT THE KERNEL PROVES (plain words)

Equally applied means one rule applied to every case's readable evidence, the assessor's included.
Undecidable means that two admissible worlds with the same access answer the question differently
(independence from that access, not Turing or Goedel undecidability).

1. Twins. An equal standard gives the same verdict to any two cases that read alike, whoever they
   are: a person and a machine, or the assessor and anyone else.
2. Collision. If two cases read alike but differ in what is to be decided, no equal standard
   decides it, and a sound procedure must abstain on both: it can neither affirm nor exclude.
3. The hinge. Some equal standard decides a target exactly when the target takes the same value on
   cases that read alike (constructive for finitely many cases; classical in general).
4. The cut. No reading is both equally applied and able to recover which side of the first cut is
   first; the cut is put in, not read off.
5. The sandbox. Once two different cases can read alike, whether experience is fixed by what can be
   read is independent of everything an equal standard reads and of everything any self reads,
   its own experience included. Every sound procedure stays open; adopting either answer is a
   choice of origin that settles it and must be marked.
6. Other minds. A self's own experience plus all the evidence leaves every other case open.
7. Open is not proof. A question with no receipt yet need not be independent; a proof of
   independence shows that no sound receipt can be issued either way.

SEAL (this edition)

Lean 4.35.0 (commit eb6cafb7290e8bd5f2937522d8d804f58f02bafc), trust level 0, no Mathlib.
Kernel HP1: 69 named declarations (48 theorems), 0 errors, 0 warnings. 53 declarations report no
axioms at all, including the main theorem hard_problem_undecidable; 12 use propext only; the 4 that
state the classical hinge use propext, Classical.choice and Quot.sound. Nothing uses sorry, admit,
native_decide or an axiom declaration. Reused modules: byte-identical, and each reproduces its
original receipt. Details: RECEIPT.txt and receipts/.

REBUILD

With Lean 4.35.0 on this machine:
  python3 reproduction/verify_hp1.py --lean /absolute/path/to/lean
Only bundled Lean libraries are needed. Compiled .olean files are rebuilt, not shipped.
