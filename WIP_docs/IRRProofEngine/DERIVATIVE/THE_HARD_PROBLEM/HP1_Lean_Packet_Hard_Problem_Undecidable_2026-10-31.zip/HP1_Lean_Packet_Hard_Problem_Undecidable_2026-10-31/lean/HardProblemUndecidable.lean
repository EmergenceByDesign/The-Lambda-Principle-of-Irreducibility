import DIYQCKernel
import BeforeTheProof_BU_FINAL

/-!
# The hard problem proven undecidable: formal kernel HP1
## The distinction between open conjecture and proof‽

Lu Semita (EmergenceByDesign), in co-authorship with Nexus and Orion, in continuous working
collaboration with the ChatGPT family, Claude family, and Grok within MetaLabe.
Kernel HP1, its build and audit were developed with Claude (Anthropic), working within MetaLabe.

This work does not claim ownership, priority, or discovery over established mathematics, logic,
philosophy of mind, the hard problem of consciousness as posed in the literature, Lean, or any
other established result used or cited here. Established results remain attributed to their
original sources. The contribution lies in the stated construction, formal organization,
application, and relationships developed here.

Scope. This file checks only the propositions written below. The words case, evidence, verdict,
standard, world, self, held, experience and hard problem receive only the roles assigned to them
here. That the hard problem of consciousness, as posed in the literature, is an instance of this
model is a bridge stated in the paper with its own status. Acceptance of this file by Lean does
not certify any bridge: Lean certifies the model.

Origin. Description starts from the first cut: a source role and a target role (a self-side and an
other-side) held by the describer. The cut is declared, not posited as fundamental, and nothing
here asserts a first position or a hierarchy (kernel K1, Section 0, reused).

"Equally applied" means one rule applied to every case's readable evidence, the assessor's
included (`EqualStandard`). "Undecidable from an access" means that two admissible worlds with the
same access answer the question differently (`IndependentOf`): independence relative to a declared
access and a declared class of admissible worlds. It is not Turing undecidability and not Gödel
incompleteness.

Reused unchanged (SHA-256 recorded in the receipt):
  UniversalRecoveryClosure, ClosureConsequences (Closure at the Adjudication Seam, R8 core)
  LambdaSpatiotemporalFrame (Lambda, Reference, and the Spatiotemporal Descriptive Frame)
  DIYQCKernel (kernel K1 of On DIY Quantum Computing; Section 0, the first cut, is used here)
  BeforeTheProof_BU_FINAL (Before the Proof, certified appendix: bridge underdetermination)
-/

namespace HardProblem

open ClosureConsequences LambdaSpatiotemporal

/-! ## 1. Cases, readable evidence and equal standards -/

section Standards

variable {Case Ev V : Type}

/-- An equal standard: one rule applied to every case's readable evidence, the assessor's
included. -/
def EqualStandard (evidence : Case → Ev) (verdict : Case → V) : Prop :=
  ∃ rule : Ev → V, ∀ x, verdict x = rule (evidence x)

/-- Same readable evidence, same value. -/
def SameEvidenceSameValue (evidence : Case → Ev) (f : Case → V) : Prop :=
  ∀ a b, evidence a = evidence b → f a = f b

/-- A verdict decides a target when it agrees with the target on every case. -/
def Decides (verdict target : Case → V) : Prop := ∀ x, verdict x = target x

/-- Some equal standard decides the target. -/
def EquallyDecidable (evidence : Case → Ev) (target : Case → V) : Prop :=
  ∃ verdict, EqualStandard evidence verdict ∧ Decides verdict target

/-- A read target: fixed by the readable evidence through some rule. -/
def ReadTarget (evidence : Case → Ev) (target : Case → V) : Prop := EqualStandard evidence target

/-- A held target: it differs on two cases that present the same readable evidence. -/
def HeldTarget (evidence : Case → Ev) (target : Case → V) : Prop :=
  ∃ a b, evidence a = evidence b ∧ target a ≠ target b

/-- Being decided by an equal standard is the R8 notion of recovery from the evidence. -/
theorem equally_decidable_iff_recovers (evidence : Case → Ev) (target : Case → V) :
    EquallyDecidable evidence target ↔ Recovers evidence target := by
  constructor
  · rintro ⟨verdict, ⟨rule, hrule⟩, hdec⟩
    exact ⟨rule, fun x => (hrule x).symm.trans (hdec x)⟩
  · rintro ⟨decode, hdecode⟩
    exact ⟨target, ⟨decode, fun x => (hdecode x).symm⟩, fun _ => rfl⟩

/-- Twins: an equal standard gives the same verdict to any two cases that present the same
evidence, whoever they are: a person and a machine, or the assessor and anyone else. -/
theorem equal_standard_cannot_separate_twins {evidence : Case → Ev} {verdict : Case → V}
    (h : EqualStandard evidence verdict) : SameEvidenceSameValue evidence verdict := by
  rcases h with ⟨rule, hrule⟩
  intro a b same
  rw [hrule a, hrule b, same]

/-- The assessor is assessed alike: under an equal standard the assessor receives the verdict of
every case that reads like it. -/
theorem assessor_is_assessed_alike {evidence : Case → Ev} {verdict : Case → V}
    (h : EqualStandard evidence verdict) (assessor x : Case)
    (same : evidence assessor = evidence x) : verdict assessor = verdict x :=
  equal_standard_cannot_separate_twins h assessor x same

/-- The twin verdicts are a Before the Proof verification: two chains with the same verifier
input (the evidence) get the same result, while a differing upstream bridge (the held value)
stays an independent premise (`two_chain_bridge_underdetermination`). -/
theorem twins_as_bridge_underdetermination {evidence : Case → Ev} (rule : Ev → V)
    (held : Case → Bool) {a b : Case} (same : evidence a = evidence b)
    (ha : held a = true) (hb : ¬ held b = true) :
    rule (evidence a) = rule (evidence b) ∧ held a = true ∧ ¬ held b = true :=
  BeforeTheProof.two_chain_bridge_underdetermination rule
    ⟨evidence a, held a, rule (evidence a)⟩ ⟨evidence b, held b, rule (evidence b)⟩
    same rfl rfl (fun h => h = true) ha hb

/-- Collision: a held target is decided by no equal standard (R8 `universal_class_is_closed`). -/
theorem held_target_not_equally_decidable {evidence : Case → Ev} {target : Case → V}
    (held : HeldTarget evidence target) : ¬ EquallyDecidable evidence target := by
  rcases held with ⟨a, b, same, different⟩
  intro h
  exact universal_class_is_closed evidence target a b same different
    ((equally_decidable_iff_recovers evidence target).1 h)

/-- A read target is decided by an equal standard: itself. -/
theorem read_target_equally_decidable {evidence : Case → Ev} {target : Case → V}
    (h : ReadTarget evidence target) : EquallyDecidable evidence target :=
  ⟨target, h, fun _ => rfl⟩

/-- No target is both read and held. -/
theorem not_read_and_held {evidence : Case → Ev} {target : Case → V} :
    ¬ (ReadTarget evidence target ∧ HeldTarget evidence target) := fun ⟨read, held⟩ =>
  held_target_not_equally_decidable held (read_target_equally_decidable read)

/-- The hinge, forward half (R8 `recovery_requires_target_constancy`): whatever an equal standard
decides takes the same value on cases that read alike. -/
theorem equally_decidable_same_value {evidence : Case → Ev} {target : Case → V}
    (h : EquallyDecidable evidence target) : SameEvidenceSameValue evidence target :=
  recovery_requires_target_constancy evidence target
    ((equally_decidable_iff_recovers evidence target).1 h)

/-- A rule built by search: the target value of the first listed case whose evidence matches. -/
def firstMatch [DecidableEq Ev] (evidence : Case → Ev) (target : Case → V) (fallback : V) :
    List Case → Ev → V
  | [], _ => fallback
  | c :: cs, e => if evidence c = e then target c else firstMatch evidence target fallback cs e

theorem firstMatch_correct [DecidableEq Ev] (evidence : Case → Ev) (target : Case → V)
    (fallback : V) (const : SameEvidenceSameValue evidence target) :
    ∀ (listed : List Case) (x : Case), x ∈ listed →
      firstMatch evidence target fallback listed (evidence x) = target x
  | [], _, hx => nomatch hx
  | c :: cs, x, hx => by
    simp only [firstMatch]
    split
    · rename_i hc
      exact const c x hc
    · rename_i hc
      cases hx with
      | head => exact absurd rfl hc
      | tail _ h => exact firstMatch_correct evidence target fallback const cs x h

/-- The hinge, converse half, constructive: over finitely many listed cases with decidable
evidence, a target that takes the same value on cases that read alike is decided by an equal
standard. -/
theorem finite_hinge [DecidableEq Ev] (evidence : Case → Ev) (target : Case → V) (fallback : V)
    (listed : List Case) (complete : ∀ x, x ∈ listed) :
    EquallyDecidable evidence target ↔ SameEvidenceSameValue evidence target :=
  ⟨equally_decidable_same_value, fun const =>
    ⟨target, ⟨firstMatch evidence target fallback listed,
      fun x => (firstMatch_correct evidence target fallback const listed x (complete x)).symm⟩,
     fun _ => rfl⟩⟩

/-- A rule built by choice: for evidence that some case presents, the target value of a chosen
such case. -/
noncomputable def chosenRule [Inhabited V] (evidence : Case → Ev) (target : Case → V) (e : Ev) :
    V :=
  @dite V (∃ x, evidence x = e) (Classical.propDecidable _)
    (fun h => target (Classical.choose h)) (fun _ => default)

/-- The hinge, general form (uses `Classical.choice`): some equal standard decides the target
exactly when the target takes the same value on cases that read alike. -/
theorem hinge [Inhabited V] (evidence : Case → Ev) (target : Case → V) :
    EquallyDecidable evidence target ↔ SameEvidenceSameValue evidence target := by
  refine ⟨equally_decidable_same_value, fun const =>
    ⟨target, ⟨chosenRule evidence target, fun x => ?_⟩, fun _ => rfl⟩⟩
  have h : ∃ y, evidence y = evidence x := ⟨x, rfl⟩
  unfold chosenRule
  rw [dite_eq_left h]
  exact (const _ _ (Classical.choose_spec h)).symm

/-- Every target is read or held (classical), and never both (`not_read_and_held`). -/
theorem read_or_held [Inhabited V] (evidence : Case → Ev) (target : Case → V) :
    ReadTarget evidence target ∨ HeldTarget evidence target := by
  cases Classical.em (HeldTarget evidence target) with
  | inl held => exact Or.inr held
  | inr notHeld =>
    left
    have const : SameEvidenceSameValue evidence target := fun a b same =>
      Classical.byContradiction fun different => notHeld ⟨a, b, same, different⟩
    obtain ⟨_, ⟨rule, hrule⟩, hdec⟩ := (hinge evidence target).2 const
    exact ⟨rule, fun x => (hdec x).symm.trans (hrule x)⟩

/-- Both edges. A sound procedure that reads only the evidence abstains at every stage on both
cases of a pair that read alike and differ in the target: it can neither affirm nor exclude
either one (R8 `both_witnesses_have_certified_abstention`, read for verdicts). -/
theorem sound_equal_procedure_abstains {evidence : Case → Ev} {target : Case → V} {a b : Case}
    (same : evidence a = evidence b) (different : target a ≠ target b)
    (attempt : Ev → Nat → Option V) (sound : SoundAttempt evidence target attempt) :
    (∀ n, attempt (evidence a) n = none) ∧ (∀ n, attempt (evidence b) n = none) :=
  both_witnesses_have_certified_abstention evidence target a b same different attempt sound

end Standards

/-! ## 2. The first cut is held, not read -/

section Cut

variable {Case R : Type}

/-- No reading is both equally applied (role-blind) and able to recover which side of the cut is
the first, once two different cases exist (K1 `role_blind_reading_cannot_order`). -/
theorem no_reading_is_equal_and_recovers_the_cut {a b : Case} (hab : a ≠ b) :
    ¬ ∃ reading : Case × Case → R,
      DIYQC.FirstCut.RoleBlind reading ∧ FactorsThrough reading Prod.fst := by
  rintro ⟨reading, blind, recovers⟩
  exact DIYQC.FirstCut.role_blind_reading_cannot_order reading blind a b hab recovers

/-- The labeled reading recovers the cut (K1 `labelled_reading_recovers_order`) and is not
role-blind once two different cases exist. -/
theorem labelled_reading_recovers_and_is_not_equal {a b : Case} (hab : a ≠ b) :
    Recovers (fun p : Case × Case => p) Prod.fst ∧
      ¬ DIYQC.FirstCut.RoleBlind (fun p : Case × Case => p) :=
  ⟨DIYQC.FirstCut.labelled_reading_recovers_order,
   fun blind => hab (congrArg Prod.fst (blind (a, b))).symm⟩

/-- The cut is put in, not read off: any coordinate that lets a role-blind reading recover the
order separates the two orders of every pair of different cases, and is itself not recovered from
the role-blind reading (R8 `adequate_coordinate_must_distinguish`,
`essential_coordinate_is_not_recoverable`). -/
theorem the_cut_is_put_in_not_read_off (reading : Case × Case → R)
    (blind : DIYQC.FirstCut.RoleBlind reading) {a b : Case} (hab : a ≠ b)
    {Coordinate : Type} (coordinate : Case × Case → Coordinate)
    (adequate : Recovers (fun p => (reading p, coordinate p)) Prod.fst) :
    coordinate (a, b) ≠ coordinate (b, a) ∧ ¬ Recovers reading coordinate :=
  ⟨adequate_coordinate_must_distinguish reading Prod.fst (a, b) (b, a) (blind (a, b)).symm hab
     coordinate adequate,
   essential_coordinate_is_not_recoverable reading Prod.fst (a, b) (b, a) (blind (a, b)).symm
     hab coordinate adequate⟩

end Cut

/-! ## 3. Settled, independent, open: the status of a question -/

section Status

variable {W A : Type}

/-- The access settles a question over the admissible worlds when admissible worlds with the same
access answer it alike. -/
def SettledBy (admissible : W → Prop) (access : W → A) (Q : W → Prop) : Prop :=
  ∀ w₁ w₂, admissible w₁ → admissible w₂ → access w₁ = access w₂ → (Q w₁ ↔ Q w₂)

/-- Proved undecidable from the access: two admissible worlds with the same access answer the
question differently. -/
def IndependentOf (admissible : W → Prop) (access : W → A) (Q : W → Prop) : Prop :=
  ∃ w₁ w₂, admissible w₁ ∧ admissible w₂ ∧ access w₁ = access w₂ ∧ Q w₁ ∧ ¬ Q w₂

/-- A verdict procedure that reads only the access: `some true` affirms, `some false` excludes,
`none` abstains. It is sound when it never affirms or excludes wrongly in an admissible world. -/
def SoundVerdict (admissible : W → Prop) (access : W → A) (Q : W → Prop)
    (verdict : A → Option Bool) : Prop :=
  ∀ w, admissible w →
    (verdict (access w) = some true → Q w) ∧ (verdict (access w) = some false → ¬ Q w)

/-- Open at an access value: the procedure neither affirms nor excludes there. -/
def OpenAt (verdict : A → Option Bool) (α : A) : Prop := verdict α = none

theorem independent_not_settled {admissible : W → Prop} {access : W → A} {Q : W → Prop}
    (h : IndependentOf admissible access Q) : ¬ SettledBy admissible access Q := by
  rcases h with ⟨w₁, w₂, h₁, h₂, same, yes, no⟩
  intro settled
  exact no ((settled w₁ w₂ h₁ h₂ same).1 yes)

/-- A proof of independence forces openness: where two admissible worlds with the same access
answer differently, every sound procedure stays open (world-level reading of R8
`forced_abstention_at_seam`). -/
theorem independence_forces_openness {admissible : W → Prop} {access : W → A} {Q : W → Prop}
    {verdict : A → Option Bool} (sound : SoundVerdict admissible access Q verdict)
    {w₁ w₂ : W} (h₁ : admissible w₁) (h₂ : admissible w₂) (same : access w₁ = access w₂)
    (yes : Q w₁) (no : ¬ Q w₂) : OpenAt verdict (access w₁) := by
  unfold OpenAt
  cases hv : verdict (access w₁) with
  | none => rfl
  | some b =>
    cases b with
    | true =>
      have hv₂ : verdict (access w₂) = some true := same ▸ hv
      exact absurd ((sound w₂ h₂).1 hv₂) no
    | false => exact absurd yes ((sound w₁ h₁).2 hv)

/-- Openness is not proof: a sound procedure can stay open on a question that its access settles
(in this setting, the Axiom as Pharmakon countermodel `open_not_indep`). -/
theorem openness_is_not_proof :
    ∃ (admissible : Unit → Prop) (access : Unit → Unit) (Q : Unit → Prop)
      (verdict : Unit → Option Bool),
      SoundVerdict admissible access Q verdict ∧ OpenAt verdict () ∧
        SettledBy admissible access Q ∧ ¬ IndependentOf admissible access Q :=
  ⟨fun _ => True, fun _ => (), fun _ => True, fun _ => none,
   fun _ _ => ⟨fun h => (by cases h), fun h => (by cases h)⟩, rfl,
   fun _ _ _ _ _ => Iff.rfl, fun ⟨_, _, _, _, _, _, no⟩ => no trivial⟩

/-- Independence is relative to the admissible worlds: adopting either answer as an axiom (keeping
only the worlds where it holds, or only those where it fails) settles the question (in this
setting, Pharmakon's `not_indep_union_self`). -/
theorem adopting_an_answer_settles {admissible : W → Prop} {access : W → A} (Q : W → Prop) :
    SettledBy (fun w => admissible w ∧ Q w) access Q ∧
      SettledBy (fun w => admissible w ∧ ¬ Q w) access Q :=
  ⟨fun _ _ h₁ h₂ _ => ⟨fun _ => h₂.2, fun _ => h₁.2⟩,
   fun _ _ h₁ h₂ _ => ⟨fun q => absurd q h₁.2, fun q => absurd q h₂.2⟩⟩

/-- Both answers meet the access: when a question is independent of the access, a world where it
holds and a world where it fails present the same access value (in this setting, Pharmakon's
`indep_decided_in_extensions`). -/
theorem both_answers_meet_the_access {admissible : W → Prop} {access : W → A} {Q : W → Prop}
    (h : IndependentOf admissible access Q) :
    ∃ α, (∃ w, admissible w ∧ Q w ∧ access w = α) ∧
      (∃ w, admissible w ∧ ¬ Q w ∧ access w = α) := by
  rcases h with ⟨w₁, w₂, h₁, h₂, same, yes, no⟩
  exact ⟨access w₁, ⟨w₁, h₁, yes, rfl⟩, ⟨w₂, h₂, no, same.symm⟩⟩

/-- Adopting an answer is a residual selection in the frame kernel's sense: the admissible worlds
that meet the access do not force one answer, so the selection must be marked (frame kernel
`residual_will_from_competing_admissible_procedures`; the Lambda Dictionary declares that this term
attributes nothing to agency or consciousness). -/
theorem adopting_an_answer_is_residual {admissible : W → Prop} {access : W → A} {Q : W → Prop}
    {w₁ w₂ : W} (h₁ : admissible w₁) (h₂ : admissible w₂) (same : access w₁ = access w₂)
    (yes : Q w₁) (no : ¬ Q w₂) :
    ResidualWill (fun w => admissible w ∧ access w = access w₁) Q w₁ :=
  residual_will_from_competing_admissible_procedures
    (fun w => admissible w ∧ access w = access w₁) Q ⟨h₁, rfl⟩ ⟨h₂, same.symm⟩
    (fun e => no (e ▸ yes))

end Status

/-! ## 4. The hard problem: its own hardness is undecidable from inside -/

section Hard

variable {Case Ev : Type}

/-- A world assigns to each case its held value: whether there is something it is like to be it. -/
abbrev World (Case : Type) := Case → Bool

/-- Everything an equal standard reads in a world: the evidence, the same in every world. -/
def standardAccess (evidence : Case → Ev) (_ : World Case) : Case → Ev := evidence

/-- Everything a self reads in a world: the evidence and its own held value. -/
def selfAccess (evidence : Case → Ev) (self : Case) (w : World Case) : (Case → Ev) × Bool :=
  (evidence, w self)

/-- The hardness question: is experience fixed by the readable evidence in this world? -/
def FixedByEvidence (evidence : Case → Ev) (w : World Case) : Prop :=
  SameEvidenceSameValue evidence w

/-- The world that gives every case `base`, except the case `c`, which gets `v`. -/
def setAt [DecidableEq Case] (base : Bool) (c : Case) (v : Bool) : World Case :=
  fun x => if x = c then v else base

theorem setAt_at [DecidableEq Case] (base : Bool) (c : Case) (v : Bool) :
    setAt base c v c = v := ite_eq_left rfl

theorem setAt_off [DecidableEq Case] (base : Bool) {c x : Case} (v : Bool) (h : x ≠ c) :
    setAt base c v x = base := ite_eq_right h

theorem not_self_ne (b : Bool) : (!b) ≠ b := by cases b <;> decide

/-- Of two different cases, at least one is not the self. -/
theorem pair_member_other_than [DecidableEq Case] {evidence : Case → Ev} {a b : Case}
    (hab : a ≠ b) (same : evidence a = evidence b) (self : Case) :
    ∃ c d, c ≠ d ∧ evidence c = evidence d ∧ c ≠ self := by
  by_cases hs : self = a
  · exact ⟨b, a, fun h => hab h.symm, same.symm, fun h => hab (h.trans hs).symm⟩
  · exact ⟨a, b, hab, same, fun h => hs h.symm⟩

/-- The sandbox. Once two different cases present the same evidence, whether experience is fixed by
the evidence is independent of everything a self can read (the evidence and its own held value),
whichever case the self is and whatever it holds. -/
theorem hardness_independent_of_self_access [DecidableEq Case] (evidence : Case → Ev)
    {a b : Case} (hab : a ≠ b) (same : evidence a = evidence b) (self : Case) (held : Bool) :
    IndependentOf (fun w : World Case => w self = held) (selfAccess evidence self)
      (FixedByEvidence evidence) := by
  obtain ⟨c, d, hcd, hsame, hcs⟩ := pair_member_other_than hab same self
  have hsc : self ≠ c := fun h => hcs h.symm
  have hdc : d ≠ c := fun h => hcd h.symm
  have hself : setAt held c (!held) self = held := setAt_off held (!held) hsc
  refine ⟨fun _ => held, setAt held c (!held), rfl, hself, ?_, fun _ _ _ => rfl, ?_⟩
  · show (evidence, held) = (evidence, setAt held c (!held) self)
    rw [hself]
  · intro fixed
    have h := fixed c d hsame
    rw [setAt_at, setAt_off held (!held) hdc] at h
    exact not_self_ne held h

/-- The same with the evidence alone: whether experience is fixed by the evidence is independent of
everything an equal standard reads. -/
theorem hardness_independent_of_the_evidence [DecidableEq Case] (evidence : Case → Ev)
    {a b : Case} (hab : a ≠ b) (same : evidence a = evidence b) :
    IndependentOf (fun _ : World Case => True) (standardAccess evidence)
      (FixedByEvidence evidence) := by
  have hba : b ≠ a := fun h => hab h.symm
  refine ⟨fun _ => true, setAt true a false, trivial, trivial, rfl, fun _ _ _ => rfl, ?_⟩
  intro fixed
  have h := fixed a b same
  rw [setAt_at, setAt_off true false hba] at h
  exact Bool.noConfusion h

/-- No self can close the hardness question from inside: every sound procedure that reads what a
self reads stays open at that self's access. -/
theorem hardness_open_for_every_self [DecidableEq Case] (evidence : Case → Ev)
    {a b : Case} (hab : a ≠ b) (same : evidence a = evidence b) (self : Case) (held : Bool)
    (verdict : (Case → Ev) × Bool → Option Bool)
    (sound : SoundVerdict (fun w : World Case => w self = held) (selfAccess evidence self)
      (FixedByEvidence evidence) verdict) :
    OpenAt verdict (evidence, held) := by
  obtain ⟨w₁, w₂, h₁, h₂, sameAccess, yes, no⟩ :=
    hardness_independent_of_self_access evidence hab same self held
  have hopen := independence_forces_openness sound h₁ h₂ sameAccess yes no
  have h₁' : w₁ self = held := h₁
  have hα : selfAccess evidence self w₁ = (evidence, held) := by
    show (evidence, w₁ self) = (evidence, held)
    rw [h₁']
  rw [hα] at hopen
  exact hopen

/-- The pair hypothesis is needed: if the evidence tells every two cases apart, every world is
fixed by the evidence, so the hardness question is settled (trivially), while other minds stay
undetermined (`other_case_independent_of_self_access` needs no pair). -/
theorem individuating_evidence_fixes_every_world {evidence : Case → Ev}
    (individuates : ∀ a b, evidence a = evidence b → a = b) (w : World Case) :
    FixedByEvidence evidence w := fun a b same => by rw [individuates a b same]

/-- Other minds. A self's own held value together with all the evidence leaves the held value of
every other case undetermined. -/
theorem other_case_independent_of_self_access [DecidableEq Case] (evidence : Case → Ev)
    {self other : Case} (h : other ≠ self) (held : Bool) :
    IndependentOf (fun w : World Case => w self = held) (selfAccess evidence self)
      (fun w => w other = true) := by
  have hso : self ≠ other := fun e => h e.symm
  have h₁ : setAt held other true self = held := setAt_off held true hso
  have h₂ : setAt held other false self = held := setAt_off held false hso
  refine ⟨setAt held other true, setAt held other false, h₁, h₂, ?_,
    setAt_at held other true, ?_⟩
  · show (evidence, setAt held other true self) = (evidence, setAt held other false self)
    rw [h₁, h₂]
  · intro e
    rw [setAt_at] at e
    exact Bool.noConfusion e

/-- The hardness question is the read/held fork: experience is fixed by the evidence exactly when
it is a read target (classical, through `hinge`). -/
theorem fixed_iff_read (evidence : Case → Ev) (w : World Case) :
    FixedByEvidence evidence w ↔ ReadTarget evidence w := by
  constructor
  · intro fixed
    obtain ⟨_, ⟨rule, hrule⟩, hdec⟩ := (hinge evidence w).2 fixed
    exact ⟨rule, fun x => (hdec x).symm.trans (hrule x)⟩
  · intro read
    exact equal_standard_cannot_separate_twins read

/-- Main theorem. Once two different cases present the same readable evidence: whether experience
is fixed by that evidence is independent of everything an equal standard reads and of everything
any self reads; no world in which those two cases differ is decided by an equal standard; and
every sound procedure that reads what a self reads stays open on the question. -/
theorem hard_problem_undecidable [DecidableEq Case] (evidence : Case → Ev)
    {a b : Case} (hab : a ≠ b) (same : evidence a = evidence b) :
    IndependentOf (fun _ : World Case => True) (standardAccess evidence)
        (FixedByEvidence evidence) ∧
      (∀ self held, IndependentOf (fun w : World Case => w self = held)
        (selfAccess evidence self) (FixedByEvidence evidence)) ∧
      (∀ w : World Case, w a ≠ w b → ¬ EquallyDecidable evidence w) ∧
      (∀ self held verdict, SoundVerdict (fun w : World Case => w self = held)
        (selfAccess evidence self) (FixedByEvidence evidence) verdict →
          OpenAt verdict (evidence, held)) :=
  ⟨hardness_independent_of_the_evidence evidence hab same,
   fun self held => hardness_independent_of_self_access evidence hab same self held,
   fun _ hw => held_target_not_equally_decidable ⟨a, b, same, hw⟩,
   fun self held verdict sound =>
     hardness_open_for_every_self evidence hab same self held verdict sound⟩

end Hard

/-! ## 5. A three-case model: every hypothesis is met and both worlds exist -/

namespace Witness

/-- Case 0 is the self, case 1 its twin (it reads like the self), case 2 reads differently. -/
def evidence : Fin 3 → Bool := fun x => x.val != 2

theorem twin_reads_like_self : evidence 0 = evidence 1 := by decide

theorem twin_is_another_case : (0 : Fin 3) ≠ 1 := by decide

/-- A world in which experience is fixed by the evidence. -/
def fixedWorld : World (Fin 3) := fun _ => true

/-- A world in which it is not: the twin differs from the self. -/
def heldWorld : World (Fin 3) := fun x => x.val != 1

theorem self_holds_alike : fixedWorld 0 = heldWorld 0 := by decide

theorem fixed_world_is_fixed : FixedByEvidence evidence fixedWorld := fun _ _ _ => rfl

theorem held_world_is_not_fixed : ¬ FixedByEvidence evidence heldWorld :=
  fun h => absurd (h 0 1 twin_reads_like_self) (by decide)

theorem held_world_is_held : HeldTarget evidence heldWorld :=
  ⟨0, 1, twin_reads_like_self, by decide⟩

theorem fixed_world_is_read : ReadTarget evidence fixedWorld := ⟨fun _ => true, fun _ => rfl⟩

theorem no_equal_standard_decides_the_held_world : ¬ EquallyDecidable evidence heldWorld :=
  held_target_not_equally_decidable held_world_is_held

/-- Every case of the model is listed. -/
theorem all_cases_listed : ∀ x : Fin 3, x ∈ [0, 1, 2]
  | ⟨0, _⟩ => List.Mem.head _
  | ⟨1, _⟩ => List.Mem.tail _ (List.Mem.head _)
  | ⟨2, _⟩ => List.Mem.tail _ (List.Mem.tail _ (List.Mem.head _))
  | ⟨n + 3, h⟩ => absurd h (Nat.not_lt.mpr (Nat.le_add_left 3 n))

/-- The finite hinge, instantiated: the fixed world is decided by an equal standard, built by
search over the listed cases (constructive). -/
theorem fixed_world_equally_decidable : EquallyDecidable evidence fixedWorld :=
  (finite_hinge evidence fixedWorld false [0, 1, 2] all_cases_listed).2 fixed_world_is_fixed

/-- The sandbox, instantiated: the self (case 0), holding `true`, cannot read whether experience is
fixed by the evidence. -/
theorem sandbox_instance :
    IndependentOf (fun w : World (Fin 3) => w 0 = true) (selfAccess evidence 0)
      (FixedByEvidence evidence) :=
  hardness_independent_of_self_access evidence twin_is_another_case twin_reads_like_self 0 true

/-- Other minds, instantiated: the self cannot read the held value of case 2. -/
theorem other_mind_instance :
    IndependentOf (fun w : World (Fin 3) => w 0 = true) (selfAccess evidence 0)
      (fun w => w 2 = true) :=
  other_case_independent_of_self_access evidence (by decide) true

/-- The main theorem, instantiated on the three-case model (its first clause: nothing an equal
standard reads decides whether experience is fixed by the evidence). -/
theorem main_instance :
    IndependentOf (fun _ : World (Fin 3) => True) (standardAccess evidence)
      (FixedByEvidence evidence) :=
  (hard_problem_undecidable evidence twin_is_another_case twin_reads_like_self).1

/-- A role-blind reading of a pair of cases. -/
def pairReading (p : Fin 3 × Fin 3) : Bool := evidence p.1 && evidence p.2

theorem pairReading_role_blind : DIYQC.FirstCut.RoleBlind pairReading := fun p =>
  Bool.and_comm (evidence p.2) (evidence p.1)

/-- The cut, instantiated: the role-blind pair reading does not recover which case is first. -/
theorem cut_instance : ¬ FactorsThrough pairReading Prod.fst :=
  DIYQC.FirstCut.role_blind_reading_cannot_order pairReading pairReading_role_blind 0 1
    twin_is_another_case

end Witness

end HardProblem
