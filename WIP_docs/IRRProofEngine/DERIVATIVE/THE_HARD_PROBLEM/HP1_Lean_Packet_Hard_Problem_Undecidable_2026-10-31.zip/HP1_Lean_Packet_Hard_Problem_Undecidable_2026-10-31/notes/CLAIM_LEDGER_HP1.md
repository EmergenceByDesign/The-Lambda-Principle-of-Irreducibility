# Claim ledger for kernel HP1

**The Hard Problem Proven Undecidable**
*The distinction between open conjecture and proof‽*

Lu Semita (EmergenceByDesign), in co-authorship with Nexus and Orion, in continuous working
collaboration with the ChatGPT family, Claude family, and Grok within MetaLabe.
Kernel HP1, its build and audit, and this ledger were developed with Claude (Anthropic), working
within MetaLabe. 31 October 2026.

This work does not claim ownership, priority, or discovery over established mathematics, logic,
philosophy of mind, the hard problem of consciousness as posed in the literature, Lean, or any other
established result used or cited here. Established results remain attributed to their original
sources. The contribution lies in the stated construction, formal organization, application, and
relationships developed here. No cited person, institution, or prior author should be understood
to endorse the interpretations or extensions developed here.

Labels give provenance and scope, never rank. Every work in the ledger stands on equal footing and
is checked against the others.

| Label | Meaning |
|---|---|
| DECLARED | A definition or modeling choice, stated at the strength at which it is held |
| REUSED | Corpus Lean module, byte-identical, re-checked here |
| PROVED (HP1) | New Lean theorem in HardProblemUndecidable.lean, checked here |
| BRIDGE | Premise linking the Lean model to the hard problem as posed; argued, not certified by Lean |
| IMPORTED | Outside result or argument, with source; not proved here |
| OPEN | Not settled by anything here |

## 0. Origin, scope and method

- **The conjecture (the author's words, spelling corrected).** "My current conjecture is that this
  is undecidable by any truly equally applied standard I can currently imagine applying; this
  Consciousness can be seen as the structure that's cause of and is caused by, both reinforces and
  tries to escape, its own axiomatized sandbox condition." The sandbox is self-sealing: it cannot
  be escaped while being a self, and it goes back at least as far as the first self-made
  distinction.
- **Declared origin (D3).** Description begins at the first cut: a source role and a target role
  held by the describer. The cut is declared, not posited as fundamental; neither side comes first.
  Reused from kernel K1, Section 0.
- **Equally applied (D1).** One rule applied to every case's readable evidence, the assessor's
  included: `EqualStandard evidence verdict := ∃ rule, ∀ x, verdict x = rule (evidence x)`.
- **Undecidable (D2).** A question is undecidable from an access when two admissible worlds with
  the same access answer it differently (`IndependentOf`). This is independence relative to a
  declared access and a declared class of admissible worlds, the sense used in the Rule 30 and
  Axiom as Pharmakon work. It is not Turing undecidability and not Gödel incompleteness.
- **The hard problem, as modelled.** A world assigns each case a held value: whether there is
  something it is like to be it (B1). Two questions are asked: the case question (what is the
  held value of this case?) and the hardness question (is experience fixed by the readable
  evidence, so that cases that read alike always hold alike?).
- **What Lean certifies.** Lean certifies the model: the propositions in the file, under their
  stated hypotheses. That the hard problem as posed in the literature is an instance is a BRIDGE.
- **The subtitle.** An open conjecture has no receipt either way. A proof of independence is a
  receipt that, within its scope, no sound procedure can ever issue a receipt either way.
  Openness alone does not establish independence (`openness_is_not_proof`); independence forces
  openness for every sound procedure (`independence_forces_openness`).

## 1. Reused (corpus Lean, unchanged)

| Module | Supplies here | Receipt |
|---|---|---|
| UniversalRecoveryClosure, ClosureConsequences (R8 core) | `Recovers`, the collision theorem `universal_class_is_closed`, forced abstention, adequate coordinates | 18 theorems, 25 declarations, all axiom-free (as R8 records) |
| LambdaSpatiotemporalFrame (frame kernel) | reference polarity, `FactorsThrough`, `residual_selection`, `ResidualWill` | 23 theorems, 48 declarations, all axiom-free |
| DIYQCKernel (kernel K1) | Section 0, the first cut: `RoleBlind`, `role_blind_reading_cannot_order`, `cut_is_held_not_read`, `labelled_reading_recovers_order` | 175 declarations, profile as K1 records |
| BeforeTheProof_BU_FINAL (Before the Proof) | `two_chain_bridge_underdetermination` | 5 declarations, all axiom-free; first check under Lean 4.35.0 |

## 2. Proved (HP1)

Lean names drop the prefix `HardProblem.`. Unless marked, a result uses no axioms at all.

1. **Equal is recovery** (`equally_decidable_iff_recovers`). Being decided by some equal standard
   is the R8 notion of recovery from the evidence.
2. **Twins, the assessor included** (`equal_standard_cannot_separate_twins`,
   `assessor_is_assessed_alike`, `twins_as_bridge_underdetermination`). An equal standard gives the
   same verdict to any two cases that read alike: a person and a machine, or the assessor and
   anyone else. The held value plays the role of Before the Proof's upstream bridge.
3. **Collision** (`held_target_not_equally_decidable`, `read_target_equally_decidable`,
   `not_read_and_held`). No equal standard decides a held target (one that differs on two cases that
   read alike); a read target is decided by itself; no target is both.
4. **The hinge.** `finite_hinge` (constructive): over finitely many listed cases, some equal
   standard decides a target exactly when the target takes the same value on cases that read
   alike. `hinge`, `read_or_held` (classical, `Classical.choice`): the same for every type of cases;
   every target is read or held.
5. **Both edges for cases** (`sound_equal_procedure_abstains`). A sound procedure that reads only
   the evidence abstains at every stage on both cases of a pair that read alike and differ in the
   target: it can neither affirm nor exclude either one.
6. **The cut** (`no_reading_is_equal_and_recovers_the_cut`,
   `labelled_reading_recovers_and_is_not_equal`, `the_cut_is_put_in_not_read_off`). No reading is
   both role-blind and able to recover which side of the cut is first. The labeled reading
   recovers it and is not role-blind. Any coordinate that restores the order must separate the two
   orders, and it is itself not recovered from the role-blind reading: the cut is put in, not read
   off.
7. **Status of a question** (`independent_not_settled`, `independence_forces_openness`,
   `openness_is_not_proof`, `adopting_an_answer_settles`, `both_answers_meet_the_access`,
   `adopting_an_answer_is_residual`). Independence excludes settlement and forces every sound
   procedure to stay open. Openness alone does not establish independence. Adopting either answer
   as an axiom settles the question; both answers meet the access; adopting one is a residual
   selection in the frame kernel's sense, which must be marked (the Lambda Dictionary declares that
   this term attributes nothing to agency or consciousness).
8. **The sandbox** (`hardness_independent_of_the_evidence`, `hardness_independent_of_self_access`,
   `hardness_open_for_every_self`). Once two different cases present the same evidence, whether
   experience is fixed by the evidence is independent of everything an equal standard reads and of
   everything any self reads (the evidence and its own held value), whichever case the self is and
   whatever it holds. Every sound procedure stays open.
9. **Other minds** (`other_case_independent_of_self_access`). The held value of any other case is
   independent of the evidence together with the self's own held value. No pair is needed.
10. **The pair is needed** (`individuating_evidence_fixes_every_world`). If the evidence tells every
    two cases apart, every world is fixed by it (so the hardness question is settled, trivially),
    while other minds stay undetermined.
11. **The fork** (`fixed_iff_read`, classical). A world is fixed by the evidence exactly when it is a
    read target: the hardness question is the read/held fork.
12. **Main theorem** (`hard_problem_undecidable`). Results 3 and 8 together, for any evidence with
    a pair of different cases that read alike. It uses no axioms.
13. **Witness model** (`Witness.*`). Three cases (a self, its twin, another case); every hypothesis
    is met and both worlds exist, so nothing above is vacuous. Uses `propext` only.

Totals: 69 declarations (48 theorems): no axioms 53, `propext` 12, `propext, Classical.choice,
Quot.sound` 4 (`chosenRule`, `hinge`, `read_or_held`, `fixed_iff_read`).

## 3. Bridges

- **B1.** The target of the hard problem is a held value per case, and the admissible worlds carry
  no supervenience axiom. Functionalists and illusionists deny this: for them the target is read.
  The Lambda Dictionary R4 likewise holds the accumulator's psychological and consciousness
  applications as bridges (§26).
- **B2.** Everything an equal standard can use is in the evidence map: structure, behavior,
  report, and any coarse-graining the standard treats as sameness. Adding an observation changes
  the map.
- **B3.** Two different cases can present the same readable evidence (substitution pairs; Kleiner
  and Hoel 2021; identical carriers in K1). Needed only by the sandbox.
- **B4.** A self reads the evidence and its own held value: first-person access, the cut held.

## 4. Imported

- **I1.** The hard problem as posed (Chalmers 1995; the explanatory gap, Levine 1983; subjective
  character, Nagel 1974).
- **I2.** The substitution argument: when prediction data and inference data are independent, a
  non-trivial theory is falsified unless every inference from the reports is wrong (Kleiner and Hoel
  2021).
- **I3.** Open is not independent; independence is relative to the premises; both extensions are
  consistent (Axiom as Pharmakon R3: `open_not_indep`, `not_indep_union_self`,
  `indep_decided_in_extensions`; Mathlib, correspondence only, not recompiled here).
- Lineage, imported as readings: Nagel's view from nowhere (1986); Wittgenstein, Tractatus
  5.632–5.633 and Investigations §293; Spencer-Brown, Laws of Form (1969); Hofstadter, I Am a Strange
  Loop (2007); McGinn, cognitive closure (1989); Dennett (1991) and Frankish (2016) for the read
  position.

## 5. Open

- **O1.** Which answer holds: whether experience is fixed by the readable evidence. Open, and
  proved (result 8) to stay open for every equal standard and every self; settled only by adopting
  an origin (result 7).
- **O2.** Standards that are not equal (first-person, labeled): what a shared practice can build on
  them. Outside this scope.
- **O3.** Graded evidence and probabilistic verdicts (similarity rather than sameness).
- **O4.** Explanation: why and how experience arises, beyond what equal standards can decide.

## 6. Both edges

- The same results block "this case is conscious" and "this case is not conscious" as verdicts of
  an equal standard on a held target (result 5), and block both "the hard problem is dissolved"
  (fixed) and "the hard problem is real" (not fixed) as verdicts of an equal standard or of any self
  (result 8). The assessor is a case like any other (result 2).
- Equal standards have one positive consequence: cases that read alike get the same verdict.
- Adopting an origin settles the hardness question, and the selection must be marked: in the corpus
  vocabulary it is a declared stop that names its actor (Lambda Dictionary R4, §§22–23).
- Application. Hoel (arXiv:2512.12802, v3) writes: "there is no scientific theory of consciousness
  which could judge contemporary LLMs as conscious. Therefore, they are not conscious." Within this
  scope the first sentence is the kind of statement an equal standard can establish; the second is
  an exclusionary verdict, which result 5 shows a sound evidence-reading procedure cannot issue on a
  substitution pair either. The step needs its own receipt. Nothing else in that paper is assessed
  here.

## 7. Symbols and their scope

| Symbol | Carries | Formal anchor | Does not carry |
|---|---|---|---|
| The self-sealing sandbox | the hardness question cannot be closed from inside, by anyone | results 8 and 7 | any claim about which answer holds |
| Cause of and caused by; reinforces and tries to escape | every labeled reading re-asserts the cut; every role-blind reading cannot recover it; none does both | result 6 | a mechanism of consciousness |
| The beetle in the box (Wittgenstein) | the held value drops out of every equal standard | results 3 and 5 | Wittgenstein's grammatical conclusion |
| The eye not in its visual field (Tractatus 5.633) | the self's held side is not among what it reads of others | results 6 and 9 | a metaphysical subject |
| The first distinction (Spencer-Brown) | the declared origin, the first cut | D3, K1 Section 0 | the calculus of indications |
| The strange loop (Hofstadter) | self-reference keeps the two roles distinct on one carrier | `cut_is_held_not_read` | a theory of the self |

## 8. Return rule

Carry each proved result forward in its unchanged hypotheses. A further instance already
quantified by a theorem does not reopen it. An objection names a failed hypothesis, an invalid
bridge, or an inference not preserved; doubt alone leaves a claim OPEN, not FALSE.
