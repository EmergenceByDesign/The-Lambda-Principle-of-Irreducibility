import HardProblemUndecidable
#check HardProblem.EqualStandard
#print axioms HardProblem.EqualStandard
#check HardProblem.SameEvidenceSameValue
#print axioms HardProblem.SameEvidenceSameValue
#check HardProblem.Decides
#print axioms HardProblem.Decides
#check HardProblem.EquallyDecidable
#print axioms HardProblem.EquallyDecidable
#check HardProblem.ReadTarget
#print axioms HardProblem.ReadTarget
#check HardProblem.HeldTarget
#print axioms HardProblem.HeldTarget
#check HardProblem.equally_decidable_iff_recovers
#print axioms HardProblem.equally_decidable_iff_recovers
#check HardProblem.equal_standard_cannot_separate_twins
#print axioms HardProblem.equal_standard_cannot_separate_twins
#check HardProblem.assessor_is_assessed_alike
#print axioms HardProblem.assessor_is_assessed_alike
#check HardProblem.twins_as_bridge_underdetermination
#print axioms HardProblem.twins_as_bridge_underdetermination
#check HardProblem.held_target_not_equally_decidable
#print axioms HardProblem.held_target_not_equally_decidable
#check HardProblem.read_target_equally_decidable
#print axioms HardProblem.read_target_equally_decidable
#check HardProblem.not_read_and_held
#print axioms HardProblem.not_read_and_held
#check HardProblem.equally_decidable_same_value
#print axioms HardProblem.equally_decidable_same_value
#check HardProblem.firstMatch
#print axioms HardProblem.firstMatch
#check HardProblem.firstMatch_correct
#print axioms HardProblem.firstMatch_correct
#check HardProblem.finite_hinge
#print axioms HardProblem.finite_hinge
#check HardProblem.chosenRule
#print axioms HardProblem.chosenRule
#check HardProblem.hinge
#print axioms HardProblem.hinge
#check HardProblem.read_or_held
#print axioms HardProblem.read_or_held
#check HardProblem.sound_equal_procedure_abstains
#print axioms HardProblem.sound_equal_procedure_abstains
#check HardProblem.no_reading_is_equal_and_recovers_the_cut
#print axioms HardProblem.no_reading_is_equal_and_recovers_the_cut
#check HardProblem.labelled_reading_recovers_and_is_not_equal
#print axioms HardProblem.labelled_reading_recovers_and_is_not_equal
#check HardProblem.the_cut_is_put_in_not_read_off
#print axioms HardProblem.the_cut_is_put_in_not_read_off
#check HardProblem.SettledBy
#print axioms HardProblem.SettledBy
#check HardProblem.IndependentOf
#print axioms HardProblem.IndependentOf
#check HardProblem.SoundVerdict
#print axioms HardProblem.SoundVerdict
#check HardProblem.OpenAt
#print axioms HardProblem.OpenAt
#check HardProblem.independent_not_settled
#print axioms HardProblem.independent_not_settled
#check HardProblem.independence_forces_openness
#print axioms HardProblem.independence_forces_openness
#check HardProblem.openness_is_not_proof
#print axioms HardProblem.openness_is_not_proof
#check HardProblem.adopting_an_answer_settles
#print axioms HardProblem.adopting_an_answer_settles
#check HardProblem.both_answers_meet_the_access
#print axioms HardProblem.both_answers_meet_the_access
#check HardProblem.adopting_an_answer_is_residual
#print axioms HardProblem.adopting_an_answer_is_residual
#check HardProblem.World
#print axioms HardProblem.World
#check HardProblem.standardAccess
#print axioms HardProblem.standardAccess
#check HardProblem.selfAccess
#print axioms HardProblem.selfAccess
#check HardProblem.FixedByEvidence
#print axioms HardProblem.FixedByEvidence
#check HardProblem.setAt
#print axioms HardProblem.setAt
#check HardProblem.setAt_at
#print axioms HardProblem.setAt_at
#check HardProblem.setAt_off
#print axioms HardProblem.setAt_off
#check HardProblem.not_self_ne
#print axioms HardProblem.not_self_ne
#check HardProblem.pair_member_other_than
#print axioms HardProblem.pair_member_other_than
#check HardProblem.hardness_independent_of_self_access
#print axioms HardProblem.hardness_independent_of_self_access
#check HardProblem.hardness_independent_of_the_evidence
#print axioms HardProblem.hardness_independent_of_the_evidence
#check HardProblem.hardness_open_for_every_self
#print axioms HardProblem.hardness_open_for_every_self
#check HardProblem.individuating_evidence_fixes_every_world
#print axioms HardProblem.individuating_evidence_fixes_every_world
#check HardProblem.other_case_independent_of_self_access
#print axioms HardProblem.other_case_independent_of_self_access
#check HardProblem.fixed_iff_read
#print axioms HardProblem.fixed_iff_read
#check HardProblem.hard_problem_undecidable
#print axioms HardProblem.hard_problem_undecidable
#check HardProblem.Witness.evidence
#print axioms HardProblem.Witness.evidence
#check HardProblem.Witness.twin_reads_like_self
#print axioms HardProblem.Witness.twin_reads_like_self
#check HardProblem.Witness.twin_is_another_case
#print axioms HardProblem.Witness.twin_is_another_case
#check HardProblem.Witness.fixedWorld
#print axioms HardProblem.Witness.fixedWorld
#check HardProblem.Witness.heldWorld
#print axioms HardProblem.Witness.heldWorld
#check HardProblem.Witness.self_holds_alike
#print axioms HardProblem.Witness.self_holds_alike
#check HardProblem.Witness.fixed_world_is_fixed
#print axioms HardProblem.Witness.fixed_world_is_fixed
#check HardProblem.Witness.held_world_is_not_fixed
#print axioms HardProblem.Witness.held_world_is_not_fixed
#check HardProblem.Witness.held_world_is_held
#print axioms HardProblem.Witness.held_world_is_held
#check HardProblem.Witness.fixed_world_is_read
#print axioms HardProblem.Witness.fixed_world_is_read
#check HardProblem.Witness.no_equal_standard_decides_the_held_world
#print axioms HardProblem.Witness.no_equal_standard_decides_the_held_world
#check HardProblem.Witness.all_cases_listed
#print axioms HardProblem.Witness.all_cases_listed
#check HardProblem.Witness.fixed_world_equally_decidable
#print axioms HardProblem.Witness.fixed_world_equally_decidable
#check HardProblem.Witness.sandbox_instance
#print axioms HardProblem.Witness.sandbox_instance
#check HardProblem.Witness.other_mind_instance
#print axioms HardProblem.Witness.other_mind_instance
#check HardProblem.Witness.main_instance
#print axioms HardProblem.Witness.main_instance
#check HardProblem.Witness.pairReading
#print axioms HardProblem.Witness.pairReading
#check HardProblem.Witness.pairReading_role_blind
#print axioms HardProblem.Witness.pairReading_role_blind
#check HardProblem.Witness.cut_instance
#print axioms HardProblem.Witness.cut_instance
