#!/usr/bin/env python3
"""Write a single-file Lean bundle of kernel HP1 and its five reused modules.

The bundle is a convenience for checking in one paste (for example on a web Lean editor).
The separate files under lean/ stay the authoritative inputs; this script copies their text
verbatim, drops only the import lines between them, wraps each file in its own `section ... end`
(so that each file's universe declarations stay local to it, as they are in separate files), and
appends an axiom audit of every kernel declaration. Same layout as the K1 bundle.

Usage:  python3 reproduction/make_bundle.py [--out PATH]
"""
from pathlib import Path
import argparse, re, sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
p = argparse.ArgumentParser()
p.add_argument('--out', type=Path)
a = p.parse_args()
root = Path(__file__).resolve().parents[1]
parts = [root / 'lean/reused/UniversalRecoveryClosure.lean',
         root / 'lean/reused/ClosureConsequences.lean',
         root / 'lean/reused/LambdaSpatiotemporalFrame.lean',
         root / 'lean/reused/DIYQCKernel.lean',
         root / 'lean/reused/BeforeTheProof_BU_FINAL.lean',
         root / 'lean/HardProblemUndecidable.lean']
out = ['import Lean', '']
for f in parts:
    text = f.read_text()
    body = '\n'.join(line for line in text.splitlines() if not re.match(r'^import\s', line))
    out += [f'-- ===== {f.relative_to(root)} (verbatim, import lines removed) =====',
            'section', '', body.strip(), '', 'end', '']

from declaration_names import declarations  # noqa: E402
names, _ = declarations((root / 'lean/HardProblemUndecidable.lean').read_text())
out += ['-- ===== audit of every kernel HP1 declaration =====']
out += [f'#print axioms {n}' for n in names]
dest = a.out or (root / 'bundle' / 'HardProblemUndecidable_HP1_bundle.lean')
dest.parent.mkdir(parents=True, exist_ok=True)
dest.write_text('\n'.join(out) + '\n')
print(dest, len(names), 'declarations audited')
