#!/usr/bin/env python3
"""Compose RECEIPT.txt (the layout of the K1 and Axiom as Pharmakon R3 receipts) from the certificates."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

root = Path(__file__).resolve().parents[1]
summary = json.loads((root / 'receipts/verification_summary.json').read_text())
TARGETS = ('reused_core', 'reused_frame', 'reused_k1', 'reused_before_the_proof', 'kernel')
certs = {t: json.loads((root / f'receipts/{t}/certificate.json').read_text()) for t in TARGETS}
k = certs['kernel']
COMMIT = '7e472d82ab5ce7faf2d4dfb0c489f5f6ebe88e85'
BUNDLE = root / 'bundle/HardProblemUndecidable_HP1_bundle.lean'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def stage_text(cert, module):
    s = next(x for x in cert['stages'] if x['module'] == module)
    extra = (f"; {s['information']} information message(s) (its own #print/#eval lines)"
             if s['information'] else '')
    return f"exit {s['exit_code']}, {s['errors']} errors, {s['warnings']} warnings{extra}"


def profile_text(p):
    keys = sorted(p, key=lambda k: (k != 'none', len(k), k))
    return '; '.join(f"[{k}]: {p[k]}" if k != 'none' else f"none: {p[k]}" for k in keys)


def module_profile(cert, prefix):
    prof, n = {}, 0
    for d, rep in zip(cert['audited_declarations'], cert['axiom_reports']):
        if not d.startswith(prefix):
            continue
        n += 1
        used = 'none'
        if 'depends on axioms: [' in rep:
            used = rep.split('depends on axioms: [')[1].split(']')[0]
        prof[used] = prof.get(used, 0) + 1
    return n, prof


D = 'WIP_docs/IRRProofEngine/DERIVATIVE/'
REUSED = [
    ('UniversalRecoveryClosure', 'reused_core', 'UniversalRecoveryClosure.',
     'core/UniversalRecoveryClosure.lean of ' + D + 'Closure_at_the_Adjudication_Seam_2026-10-24_R8_Complete_Proofs.zip',
     'Closure at the Adjudication Seam, core (R8 packet, 24 October 2026)',
     'Lean 4.22.0, trust level 0: 0 errors, 0 warnings; core axiom reports empty'),
    ('ClosureConsequences', 'reused_core', 'ClosureConsequences.',
     'core/ClosureConsequences.lean of ' + D + 'Closure_at_the_Adjudication_Seam_2026-10-24_R8_Complete_Proofs.zip',
     'Closure at the Adjudication Seam, core (R8 packet, 24 October 2026)',
     'Lean 4.22.0, trust level 0: 0 errors, 0 warnings; core axiom reports empty'),
    ('LambdaSpatiotemporalFrame', 'reused_frame', 'LambdaSpatiotemporal.',
     'embedded file LambdaSpatiotemporalFrame.lean of ' + D + 'Lambda_Reference_and_Spatiotemporal_Descriptive_Frame_V1.pdf',
     'Lambda, Reference, and the Spatiotemporal Descriptive Frame, receipt edition (10 September 2026)',
     'Lean Web, Lean 4.33.0: PASS, 23 theorems, 0 errors, 0 warnings, 23 axiom-free reports'),
    ('DIYQCKernel', 'reused_k1', 'DIYQC.',
     'lean/DIYQCKernel.lean of ' + D + 'DIY_Quantum_Computing/DIYQC_Supplement_K1_2026-10-31.zip',
     'The Exchange Lock and Its Key, kernel K1 (On DIY Quantum Computing, 31 October 2026)',
     'Lean 4.35.0 (this toolchain), trust level 0: 175 declarations (114 theorems), 0 errors, 0 warnings'),
    ('BeforeTheProof_BU_FINAL', 'reused_before_the_proof', 'BeforeTheProof.',
     D + 'Before_the_Proof_CERTIFIED_PACKAGE_2026-08-21/Before_the_Proof/BeforeTheProof_BU_FINAL.lean',
     'Before the Proof, Certified Edition V1, Certified Appendix (C_BU, bridge underdetermination)',
     'Lean Web, Lean 4.34.0-rc2: accepted, zero error diagnostics (its BUILD_REPORT.txt)'),
]

lines = [
    'THE HARD PROBLEM PROVEN UNDECIDABLE - Lean kernel HP1 - receipt '
    f"({datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M')} UTC)",
    'The distinction between open conjecture and proof‽',
    '',
    f"Toolchain: {summary['lean_version']}",
    '           compiled here from the official source tree at tag v4.35.0 (the release archive could',
    '           not be downloaded from this environment); the build that sealed kernel K1, same commit',
    '           as the toolchain of the Axiom as Pharmakon R3 receipt. Executable SHA-256',
    f"           {summary['lean_executable_sha256']}",
    '           (a thin launcher linked to the compiler library libleanshared.so, SHA-256',
    f"           {summary.get('lean_shared_library_sha256', 'not recorded')}).",
    'Library:   bundled Lean libraries only (no Mathlib). Trust level 0 for every compilation.',
    '',
    f"Main file: HardProblemUndecidable.lean   SHA-256 {sha(root / 'lean/HardProblemUndecidable.lean')}",
    f"           {len(k['audited_declarations'])} declarations ({len(k['audited_theorems'])} theorems); "
    'sorry/admit/native_decide/axiom declarations: 0.',
    f"           Result: {stage_text(k, 'HardProblemUndecidable')}.",
    f"           Axiom profiles: {profile_text(k['axiom_profile'])}",
    '           Classical.choice appears only in ' + ', '.join(n.split('.')[-1] for n in k['classical_declarations'][:-1])
    + ' and ' + k['classical_declarations'][-1].split('.')[-1] + ':',
    '           the classical form of the hinge (checked by the audit script). The main theorem',
    '           hard_problem_undecidable depends on no axioms.',
    '           Every axiom report is in receipts/kernel/statements_and_axioms.txt, verbatim.',
    '',
    'Reused modules (folder lean/reused/), byte-identical to their sources, compiled here in this order:',
]
for name, target, prefix, src, work, orig in REUSED:
    c = certs[target]
    n, prof = module_profile(c, prefix)
    lines += [
        f'  {name}.lean',
        f"      SHA-256 {sha(root / 'lean/reused' / (name + '.lean'))}  unchanged; this build: "
        f'{stage_text(c, name)}',
        f'      audited here: {n} declarations; axiom profile {profile_text(prof)}',
        f'      from: {src}',
        f'      work: {work}',
        f'      original check: {orig}',
    ]
core, frame, k1, btp = (certs[t] for t in TARGETS[:4])
lines += [
    '',
    'Agreement with the original receipts:',
    f"  R8 core: {len(core['audited_theorems'])} theorems and {len(core['audited_declarations'])} named "
    'declarations, every axiom report empty (R8 recorded 18 and 25, all empty).',
    f"  Frame kernel: {len(frame['audited_theorems'])} theorems, every axiom report empty "
    f"({len(frame['audited_declarations'])} named declarations audited; the V1 receipt recorded 23 theorems).",
    f"  Kernel K1: {len(k1['audited_theorems'])} theorems, {len(k1['audited_declarations'])} declarations; "
    f"axiom profile {profile_text(module_profile(k1, 'DIYQC.')[1])} (as the K1 receipt records).",
    f"  Before the Proof: {len(btp['audited_theorems'])} theorems, {len(btp['audited_declarations'])} declarations, "
    'every axiom report empty; its first check under Lean 4.35.0.',
    '',
    f'Sources: corpus repository EmergenceByDesign/The-Lambda-Principle-of-Irreducibility, commit',
    f'  {COMMIT} (31 October 2026):',
    '  ' + D + 'Closure_at_the_Adjudication_Seam_2026-10-24_R8_Complete_Proofs.zip',
    '      SHA-256 dec8a3bb86780380bedb3c6b6aef214dba9c4766852a970115a267d7f7eab89c',
    '  ' + D + 'Lambda_Reference_and_Spatiotemporal_Descriptive_Frame_V1.pdf',
    '      SHA-256 f73ad48bdd06a528bced44d4babccf24c00a78939cead983343b1d74d01d868a',
    '  ' + D + 'DIY_Quantum_Computing/DIYQC_Supplement_K1_2026-10-31.zip',
    '      SHA-256 97e0063a2edcd96216222853723c91fd769dc561ced05e90130adfa6ad8744e0',
    '  ' + D + 'Before_the_Proof_CERTIFIED_PACKAGE_2026-08-21/Before_the_Proof/BeforeTheProof_BU_FINAL.lean',
    '      SHA-256 18f47a8677797108da06057b00cefe5829fe9e748912c6a8441fef29d059dc5c (equal to its SHA256SUMS.txt)',
    '',
    'Explicit premises (hypotheses, never axioms): the evidence map; a pair a != b with equal evidence (only',
    '  where stated); decidable equality of cases where worlds are built; Inhabited V for the classical hinge.',
    '  No statement about consciousness is certified by this file; THEOREM_REGISTER.json lists every bridge.',
    '',
    'Rebuild (from this folder, with Lean 4.35.0):',
    '  python3 reproduction/verify_hp1.py --lean /absolute/path/to/lean',
    'One-paste check: bundle/HardProblemUndecidable_HP1_bundle.lean (the six files verbatim, import lines',
    '  removed, each in its own section, then #print axioms for every kernel declaration).',
    f'  SHA-256 {sha(BUNDLE)}; checked here at trust level 0: 0 errors, 0 warnings, and the same',
    f"  {len(k['audited_declarations'])} kernel axiom reports as the separate-file audit.",
]
(root / 'RECEIPT.txt').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
