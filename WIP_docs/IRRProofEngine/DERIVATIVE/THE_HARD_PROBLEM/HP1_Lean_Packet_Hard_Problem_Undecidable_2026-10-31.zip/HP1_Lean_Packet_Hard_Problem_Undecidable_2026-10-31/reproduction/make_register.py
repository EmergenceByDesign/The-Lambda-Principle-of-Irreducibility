#!/usr/bin/env python3
"""Write THEOREM_REGISTER.json (R8 layout, as in supplement K1) for kernel HP1.

Each claim carries a status label (provenance and scope, never rank). For PROVED claims the axiom
dependencies are copied from the certificates in receipts/, the compiler's own reports; a receipt
may name a kernel declaration or a reused one.
"""
from pathlib import Path
import json

root = Path(__file__).resolve().parents[1]
axioms = {}
for target in ('kernel', 'reused_core', 'reused_frame', 'reused_k1', 'reused_before_the_proof'):
    cert = json.loads((root / f'receipts/{target}/certificate.json').read_text())
    for name, rep in zip(cert['audited_declarations'], cert['axiom_reports']):
        used = []
        if 'depends on axioms: [' in rep:
            used = rep.split('depends on axioms: [')[1].split(']')[0].split(', ')
        axioms[name] = used
kernel = json.loads((root / 'receipts/kernel/certificate.json').read_text())

H = 'HardProblem.'


def proved(cid, receipts, premises, conclusion, coverage):
    rs = [r if '.' in r and not r.startswith('Witness.') else H + r for r in receipts]
    for r in rs:
        assert r in axioms, r
    used = {a for r in rs for a in axioms[r]}
    deps = [a for a in ('propext', 'Classical.choice', 'Quot.sound') if a in used] + \
        sorted(used - {'propext', 'Classical.choice', 'Quot.sound'})
    return {'id': cid, 'status': 'proved', 'premises': premises, 'conclusion': conclusion,
            'coverage': coverage, 'receipt': rs, 'axiom_dependencies': deps}


def other(cid, status, statement, receipt, scope):
    return {'id': cid, 'status': status, 'statement': statement, 'receipt': receipt, 'scope': scope}


claims = [
    other('D1', 'declared', 'An equal standard is one rule applied to every case\'s readable evidence, the '
          'assessor\'s included: verdict x = rule (evidence x) for every case x.',
          'definition HardProblem.EqualStandard', 'the definition used throughout; proposed in the discussion '
          'and adopted when the author asked for this build'),
    other('D2', 'declared', 'Undecidable from an access means independent of it: two admissible worlds with the '
          'same access answer the question differently. Not Turing undecidability, not Goedel incompleteness.',
          'definitions HardProblem.IndependentOf, HardProblem.SettledBy', 'relative to a declared access and a '
          'declared class of admissible worlds'),
    other('D3', 'declared', 'Origin: the first cut, a source role and a target role held by the describer; declared, '
          'not posited as fundamental; no first position or hierarchy.', 'kernel K1, Section 0 (reused)',
          'carried by the reused frame kernel'),
    proved('equal_is_recovery', ['equally_decidable_iff_recovers'], ['evidence : Case -> Ev', 'target : Case -> V'],
           'Being decided by some equal standard is the R8 notion Recovers evidence target.',
           'Every type of cases, evidence and values.'),
    proved('twins', ['equal_standard_cannot_separate_twins', 'assessor_is_assessed_alike',
                     'twins_as_bridge_underdetermination', 'BeforeTheProof.two_chain_bridge_underdetermination'],
           ['EqualStandard evidence verdict', 'evidence a = evidence b'],
           'verdict a = verdict b: an equal standard cannot separate two cases that read alike, a person and a '
           'machine or the assessor and anyone else; the held value is an upstream bridge it does not read.',
           'Every pair of cases.'),
    proved('collision', ['held_target_not_equally_decidable', 'read_target_equally_decidable', 'not_read_and_held',
                         'ClosureConsequences.universal_class_is_closed'],
           ['HeldTarget: evidence a = evidence b and target a != target b'],
           'No equal standard decides a held target; a read target is decided by itself; no target is both.',
           'Every target.'),
    proved('hinge_finite', ['equally_decidable_same_value', 'finite_hinge',
                            'ClosureConsequences.recovery_requires_target_constancy'],
           ['finitely many listed cases', 'decidable equality of evidence'],
           'Some equal standard decides the target exactly when the target takes the same value on cases that read '
           'alike; the deciding rule is built by search.',
           'Constructive; every finite listing of cases.'),
    proved('hinge_classical', ['hinge', 'read_or_held'], ['Classical.choice'],
           'The same equivalence for every type of cases; every target is read or held.',
           'The classical general form; the only use of Classical.choice in the kernel.'),
    proved('both_edges_cases', ['sound_equal_procedure_abstains',
                                'ClosureConsequences.both_witnesses_have_certified_abstention'],
           ['evidence a = evidence b', 'target a != target b', 'attempt reads only the evidence and is sound'],
           'The procedure abstains at every stage on both cases: it can neither affirm nor exclude either one.',
           'Every sound procedure and every such pair.'),
    proved('cut', ['no_reading_is_equal_and_recovers_the_cut', 'labelled_reading_recovers_and_is_not_equal',
                   'the_cut_is_put_in_not_read_off', 'DIYQC.FirstCut.cut_is_held_not_read',
                   'DIYQC.FirstCut.role_blind_reading_cannot_order'],
           ['a != b', 'reading is role-blind (for the third result)'],
           'No reading is both role-blind and able to recover which side of the cut is first; the labeled reading '
           'recovers it and is not role-blind; any coordinate that restores the order must separate the two orders '
           'and is itself not recovered from the role-blind reading.',
           'Every type of cases and readings.'),
    proved('status', ['independent_not_settled', 'independence_forces_openness', 'openness_is_not_proof',
                      'adopting_an_answer_settles', 'both_answers_meet_the_access', 'adopting_an_answer_is_residual'],
           ['IndependentOf admissible access Q (for the first, second, fifth and sixth)'],
           'Independence excludes settlement and forces every sound procedure to stay open; openness alone does '
           'not establish independence; adopting either answer as an axiom settles the question; both answers meet '
           'the access; adopting one is a residual selection that must be marked.',
           'Every type of worlds, access values and questions.'),
    proved('sandbox', ['hardness_independent_of_the_evidence', 'hardness_independent_of_self_access',
                       'hardness_open_for_every_self'],
           ['a != b', 'evidence a = evidence b', 'decidable equality of cases'],
           'Whether experience is fixed by the evidence is independent of everything an equal standard reads and of '
           'everything any self reads (the evidence and its own held value); every sound procedure stays open.',
           'Every self, every held value, every such pair.'),
    proved('other_minds', ['other_case_independent_of_self_access'], ['other != self', 'decidable equality of cases'],
           'The held value of any other case is independent of the evidence together with the self\'s own held value.',
           'Every self and every other case; no pair needed.'),
    proved('pair_needed', ['individuating_evidence_fixes_every_world'],
           ['the evidence tells every two cases apart'],
           'Then every world is fixed by the evidence: the sandbox needs its pair hypothesis.',
           'Every world.'),
    proved('fork', ['fixed_iff_read'], ['Classical.choice'],
           'A world is fixed by the evidence exactly when it is a read target: the hardness question is the read/held fork.',
           'Every world.'),
    proved('main', ['hard_problem_undecidable'],
           ['a != b', 'evidence a = evidence b', 'decidable equality of cases'],
           'The hardness question is independent of what equal standards read and of what every self reads; no world '
           'in which a and b differ is equally decidable; every sound procedure stays open.',
           'The headline theorem; uses no axioms at all.'),
    proved('witness', ['Witness.twin_reads_like_self', 'Witness.twin_is_another_case', 'Witness.fixed_world_is_fixed',
                       'Witness.held_world_is_not_fixed', 'Witness.held_world_is_held',
                       'Witness.fixed_world_equally_decidable', 'Witness.no_equal_standard_decides_the_held_world',
                       'Witness.sandbox_instance', 'Witness.other_mind_instance', 'Witness.main_instance',
                       'Witness.cut_instance'],
           ['three cases: self, twin, other'],
           'Every hypothesis is met and both worlds exist: the theorems are not vacuous.',
           'The declared three-case model.'),
    other('B1', 'bridge', 'The target of the hard problem (whether there is something it is like to be a case) is '
          'modelled as a held value per case, and the admissible worlds carry no supervenience axiom.',
          'declared modeling choice; the Lambda Dictionary R4 likewise holds the accumulator\'s psychological and consciousness applications as bridges (section 26)',
          'denied by functionalists and illusionists, who take the target to be read'),
    other('B2', 'bridge', 'Everything an equal standard can use is in the evidence map: structure, behavior, report, '
          'and any coarse-graining the standard treats as sameness.', 'declared', 'adding an observation changes the map'),
    other('B3', 'bridge', 'Two different cases can present the same readable evidence (substitution pairs).',
          'Kleiner and Hoel 2021 (substitutions); identical carriers in kernel K1', 'needed only by the sandbox'),
    other('B4', 'bridge', 'A self reads the evidence and its own held value: first-person access, the cut held.',
          'declared; kernel K1 Section 0', 'the self\'s access is the strongest access modelled'),
    other('I1', 'imported', 'The hard problem of consciousness as posed: why and how physical processing is '
          'accompanied by experience.', 'Chalmers 1995; Levine 1983; Nagel 1974', 'statement of the question'),
    other('I2', 'imported', 'Substitution argument: theories that predict experience from anything but the inference '
          'data are falsified by substitutions or trivial.', 'Kleiner and Hoel 2021', 'theories tested against reports'),
    other('I3', 'imported', 'Open is not independent; independence is relative to the premises; both extensions are '
          'consistent.', 'Axiom as Pharmakon R3: open_not_indep, not_indep_union_self, indep_decided_in_extensions '
          '(Mathlib; correspondence only, not recompiled here)', 'proof-theoretic setting'),
    other('O1', 'open', 'Which answer holds: whether experience is fixed by the readable evidence.',
          'proved to stay open for every equal standard and every self (sandbox)', 'settled only by adopting an origin'),
    other('O2', 'open', 'Standards that are not equal (first-person, labeled): what a shared practice can build on them.',
          'none', 'outside this scope'),
    other('O3', 'open', 'Graded evidence and probabilistic verdicts (similarity rather than sameness).', 'none',
          'the kernel treats sameness as the standard reads it'),
    other('O4', 'open', 'Explanation: why and how experience arises, beyond what equal standards can decide.', 'none',
          'not addressed'),
]
register = {
    'edition': 'The Hard Problem Proven Undecidable, kernel HP1, 2026-10-31',
    'central_status': 'proved_within_declared_scope',
    'return_rule': ('Carry each proved result forward in its unchanged hypotheses. A further instance already '
                    'quantified by a theorem does not reopen it. An objection names a failed hypothesis, an '
                    'invalid bridge, or an inference not preserved; doubt alone leaves a claim OPEN, not FALSE.'),
    'lean_version': kernel['lean_version'],
    'claims': claims,
}
(root / 'THEOREM_REGISTER.json').write_text(json.dumps(register, indent=2, ensure_ascii=False) + '\n')
print('claims:', len(claims), '| proved:', sum(c['status'] == 'proved' for c in claims))
