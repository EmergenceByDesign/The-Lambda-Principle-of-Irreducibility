#!/usr/bin/env python3
"""Write MANIFEST_SHA256.json for every shipped file and zip the supplement (no compiled .olean)."""
from pathlib import Path
import hashlib, json, sys, zipfile

root = Path(__file__).resolve().parents[1]
name = sys.argv[1] if len(sys.argv) > 1 else 'HP1_Lean_Packet_Hard_Problem_Undecidable_2026-10-31'
SKIP_DIRS = {'build', '__pycache__'}


def shipped():
    for p in sorted(root.rglob('*')):
        if p.is_dir() or any(part in SKIP_DIRS for part in p.relative_to(root).parts):
            continue
        if p.suffix in ('.olean', '.ilean', '.zip') or p.name == 'MANIFEST_SHA256.json':
            continue
        yield p


files = {str(p.relative_to(root)): {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
                                   'bytes': p.stat().st_size} for p in shipped()}
manifest = {'edition': name, 'hash_algorithm': 'SHA-256', 'files': files}
(root / 'MANIFEST_SHA256.json').write_text(json.dumps(manifest, indent=2) + '\n')
out = root.parent / (name + '.zip')
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
    for rel in list(files) + ['MANIFEST_SHA256.json']:
        z.write(root / rel, f'{name}/{rel}')
print(out, len(files) + 1, 'files')
