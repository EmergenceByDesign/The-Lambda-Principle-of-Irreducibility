#!/usr/bin/env python3
"""
QED reference verifier — verifier_class: lean4_kernel
=====================================================

Deterministic, re-runnable verification of a Lean 4 proof submission
against a SealedStatement. Anyone can run this; identical inputs in the
pinned environment MUST yield identical receipts. That property is what
makes optimistic settlement honest.

ACCEPTANCE CRITERION (all must hold):
  1. The submission builds against the sealed statement inside the pinned
     container (statement.toolchain.container_digest), with no network,
     read-only toolchain, and the sealed resource limits.
  2. `#print axioms` for the proved statement yields a set that is a
     subset of statement.axiom_whitelist. `sorryAx` is never permitted.
  3. Imports used are a subset of statement.import_manifest.
  4. Resource limits are respected; exceeding them fails closed
     (result: resource_exceeded).

USAGE:
  verify_lean.py --statement sealed_statement.json \
                 --submission proof.lean \
                 --key verifier_key.hex \
                 [--out receipt.json]

REQUIREMENTS: docker (or podman aliased to docker). The container image
must already be present or pullable BY DIGEST ONLY — never by tag; tags
move, digests don't. A receipt produced outside the pinned digest is
void on its face.

This is reference code: readable over clever. Harden per the SELF asks.
"""

import argparse, hashlib, json, subprocess, sys, tempfile, time
from pathlib import Path

FORBIDDEN_ALWAYS = {"sorryAx"}


def canonical(obj) -> str:
    """Canonical JSON: UTF-8, sorted keys, no insignificant whitespace."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def artifact_id(prefix: str, body: dict) -> str:
    return f"qed:{prefix}:{sha256_hex(canonical(body).encode())}"


def run_in_container(statement: dict, submission_path: Path, workdir: Path):
    """Build the submission against the sealed statement in the pinned
    container. Returns (result_str, axiom_record, usage, log)."""
    tc = statement["toolchain"]
    limits = statement["resource_limits"]
    digest = tc["container_digest"]

    # Assemble the project: sealed statement source + submission.
    # The statement's formal_src declares the target theorem(s); the
    # submission must prove them. The driver emits `#print axioms` for
    # every target into a machine-readable marker line.
    (workdir / "Statement.lean").write_text(statement["formal_src"], encoding="utf-8")
    (workdir / "Submission.lean").write_text(submission_path.read_text(encoding="utf-8"), encoding="utf-8")
    (workdir / "check.sh").write_text(
        "#!/bin/sh\nset -e\ncd /work\nlake env lean Statement.lean Submission.lean\n",
        encoding="utf-8",
    )

    cmd = [
        "docker", "run", "--rm",
        "--network", "none",                       # no network, ever
        "--read-only",                             # toolchain immutable
        "--tmpfs", "/tmp:rw,size=512m",
        "-v", f"{workdir}:/work:rw",
        "--memory", f"{limits['memory_mb']}m",
        "--cpus", "1",
        "--pids-limit", "256",
        digest,
        "sh", "/work/check.sh",
    ]

    t0 = time.monotonic()
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=limits["wall_seconds"]
        )
    except subprocess.TimeoutExpired as e:
        return "resource_exceeded", [], {"wall_seconds": time.monotonic() - t0}, (e.stdout or "") + (e.stderr or "")
    wall = time.monotonic() - t0
    log = proc.stdout + proc.stderr

    if proc.returncode != 0:
        return "rejected", [], {"wall_seconds": wall}, log

    # Axiom record: the sealed statement's formal_src is REQUIRED to end
    # with `#print axioms <target>` directives for each target theorem;
    # Lean prints lines of the form: "'<target>' depends on axioms: [a, b]".
    axioms = set()
    for line in log.splitlines():
        if "depends on axioms:" in line:
            inside = line.split("depends on axioms:", 1)[1].strip().strip("[]")
            for ax in inside.split(","):
                ax = ax.strip()
                if ax:
                    axioms.add(ax)
    return "accepted", sorted(axioms), {"wall_seconds": wall}, log


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--statement", required=True)
    ap.add_argument("--submission", required=True)
    ap.add_argument("--key", required=True, help="verifier public key hex (signing left to your key tooling; see note)")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    statement = json.loads(Path(args.statement).read_text(encoding="utf-8"))
    submission_path = Path(args.submission)

    # 0. Integrity: recompute the statement id from its sealed body.
    body = {k: v for k, v in statement.items() if k not in ("id",)}
    expected = artifact_id("stmt", body)
    if statement.get("id") != expected:
        print(f"VOID: statement id mismatch\n  declared {statement.get('id')}\n  computed {expected}", file=sys.stderr)
        return 2

    with tempfile.TemporaryDirectory() as td:
        result, axiom_record, usage, log = run_in_container(statement, submission_path, Path(td))

    # Axiom whitelist check (only meaningful on build success).
    if result == "accepted":
        whitelist = set(statement.get("axiom_whitelist", []))
        record = set(axiom_record)
        if record & FORBIDDEN_ALWAYS or not record <= whitelist:
            result = "rejected"

    receipt_body = {
        "statement_id": statement["id"],
        "commit_ref": sha256_hex(submission_path.read_bytes()),
        "verifier_class": "lean4_kernel",
        "toolchain": statement["toolchain"],
        "result": result,
        "axiom_record": axiom_record,
        "resource_usage": usage,
        "verifier": {"key": args.key, "sig": "UNSIGNED-REFERENCE-RUN"},
    }
    receipt = {"id": artifact_id("receipt", receipt_body), **receipt_body}
    out = json.dumps(receipt, indent=2)
    if args.out:
        Path(args.out).write_text(out + "\n", encoding="utf-8")
    print(out)
    print(f"\n== {result.upper()} ==", file=sys.stderr)
    # NOTE: production nodes sign receipt_body's canonical JSON with the
    # verifier key (ed25519 recommended) and place the signature in
    # verifier.sig. Signing is deliberately left to your key tooling so
    # this script has zero dependencies.
    return 0 if result == "accepted" else 1


if __name__ == "__main__":
    sys.exit(main())
