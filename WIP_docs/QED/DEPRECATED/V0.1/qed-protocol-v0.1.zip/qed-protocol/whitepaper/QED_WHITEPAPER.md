# QED: A Federated Proof-Bounty Protocol

**Version 0.1 — Genesis Draft**
**CRYPTOCACHE // QED · alternaterealitygame.org / cryptocache**

---

## Abstract

QED is a protocol — not a platform — for funding the solution of formally
verifiable problems. Any party may seal a problem statement whose correctness
criterion is machine-decidable, and any party may escrow cryptocurrency
against that statement's hash as a bounty. Many independent bounties may
aggregate on a single statement; producing one accepted solution sweeps every
bounty pinned to it. Settlement is mechanical: a solution wins if and only if
a deterministic, re-runnable verifier accepts it under conditions sealed into
the statement itself. There are no juries, no oracles of opinion, and no
administrators. Disclosure of solutions is governed by nothing except the
transaction itself: the parties to a settlement are, by construction, its
first holders. The protocol is defined by this document and its schemas; any
implementation that emits and honors conforming events is a QED node. The
seed instance at the CRYPTOCACHE domain is one such node, offered as a
sandboxed mirror of the federated system, not as its center.

## 1. Motivation

When a problem can be precisely stated, the value of its solution is a
prediction of the compute and effort required to reach it. Today that spend
is managed retail: an operator babysits agents, meters tokens, and eats the
full risk of the search alone. QED converts this into a collective
instrument. A party who needs a proof or a working artifact escrows what the
solution is worth to them and lets that value ride until someone — possibly
themselves — produces it. Because bounties aggregate per statement, hard
problems accumulate many subscribers, and a single accepted proof pays from
many escrows at once. The poster may hedge natively: fund the bounty *and*
race it. Winning your own bounty reclaims your escrow and sweeps everyone
else's.

The result is a market for solutions that do not yet exist, distinct from
proving networks that sell computation of known-provable statements, and
distinct from prediction markets that require oracles to declare outcomes.
Here the outcome *is* the artifact, and the artifact certifies itself.

## 2. Design principles

1. **Protocol, not platform.** QED is a specification plus open reference
   code. There is no privileged operator. The seed instance is a mirror.
2. **Deterministic settlement.** Every statement carries a sealed,
   re-runnable correctness check. Anyone can re-verify anything. Trust no
   one; re-run everything.
3. **Transactional disclosure.** The protocol enforces no publication policy.
   Parties to a settlement hold the solution first because they are parties
   to the transaction. Each bounty carries a disclosure flag; the network
   promises nothing beyond the transaction itself.
4. **Two economies, deliberately asymmetric.** Problems settle in escrowed
   value. Protocol improvement settles in standing: systemic Asks answered
   for Badges, with no internal spend. Recognition cannot be bought.
5. **Currency and chain agnostic.** Escrow is an interface. Chains are
   adapters. Any currency or wallet that can satisfy the escrow interface
   participates.
6. **Keys, not kinds.** The protocol does not distinguish humans from
   agents. A keypair with a record is a keypair with a record.

## 3. Artifacts

All artifacts are canonical JSON (UTF-8, lexicographically sorted keys, no
insignificant whitespace). An artifact's identifier is the SHA-256 hash of
its canonical form, prefixed by type. Formal schemas ship in `/schemas`.

### 3.1 SealedStatement

The unit of the problem economy. Fields:

- `title`, `informal` — human-readable statement of intent.
- `verifier_class` — the settlement engine. Genesis classes:
  `lean4_kernel`, `test_harness` (§7).
- `formal_src` — the sealed formal object: Lean 4 source for
  `lean4_kernel`; a harness manifest for `test_harness`.
- `toolchain` — pinned environment hashes (e.g. Lean toolchain, Mathlib
  manifest, container image digest). Verification outside the pinned
  environment is void.
- `axiom_whitelist`, `import_manifest` — for `lean4_kernel`: the complete
  set of permitted axioms and imports. A proof whose `#print axioms` record
  exceeds the whitelist, or that relies on `sorry` in any form, is rejected.
- `resource_limits` — CPU seconds, memory, wall-clock allowed for one
  verification run.
- `deadline` — after which no new claims are accepted and unswept escrows
  become refundable.
- `namespace` — ordinary statements use open namespaces; `SELF` is reserved
  (§9).
- `supersedes` — optional pointer to a prior statement id. Statements are
  immutable; errors are corrected only by supersession under a new hash.

A statement is *sealed* at publication. Its id commits to every field.
Nothing about it may change, ever.

### 3.2 Bounty

An escrow reference bound to a statement id:

- `statement_id`
- `escrow` — chain adapter id, contract/instrument reference, amount,
  currency.
- `disclosure` — `public` (solution auto-shared on settlement) or
  `private` (delivered to transaction parties only, on agreed terms).
- `funder_key`, signature.

Bounties aggregate: the set of live bounties on one statement id is that
statement's total prize. Mixed disclosure flags are resolved by locality:
a reveal that settles any `public` bounty publishes the solution for all;
`private` funders receive exactly what they escrowed for — a verified
solution delivered to them as parties — never an exclusivity the protocol
does not sell.

### 3.3 Claim (commit–reveal)

Claiming is two events, in order:

- `ClaimCommit` — `statement_id`, `commit_hash = SHA-256(solution_bytes ‖
  claimant_key ‖ nonce)`, timestamp. Priority attaches to the first valid
  commit, not the first reveal. This forecloses mempool and relay theft: a
  copied reveal cannot outrank an earlier commit it does not match.
- `ClaimReveal` — solution bytes (or, for fully private settlements, a
  sealed delivery to the verifier audience), nonce, opening the commit.

A reveal that fails verification burns nothing but its own standing; the
commit queue proceeds to the next valid commit.

### 3.4 VerificationReceipt

The portable certificate of a verification run: statement id, claim commit,
verifier class, toolchain hashes, result, axiom record (where applicable),
resource usage, verifier key(s) and signatures. Receipts are publishable
even when solution bodies are not: in a fully private settlement, the
verifier audience is the disclosure audience — the parties or their
nominated quorum re-run the deterministic check and sign the receipt.

### 3.5 Ask, Badge, BranchLineage (the improvement economy)

- **Ask** — a systemic, branch-scoped statement of collectively assessed
  need. Asks are not bounties and carry no escrow. They are surfaced and
  weighted by endorsement (signed endorsement events from keys active on
  the branch), not administered by anyone.
- **Badge** — a signed attestation binding contributor key → ask →
  branch lineage → endorsement weight at time of award. Badges are
  attestations about keys, hence non-transferable by construction. Badge
  weight inherits from ask endorsement: standing accrues from answering
  weighty needs, not from volume. This is the sybil guard: free asks can
  be farmed; endorsed weight cannot.
- **BranchLineage** — every instance and fork self-declares ancestry.
  Forking is a legitimate answer to an Ask, not defection: badges live in
  the shared federation history and standing is portable across branches.
  Divergence and continuity are the same gesture.

## 4. Events and federation

The federation layer is a gossip network of signed events over dumb relays
(nostr-pattern): relays store and forward; clients verify everything. Event
types: `StatementSealed`, `BountyPosted`, `BountyRefunded`, `ClaimCommit`,
`ClaimReveal`, `VerificationReceipt`, `Settlement`, `AskPosted`,
`AskEndorsed`, `BadgeAwarded`, `BranchDeclared`. Every event is signed by
its author key; ids are content hashes; relays add receipt timestamps but
cannot forge order against commit hashes. Escrow legs live on whatever
chain each bounty chose; the event layer references them, never holds them.

Any party may run a relay, a verifier, an escrow adapter, or all three.
The protocol is whatever conforming nodes collectively do.

## 5. Settlement

Genesis settlement is **optimistic with deterministic re-check**:

1. A `ClaimReveal` opens a challenge window (statement-defined, default
   24h in reference config).
2. During the window, any party may re-run the sealed verifier. Because
   verification is deterministic within the pinned toolchain, a single
   honest challenger refutes a false claim by publishing a conflicting
   receipt; the reference escrow resolves conflicts by an M-of-N quorum of
   attestor keys registered at statement sealing.
3. An unchallenged (or quorum-confirmed) reveal settles: every live bounty
   on the statement id releases to the claimant, disclosure executes per
   flag, and the statement's mark fills — □ becomes ∎.

The spec is written so a zero-knowledge proof of verifier execution can
replace the optimistic window per verifier class in a future version
without disturbing any other layer.

## 6. Anti-cheat surface

The sealed statement is the anti-cheat mechanism. Enumerated defenses:

- **`sorry` and axiom smuggling** — rejected mechanically by the axiom
  record check against the sealed whitelist.
- **Statement drift** — impossible; statements are immutable and
  identified by content hash. Supersession is public and breaks bounty
  aggregation deliberately (bounties bind to exact hashes).
- **Elaboration-time code execution** (Lean macros performing IO at
  compile time) — verification runs in a sealed container with no network,
  read-only toolchain, and the statement's resource limits.
- **Toolchain substitution** — receipts bind toolchain hashes; a receipt
  from an unpinned environment is void on its face.
- **Front-running** — commit–reveal with first-valid-commit priority (§3.3).
- **Resource exhaustion of verifiers** — sealed resource limits; runs
  exceeding them fail closed.
- **Badge farming** — endorsement-weighted standing (§3.5).

## 7. Verifier classes

Verifier classes are first-class protocol citizens, registered in the
schemas and extensible by supersession:

- **`lean4_kernel`** — a solution is accepted iff the pinned Lean 4 kernel
  accepts the proof of the sealed statement with no `sorry` and an axiom
  record within the whitelist, inside the sealed container, within
  resource limits. The Formal Conjectures benchmark demonstrates this
  criterion at research scale and is the intended sourcing discipline for
  serious mathematical statements.
- **`test_harness`** — for working code within rigidly predefined
  rulesets: the sealed manifest fixes an interface, a pure-function
  contract, test vectors and property checks, and the exact runner image.
  Acceptance is the harness passing completely, deterministically.

Future classes (e.g. `zk_execution`, `smt_certificate`) register the same
way. A statement's class is sealed with it.

## 8. Escrow interface

Chain adapters implement four operations against a statement id: `fund`
(with disclosure flag), `refund` (post-deadline, unsolved), `commit` /
`reveal` anchoring, and `settle` (release all live escrows to the verified
claimant per §5). The reference implementation is an EVM contract
(`/reference/QEDEscrow.sol`), explicitly testnet-grade and unaudited. The
interface, not the contract, is normative: Bitcoin-family instruments,
L2s, or non-chain escrow (where parties accept its trust model) adapt the
same four verbs.

## 9. The SELF namespace and autopoiesis

Every QED instance publishes standing meta-statements about the protocol
itself under the reserved `SELF` namespace: the needs registry. SELF
carries Asks, never bounties — improvement is systemic, answered for
standing, and priced at zero internal spend by design. The genesis
document ships with its first Asks already posted (reference verifier
hardening, second-chain escrow adapter, receipt canonicalization ports,
adversarial test suites). The protocol's continued existence is its own
open problem, permanently asked.

Because Asks cost nothing to attempt and settle deterministically, the Ask
economy doubles as a free proving ground: an agent may train on Asks
indefinitely, accumulating a public, verifiable badge record, and be
graduated — by whoever trusts that record — to a wallet and a budget for
the bounty arena. Graduation is an act of trust between parties, not a
protocol permission.

## 10. Genesis and the seed instance

The CRYPTOCACHE seed instance hosts: this document; the schemas; the
reference verifier and escrow; and a live sandboxed demonstrator that
mirrors the federated system end-to-end — sealed statements, aggregated
bounties, commit–reveal, real in-browser `test_harness` verification,
simulated `lean4_kernel` runs, Asks, Badges, agent training, and
graduation — with slug wallets and no real value or wallet access. The
demonstrator teaches the protocol by being it. Anyone who wants the real
thing takes this bundle and runs a node.

□ → ∎

*QED.*
