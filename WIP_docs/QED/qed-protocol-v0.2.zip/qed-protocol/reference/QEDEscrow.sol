// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * QEDEscrow — reference EVM escrow adapter for the QED protocol.
 * =============================================================
 * PROTOCOL VERSION 0.2.
 *
 * TESTNET-GRADE. UNAUDITED. CONTAINS KNOWN EXPLOITABLE PATHS. This file is
 * published as a REFERENCE AND AS A TARGET, not as working infrastructure.
 * Every defect below is catalogued in CLAIM_TABLE.md (QED-SETTLE-*) and has
 * a case in conformance/adversarial_corpus.json. Do not deploy with real
 * value. Fixing these is open work, not a private roadmap.
 *
 * KNOWN OPEN DEFECTS in this file (v0.2 does NOT fix them; v1.0 gates do):
 *   QED-SETTLE-002  quorumM == 0 permits dispute-then-settle with zero
 *                   confirming attestations. A claimant can self-settle a
 *                   rejected reveal.
 *   QED-SETTLE-003  revealClaim scans an unbounded commit array and settle
 *                   scans every bounty; either can be inflated past the
 *                   block gas limit, bricking settlement permanently.
 *   QED-SETTLE-004  registerStatement is unauthenticated. Anyone may claim
 *                   a statement hash first with arbitrary deadline,
 *                   challenge window, and attestor set. The contract never
 *                   proves those parameters match the hashed statement.
 *   QED-SETTLE-005  attested[] is keyed per statement, not per reveal.
 *                   After a refuted reveal is deleted, prior voters cannot
 *                   vote again and stale state persists.
 *   QED-SETTLE-006  refund() is callable after the deadline while a reveal
 *                   is under challenge, letting funders withdraw the prize
 *                   out from under a valid claimant.
 *   Payments are PUSH, not pull. A claimant contract that reverts on
 *   receive() bricks settle() for everyone on that statement. The escrow INTERFACE (fund /
 * refund / commit / reveal / settle) is normative; this contract is one
 * illustration of it in native ETH. ERC-20 and other-chain adapters
 * implement the same four verbs.
 *
 * Settlement model (whitepaper §5): optimistic with deterministic
 * re-check. A reveal opens a challenge window. Because verification is
 * deterministic in the sealed toolchain, any honest party can refute a
 * false claim off-chain; on-chain, disputes resolve by an M-of-N quorum
 * of attestor keys registered at statement registration. Unchallenged
 * reveals settle after the window: every live bounty on the statement
 * releases to the claimant.
 *
 * Commit–reveal (whitepaper §3.3): priority attaches to the FIRST VALID
 * COMMIT. A reveal only settles if it opens the earliest commit whose
 * hash it matches, which forecloses mempool theft of revealed proofs.
 */
contract QEDEscrow {
    struct Statement {
        bytes32 statementHash;   // sha256 of the SealedStatement canonical JSON
        uint64 deadline;         // unix; no commits after this
        uint32 challengeWindow;  // seconds
        uint8 quorumM;           // attestations required to resolve a dispute
        address[] attestors;
        bool exists;
    }

    struct Bounty {
        address funder;
        uint256 amount;
        bool disclosurePublic;   // informational; disclosure is transactional (§3.2)
        bool refunded;
    }

    struct Commit {
        address claimant;
        bytes32 commitHash;      // sha256(solution || claimant || nonce)
        uint64 at;
    }

    struct Reveal {
        uint256 commitIndex;
        bytes32 solutionHash;    // sha256 of revealed solution bytes
        bytes32 receiptRef;      // qed:receipt: hash; zero => no receipt (L3)
        uint64 at;
        bool disputed;
        uint8 attestationsFor;   // quorum votes confirming acceptance
        uint8 attestationsAgainst;
        bool settled;
    }

    mapping(bytes32 => Statement) public statements;          // key: statementHash
    mapping(bytes32 => Bounty[]) public bounties;
    mapping(bytes32 => Commit[]) public commits;
    mapping(bytes32 => Reveal) public reveals;                // one live reveal per statement
    mapping(bytes32 => mapping(address => bool)) public attested;

    event StatementRegistered(bytes32 indexed statementHash, uint64 deadline);
    event BountyFunded(bytes32 indexed statementHash, uint256 index, address funder, uint256 amount, bool disclosurePublic);
    event BountyRefunded(bytes32 indexed statementHash, uint256 index);
    event ClaimCommitted(bytes32 indexed statementHash, uint256 index, address claimant, bytes32 commitHash);
    event ClaimRevealed(bytes32 indexed statementHash, uint256 commitIndex, bytes32 solutionHash);
    event Disputed(bytes32 indexed statementHash, address challenger);
    event Attested(bytes32 indexed statementHash, address attestor, bool accept);
    /// L3 naming discipline (QED-NAME-001). Settled REQUIRES a referenced
    /// verification receipt. A release with no receipt behind it emits
    /// Released instead, with the reason recorded. The configuration stays
    /// legal; only the vocabulary is constrained, because downstream
    /// readers act on these names without seeing what produced them.
    event Settled(bytes32 indexed statementHash, address claimant, uint256 total, bytes32 receiptRef);
    event Released(bytes32 indexed statementHash, address claimant, uint256 total, string reason);

    // -- registration -----------------------------------------------------

    function registerStatement(
        bytes32 statementHash,
        uint64 deadline,
        uint32 challengeWindow,
        uint8 quorumM,
        address[] calldata attestors
    ) external {
        require(!statements[statementHash].exists, "exists");
        require(deadline > block.timestamp, "deadline past");
        require(quorumM == 0 || quorumM <= attestors.length, "bad quorum");
        statements[statementHash] = Statement(statementHash, deadline, challengeWindow, quorumM, attestors, true);
        emit StatementRegistered(statementHash, deadline);
    }

    // -- fund / refund ----------------------------------------------------

    function fund(bytes32 statementHash, bool disclosurePublic) external payable {
        Statement storage s = statements[statementHash];
        require(s.exists, "no statement");
        require(block.timestamp < s.deadline, "past deadline");
        require(msg.value > 0, "zero");
        bounties[statementHash].push(Bounty(msg.sender, msg.value, disclosurePublic, false));
        emit BountyFunded(statementHash, bounties[statementHash].length - 1, msg.sender, msg.value, disclosurePublic);
    }

    /// After the deadline, if the statement is unsettled, funders reclaim.
    function refund(bytes32 statementHash, uint256 index) external {
        Statement storage s = statements[statementHash];
        require(s.exists, "no statement");
        require(block.timestamp >= s.deadline, "not yet");
        require(!reveals[statementHash].settled, "settled");
        Bounty storage b = bounties[statementHash][index];
        require(b.funder == msg.sender && !b.refunded, "not yours / done");
        b.refunded = true;
        emit BountyRefunded(statementHash, index);
        (bool ok, ) = msg.sender.call{value: b.amount}("");
        require(ok, "xfer");
    }

    // -- commit / reveal --------------------------------------------------

    function commitClaim(bytes32 statementHash, bytes32 commitHash) external {
        Statement storage s = statements[statementHash];
        require(s.exists && block.timestamp < s.deadline, "closed");
        commits[statementHash].push(Commit(msg.sender, commitHash, uint64(block.timestamp)));
        emit ClaimCommitted(statementHash, commits[statementHash].length - 1, msg.sender, commitHash);
    }

    /// Reveal opens the EARLIEST commit that matches; earlier unrevealed
    /// commits by others do not block (they simply haven't proven they
    /// hold a solution), but an earlier MATCHING commit always wins over
    /// a later copier: the copier cannot produce a matching earlier hash
    /// because the commit binds the claimant address.
    /// @param receiptRef qed:receipt: hash of a VerificationReceipt for this
    ///        claim, or bytes32(0). Zero is permitted; it only changes which
    ///        event settlement may emit (L3).
    /// NOTE: `solution` is public calldata. There is no private reveal on a
    /// public chain, whatever a bounty's disclosure flag says (QED-PRIV-001).
    function revealClaim(bytes32 statementHash, bytes calldata solution, bytes32 nonce, bytes32 receiptRef) external {
        Statement storage s = statements[statementHash];
        require(s.exists, "no statement");
        require(reveals[statementHash].at == 0, "reveal live");
        bytes32 want = sha256(abi.encodePacked(solution, msg.sender, nonce));
        Commit[] storage cs = commits[statementHash];
        for (uint256 i = 0; i < cs.length; i++) {
            if (cs[i].claimant == msg.sender && cs[i].commitHash == want) {
                reveals[statementHash] = Reveal(i, sha256(solution), receiptRef, uint64(block.timestamp), false, 0, 0, false);
                emit ClaimRevealed(statementHash, i, sha256(solution));
                return;
            }
        }
        revert("no matching commit");
    }

    // -- challenge / attest / settle -------------------------------------

    function dispute(bytes32 statementHash) external {
        Reveal storage r = reveals[statementHash];
        require(r.at != 0 && !r.settled, "no live reveal");
        require(block.timestamp < r.at + statements[statementHash].challengeWindow, "window closed");
        r.disputed = true;
        emit Disputed(statementHash, msg.sender);
    }

    function attest(bytes32 statementHash, bool accept) external {
        Statement storage s = statements[statementHash];
        Reveal storage r = reveals[statementHash];
        require(r.disputed && !r.settled, "no dispute");
        bool isAttestor;
        for (uint256 i = 0; i < s.attestors.length; i++) {
            if (s.attestors[i] == msg.sender) { isAttestor = true; break; }
        }
        require(isAttestor && !attested[statementHash][msg.sender], "not eligible");
        attested[statementHash][msg.sender] = true;
        if (accept) r.attestationsFor++; else r.attestationsAgainst++;
        emit Attested(statementHash, msg.sender, accept);
        if (r.attestationsAgainst >= s.quorumM) {
            // Claim refuted: clear the reveal; commits remain; next valid
            // claimant may reveal.
            delete reveals[statementHash];
        }
    }

    function settle(bytes32 statementHash) external {
        Statement storage s = statements[statementHash];
        Reveal storage r = reveals[statementHash];
        require(r.at != 0 && !r.settled, "nothing to settle");
        bool windowPassed = block.timestamp >= r.at + s.challengeWindow;
        bool quorumOk = r.disputed && r.attestationsFor >= s.quorumM;
        require((!r.disputed && windowPassed) || quorumOk, "not settleable");
        r.settled = true;
        address claimant = commits[statementHash][r.commitIndex].claimant;
        uint256 total;
        Bounty[] storage bs = bounties[statementHash];
        for (uint256 i = 0; i < bs.length; i++) {
            if (!bs[i].refunded) { total += bs[i].amount; bs[i].refunded = true; }
        }
        if (r.receiptRef != bytes32(0)) {
            emit Settled(statementHash, claimant, total, r.receiptRef);
        } else {
            emit Released(statementHash, claimant, total, "no verification receipt referenced");
        }
        (bool ok, ) = claimant.call{value: total}("");
        require(ok, "xfer");
    }
}
