#!/usr/bin/env python3
"""
QED reference verifier — verifier_class: lean4_kernel
=====================================================

Deterministic, re-runnable verification of a Lean 4 proof submission
against a SealedStatement. Anyone can run this; identical inputs in the
pinned environment MUST yield identical receipts. That property is what
makes optimistic settlement honest.

ACCEPTANCE CRITERION (all must hold):
  1. The submission builds against the sealed statement inside the pinned
     container (statement.toolchain.container_digest), with no network,
     read-only toolchain, and the sealed resource limits.
  2. Every theorem named in statement.target_theorems is proved, and
     `#print axioms` output is PRESENT for each. Absence of the axiom
     record is malformed, never an empty set (v0.1 accepted absence).
  3. Axiom records are a subset of statement.axiom_whitelist. `sorryAx`
     is never permitted.
  4. Imports in the submission are a subset of statement.import_manifest.
  4. Resource limits are respected; exceeding them fails closed
     (result: resource_exceeded).

USAGE:
  verify_lean.py --statement sealed_statement.json \
                 --submission proof.lean \
                 --key verifier_key.hex \
                 [--out receipt.json]

REQUIREMENTS: docker (or podman aliased to docker). The container image
must already be present or pullable BY DIGEST ONLY — never by tag; tags
move, digests don't. A receipt produced outside the pinned digest is
void on its face.

PROTOCOL VERSION 0.2. This is reference code: readable over clever.

KNOWN GAPS — see CLAIM_TABLE.md. This script closes some v0.1 findings
(import manifest, target binding, complete-axiom-record, cpu limit) and
does NOT close others (receipt signing, seccomp/least-privilege isolation).
Every remaining gap has a corpus case in conformance/adversarial_corpus.json.
Do not treat a receipt from this script as authoritative.

CANONICALIZATION: this file implements a JCS SUBSET sufficient for the
integer-valued artifacts it handles. It is a KNOWN divergence from RFC 8785
on number formatting (see conformance/identity_vectors.json, small_decimal).
Closing that is ASK-001.
"""

import argparse, hashlib, json, re, subprocess, sys, tempfile, time
from pathlib import Path

FORBIDDEN_ALWAYS = {"sorryAx"}


def canonical(obj) -> str:
    """Canonical JSON: UTF-8, sorted keys, no insignificant whitespace."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def artifact_id(prefix: str, body: dict) -> str:
    return f"qed:{prefix}:{sha256_hex(canonical(body).encode())}"


IMPORT_RE = re.compile(r"^\s*import\s+([\w.]+)", re.M)


def check_imports(submission_text: str, manifest) -> tuple:
    """QED-VERIFY-002. v0.1 documented this and never checked it."""
    if manifest is None:
        return False, "statement declares no import_manifest; cannot verify (L1 completeness)"
    used = set(IMPORT_RE.findall(submission_text))
    allowed = set(manifest)
    extra = used - allowed
    if extra:
        return False, f"imports outside manifest: {sorted(extra)}"
    return True, ""


def parse_axiom_records(log: str) -> dict:
    """Return {theorem: [axioms]}. Absence is absence, not emptiness."""
    out = {}
    for line in log.splitlines():
        if "depends on axioms:" in line:
            head, tail = line.split("depends on axioms:", 1)
            name = head.strip().strip("'\"")
            axs = [a.strip() for a in tail.strip().strip("[]").split(",") if a.strip()]
            out[name] = axs
    return out


def run_in_container(statement: dict, submission_path: Path, workdir: Path):
    """Build the submission against the sealed statement in the pinned
    container. Returns (result_str, axiom_record, usage, log)."""
    tc = statement["toolchain"]
    limits = statement["resource_limits"]
    digest = tc["container_digest"]

    # Assemble the project: sealed statement source + submission.
    # The statement's formal_src declares the target theorem(s); the
    # submission must prove them. The driver emits `#print axioms` for
    # every target into a machine-readable marker line.
    (workdir / "Statement.lean").write_text(statement["formal_src"], encoding="utf-8")
    (workdir / "Submission.lean").write_text(submission_path.read_text(encoding="utf-8"), encoding="utf-8")
    (workdir / "check.sh").write_text(
        "#!/bin/sh\nset -e\ncd /work\nlake env lean Statement.lean Submission.lean\n",
        encoding="utf-8",
    )

    cmd = [
        "docker", "run", "--rm",
        "--network", "none",                       # no network, ever
        "--read-only",                             # toolchain immutable
        "--tmpfs", "/tmp:rw,size=512m",
        "-v", f"{workdir}:/work:rw",
        "--memory", f"{limits['memory_mb']}m",
        "--memory-swap", f"{limits['memory_mb']}m",   # no swap escape hatch
        "--cpus", "1",
        "--ulimit", f"cpu={limits['cpu_seconds']}",   # QED-VERIFY-005
        "--security-opt", "no-new-privileges",
        "--cap-drop", "ALL",
        "--pids-limit", "256",
        digest,
        "sh", "/work/check.sh",
    ]

    t0 = time.monotonic()
    try:
        proc = subprocess.run(
            cmd, capture_output=True, text=True, timeout=limits["wall_seconds"]
        )
    except subprocess.TimeoutExpired as e:
        return "resource_exceeded", [], {"wall_seconds": time.monotonic() - t0}, (e.stdout or "") + (e.stderr or "")
    wall = time.monotonic() - t0
    log = proc.stdout + proc.stderr

    if proc.returncode != 0:
        return "rejected", [], {"wall_seconds": wall}, log

    return "accepted", parse_axiom_records(log), {"wall_seconds": wall}, log


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--statement", required=True)
    ap.add_argument("--submission", required=True)
    ap.add_argument("--key", required=True, help="verifier public key hex (signing left to your key tooling; see note)")
    ap.add_argument("--commit-ref", dest="commit_ref", default=None,
                    help="qed:claim: id of the ClaimCommit this submission opens (QED-VERIFY-006)")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    statement = json.loads(Path(args.statement).read_text(encoding="utf-8"))
    submission_path = Path(args.submission)

    # 0. Integrity: recompute the statement id from its sealed body.
    body = {k: v for k, v in statement.items() if k not in ("id",)}
    expected = artifact_id("stmt", body)
    if statement.get("id") != expected:
        print(f"VOID: statement id mismatch\n  declared {statement.get('id')}\n  computed {expected}", file=sys.stderr)
        return 2

    with tempfile.TemporaryDirectory() as td:
        result, axiom_record, usage, log = run_in_container(statement, submission_path, Path(td))

    reason = ""
    all_axioms = []
    if result == "accepted":
        submission_text = submission_path.read_text(encoding="utf-8")

        # QED-VERIFY-002: imports within manifest.
        ok, why = check_imports(submission_text, statement.get("import_manifest"))
        if not ok:
            result, reason = "rejected", why

        # QED-VERIFY-003: targets explicitly bound, axiom record PRESENT.
        targets = statement.get("target_theorems") or []
        if result == "accepted":
            if not targets:
                result, reason = "malformed", "statement declares no target_theorems (L1 completeness)"
            else:
                missing = [t for t in targets if t not in axiom_record]
                if missing:
                    result, reason = "malformed", f"no axiom record emitted for targets: {missing} (absence is not an empty set)"

        # QED-VERIFY-001: whitelist subset, sorryAx never.
        if result == "accepted":
            whitelist = set(statement.get("axiom_whitelist", []))
            for t in targets:
                rec = set(axiom_record[t])
                all_axioms.extend(axiom_record[t])
                if rec & FORBIDDEN_ALWAYS:
                    result, reason = "rejected", f"{t} depends on forbidden axiom(s): {sorted(rec & FORBIDDEN_ALWAYS)}"
                    break
                if not rec <= whitelist:
                    result, reason = "rejected", f"{t} depends on axioms outside whitelist: {sorted(rec - whitelist)}"
                    break

    receipt_body = {
        "statement_id": statement["id"],
        # QED-VERIFY-006: must reference the ClaimCommit artifact id, not a
        # raw submission hash. Supplied by the caller; absent in bare runs.
        "commit_ref": args.commit_ref or ("qed:claim:UNBOUND-" + sha256_hex(submission_path.read_bytes())[:16]),
        "verifier_class": "lean4_kernel",
        "toolchain": statement["toolchain"],
        "target_theorems": statement.get("target_theorems", []),
        "result": result,
        "reason": reason,
        "axiom_record": sorted(set(all_axioms)),
        "axiom_record_by_target": axiom_record,
        "resource_usage": usage,
        "verifier": {"key": args.key, "sig": "UNSIGNED-REFERENCE-RUN"},
    }
    receipt = {"id": artifact_id("receipt", receipt_body), **receipt_body}
    out = json.dumps(receipt, indent=2)
    if args.out:
        Path(args.out).write_text(out + "\n", encoding="utf-8")
    print(out)
    print(f"\n== {result.upper()} ==", file=sys.stderr)
    # QED-VERIFY-004 REMAINS OPEN: this receipt is UNSIGNED. An unsigned
    # receipt is malformed under the corpus (federation/unsigned_receipt)
    # and carries no weight. Production nodes must sign receipt_body's
    # canonical form with an ed25519 verifier key. Signing is left to
    # external key tooling so this script keeps zero dependencies -- that
    # is a convenience, not a design justification, and it is why no
    # receipt from this script is authoritative.
    return 0 if result == "accepted" else 1


if __name__ == "__main__":
    sys.exit(main())
