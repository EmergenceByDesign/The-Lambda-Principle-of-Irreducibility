# QED: A Federated Proof-Bounty Protocol

**Protocol version 0.2 · Status: draft (pre-publication) · Supersedes: v0.1**
**CRYPTOCACHE // QED**

---

## Reading this document

QED is an index and a set of shared abstractions, not an assurance
provider. It verifies **representation** — that artifacts are what they
claim to be, that references resolve, that parameters are declared, that
signatures attribute. It does not verify that any particular choice is
wise, safe, or worth funding. Those are judgments, and they belong to
publishers, reviewers, and users.

Every normative claim in this document carries an id and resolves through
`CLAIM_TABLE.md`. A claim with neither executable evidence nor an explicit
`declared-direction` tag is a defect in this document. Sections describing
the architectural horizon are marked as such and are not claims about what
the software does.

---

## Abstract

QED is a protocol for funding the solution of machine-verifiable problems.
Any party may seal a problem statement whose correctness criterion is
decidable by a specified verifier; any party may escrow value against that
statement's hash as a bounty. Bounties aggregate: many independent funders
may attach to one statement, and one accepted solution sweeps every bounty
attached to it. Settlement is mechanical — a solution wins if and only if a
deterministic, re-runnable verifier accepts it under conditions sealed into
the statement. There is no jury, no oracle of opinion, and no administrator
with discretionary control over outcomes.

QED does not certify anything. It makes independently authored options
legible, comparable, attributable, and difficult to misrepresent. Users
assess them; communities debate them in public, signed artifacts;
publishers stand behind only their own work. The seed instance is one
publisher among the eventual many, and its own profile is a contribution,
not a recommendation.

## 1. Motivation

When a problem can be precisely stated, the value of its solution is a
prediction about the compute and effort needed to reach it. Today that
spend is managed retail: an operator meters tokens, babysits agents, and
absorbs the full risk of the search alone. QED makes the same spend a
collective instrument. A party who needs a proof escrows what it is worth
to them and lets the escrow ride until someone — possibly themselves —
produces an accepted solution. Because bounties aggregate per statement,
hard problems accumulate subscribers, and one accepted proof pays from many
escrows at once. The poster may hedge natively by funding and also racing.

This is distinct from proving networks, which sell computation of
statements already known to be provable, and from prediction markets, which
need an oracle to declare outcomes. Here the outcome *is* the artifact, and
the artifact certifies itself against a check anyone can re-run.

## 2. Design principles

1. **Protocol, not platform.** A specification plus open reference code.
   No privileged operator. Any conforming implementation is a QED node.
2. **Deterministic settlement.** Every statement carries a sealed,
   re-runnable check. Trust no receipt you cannot re-derive.
3. **Representation, not endorsement.** QED verifies that a profile is the
   profile it claims to be. QED does not verify that adopting it is wise.
4. **Declared, not neutral.** There is no neutral presentation — ordering,
   defaults, and placement are editorial. Instances declare their rules,
   make them inspectable, and log changes, rather than claiming a
   neutrality no index can have.
5. **Transactional disclosure.** The protocol enforces no publication
   policy. Parties to a settlement hold the solution first because they are
   parties to it.
6. **Currency and chain agnostic.** Escrow is an interface; chains are
   adapters.
7. **Keys, not kinds.** The protocol never distinguishes humans from
   agents. A keypair with a record is a keypair with a record.

## 3. Channels

Statements live in exactly one of two channels, sealed into the statement
hash and therefore unforgeable after publication.

- **PROFILED** — the statement references a published profile by hash and
  inherits its parameters. It cannot restate them.
- **INLINE** — the statement declares its full parameter set itself.

Neither channel is privileged. PROFILED is not "approved"; INLINE is not
"unsafe." They are two structures with different evidence available, offered
side by side. `CHANNELS_AND_PROFILES.md` specifies both.

**Bounties do not aggregate across channels**, and since a statement lives
in one channel, a funder never lands in a parameter set they did not see
before committing value. This is the mechanical property that makes free
parameters safe to offer rather than a trap.

## 4. Artifacts

All artifacts are canonical JSON under **RFC 8785 (JCS)**; identifiers are
`qed:<type>:` prefixed to the SHA-256 of the canonical form. Signatures are
**ed25519** over the canonical body. Determinism here is not a preference:
if two nodes disagree on encoding, they assign different ids to the same
object and the federation splits silently. `[QED-ID-001]`

Formal schemas ship in `/schemas`.

### 4.1 SealedStatement

Fields: `channel`, `profile` (PROFILED) or the full parameter set (INLINE),
`title`, `informal`, `verifier_class`, `formal_src`, `toolchain` digests,
`axiom_whitelist` and `import_manifest` where applicable, `resource_limits`,
`deadline`, `namespace`, optional `supersedes`.

A statement is sealed at publication; its id commits to every
settlement-affecting field. Nothing may change. Errors are corrected only by
supersession under a new hash, which deliberately breaks bounty aggregation.
`[QED-SEAL-001]`

### 4.2 Bounty

An escrow reference bound to a statement id: adapter, instrument, amount,
currency, disclosure flag, funder signature. The set of live bounties on a
statement is its prize. `[QED-AGG-001]`

### 4.3 Claim — commit then reveal

`ClaimCommit` posts SHA-256(solution ‖ claimant_key ‖ nonce). `ClaimReveal`
opens it. Priority attaches to the first valid commit **as ordered by the
settlement chain of the escrow in question** — not globally across the
federation. Content hashes prove integrity, not chronology; relays cannot
establish global order without a consensus mechanism, and QED does not
claim one. `[QED-ORDER-001, scoped]`

### 4.4 VerificationReceipt

Statement id, commit reference, verifier class, toolchain digests, result,
axiom record, resource usage, verifier signature. Receipts are portable and
travel away from the solutions they describe, which is exactly why the word
`accepted` is vocabulary-constrained (§7). `[QED-VERIFY-004]`

### 4.5 Profile

A content-addressed artifact declaring a complete parameter set plus its
conformance suite reference and publisher identity. Statements reference it
by hash. A profile makes no safety claim; it makes a *completeness* claim,
which is checkable. `[QED-PROF-001]`

### 4.6 Evidence artifacts

Attestations, reviews, objections, counterexamples, and adoption records
are signed, indexed artifacts that attach to a profile or implementation.
QED preserves their identity and relationships; it does not collapse them
into a verdict (§6).

### 4.7 Ask, Badge, BranchLineage — non-normative

Asks are branch-scoped statements of need carrying no escrow. Badges are
signed attestations of an answered Ask. BranchLineage declares fork
ancestry. **These are practice, not protocol claims.** v0.2 makes no
normative claim about badge weight, sybil resistance, or portable standing;
ranking is a view policy each client sets and declares, in the way that spam
filtering is not part of SMTP. `[QED-STAND-001, non-normative]`

## 5. Federation

Signed events over dumb relays: relays store and forward, clients verify
everything. Event types: `StatementSealed`, `ProfilePublished`,
`BountyPosted`, `BountyRefunded`, `ClaimCommit`, `ClaimReveal`,
`VerificationReceipt`, `Settlement`, `Release`, `AttestationPublished`,
`ObjectionPublished`, `AskPosted`, `BadgeAwarded`, `BranchDeclared`.

Relays impose no order beyond their own receipt timestamps. Where ordering
is consequential, the settlement chain is authoritative. Volume management
— flooding, spam, ranking — is a client concern, not a protocol one.

## 6. The evidence graph

A profile is a node with signed edges:

```
Profile
├── publisher signature
├── conformance claims (suite id → declared results)
├── test-suite results
├── reviews and audits
├── objections and counterexamples
├── successor profiles
└── adoption records
```

QED records these relationships and preserves attribution. It does not
average them, score them, or resolve them. **"Conforming" means exactly one
thing: this implementation produced the declared results for this identified
test suite.** It does not mean secure, audited, suitable, or endorsed.
`[QED-CONF-001]`

An objection is a first-class artifact for the same reason a receipt is:
criticism that stays attached to what it criticizes, carries a signature,
and can be reproduced is worth more than criticism that evaporates into a
thread.

## 7. Vocabulary discipline

Some names are load-bearing for readers who cannot see what produced them.
The rule: **a name is constrained when a reader can act on it without being
able to inspect its provenance.** Portable and consequential is constrained;
local and inspectable is free.

Constrained in v0.2:

| Name | Constraint |
|---|---|
| `Settlement` | Requires a referenced VerificationReceipt. Releases without one emit `Release`, reason recorded. |
| `VerificationReceipt` with `result: accepted` | Requires that a verifier actually ran under the sealed toolchain. |
| `conforming` | Means only: declared results reproduced for an identified suite. |
| `sealed` | Requires that every settlement-affecting parameter is in the hash. |
| a `profile` reference | Requires the statement's parameters to match the referenced profile. |
| `Badge` | Self-issued badges without an underlying receipt must be marked self-attested. |

**Scope, stated honestly.** This is a conformance property, not a protocol
guarantee. Nothing prevents a hostile node from emitting a misnamed event,
just as nothing in SMTP prevents a forged sender. What QED provides is
attribution — every artifact is signed, so a false receipt has a key
attached — and cheap falsification, since verification is deterministic and
anyone may publish a conflicting receipt. Conformance vectors test for
naming discipline, so an implementation claiming conformance while
misnaming events is mechanically caught. `[QED-NAME-001]`

## 8. Verifier classes

**`lean4_kernel`** — accepted iff the pinned Lean 4 kernel accepts a proof
of the explicitly bound target theorem, with no `sorry`, a complete axiom
record within the whitelist, imports within the manifest, inside the sealed
container, within resource limits. Each of those conditions is an
adversarial corpus case (§9). `[QED-VERIFY-001..003]`

**`test_harness`** — a sealed manifest fixing interface, contract, vectors,
and runner image. **Not offered as a public verifier class in v1.0**;
retained as tooling for conformance and corpus execution, because arbitrary
user-submitted code executed by infrastructure is a sandbox-escape surface
that deserves its own hardening cycle. `[QED-HARNESS-001, declared-direction]`

Future classes register the same way. A statement's class is sealed with it.

## 9. The adversarial corpus

The corpus is a first-class, append-only protocol artifact: a set of hostile
inputs each paired with a required verdict. An implementation is conforming
against the corpus only if it reproduces every required verdict exactly.

The corpus opens with every failure identified in review of v0.1: missing
axiom output, import-manifest violation, unbound target theorem, `sorryAx`,
malformed container digest, cross-language canonicalization divergence,
signature substitution, replayed claims and receipts, zero quorum,
duplicate attestors, repeated reveal after rejection, refund during active
settlement, and collection exhaustion.

Because the corpus is federation-wide and grows monotonically, a discovery
made once immunizes every implementation and every fork against that class
permanently. This is the mechanism by which criticism becomes capital, and
it is the intended home of the standing red-team invitation.

Append-only has one stated limit: material that is illegal, malware-bearing,
or targeted at a person may be removed. Removals are themselves logged
artifacts recording what was removed and why, which is more auditable than a
promise never to remove anything — a promise that breaks the first time it
is tested.

## 10. Escrow interface

Adapters implement four verbs against a statement id: `fund`, `refund`,
`commit`/`reveal` anchoring, and `settle`. The interface is normative; the
reference EVM contract is not — it is unaudited, testnet-grade, and known to
contain the settlement defects catalogued in the claim table.
`[QED-SETTLE-001..003]`

**Cross-chain aggregation is not implemented and not claimed.** A common
interface cannot make a sweep atomic across unrelated chains; that requires
a canonical settlement authority QED does not have. `[QED-XCHAIN-001,
declared-direction]`

**Private settlement is not implemented and not claimed.** The v0.1 paper
described a sealed-delivery mechanism with no specified encryption, key
exchange, fair-delivery, or payment-binding protocol; on an EVM adapter the
solution is calldata and therefore public regardless of intent. Bounties may
still carry a disclosure flag as a statement of the funder's expectation, and
the flag is honoured socially, not cryptographically. `[QED-PRIV-001,
declared-direction]`

## 11. The SELF namespace

Every instance publishes standing meta-statements about the protocol under
the reserved `SELF` namespace. SELF carries Asks, never bounties. Genesis
Asks ship with this release, including the identity gate: *produce a
conforming canonicalization, artifact-id, and signature library in a
language other than Python that reproduces every conformance vector
byte-for-byte.* Cross-implementation agreement cannot be self-certified by a
single author, which makes it the natural first collective task.

Because Asks are free to attempt and settle deterministically, they double
as a zero-spend proving ground for agents: train on Asks, accumulate a
public record, and be graduated to a budget by whoever chooses to trust that
record. Graduation is an act of trust between parties, never a protocol
permission.

## 12. Risk

QED holds no discretionary control over settlement: it cannot reverse a
verification, seize an escrow, favour a claimant, or settle by fiat. That is
a checkable property, unlike neutrality. Everything else about risk —
including the asymmetry between funders, whose downside is bounded and
refundable, and solvers, whose revelation is irreversible — is stated in
`RISK.md`, which is required reading before any value moves.

□ → ∎
